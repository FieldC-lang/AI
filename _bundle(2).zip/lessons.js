// Each unit has lessons; each lesson is a list of steps.
// step types: learn {title, text, code?}, mc {q, options, answer, why}, tf {q, answer, why},
// fill {q, code (with ___), options, answer, why}, order {q, lines (correct order), why}
window.UNITS = [
{
 title: "The Big Picture", color: "#58cc02", lessons: [
 { title: "What is BitNet?", steps: [
  {type:"learn", title:"A brain made of numbers", text:"A language model (LLM) is a giant pile of numbers called <b>weights</b>. To answer you, the computer multiplies your words (turned into numbers) by these weights, over and over, to guess the next word."},
  {type:"learn", title:"BitNet's big trick", text:"Normal models store each weight as a 16-bit decimal number like <code>0.0371</code>. BitNet b1.58 stores each weight as only <b>-1, 0 or +1</b>. That's called <b>ternary</b>. It makes the model about 10x smaller and much faster on a normal CPU."},
  {type:"mc", q:"In BitNet b1.58, what values can a weight have?", options:["Any decimal number","Only 0 or 1","Only -1, 0 or +1","Only whole numbers 0 to 255"], answer:2, why:"Three possible values: -1, 0, +1. That's what 'ternary' means."},
  {type:"learn", title:"Why '1.58 bits'?", text:"With 3 choices, each weight holds log₂(3) ≈ <b>1.58 bits</b> of information. A normal bit has 2 choices (0/1); a ternary 'trit' has 3."},
  {type:"tf", q:"BitNet is called '1.58-bit' because log₂(3) ≈ 1.58.", answer:true, why:"Exactly. 3 choices = 1.58 bits of information."},
  {type:"mc", q:"Why does having weights of only -1, 0, +1 make things fast?", options:["Multiplying by -1/0/+1 is just subtract / skip / add","The CPU runs at a higher clock","It uses the GPU automatically","It removes the need for memory"], answer:0, why:"x·(+1)=x, x·(-1)=-x, x·0=0. No real multiplication needed — just adds and subtracts."}
 ]},
 { title: "The road map", steps: [
  {type:"learn", title:"What we'll build", text:"Our C program (an <b>inference engine</b>) will: <br>1. Load the model file<br>2. Turn text into token numbers<br>3. Run the numbers through layers of the network<br>4. Pick the next token<br>5. Repeat until done"},
  {type:"order", q:"Put the engine's steps in order:", lines:["Load model weights from file","Turn text into tokens","Run tokens through the layers","Pick the next token","Repeat to generate more text"], why:"Load → tokenize → forward pass → sample → loop."},
  {type:"learn", title:"Inference vs training", text:"<b>Training</b> = creating the weights (needs huge GPUs, done by Microsoft). <b>Inference</b> = using the finished weights to generate text. bitnet.cpp, and our program, only do <b>inference</b>."},
  {type:"tf", q:"Our C program will train the BitNet model.", answer:false, why:"We only do inference — use the already-trained weights."},
  {type:"mc", q:"What is a 'token'?", options:["A password","A small chunk of text (word or piece of a word) given an ID number","A type of CPU","A weight value"], answer:1, why:"E.g. 'hello' might be token 15339. The model only sees numbers."}
 ]}
]},
{
 title: "C Survival Kit", color: "#1cb0f6", lessons: [
 { title: "Number types", steps: [
  {type:"learn", title:"Picking the right box", text:"C makes you choose the size of every number:<br><code>float</code> – 32-bit decimal (activations, scales)<br><code>int8_t</code> – whole number -128..127 (quantized activations)<br><code>uint8_t</code> – 0..255 (packed weights)<br><code>int32_t</code> – big whole number (sums)", code:"#include <stdint.h>\nfloat   scale = 0.42f;\nint8_t  act   = -57;\nuint8_t packed = 0b10010100;\nint32_t sum   = 0;"},
  {type:"mc", q:"Which type should hold a quantized activation between -127 and 127?", options:["float","int8_t","uint8_t","double"], answer:1, why:"int8_t holds -128..127 in just 1 byte."},
  {type:"fill", q:"We need a header to use int8_t. Fill it in:", code:"#include <___>", options:["stdio.h","stdint.h","math.h","string.h"], answer:1, why:"stdint.h defines exact-size integers like int8_t and uint8_t."},
  {type:"mc", q:"Why add up int8 products into an int32_t, not an int8_t?", options:["int32 is faster to print","The sum gets too big for int8 and would overflow","int8 can't be negative","It's required by the compiler"], answer:1, why:"Thousands of products like 127×1 add up way past 127. int32 has room."}
 ]},
 { title: "Arrays & memory", steps: [
  {type:"learn", title:"malloc: asking for memory", text:"A model needs millions of numbers. We ask the operating system for a block of memory with <code>malloc</code> and give it back with <code>free</code>.", code:"float *x = malloc(dim * sizeof(float));\n// use x[0] .. x[dim-1]\nfree(x);"},
  {type:"fill", q:"Ask for room for n floats:", code:"float *buf = malloc(n * ___);", options:["n","sizeof(float)","4.0","float"], answer:1, why:"malloc counts bytes, so multiply the count by the size of one float."},
  {type:"learn", title:"Matrices are flat arrays", text:"A weight matrix with <code>rows</code> × <code>cols</code> is stored as one long line of numbers. Element (i, j) lives at <code>W[i*cols + j]</code>.", code:"float get(float *W, int cols, int i, int j) {\n    return W[i * cols + j];\n}"},
  {type:"mc", q:"Matrix with 4 columns. Where is row 2, column 3 (0-based)?", options:["W[5]","W[11]","W[9]","W[23]"], answer:1, why:"2*4 + 3 = 11."},
  {type:"tf", q:"Forgetting to call free() on memory you no longer need causes a memory leak.", answer:true, why:"The memory stays reserved until the program ends."}
 ]},
 { title: "Structs", steps: [
  {type:"learn", title:"Grouping things together", text:"A <code>struct</code> bundles related variables. We'll describe the model's shape with one.", code:"typedef struct {\n    int dim;        // size of each token vector\n    int hidden_dim; // size inside the feed-forward\n    int n_layers;   // how many layers\n    int n_heads;    // attention heads\n    int n_kv_heads; // key/value heads\n    int vocab_size; // number of tokens\n    int seq_len;    // max context length\n} Config;"},
  {type:"mc", q:"What does n_layers describe?", options:["How many tokens the vocab has","How many times the block of attention + feed-forward is stacked","Number of CPU threads","Length of the prompt"], answer:1, why:"BitNet b1.58 2B has 30 stacked transformer layers."},
  {type:"fill", q:"Read a field from a struct pointer:", code:"Config *c = load();\nint d = c___dim;", options:[".","->","::","*"], answer:1, why:"Use -> with a pointer, . with a plain struct."}
 ]}
]},
{
 title: "Ternary Weights", color: "#ce82ff", lessons: [
 { title: "Absmean quantization", steps: [
  {type:"learn", title:"Squashing weights to -1, 0, +1", text:"During training, BitNet turns real weights into ternary using <b>absmean</b>:<br>1. Find the average size: γ = mean(|W|)<br>2. Divide each weight by γ<br>3. Round, then clip to [-1, 1]<br>γ is kept as a <b>scale</b> so we can undo the shrink later.", code:"float gamma = 0;\nfor (int i = 0; i < n; i++) gamma += fabsf(w[i]);\ngamma = gamma / n + 1e-5f;\nfor (int i = 0; i < n; i++) {\n    float v = roundf(w[i] / gamma);\n    q[i] = v > 1 ? 1 : (v < -1 ? -1 : v);\n}"},
  {type:"mc", q:"γ = 0.5. A weight is 0.9. What ternary value does it become?", options:["-1","0","+1","0.9"], answer:2, why:"0.9 / 0.5 = 1.8 → round = 2 → clip to +1."},
  {type:"mc", q:"γ = 0.5. A weight is 0.2. What does it become?", options:["-1","0","+1","2"], answer:1, why:"0.2/0.5 = 0.4 → rounds to 0. Small weights get switched off."},
  {type:"tf", q:"Why add 1e-5 to gamma? To avoid dividing by zero if all weights are 0.", answer:true, why:"A tiny 'epsilon' keeps us safe from division by zero."},
  {type:"mc", q:"What's the purpose of keeping γ (the scale)?", options:["To make the file bigger","To multiply results back to the right size later","It's the learning rate","It counts the zeros"], answer:1, why:"Ternary values lost the size info. Multiplying by γ at the end restores it."}
 ]},
 { title: "Packing 4 per byte", steps: [
  {type:"learn", title:"2 bits per weight", text:"A ternary value needs only 2 bits. We store it as code = value + 1, so -1→0, 0→1, +1→2. Four codes fit in one byte (8 bits). This is similar to bitnet.cpp's <b>I2_S</b> format.", code:"uint8_t pack4(int8_t a, int8_t b, int8_t c, int8_t d) {\n    return (uint8_t)(((a+1) << 6) | ((b+1) << 4)\n                   | ((c+1) << 2) |  (d+1));\n}"},
  {type:"mc", q:"With code = value + 1, which code does weight -1 get?", options:["0","1","2","3"], answer:0, why:"-1 + 1 = 0. So codes are always 0, 1 or 2 (never negative)."},
  {type:"fill", q:"Unpack weight number k (0..3, from the top) out of byte b:", code:"int8_t w = ((b >> (6 - 2*k)) & ___) - 1;", options:["0x1","0x3","0xF","0xFF"], answer:1, why:"0x3 = binary 11 keeps exactly 2 bits."},
  {type:"mc", q:"A 2-billion-weight model at 2 bits/weight is roughly how big?", options:["~4 GB","~500 MB","~50 MB","~16 GB"], answer:1, why:"2e9 × 2 bits = 4e9 bits = 500 MB. In 16-bit it would be ~4 GB."},
  {type:"tf", q:"The << operator shifts bits left, moving each code into its own slot in the byte.", answer:true, why:"Shifting by 6, 4, 2, 0 places the four codes side by side."}
 ]}
]},
{
 title: "8-bit Activations", color: "#ff9600", lessons: [
 { title: "Absmax quantization", steps: [
  {type:"learn", title:"Shrinking the inputs too", text:"<b>Activations</b> are the numbers flowing between layers. BitNet turns them into int8 using <b>absmax</b>: find the biggest |x|, and scale so it becomes 127.", code:"float amax = 1e-5f;\nfor (int i = 0; i < n; i++)\n    amax = fmaxf(amax, fabsf(x[i]));\nfloat s = 127.0f / amax;\nfor (int i = 0; i < n; i++) {\n    float v = roundf(x[i] * s);\n    xq[i] = (int8_t)fminf(127, fmaxf(-128, v));\n}"},
  {type:"mc", q:"x = [2.0, -4.0, 1.0]. What is amax?", options:["1.0","2.0","4.0","-4.0"], answer:2, why:"Biggest absolute value: |-4.0| = 4.0."},
  {type:"mc", q:"With amax = 4.0, what int8 does -4.0 become?", options:["-4","-127","-128","0"], answer:1, why:"s = 127/4 = 31.75; -4 × 31.75 = -127."},
  {type:"tf", q:"Weights are 1.58-bit but activations are 8-bit in BitNet b1.58 (often written W1.58A8).", answer:true, why:"Ternary weights × int8 activations."},
  {type:"mc", q:"Why use absmax (biggest value) for activations instead of mean?", options:["So no value goes past the int8 range","It's random","Mean is illegal in C","To make all values zero"], answer:0, why:"Scaling by the max guarantees everything fits in -127..127."}
 ]}
]},
{
 title: "BitLinear: Math Without Multiply", color: "#ff4b4b", lessons: [
 { title: "The ternary dot product", steps: [
  {type:"learn", title:"Heart of the engine", text:"A linear layer computes out[i] = Σ W[i][j] · x[j]. With ternary W, each term is just: add x, subtract x, or skip.", code:"int32_t dot_ternary(const int8_t *w, const int8_t *x, int n) {\n    int32_t sum = 0;\n    for (int j = 0; j < n; j++) {\n        if      (w[j] ==  1) sum += x[j];\n        else if (w[j] == -1) sum -= x[j];\n        // w == 0: do nothing\n    }\n    return sum;\n}"},
  {type:"mc", q:"w = [1, 0, -1, 1], x = [5, 9, 2, 3]. What is the sum?", options:["15","6","9","-1"], answer:1, why:"5 + 0 - 2 + 3 = 6."},
  {type:"fill", q:"Complete the case for weight -1:", code:"else if (w[j] == -1) sum ___ x[j];", options:["+=","-=","*=","="], answer:1, why:"Multiplying by -1 is the same as subtracting."},
  {type:"learn", title:"Getting back to real numbers", text:"The sum is an integer in 'shrunk' units. To restore the real value, undo both scalings: multiply by γ (weight scale) and divide by s (activation scale).", code:"float out = (float)sum * gamma / s;\n// gamma: weight scale, s = 127/amax"},
  {type:"mc", q:"Why multiply the integer sum by γ / s at the end?", options:["To undo the weight and activation shrinking","To round it","To make it negative","To convert to int8"], answer:0, why:"Both quantizations scaled the numbers; this reverses them."}
 ]},
 { title: "The full BitLinear", steps: [
  {type:"learn", title:"Putting it together", text:"One BitLinear layer = quantize input → ternary matmul on each output row → rescale.", code:"void bitlinear(float *out, const float *x,\n               const int8_t *W, float gamma,\n               int in, int outn, int8_t *xq) {\n    float s = quantize_act(x, xq, in); // absmax\n    for (int i = 0; i < outn; i++) {\n        int32_t acc = dot_ternary(W + i*in, xq, in);\n        out[i] = acc * gamma / s;\n    }\n}"},
  {type:"order", q:"Order the steps inside bitlinear():", lines:["Quantize the input to int8 (absmax)","For each output row, do the ternary dot product","Multiply the integer result by gamma / s"], why:"Quantize → add/subtract → rescale."},
  {type:"mc", q:"What does 'W + i*in' point to?", options:["The whole matrix","The start of row i of the weights","The gamma value","The output"], answer:1, why:"Each row has 'in' weights, so row i starts at offset i*in."},
  {type:"tf", q:"In the transformer, the attention projections (Q, K, V, O) and feed-forward layers are all BitLinear.", answer:true, why:"Those are the big matrices; they're all ternary. Embeddings stay higher precision."}
 ]}
]},
{
 title: "Building Blocks", color: "#2b70c9", lessons: [
 { title: "RMSNorm", steps: [
  {type:"learn", title:"Keeping numbers tame", text:"Before each sub-layer, we <b>normalize</b> the vector so numbers don't explode or vanish. RMSNorm divides by the root-mean-square, then multiplies by learned weights.", code:"void rmsnorm(float *o, const float *x, const float *w, int n) {\n    float ss = 0;\n    for (int i = 0; i < n; i++) ss += x[i]*x[i];\n    ss = 1.0f / sqrtf(ss / n + 1e-5f);\n    for (int i = 0; i < n; i++) o[i] = w[i] * x[i] * ss;\n}"},
  {type:"mc", q:"What is the purpose of RMSNorm?", options:["Pick the next token","Keep values at a steady scale between layers","Compress the file","Load weights"], answer:1, why:"It rescales the vector so it has an RMS of ~1."},
  {type:"fill", q:"RMS = sqrt of the mean of the ___:", code:"ss += x[i] ___ x[i];", options:["+","*","-","/"], answer:1, why:"Square each value: x[i]*x[i]."},
  {type:"tf", q:"BitNet adds extra 'SubLN' norms inside attention and the feed-forward to keep low-bit training stable.", answer:true, why:"Extra normalization before output projections helps the ternary model stay stable."}
 ]},
 { title: "Softmax", steps: [
  {type:"learn", title:"Scores into probabilities", text:"Softmax turns any list of scores into probabilities that add up to 1. We subtract the max first so exp() doesn't overflow.", code:"void softmax(float *x, int n) {\n    float max = x[0];\n    for (int i = 1; i < n; i++) if (x[i] > max) max = x[i];\n    float sum = 0;\n    for (int i = 0; i < n; i++) { x[i] = expf(x[i]-max); sum += x[i]; }\n    for (int i = 0; i < n; i++) x[i] /= sum;\n}"},
  {type:"mc", q:"After softmax, what do all values add up to?", options:["0","1","n","The max"], answer:1, why:"They are probabilities, so they total 1."},
  {type:"mc", q:"Why subtract the max before exp()?", options:["Makes it slower","Avoids overflow — exp(1000) is infinity","Required for negatives","To sort the list"], answer:1, why:"Subtracting max keeps exponents ≤ 0, so exp() stays ≤ 1. Same final answer."}
 ]},
 { title: "RoPE positions", steps: [
  {type:"learn", title:"Where is each word?", text:"Attention by itself doesn't know word order. <b>RoPE</b> (rotary position embedding) rotates pairs of numbers in the query and key by an angle depending on the position.", code:"for (int i = 0; i < head_dim; i += 2) {\n    float freq = 1.0f / powf(500000.0f, (float)i / head_dim);\n    float a = pos * freq;\n    float c = cosf(a), s = sinf(a);\n    float x0 = v[i], x1 = v[i+1];\n    v[i]   = x0*c - x1*s;\n    v[i+1] = x0*s + x1*c;\n}"},
  {type:"mc", q:"What problem does RoPE solve?", options:["Tells the model the position/order of tokens","Makes weights ternary","Loads the tokenizer","Speeds up memory"], answer:0, why:"Without positions, 'dog bites man' = 'man bites dog'."},
  {type:"tf", q:"RoPE is applied to queries and keys, not values.", answer:true, why:"Position matters for the matching (Q·K), so only Q and K are rotated."}
 ]}
]},
{
 title: "Attention", color: "#00cd9c", lessons: [
 { title: "Q, K, V", steps: [
  {type:"learn", title:"Looking back at earlier words", text:"For each token, we make three vectors with BitLinear:<br><b>Query</b> – 'what am I looking for?'<br><b>Key</b> – 'what do I contain?'<br><b>Value</b> – 'what I'll share if picked'.<br>Score = Q·K; softmax the scores; output = weighted sum of V."},
  {type:"mc", q:"Which vector answers 'what am I looking for?'", options:["Key","Value","Query","Output"], answer:2, why:"The Query is compared to everyone's Key."},
  {type:"learn", title:"The code", text:"For one head at position pos:", code:"for (int t = 0; t <= pos; t++) {\n    float *k = key_cache + t*kv_dim + kvh*head_dim;\n    float score = 0;\n    for (int i = 0; i < head_dim; i++) score += q[i]*k[i];\n    att[t] = score / sqrtf(head_dim);\n}\nsoftmax(att, pos + 1);\nmemset(out, 0, head_dim*sizeof(float));\nfor (int t = 0; t <= pos; t++) {\n    float *v = val_cache + t*kv_dim + kvh*head_dim;\n    for (int i = 0; i < head_dim; i++) out[i] += att[t]*v[i];\n}"},
  {type:"mc", q:"Why does the loop only go to t <= pos?", options:["A token can only look at itself and earlier tokens, not the future","To save electricity","pos is the vocab size","It's a bug"], answer:0, why:"This is 'causal' attention: no peeking at future words."},
  {type:"fill", q:"Scores are divided by the square root of:", code:"att[t] = score / sqrtf(___);", options:["pos","head_dim","vocab_size","n_layers"], answer:1, why:"Scaling by √head_dim keeps scores from getting too large."}
 ]},
 { title: "KV cache", steps: [
  {type:"learn", title:"Don't redo old work", text:"Each new token needs the keys and values of all earlier tokens. Instead of recomputing them, we save them in a <b>KV cache</b> per layer.", code:"float *kc = s->key_cache + l*seq_len*kv_dim + pos*kv_dim;\nfloat *vc = s->val_cache + l*seq_len*kv_dim + pos*kv_dim;\nmemcpy(kc, k, kv_dim*sizeof(float));\nmemcpy(vc, v, kv_dim*sizeof(float));"},
  {type:"tf", q:"Without a KV cache, generating each new token would re-process the entire prompt.", answer:true, why:"The cache trades memory for a huge speedup."},
  {type:"mc", q:"BitNet 2B uses fewer KV heads than query heads (grouped-query attention). Why?", options:["Smaller KV cache, less memory","More accuracy only","It's required by C","To use the GPU"], answer:0, why:"Several query heads share one K/V head, shrinking the cache."}
 ]}
]},
{
 title: "Feed-Forward & Layers", color: "#ffc800", lessons: [
 { title: "Squared ReLU FFN", steps: [
  {type:"learn", title:"Thinking per token", text:"After attention, each token goes through a feed-forward network (FFN). BitNet b1.58 2B uses a gated FFN with <b>squared ReLU</b>: relu(x)².", code:"bitlinear(gate, xb, W_gate, ...); // dim -> hidden\nbitlinear(up,   xb, W_up,   ...); // dim -> hidden\nfor (int i = 0; i < hidden; i++) {\n    float g = gate[i] > 0 ? gate[i] : 0;\n    hb[i] = g * g * up[i];          // relu² gating\n}\nbitlinear(xb, hb, W_down, ...);   // hidden -> dim"},
  {type:"mc", q:"What is relu(-3)²?", options:["9","-9","0","3"], answer:2, why:"relu(-3)=0, and 0²=0."},
  {type:"mc", q:"What is the purpose of the 'gate'?", options:["It decides how much of each 'up' value passes through","It loads files","It quantizes weights","It picks the token"], answer:0, why:"The activated gate multiplies 'up', letting the network turn features on/off."}
 ]},
 { title: "Residuals & one layer", steps: [
  {type:"learn", title:"Adding back the input", text:"Each sub-layer's output is <b>added</b> to its input (a residual connection). This lets information skip ahead and makes deep networks trainable.", code:"for (int l = 0; l < n_layers; l++) {\n    rmsnorm(xb, x, w->attn_norm[l], dim);\n    attention(xb2, xb, l, pos);\n    for (int i = 0; i < dim; i++) x[i] += xb2[i];\n\n    rmsnorm(xb, x, w->ffn_norm[l], dim);\n    ffn(xb2, xb, l);\n    for (int i = 0; i < dim; i++) x[i] += xb2[i];\n}"},
  {type:"order", q:"Order one transformer layer:", lines:["RMSNorm the input","Attention","Add result to x (residual)","RMSNorm again","Feed-forward","Add result to x (residual)"], why:"Norm → attention → add, then norm → FFN → add."},
  {type:"tf", q:"x[i] += xb2[i] is the residual connection.", answer:true, why:"It adds the sub-layer output onto the running vector x."},
  {type:"learn", title:"Getting logits", text:"After the last layer: one final RMSNorm, then multiply by the output embedding matrix to get a score (<b>logit</b>) for every token in the vocabulary.", code:"rmsnorm(x, x, w->final_norm, dim);\nmatmul_f32(logits, x, w->output, dim, vocab_size);"},
  {type:"mc", q:"How many logits do we get?", options:["One per layer","One per token in the vocabulary","Just one","One per head"], answer:1, why:"Each logit scores how likely that token is next."}
 ]}
]},
{
 title: "Files & Tokens", color: "#a560e8", lessons: [
 { title: "Loading GGUF", steps: [
  {type:"learn", title:"The model file", text:"bitnet.cpp is built on llama.cpp and stores models in <b>GGUF</b> files: a header, key/value metadata (dim, layers…), then tensor info and raw tensor data."},
  {type:"learn", title:"mmap: map, don't copy", text:"Instead of reading 500 MB into memory, we use <code>mmap</code> to make the file appear as memory. The OS loads pages only when touched.", code:"int fd = open(path, O_RDONLY);\nstruct stat st; fstat(fd, &st);\nvoid *data = mmap(NULL, st.st_size, PROT_READ,\n                  MAP_PRIVATE, fd, 0);\nuint32_t magic = *(uint32_t*)data; // 'GGUF'"},
  {type:"mc", q:"Why use mmap for big model files?", options:["Loads instantly and lets the OS load pages on demand","Encrypts the file","Compresses weights","It's the only way to open files"], answer:0, why:"No big copy; the OS handles it lazily and can share memory."},
  {type:"tf", q:"The first 4 bytes of a GGUF file are a 'magic' value that identifies the format.", answer:true, why:"Checking the magic catches wrong or corrupt files early."}
 ]},
 { title: "Tokenizer", steps: [
  {type:"learn", title:"Text ↔ numbers", text:"A <b>BPE tokenizer</b> starts with single bytes, then repeatedly merges the best-scoring neighbouring pair into a bigger token, until no merge is possible.", code:"while (1) {\n    float best = -1e10; int best_i = -1, best_id = -1;\n    for (int i = 0; i < n-1; i++) {\n        int id = lookup(pair(tok[i], tok[i+1]));\n        if (id != -1 && score[id] > best) {\n            best = score[id]; best_i = i; best_id = id;\n        }\n    }\n    if (best_i == -1) break;      // no more merges\n    tok[best_i] = best_id;\n    remove_at(tok, &n, best_i+1);\n}"},
  {type:"mc", q:"When does the merge loop stop?", options:["After 10 rounds","When no neighbouring pair is in the vocabulary","When the text is empty","Never"], answer:1, why:"best_i stays -1 → nothing left to merge → break."},
  {type:"tf", q:"Decoding (tokens → text) is simply looking up each token's string and joining them.", answer:true, why:"Decoding is easy; encoding is the tricky part."}
 ]}
]},
{
 title: "Generating Text", color: "#58cc02", lessons: [
 { title: "Sampling", steps: [
  {type:"learn", title:"Choosing the next token", text:"<b>Greedy</b>: always pick the highest logit (boring but safe). <b>Temperature sampling</b>: divide logits by T, softmax, then pick randomly by probability.", code:"int sample(float *logits, int n, float temp) {\n    if (temp == 0) return argmax(logits, n);\n    for (int i = 0; i < n; i++) logits[i] /= temp;\n    softmax(logits, n);\n    float r = (float)rand() / RAND_MAX, cdf = 0;\n    for (int i = 0; i < n; i++) {\n        cdf += logits[i];\n        if (r < cdf) return i;\n    }\n    return n - 1;\n}"},
  {type:"mc", q:"What does a low temperature (like 0.2) do?", options:["More random, creative output","More predictable, focused output","Crashes","Makes the model bigger"], answer:1, why:"Dividing by a small T sharpens the probabilities toward the top choice."},
  {type:"fill", q:"Temperature 0 means:", code:"if (temp == 0) return ___(logits, n);", options:["random","argmax","softmax","sum"], answer:1, why:"Greedy = take the index of the largest logit."}
 ]},
 { title: "The main loop", steps: [
  {type:"learn", title:"Bringing it home", text:"Feed prompt tokens one by one. Once the prompt is used up, feed back the model's own choices.", code:"int token = prompt[0];\nfor (int pos = 0; pos < steps; pos++) {\n    float *logits = forward(&model, token, pos);\n    int next = (pos + 1 < n_prompt)\n             ? prompt[pos + 1]\n             : sample(logits, vocab, temp);\n    if (next == EOS) break;\n    printf(\"%s\", decode(&tok, next));\n    fflush(stdout);\n    token = next;\n}"},
  {type:"mc", q:"During the prompt part, why do we ignore the sampled token?", options:["We already know the next token — it's in the prompt","Sampling is broken","To save memory","Because pos is 0"], answer:0, why:"We still run forward() to fill the KV cache, but force the real prompt token."},
  {type:"mc", q:"What is EOS?", options:["End-of-sequence token: the model says it's done","An error code","Extra output size","A layer type"], answer:0, why:"When the model emits EOS, we stop generating."},
  {type:"order", q:"Order one loop step:", lines:["Run forward() for the current token","Pick next token (prompt or sample)","Stop if it's EOS","Print the decoded text","Set token = next"], why:"Forward → choose → check stop → print → advance."}
 ]}
]},
{
 title: "Going Fast (bitnet.cpp tricks)", color: "#ff4b4b", lessons: [
 { title: "Lookup tables", steps: [
  {type:"learn", title:"Pre-computing answers", text:"bitnet.cpp's <b>TL1/TL2</b> kernels group weights. For 2 ternary weights there are only 3×3 = 9 combos. For each pair of activations, pre-compute all 9 possible sums once, then each weight pair is just a table lookup.", code:"// a0, a1: two activations\nint16_t lut[9];\nint k = 0;\nfor (int w0 = -1; w0 <= 1; w0++)\n  for (int w1 = -1; w1 <= 1; w1++)\n    lut[k++] = w0*a0 + w1*a1;\n// later: sum += lut[weight_pair_index];"},
  {type:"mc", q:"How many combinations do 2 ternary weights have?", options:["4","6","9","8"], answer:2, why:"3 × 3 = 9."},
  {type:"tf", q:"A lookup table is reused for every output row that shares the same input activations.", answer:true, why:"Build once per input chunk, reuse across thousands of rows — that's the speedup."}
 ]},
 { title: "SIMD & threads", steps: [
  {type:"learn", title:"Many at once", text:"<b>SIMD</b> instructions (AVX2 on x86, NEON on ARM) process 16-32 int8 values in one instruction. bitnet.cpp's kernels are written with these. <b>Threads</b> split the output rows across CPU cores.", code:"#pragma omp parallel for\nfor (int i = 0; i < outn; i++) {\n    acc[i] = dot_ternary(W + i*in, xq, in);\n}"},
  {type:"mc", q:"Why can output rows be computed on different threads safely?", options:["Each row writes to a different output slot and only reads shared input","Threads share one variable","C locks automatically","They can't"], answer:0, why:"No two threads write the same memory, so no conflicts."},
  {type:"mc", q:"What does SIMD stand for?", options:["Single Instruction, Multiple Data","Simple Integer Math Division","Serial Input Memory Device","Shared Index Matrix Data"], answer:0, why:"One instruction operates on many values at once."},
  {type:"tf", q:"Thanks to these tricks, bitnet.cpp can run a 100B BitNet model on a single CPU at human reading speed.", answer:true, why:"Microsoft reports ~5-7 tokens/sec for a 100B model on one CPU."}
 ]}
]}
];
