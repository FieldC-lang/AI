(function () {
  'use strict';
  const {chapters,marker,source,solvedPart}=window.Checkpoints;
  const el=id=>document.getElementById(id);
  const lab=id=>el('lab-'+id);
  const editor=lab('editor'), prompt=lab('input'), chapter=lab('chapter');
  const data=store.get('c-lab-v1',{index:0,drafts:{},done:{},answers:{},inputs:{}});
  let idx=0, machine=null, snapshot=null, timer=null, pendingSave=0, running=false, courseY=0;
  let checks=false, passed=false, testEpoch=0, activeTab='console', errorLine=0;
  const save=()=>{clearTimeout(pendingSave);store.set('c-lab-v1',data);};
  const saveLater=()=>{clearTimeout(pendingSave);pendingSave=setTimeout(save,180);};
  function prior(i) {
    const d=data.done[i-1];
    return i>0 && typeof d==='string'?d:'';
  }
  function status(txt) {lab('vm-state').textContent=txt;}
  function report(txt,error=false) {
    lab('report').textContent=txt;
    lab('report').classList.toggle('lab-error',error);
  }
  function controls() {
    ['run','build','step','test'].forEach(id=>lab(id).disabled=running||checks);
    lab('stop').disabled=!running;
    lab('next').disabled=!data.done[idx];
    lab('next').textContent=idx===chapters.length-1?'Back to course':'Next checkpoint →';
  }
  function resetVM(message='Ready') {
    running=false; checks=false; testEpoch++; clearTimeout(timer); machine=null; snapshot=null; errorLine=0;
    status(message); lab('output').textContent='Build or run to see output here.'; report(''); controls(); draw();
  }
  function marks() {
    const mark=errorLine||snapshot?.line||0;
    const p=editor.selectionStart;
    const lines=editor.value.slice(0,p).split('\n');
    lab('line').textContent=mark?`Line ${mark}`:`${lines.length}:${lines[lines.length-1].length+1}`;
    const g=lab('gutter');
    const count=editor.value.split('\n').length;
    if(g.childElementCount !== count) {
      const content=document.createDocumentFragment();
      for(let n=1;n<=count;n++){const s=document.createElement('span'); s.textContent=n; content.append(s);}
      g.replaceChildren(content);
    }
    g.querySelector('.marked')?.classList.remove('marked');
    if(mark) g.children[mark-1]?.classList.add('marked');
    g.scrollTop=editor.scrollTop;
  }
  function focusLine(line,select=false) {
    if(!line||line<1) return;
    const y=(line-1)*21;
    if(select || y<editor.scrollTop || y+35>editor.scrollTop+editor.clientHeight) editor.scrollTop=Math.max(0,y-editor.clientHeight*.30);
    marks();
  }
  function memory() {
    const region=lab('region').value;
    const rows=snapshot?.memory.filter(r=>region==='All'||r.region===region)||[];
    lab('split').textContent=snapshot?`${snapshot.globalBytes} B global · ${snapshot.bytes-snapshot.globalBytes} B stack`:'Build, then step or run to allocate variables.';
    const t=document.createDocumentFragment();
    for(const r of rows) {
      const tr=document.createElement('tr');
      const values=r.values.map(x=>x===null?'uninitialized':Number.isInteger(x)?x:+x.toPrecision(6)).join(', ');
      for(const v of [`0x${r.address.toString(16).padStart(4,'0')}`,`${r.name}${r.size?`[${r.size}]`:''}`,r.region,r.bytes,r.size?`[${values}${r.size>64?', …':''}]`:values]) {
        const td=document.createElement('td'); td.textContent=v; tr.append(td);
      }
      t.append(tr);
    }
    if(!rows.length) {const tr=document.createElement('tr'),td=document.createElement('td'); td.colSpan=5; td.textContent='No live variables in this region.'; tr.append(td); t.append(tr);}
    lab('memory').replaceChildren(t);
  }
  function draw() {
    lab('clock').textContent=(snapshot?.clock||0).toLocaleString();
    lab('bytes').textContent=(snapshot?.bytes||0).toLocaleString();
    lab('peak').textContent=(snapshot?.peak||0).toLocaleString();
    if(activeTab==='memory') memory();
    marks();
  }
  function setTab(tab) {
    activeTab=tab;
    for(const key of ['console','memory']) {
      lab(key+'-tab').setAttribute('aria-pressed',String(key===tab));
      lab(key+'-panel').hidden=key!==tab;
    }
    if(tab==='memory') memory();
  }
  function option(choice) {
    const c=chapters[idx];
    [...lab('opts').children].forEach((b,i)=>{
      b.classList.toggle('correct',choice===c.answer&&i===choice);
      b.classList.toggle('wrong',choice!==c.answer&&i===choice);
      b.setAttribute('aria-pressed',String(choice===i));
    });
    lab('feedback').textContent=choice===undefined?'':(choice===c.answer?'Correct. ':'Not quite. ')+c.why;
  }
  function updateCount() {
    lab('count').textContent=`${chapters.filter((_,i)=>data.done[i]).length} / ${chapters.length} complete`;
    [...chapter.options].forEach((o,i)=>o.textContent=`${String(i+1).padStart(2,'0')} · ${chapters[i].title}${data.done[i]?' ✓':''}`);
  }
  function load(i) {
    idx=i; data.index=i; passed=false;
    const c=chapters[i];
    chapter.value=i;
    lab('title').textContent=c.title; lab('subtitle').textContent=c.subtitle;
    lab('explain').textContent=c.explain; lab('task').textContent=c.task; lab('q').textContent=c.question;
    lab('opts').replaceChildren(...c.options.map((label,j)=>{
      const b=document.createElement('button'); b.className='lab-button'; b.textContent=label;
      b.onclick=()=>{
        data.answers[idx]=j; option(j); save(); maybeComplete();
      };
      return b;
    }));
    option(data.answers[i]);
    const h=lab('solve').closest('details'); h.open=false;
    editor.value=data.drafts[i]??source(i,false,prior(i));
    editor.setSelectionRange(0,0); editor.scrollTop=0; editor.scrollLeft=0;
    prompt.value=data.inputs[i]??c.tests[0][0];
    lab('input-note').textContent=i<4?'This checkpoint does not read input.':'Use red and blue, separated by spaces. The tokenizer reads until end of input.';
    setTab('console'); resetVM(); updateCount(); save();
  }
  function draft() {
    data.drafts[idx]=editor.value; passed=false; saveLater(); resetVM('Source edited');
  }
  function inputChanged() {
    data.inputs[idx]=prompt.value; saveLater(); resetVM('Input edited');
  }
  function compile() {
    if(editor.value.includes('___')) {
      const n=editor.value.slice(0,editor.value.indexOf('___')).split('\n').length;
      throw Error(`Line ${n}: replace ___ with a C expression. Use Find task to jump to it.`);
    }
    return CVM.compile(editor.value);
  }
  function problem(message) {
    errorLine=Number(/Line (\d+):/.exec(message)?.[1]||0);
    lab('output').textContent=message; status('Error'); setTab('console'); controls(); draw(); focusLine(errorLine);
  }
  function build() {
    resetVM();
    try {
      machine=CVM.machine(compile(),prompt.value); status('Built · ready'); lab('output').textContent='Built. Step through the program or press Run.';
      return true;
    } catch(e) { problem(e.message); return false; }
  }
  function reflect() {
    snapshot=machine.snapshot();
    lab('output').textContent=snapshot.stdout|| (snapshot.running?'No output yet.':'(No output)');
    if(snapshot.fault) {
      report(snapshot.fault,true); setTab('console'); status('Runtime error');
    } else if(!snapshot.running) status(`Exit ${snapshot.status}`);
    else status(running?'Running…':'Paused');
    if(!snapshot.running) running=false;
    controls(); draw();
  }
  function step() {
    if(!machine || snapshot && !snapshot.running) {if(!build()) return;}
    machine.step(); reflect(); focusLine(snapshot?.line);
  }
  function run() {
    if(!machine || snapshot && !snapshot.running) {if(!build()) return;}
    running=true; status('Running…'); controls();
    const batch=()=>{
      if(!running || !machine) return;
      machine.advance(900); reflect();
      if(running) timer=setTimeout(batch,0);
      else if(snapshot?.fault) focusLine(snapshot.line);
    };
    timer=setTimeout(batch,0);
  }
  function stop() {running=false;clearTimeout(timer);if(machine) reflect();}
  function maybeComplete() {
    if(!passed||data.answers[idx]!==chapters[idx].answer) return;
    data.done[idx]=editor.value.includes(marker)?editor.value.split(marker)[0].trimEnd():source(idx,true,prior(idx)).split(marker)[0].trimEnd();
    save();updateCount();controls();
    lab('feedback').textContent='Checkpoint complete. '+chapters[idx].why;
    report('All checks passed. Checkpoint complete.');
  }
  function test() {
    resetVM(); setTab('console');
    let compiled;
    try {compiled=compile();}catch(e){problem(e.message);return;}
    const examples=chapters[idx].tests;
    const epoch=testEpoch;
    let j=0, success=0, results=[], t=null, sample=null;
    passed=false; checks=true; status('Checking…');controls();
    const batch=()=>{
      if(epoch!==testEpoch) return;
      const [input,want,code]=examples[j];
      if(!t) t=CVM.machine(compiled,input);
      t.advance(6000);
      const r=t.snapshot();
      if(r.running) {timer=setTimeout(batch,0);return;}
      if(!sample) sample=r;
      const ok=!r.fault && r.stdout===want && r.status===code;
      if(ok) success++;
      const head=`${ok?'PASS':'FAIL'} · ${input?JSON.stringify(input):'no input'}`;
      results.push(ok?head:`${head}\n  Expected ${JSON.stringify(want)} (exit ${code})\n  Got ${r.fault||JSON.stringify(r.stdout)+' (exit '+r.status+')'}`);
      j++;t=null;
      if(j<examples.length) {timer=setTimeout(batch,0);return;}
      checks=false; passed=success===examples.length; snapshot=sample;
      lab('output').textContent=results.join('\n');
      status(`${success}/${examples.length} checks passed`);
      report(passed?(data.answers[idx]===chapters[idx].answer?'All checks passed.':'Code passes. Answer the checkpoint question to finish.'):'Read the difference, edit the code, then run the checks again.',!passed);
      controls();draw();maybeComplete();
    };
    timer=setTimeout(batch,0);
  }
  function find() {
    const n=editor.value.indexOf('___');
    if(n<0) {setTab('console');report('No unfinished expression in this file.');return;}
    editor.focus(); editor.setSelectionRange(n,n+3);
    const head=editor.value.slice(0,n);
    const col=n-1-head.lastIndexOf('\n');
    const charWidth=parseFloat(window.getComputedStyle(editor).fontSize)*0.61;
    const x=col*charWidth;
    if(x<editor.scrollLeft||x+34>editor.scrollLeft+editor.clientWidth) editor.scrollLeft=Math.max(0,x-editor.clientWidth*.35);
    focusLine(head.split('\n').length,true);
  }
  async function copy() {
    try {
      if(window.BitLingoDevice) window.BitLingoDevice.copy(editor.value);
      else if(navigator.clipboard?.writeText) await navigator.clipboard.writeText(editor.value);
      else throw Error();
      report('C source copied. Compile with: cc -std=c11 microbit.c -lm -o microbit');
    } catch {
      editor.focus(); editor.select();
      report('Source selected. Use your device’s Copy command.');
    }
    setTab('console');
  }
  function close() {
    save();resetVM();el('clab').hidden=true;el('course').hidden=false;
    window.scrollTo(0,courseY);el('open-lab').focus({preventScroll:true});
  }
  el('open-lab').onclick=()=>{
    courseY=window.scrollY;el('course').hidden=true;el('clab').hidden=false;
    load(data.index);window.scrollTo(0,0);lab('title').focus({preventScroll:true});
  };
  lab('close').onclick=close;
  chapter.replaceChildren(...chapters.map((_,i)=>{const o=document.createElement('option');o.value=i;return o;}));
  chapter.onchange=()=>load(Number(chapter.value));
  lab('next').onclick=()=>{if(idx===chapters.length-1) close();else {load(idx+1);window.scrollTo(0,0);lab('title').focus({preventScroll:true});}};
  lab('build').onclick=build;lab('step').onclick=step;
  lab('run').onclick=run;lab('stop').onclick=stop;lab('test').onclick=test;
  lab('console-tab').onclick=()=>setTab('console');
  lab('memory-tab').onclick=()=>setTab('memory');lab('region').onchange=memory;
  lab('find').onclick=find;lab('copy').onclick=copy;
  lab('solve').onclick=()=>{
    const stub=chapters[idx].part.split('[[')[0];
    const n=editor.value.indexOf('___');
    if(n<0) {setTab('console');report('No unfinished expression in this file.');return;}
    const filled=solvedPart(idx);
    const right=chapters[idx].part.slice(chapters[idx].part.lastIndexOf(']]')+2);
    const expr=filled.slice(stub.length,filled.length-right.length);
    editor.setRangeText(expr,n,n+3,'select'); draft();focusLine(editor.value.slice(0,n).split('\n').length,true);
  };
  let resetPending=false;
  lab('restore').onclick=()=>{
    if(!resetPending) {
      resetPending=true;lab('restore').textContent='Confirm reset';
      setTimeout(()=>{resetPending=false;lab('restore').textContent='Reset code';},3000);return;
    }
    resetPending=false;lab('restore').textContent='Reset code';delete data.drafts[idx];load(idx);
  };
  editor.addEventListener('input',draft); prompt.addEventListener('input',inputChanged);
  editor.addEventListener('scroll',()=>{lab('gutter').scrollTop=editor.scrollTop;});
  for(const event of ['click','select','keyup']) editor.addEventListener(event,marks);
  document.addEventListener('visibilitychange',()=>{if(document.hidden) save();});
  window.addEventListener('pagehide',save);
  window.exitBitLingoPage=()=> {
    if(el('lesson').style.display==='flex') { el('quit').click(); return true; }
    if(!el('clab').hidden) {close();return true;}
    return false;
  };
})();
