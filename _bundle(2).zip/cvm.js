/* A deliberately small C11 teaching VM. It never evaluates source as JavaScript. */
(function (root) {
  'use strict';
  const sizes = {int:4, double:8, byte:1}, CAP = 65536, LIMIT = 250000;
  const libs = new Set(['getchar','putchar','puts','printf','sqrt','exp','cos','sin','round','fabs']);
  const headers = new Set(['stdio.h','math.h','stdint.h']);
  const typeStarts = ['int','double','unsigned','uint8_t'];
  const precedence = {'=':1,'||':2,'&&':3,'|':4,'^':5,'&':6,'==':7,'!=':7,'<':8,'>':8,'<=':8,'>=':8,'<<':9,'>>':9,'+':10,'-':10,'*':11,'/':11,'%':11};
  function compile(source) {
    if (source.length > 48000) throw Error('Source exceeds the 48,000-character editor limit.');
    const tokens = [];
    const re = /\/\/[^\n]*|\/\*[\s\S]*?\*\/|#[^\n]*|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])'|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[A-Za-z_]\w*|==|!=|<=|>=|<<|>>|&&|\|\||[{}()[\],;=+\-*/%<>!&|^]|\s+|./gy;
    let line = 1, m;
    while ((m = re.exec(source))) {
      const s = m[0], l = line;
      line += (s.match(/\n/g) || []).length;
      if (/^\s|^\/[/*]/.test(s)) continue;
      if (s[0] === '#') {
        const h = /^#\s*include\s*<([^>]+)>\s*$/.exec(s);
        if (!h || !headers.has(h[1])) throw Error(`Line ${l}: only stdio.h, math.h, and stdint.h includes are supported.`);
        continue;
      }
      tokens.push({s,l});
    }
    tokens.push({s:'<end>',l:line});
    let i = 0, depth = 0;
    const globals = [], funcs = Object.create(null);
    const read = () => tokens[i], at = s => read().s === s;
    const fail = msg => { throw Error(`Line ${read().l}: ${msg}`); };
    function take(s) { const t = read(); if (s && t.s !== s) fail(`Expected '${s}', found '${t.s}'.`); if(at('<end>')) fail('Unexpected end of file.'); i++; return t; }
    const eat = s => at(s) && !!take();
    function name() {
      if (!/^[a-zA-Z_]\w*$/.test(read().s) || [...typeStarts,'void','char','if','else','while','for','return'].includes(read().s)) fail('Expected a name.');
      return take().s;
    }
    function type() {
      if (eat('uint8_t')) return 'byte';
      if (eat('unsigned')) { take('char'); return 'byte'; }
      if (!at('int') && !at('double')) fail('Expected int, double or unsigned char.');
      return take().s;
    }
    function args(end) {
      const out = [];
      if (!at(end)) { do { out.push(expr()); } while (eat(',')); }
      take(end); return out;
    }
    function quoted(s) {
      return s.slice(1,-1).replace(/\\(.)/g, (_,v) => ({n:'\n',r:'\r',t:'\t','0':'\0','\\':'\\','"':'"',"'":"'"}[v] ?? v));
    }
    function expr(min=1) {
      if (++depth > 96) fail('Expression nesting is too deep.');
      const {s,l} = take(); let a;
      if (s === '(') {
        if(typeStarts.includes(read().s)) { const t=type(); take(')'); a={k:'cast',t,a:expr(12),l}; }
        else { a=expr(); take(')'); }
      } else if (['!','-','+'].includes(s)) a={k:'un',s,a:expr(12),l};
      else if (/^(?:\d|\.\d)/.test(s)) a={k:'lit',v:Number(s),t:/[.eE]/.test(s)?'double':'int',l};
      else if (s[0]==='"') a={k:'lit',v:quoted(s),t:'str',l};
      else if (s[0]==="'") a={k:'lit',v:quoted(s).charCodeAt(0),t:'int',l};
      else if (/^[a-zA-Z_]\w*$/.test(s)) {
        if (eat('(')) a={k:'call',s,args:args(')'),l};
        else { const index=eat('[')?expr():null; if(index) take(']'); a={k:'ref',s,index,l}; }
      } else throw Error(`Line ${l}: expected a value, found '${s}'.`);
      while ((precedence[read().s] || 0) >= min) {
        const op=take(); const p=precedence[op.s];
        a={k:'bin',s:op.s,a,b:expr(p+(op.s==='='?0:1)),l:op.l};
      }
      depth--; return a;
    }
    function decl(t,s,l) {
      let n = null, init = null;
      if (eat('[')) { if (!/^\d+$/.test(read().s)) fail('Use a positive literal array size.'); n=Number(take().s); take(']'); if(!n || n*sizes[t]>CAP) fail('Array exceeds virtual memory capacity.'); }
      if (eat('=')) { if(n) { take('{'); init=args('}'); if(init.length>n) fail('Too many initializers.'); } else init=expr(); }
      take(';'); return {k:'decl',t,s,n,init,l};
    }
    function stmt() {
      if (++depth > 96) fail('Statement nesting is too deep.');
      const l=read().l; let a;
      if (eat('{')) { const list=[]; while(!eat('}')) list.push(stmt()); a={k:'block',list,l}; }
      else if (eat('if')) { take('('); const e=expr(); take(')'); a={k:'if',e,yes:stmt(),no:eat('else')?stmt():null,l}; }
      else if (eat('while')) { take('('); const e=expr(); take(')'); a={k:'while',e,body:stmt(),l}; }
      else if (eat('for')) {
        take('('); const begin=stmt(), e=at(';')?null:expr(); take(';'); const next=at(')')?null:expr(); take(')');
        a={k:'for',begin,e,next,body:stmt(),l};
      } else if (eat('return')) { const e=expr(); take(';'); a={k:'return',e,l}; }
      else if (typeStarts.includes(read().s)) a=decl(type(),name(),l);
      else if (eat(';')) a={k:'noop',l};
      else { const e=expr(); take(';'); a={k:'expr',e,l}; }
      depth--; return a;
    }
    while (!at('<end>')) {
      const l=read().l, t=type(), s=name();
      if (libs.has(s) || globals.some(g=>g.s===s) || funcs[s]) fail(`Duplicate or reserved name '${s}'.`);
      if(eat('(')) {
        const p=[];
        if (!eat('void') && !at(')')) { do { p.push({t:type(),s:name(),n:null,l}); } while(eat(',')); }
        take(')'); if(!at('{')) fail('Functions need a body.');
        funcs[s]={t,p,body:stmt(),l};
      } else globals.push(decl(t,s,l));
    }
    if(!funcs.main || funcs.main.p.length || funcs.main.t!=='int') fail('Define int main(void).');
    return {globals,funcs};
  }
  function machine(program,input='') {
    const memory = new DataView(new ArrayBuffer(CAP)), initialized = new Uint8Array(CAP), top=new Map(), frames=[];
    let sp=0, peak=0, clock=0, line=1, running=true, fault='', stdout='', status=null, pos=0, globalBytes=0;
    const v=(n,t='int')=>({n,t});
    const error=msg=>{throw Error(`Line ${line}: ${msg}`);};
    function* tick(l) { line=l; if(clock>=LIMIT) error(`Stopped at the ${LIMIT.toLocaleString()}-tick safety limit.`); clock++; yield; }
    function push() { frames.push({mark:sp,vars:new Map()}); }
    function pop() { sp=frames.pop().mark; }
    function allocate(d, vars) {
      if(vars.has(d.s)) error(`'${d.s}' is already declared.`);
      const bytes=(d.n||1)*sizes[d.t];
      if(sp+bytes>CAP) error('Out of virtual memory.');
      const r={...d, at:sp, bytes}; vars.set(d.s,r);
      new Uint8Array(memory.buffer,sp,bytes).fill(0);
      initialized.fill(vars===top || (d.n && d.init) ? 1:0,sp,sp+bytes);
      sp+=bytes; if(vars===top) globalBytes=sp; peak=Math.max(peak,sp); return r;
    }
    const methods={int:'Int32',double:'Float64',byte:'Uint8'};
    function get(r,j) {
      const a=r.at+j*sizes[r.t];
      if(!initialized[a]) error(`'${r.s}${r.n?'['+j+']':''}' was read before it was initialized.`);
      return v(memory['get'+methods[r.t]](a,true),r.t);
    }
    function set(r,j,x) {
      if(x.t==='str' || !Number.isFinite(x.n)) error('Expected a finite number.');
      if(r.t==='int' && (Math.trunc(x.n)<-2147483648 || Math.trunc(x.n)>2147483647)) error('32-bit integer overflow.');
      const a=r.at+j*sizes[r.t]; initialized[a]=1;
      memory['set'+methods[r.t]](a,x.n,true);
      return get(r,j);
    }
    function* ref(a,base) {
      if(a.k!=='ref') error('Assignment needs a variable or array element.');
      let r;
      for(let i=frames.length-1;i>=base&&!r;i--) r=frames[i].vars.get(a.s);
      r=r||top.get(a.s); if(!r) error(`Unknown variable '${a.s}'.`);
      if(Boolean(r.n)!==Boolean(a.index)) error(`Use '${a.s}${r.n?'[index]':''}'.`);
      const j=a.index?(yield* evalExpr(a.index,base)).n:0;
      if(!Number.isInteger(j)||j<0||j>=(r.n||1)) error(`Index ${j} is outside '${r.s}' (${r.n} elements).`);
      return [r,j];
    }
    function output(s) { if(stdout.length+s.length>12000) error('Console output limit reached.'); stdout+=s; }
    function builtin(s,a) {
      if (s==='getchar' && !a.length) return v(pos<input.length?input.charCodeAt(pos++):-1);
      if (s==='putchar' && a.length===1 && a[0].t!=='str') { const n=a[0].n&255; output(String.fromCharCode(n)); return v(n); }
      if (s==='puts' && a.length===1 && a[0].t==='str') { output(a[0].n+'\n'); return v(0); }
      if (s==='printf' && a[0]?.t==='str') {
        let j=1;
        const txt=a[0].n.replace(/%(?:\.(\d))?([dfcs%])|%/g,(fmt,precision,kind)=>{
          if(kind==='%') return '%';
          const x=a[j++];
          if(!x || !kind || (x.t==='str')!==(kind==='s')) error(`Invalid printf conversion '${fmt}'.`);
          return kind==='s'?x.n:kind==='c'?String.fromCharCode(x.n&255):kind==='d'?String(Math.trunc(x.n)):x.n.toFixed(precision===undefined?6:+precision);
        });
        if(j!==a.length) error('Unexpected extra printf arguments.'); output(txt); return v(txt.length);
      }
      const fn={sqrt:Math.sqrt,exp:Math.exp,cos:Math.cos,sin:Math.sin,round:n=>Math.sign(n)*Math.floor(Math.abs(n)+0.5),fabs:Math.abs}[s];
      if(fn && a.length===1 && a[0].t!=='str') { const n=fn(a[0].n); if(!Number.isFinite(n)) error(`Non-finite result from ${s}().`); return v(n,'double'); }
      error(`Wrong arguments for ${s}().`);
    }
    const truth=x=>{if(x.t==='str') error('A string is not a numeric condition.'); return x.n!==0;};
    function* evalExpr(a,base) {
      yield* tick(a.l);
      if(a.k==='lit') return v(a.v,a.t);
      if(a.k==='ref') return get(...(yield* ref(a,base)));
      if(a.k==='call') {
        const args=[]; for(const b of a.args) args.push(yield* evalExpr(b,base));
        return yield* call(a.s,args);
      }
      if(a.k==='un'||a.k==='cast') {
        const x=yield* evalExpr(a.a,base); if(x.t==='str') error('Expected a numeric operand.');
        if(a.k==='cast') return a.t==='double'?v(x.n,'double'):a.t==='byte'?v(x.n&255,'byte'):v(Math.trunc(x.n));
        return a.s==='!'?v(+!x.n):v(a.s==='-'?-x.n:x.n,x.t==='byte'?'int':x.t);
      }
      if(a.s==='=') { const dst=yield* ref(a.a,base); return set(...dst,yield* evalExpr(a.b,base)); }
      if(a.s==='&&'||a.s==='||') {
        const yes=truth(yield* evalExpr(a.a,base)); if(a.s==='&&'&&!yes||a.s==='||'&&yes) return v(+yes);
        return v(+truth(yield* evalExpr(a.b,base)));
      }
      const x=yield* evalExpr(a.a,base), y=yield* evalExpr(a.b,base), p=x.n,q=y.n;
      if(x.t==='str'||y.t==='str') error('Expected numeric operands.');
      const t=x.t==='double'||y.t==='double'?'double':'int';
      if(['%','|','&','^','<<','>>'].includes(a.s)&&t==='double') error(`'${a.s}' needs integers.`);
      if((a.s==='/'||a.s==='%')&&!q) error('Division by zero.');
      if((a.s==='<<'||a.s==='>>')&&(q<0||q>31)) error('Shift count must be between 0 and 31.');
      switch(a.s) {
        case '==':return v(+(p===q)); case '!=':return v(+(p!==q));
        case '<':return v(+(p<q)); case '>':return v(+(p>q)); case '<=':return v(+(p<=q)); case '>=':return v(+(p>=q));
        case '|':return v(p|q); case '&':return v(p&q); case '^':return v(p^q); case '<<':return v(p<<q); case '>>':return v(p>>q); case '%':return v(p%q);
        default: {
          let n=a.s==='+'?p+q:a.s==='-'?p-q:a.s==='*'?p*q:t==='int'?Math.trunc(p/q):p/q;
          if(!Number.isFinite(n)||t==='int'&&(n<-2147483648||n>2147483647)) error('Numeric overflow.');
          return v(n,t);
        }
      }
    }
    function* declare(d,vars,base) {
      const r=allocate(d,vars);
      if(d.init) { if(d.n) { let j=0; for(const x of d.init) set(r,j++,yield* evalExpr(x,base)); } else set(r,0,yield* evalExpr(d.init,base)); }
    }
    function* exec(a,base) {
      yield* tick(a.l);
      switch(a.k) {
        case 'decl':yield* declare(a,frames[frames.length-1].vars,base); break;
        case 'noop':break;
        case 'expr':yield* evalExpr(a.e,base); break;
        case 'return':return yield* evalExpr(a.e,base);
        case 'block': {
          push(); for(const b of a.list) { const r=yield* exec(b,base); if(r) {pop(); return r;} } pop(); break;
        }
        case 'if': { const b=truth(yield* evalExpr(a.e,base))?a.yes:a.no; if(b) return yield* exec(b,base); break; }
        case 'for': case 'while': {
          push(); if(a.begin) yield* exec(a.begin,base);
          while(!a.e || truth(yield* evalExpr(a.e,base))) {
            const r=yield* exec(a.body,base); if(r) {pop();return r;}
            if(a.next) yield* evalExpr(a.next,base);
          }
          pop();break;
        }
      }
    }
    function* call(s,args) {
      if(libs.has(s)) return builtin(s,args);
      const f=program.funcs[s]; if(!f) error(`Unknown function '${s}'.`);
      if(args.length!==f.p.length) error(`'${s}' needs ${f.p.length} arguments.`);
      if(frames.length>100) error('Virtual call stack limit reached.');
      const base=frames.length; push(); f.p.forEach((d,i)=>set(allocate(d,frames[frames.length-1].vars),0,args[i]));
      const r=yield* exec(f.body,base); pop();
      if(!r && s!=='main') error(`'${s}' ended without returning a value.`);
      if(r?.t==='str') error('A numeric function cannot return text.');
      if(f.t==='int' && r && (Math.trunc(r.n)<-2147483648||Math.trunc(r.n)>2147483647)) error('32-bit return value overflow.');
      return v(f.t==='int'?Math.trunc(r?.n||0):f.t==='byte'?r.n&255:r.n,f.t);
    }
    function* entry() {
      for(const d of program.globals) { yield* tick(d.l); yield* declare(d,top,0); globalBytes=sp; }
      status=(yield* call('main',[])).n;
    }
    const it=entry();
    function step() {
      if(!running) return;
      try { running=!it.next().done; } catch(e) { running=false; fault=e.message; }
    }
    const describe=(vars,region)=>Array.from(vars.values(),r=>({
      name:r.s,region,address:r.at,bytes:r.bytes,type:r.t,size:r.n,
      values:Array.from({length:Math.min(r.n||1,64)},(_,j)=>initialized[r.at+j*sizes[r.t]]?get(r,j).n:null)
    }));
    return {step, advance(n) { for(let i=0;i<n&&running;i++) step(); }, snapshot() {
      return {running,fault,stdout,status,clock,line,bytes:sp,peak,capacity:CAP,globalBytes,
        memory:[...describe(top,'Global'),...frames.flatMap(f=>describe(f.vars,'Stack'))]};
    }};
  }
  root.CVM={compile,machine};
})(typeof window !== 'undefined' ? window : globalThis);
