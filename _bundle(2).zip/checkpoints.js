(function (root) {
  'use strict';
  const header = `#include <stdio.h>
#include <stdint.h>
#include <math.h>

/* MicroBit: one layer, one attention head, four channels, eight positions.
   This is a hand-authored teaching checkpoint, not a trained chat model.
   Token IDs: 0 = red, 1 = blue, 2 = end. */
`;
  const chapters = [
    ['Boot the program', 'Start with main()', 'Every C executable starts here. puts displays one line. The number returned by main tells the caller whether the program succeeded: zero means yes.', 'Make boot_marker() return zero. Then Build and Step through main to watch its local variable appear.', 'What is the purpose of returning 0 from main?', ['It prints zero to the screen.', 'It reports successful completion.', 'It clears all global memory.'], 1, 'Exit status is separate from printed text.',
`int boot_marker(void) {
    return [[0]];
}
`,
`int main(void) {
    int status = boot_marker();
    puts("MicroBit ready");
    return status;
}`, [['','MicroBit ready\n',0]]],
    ['Load the weights', 'Turn bytes into a model', 'An embedded checkpoint supplies the model’s packed weight bytes. The loader copies them into named virtual memory. The 4×4 projection is an identity matrix in this fixture, so it passes all four channels through unchanged.', 'Copy byte i from the checkpoint into weight[i]. Look for both four-byte arrays in Global memory.', 'Why put model bytes in a separate checkpoint array?', ['To separate the model data from the code that uses it.', 'So the model can train itself.', 'So every weight becomes a double.'], 0, 'The same loader and inference code can use different valid checkpoint bytes.',
`uint8_t checkpoint[4] = {149, 101, 89, 86};
uint8_t weight[4];

int load_model(void) {
    for (int i = 0; i < 4; i = i + 1) {
        weight[i] = [[checkpoint[i]]];
    }
    return 0;
}
`,
`int main(void) {
    load_model();
    printf("%d %d %d %d\\n", (int)weight[0], (int)weight[1], (int)weight[2], (int)weight[3]);
    return boot_marker();
}`, [['','149 101 89 86\n',0]]],
    ['Unpack four weights', 'Read a two-bit slot', 'A byte holds four weight codes. Moving the chosen code to the right exposes its two bits. Keep those bits with & 3, then subtract 1 to recover −1, 0, or +1. Slot 0 starts at bit 6.', 'Write the shift for slot j. For j = 0, 1, 2, 3 it should produce 6, 4, 2, 0.', 'Why AND the shifted byte with 3?', ['It keeps only the two lowest bits.', 'It shifts by three more bits.', 'It changes the byte to a decimal.'], 0, 'Three is binary 11, so every bit above the lowest two is discarded.',
`int unpack(uint8_t packed, int j) {
    int shift = [[6 - 2 * j]];
    return ((packed >> shift) & 3) - 1;
}
`,
`int main(void) {
    load_model();
    for (int i = 0; i < 4; i = i + 1) {
        printf("%d%d%d%d\\n", unpack(weight[i],0), unpack(weight[i],1), unpack(weight[i],2), unpack(weight[i],3));
    }
    printf("%d\\n", unpack(0,0));
    return boot_marker();
}`, [['','1000\n0100\n0010\n0001\n-1\n',0]]],
    ['Build BitLinear', 'Quantize, accumulate, rescale', 'Find the largest absolute input and map it to 127. Round all channels into the signed 8-bit range (kept in int slots in this lab). For every output row, add, subtract or skip each input according to its weight. Reverse the scale to return a decimal output. The fixture uses a weight scale of 1.', 'Complete the rescale expression. Look for the rounded vector z and watch acc change as you step.', 'Why use a wider integer for acc than the range of z?', ['It makes the input byte bigger.', 'A sum of many small integers can exceed the range of one.', 'It converts the sum into a probability.'], 1, 'The full sum must fit before we convert back to a decimal.',
`double layer_in[4];
double projected[4];

int bitlinear(void) {
    double top = 0.000000001;
    for (int j = 0; j < 4; j = j + 1) {
        if (fabs(layer_in[j]) > top) top = fabs(layer_in[j]);
    }
    double scale = 127.0 / top;
    int z[4];
    for (int j = 0; j < 4; j = j + 1) {
        z[j] = (int)round(layer_in[j] * scale);
    }
    for (int i = 0; i < 4; i = i + 1) {
        int acc = 0;
        for (int j = 0; j < 4; j = j + 1) {
            int w = unpack(weight[i], j);
            if (w == 1) acc = acc + z[j];
            if (w == -1) acc = acc - z[j];
        }
        projected[i] = [[acc / scale]];
    }
    return 0;
}
`,
`int main(void) {
    load_model();
    layer_in[0] = 4.0;
    layer_in[1] = -2.0;
    bitlinear();
    printf("%.2f %.2f %.2f\\n", projected[0], projected[1], projected[2]);
    return boot_marker();
}`, [['','4.00 -2.02 0.00\n',0]]],
    ['Encode the prompt', 'Read words into token IDs', 'C sees bytes from getchar(), not words. The tokenizer splits on whitespace and matches each word exactly. It stores each token in prompt[] and refuses unknown words or more than four tokens. The course’s BPE lesson explains the more general method used by real models.', 'Set the token ID for blue. Try “red blue”, then try an unsupported word.', 'Why tokenize first instead of passing characters directly to the model?', ['The model is indexed by token ID, not by text.', 'C cannot store letters.', 'Tokens are always a single character.'], 0, 'The model’s embedding table expects IDs from the same vocabulary.',
`int prompt[4];
int prompt_count;

int whitespace(int c) {
    return c == ' ' || c == '\\n' || c == '\\t' || c == '\\r';
}
int tokenize(void) {
    int c = getchar();
    prompt_count = 0;
    while (c != -1) {
        if (whitespace(c)) {
            c = getchar();
        } else {
            int letters[4];
            int n = 0;
            while (c != -1 && !whitespace(c)) {
                if (n == 4) return 1;
                letters[n] = c;
                n = n + 1;
                c = getchar();
            }
            int id = -1;
            if (n == 3 && letters[0]=='r' && letters[1]=='e' && letters[2]=='d') id = 0;
            if (n == 4 && letters[0]=='b' && letters[1]=='l' && letters[2]=='u' && letters[3]=='e') id = [[1]];
            if (id < 0 || prompt_count == 4) return 1;
            prompt[prompt_count] = id;
            prompt_count = prompt_count + 1;
        }
    }
    return prompt_count == 0;
}
`,
`int main(void) {
    if (tokenize()) { puts("Use one to four words: red or blue."); return 1; }
    printf("%d tokens:", prompt_count);
    for (int i=0; i<prompt_count; i=i+1) printf(" %d", prompt[i]);
    puts("");
    return boot_marker();
}`, [['red blue','2 tokens: 0 1\n',0],['blue red red','3 tokens: 1 0 0\n',0],['green','Use one to four words: red or blue.\n',1]]],
    ['Embed and normalize', 'Turn a token into a vector', 'An embedding is the starting vector for a token. Row 0 is red and row 1 is blue. RMSNorm reads the mean square and divides every channel by its square root (with a small epsilon to avoid division by zero). Here all learned norm gains are 1.', 'Use id to locate the start of the embedding row. Each row is four values wide.', 'Why sum squares before taking the mean?', ['So negative and positive values cannot cancel.', 'So only negatives are kept.', 'So the tokenizer can sort the words.'], 0, 'The squared magnitudes measure vector size regardless of sign.',
`double table[12] = {1,0,0,0, 0,1,0,0, 0,0,1,0};
double x[4];

int embed(int id) {
    for (int j=0; j<4; j=j+1) x[j] = table[[[id * 4 + j]]];
    return 0;
}
int norm_x(void) {
    double square = 0.0;
    for (int j=0; j<4; j=j+1) square = square + x[j]*x[j];
    double rms = sqrt(square / 4.0 + 0.00001);
    for (int j=0; j<4; j=j+1) layer_in[j] = x[j] / rms;
    return 0;
}
`,
`int main(void) {
    if (tokenize()) return 1;
    embed(prompt[0]);
    norm_x();
    printf("%.2f %.2f\\n", layer_in[0], layer_in[1]);
    return boot_marker();
}`, [['red','2.00 0.00\n',0],['blue','0.00 2.00\n',0]]],
    ['Rotate and cache', 'Save keys and values', 'The same packed projection supplies Q, K and V in this tiny fixture. Production models use separately learned matrices. RoPE rotates the query and key’s coordinate pairs using position; the value is not rotated. A cache reserves four values per past position.', 'Use pos to compute the start of the current key row. Run with red blue and inspect kcache and vcache.', 'Why save K and V instead of recomputing them every token?', ['They are reused when later tokens attend to earlier positions.', 'They contain text to print.', 'They are the only model weights.'], 0, 'The cache trades memory for less repeated computation.',
`double q[4];
double kcache[32];
double vcache[32];

int rotate_query(int pos) {
    for (int i=0; i<4; i=i+2) {
        double angle = pos;
        if (i == 2) angle = angle / 100.0;
        double a=q[i];
        double b=q[i+1];
        q[i]=a*cos(angle)-b*sin(angle);
        q[i+1]=a*sin(angle)+b*cos(angle);
    }
    return 0;
}
int cache_qkv(int pos) {
    bitlinear();
    for (int i=0; i<4; i=i+1) q[i]=projected[i];
    rotate_query(pos);
    for (int i=0; i<4; i=i+1) {
        kcache[[[pos * 4 + i]]] = q[i];
        vcache[pos*4+i] = projected[i];
    }
    return 0;
}
`,
`int main(void) {
    load_model();
    if (tokenize() || prompt_count < 2) return 1;
    for(int p=0; p<2; p=p+1) { embed(prompt[p]); norm_x(); cache_qkv(p); }
    printf("%.2f %.2f / %.2f %.2f\\n", kcache[4], kcache[5], vcache[4], vcache[5]);
    return boot_marker();
}`, [['red blue','-1.68 1.08 / 0.00 2.00\n',0],['blue red','1.08 1.68 / 2.00 0.00\n',0]]],
    ['Compute attention', 'Mix what came before', 'Dot the query with each cached key. Divide by √4, then turn the scores into probabilities using softmax. Multiply each cached value by its probability and add the results. No future positions are read.', 'Complete the score scaling. In memory, look at probabilities after normalization and compare the two positions.', 'Why subtract the biggest score before calling exp?', ['It removes old tokens.', 'It prevents overflow without changing the final probabilities.', 'It makes all values positive before exp.'], 1, 'Softmax is unchanged when the same constant is subtracted from all scores.',
`double probs[8];

int attend(int pos) {
    double max = -1000000.0;
    for (int t=0; t<=pos; t=t+1) {
        double score=0.0;
        for(int j=0; j<4; j=j+1) score=score+q[j]*kcache[t*4+j];
        probs[t]=[[score / 2.0]];
        if(probs[t]>max) max=probs[t];
    }
    double sum=0.0;
    for(int t=0; t<=pos; t=t+1) {
        probs[t]=exp(probs[t]-max);
        sum=sum+probs[t];
    }
    for(int t=0; t<=pos; t=t+1) probs[t]=probs[t]/sum;
    for(int i=0; i<4; i=i+1) {
        layer_in[i]=0.0;
        for(int t=0; t<=pos; t=t+1) layer_in[i]=layer_in[i]+probs[t]*vcache[t*4+i];
    }
    return 0;
}
`,
`int main(void) {
    load_model();
    if (tokenize() || prompt_count<2) return 1;
    for(int p=0; p<2; p=p+1) { embed(prompt[p]); norm_x(); cache_qkv(p); }
    attend(1);
    printf("%.2f %.2f / %.2f\\n", probs[0], probs[1], probs[0]+probs[1]);
    return boot_marker();
}`, [['red blue','0.02 0.98 / 1.00\n',0],['blue blue','0.29 0.71 / 1.00\n',0]]],
    ['Wire a transformer layer', 'Add residuals and the feed-forward gate', 'The attention result goes through its output projection and is added to the starting vector. The feed-forward path normalizes again, applies a squared ReLU gate to the up projection, projects back to four channels and adds another residual. With identical gate/up weights here, gate and up come from the same projection.', 'Finish residual() so it adds projected[i] onto x[i], rather than replacing x[i].', 'What does the residual preserve?', ['The path that lets old values carry straight through.', 'A copy of the text prompt.', 'The previous value of the clock.'], 0, 'Each branch adds a change to x instead of overwriting all the information already there.',
`int residual(void) {
    for(int i=0; i<4; i=i+1) x[i]=[[x[i] + projected[i]]];
    return 0;
}
int ffn(void) {
    norm_x();
    bitlinear();
    for(int i=0; i<4; i=i+1) {
        double up=projected[i];
        double gate=up;
        if(gate<0.0) gate=0.0;
        layer_in[i]=gate*gate*up;
    }
    bitlinear();
    residual();
    return 0;
}
int block(int id,int pos) {
    embed(id);
    norm_x();
    cache_qkv(pos);
    attend(pos);
    bitlinear();
    residual();
    ffn();
    return 0;
}
`,
`int main(void) {
    load_model();
    if(tokenize()) return 1;
    block(prompt[0], 0);
    printf("%.2f %.2f\\n", x[0], x[1]);
    return boot_marker();
}`, [['red','11.00 0.00\n',0],['blue','0.00 11.00\n',0]]],
    ['Read logits and pick a token', 'Give every token a score', 'After the transformer layer, normalize again. The readout gives red the blue channel’s score, blue the red channel’s score, and the end token a low score. These hand-authored weights make the generation easy to predict. argmax returns the index of the highest score.', 'Finish the comparison which updates best. Test red and blue. The selected ID should flip.', 'Why return an index rather than the highest score itself?', ['The index is a token ID we can decode or feed back in.', 'The best score must be rounded to zero.', 'The score is stored in the tokenizer.'], 0, 'The ID selects an entry in the same vocabulary used by the tokenizer.',
`double logits[3];

int forward(int id,int pos) {
    block(id,pos);
    norm_x();
    logits[0]=layer_in[1];
    logits[1]=layer_in[0];
    logits[2]=layer_in[2]-1.0;
    return 0;
}
int argmax(void) {
    int best=0;
    for(int i=1; i<3; i=i+1) if ([[logits[i] > logits[best]]]) best=i;
    return best;
}
`,
`int main(void) {
    load_model();
    if(tokenize()) return 1;
    forward(prompt[0],0);
    printf("next ID: %d\\n",argmax());
    return boot_marker();
}`, [['red','next ID: 1\n',0],['blue','next ID: 0\n',0]]],
    ['Ship the inference engine', 'Feed each answer back in', 'Prefill runs each prompt token through forward() in order so the cache contains the whole prompt. Then pick, decode and feed back each generated ID, stopping at EOS or a safe context limit. This final C file is a standalone program: the same source runs in the lab and with a C11 compiler.', 'Wire the sampled ID back into forward(). Run with “red”, then “red blue”. Copy the completed C program to take it outside the lab.', 'Why does prefill run forward on every prompt token even though it prints none?', ['It fills the attention cache with the prompt’s keys and values.', 'It retrains the embeddings.', 'It clears the output logits.'], 0, 'The next generated token needs the context the prompt established.',
`int decode(int id) {
    if(id==0) printf("red");
    if(id==1) printf("blue");
    return 0;
}
int generate(void) {
    int pos=0;
    while(pos<prompt_count) {
        forward(prompt[pos],pos);
        pos=pos+1;
    }
    for(int step=0; step<4 && pos<8; step=step+1) {
        int next=argmax();
        if(next==2) { puts(""); return 0; }
        if(step>0) putchar(' ');
        decode(next);
        if(step<3 && pos+1<8) forward([[next]],pos);
        pos=pos+1;
    }
    puts("");
    return 0;
}
`,
`int main(void) {
    load_model();
    if(tokenize()) { puts("Use one to four words: red or blue."); return 1; }
    generate();
    return boot_marker();
}`, [['red','blue red blue red\n',0],['red blue','red blue red blue\n',0],['blue','red blue red blue\n',0],['green','Use one to four words: red or blue.\n',1]]]
  ].map(([title,subtitle,explain,task,question,options,answer,why,part,driver,tests])=>({title,subtitle,explain,task,question,options,answer,why,part,driver,tests}));
  const marker = '/* CHECKPOINT DRIVER */';
  // A solution starts with [[ and ends with ]]. Some occur inside array syntax.
  function substitute(part,solve) {
    return part.replace(/\[\[([^\[\]\n]*(?:\[[^\]\n]*\][^\[\]\n]*)*)\]\]/g, (_, answer)=>solve?answer:'___');
  }
  // Prefer an unambiguous delimiter where a hole touches a C array bracket.
  chapters[5].part=chapters[5].part.replace('table[[[id * 4 + j]]]','table[ [[id * 4 + j]] ]');
  chapters[6].part=chapters[6].part.replace('kcache[[[pos * 4 + i]]]','kcache[ [[pos * 4 + i]] ]');
  function body(index,solve,previous) {
    const base=previous || header + chapters.slice(0,index).map(c=>substitute(c.part,true)).join('\n');
    return base+'\n'+substitute(chapters[index].part,solve);
  }
  function source(index,solve=false,previous='') {
    return body(index,solve,previous)+'\n'+marker+'\n'+chapters[index].driver+'\n';
  }
  root.Checkpoints={chapters,marker,source,solvedPart:i=>substitute(chapters[i].part,true)};
})(typeof window !== 'undefined' ? window : globalThis);
