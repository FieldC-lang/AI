// BitScribe Python learning app: course player, Python (Pyodide) runner, progress, settings, sounds.
(function () {
'use strict';
const BS = window.BS = {};
const IS_APP = !!window.BitScribeApp;
const SOL_AFTER = 3;                              // failed tries before the "Show the solution" button opens          // running inside the Android app
BS.IS_APP = IS_APP;

// ---------------- small helpers ----------------
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function h(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }
function toast(msg, ms) {
  const t = h(`<div class="toast" role="status">${esc(msg)}</div>`);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms || 2600);
}
function modal(html, buttons) {
  return new Promise((resolve) => {
    const bg = h(`<div class="modal-bg"><div class="modal" role="dialog" aria-modal="true">${html}<div class="foot"></div></div></div>`);
    const foot = $('.foot', bg);
    (buttons || [{ label: 'OK', value: true, cls: 'primary' }]).forEach(b => {
      const btn = h(`<button class="btn ${b.cls || ''}">${esc(b.label)}</button>`);
      btn.onclick = () => { bg.remove(); BS.modalOpen--; resolve(b.value); };
      foot.appendChild(btn);
    });
    BS.modalOpen = (BS.modalOpen || 0) + 1;
    bg.addEventListener('click', (e) => { if (e.target === bg && buttons && buttons.length > 1) { bg.remove(); BS.modalOpen--; resolve(null); } });
    document.body.appendChild(bg);
    const first = $('.foot .btn:last-child', bg); if (first) first.focus();
  });
}
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fmtTime = (s) => { s = Math.max(0, Math.round(s)); if (s < 60) return s + ' s'; if (s < 3600) return Math.floor(s / 60) + ' min ' + (s % 60) + ' s'; const hh = Math.floor(s / 3600); return hh + ' h ' + Math.floor((s % 3600) / 60) + ' min'; };
Object.assign(BS, { $, $$, esc, h, toast, modal, today, fmtTime });

// ---------------- sounds (made with the Web Audio API, no files needed) ----------------
let actx = null;
function tone(freq, start, dur, type, vol) {
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = type || 'sine'; o.frequency.value = freq;
  const t0 = actx.currentTime + start;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(actx.destination);
  o.start(t0); o.stop(t0 + dur + 0.05);
}
function sound(kind) {
  if (!S.settings.sound) return;
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    const v = 0.18 * (S.settings.volume ?? 0.7);
    if (kind === 'correct') { tone(784, 0, 0.16, 'triangle', v); tone(1175, 0.09, 0.28, 'triangle', v); }
    else if (kind === 'wrong') { tone(220, 0, 0.18, 'square', v * 0.45); tone(165, 0.12, 0.3, 'square', v * 0.45); }
    else if (kind === 'pass') { [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.32, 'triangle', v)); }
    else if (kind === 'complete') { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, i * 0.11, i === 5 ? 0.6 : 0.22, 'triangle', v)); tone(262, 0.55, 0.6, 'sine', v * 0.6); }
    else if (kind === 'tap') tone(660, 0, 0.06, 'sine', v * 0.4);
  } catch (e) { /* audio is optional */ }
}
BS.sound = sound;

// ---------------- state ----------------
const LS_KEY = 'bitscribe-python.state.v1';
const WRITER_DEFAULTS = { topic: 'The Water Cycle', title: '', audience: 'high school students', author: '', pages: 12, volumes: 1, chapters: 0, sections: 0,
  tokens_per_hit: 400, web: 1, web_sources: 3, diagrams: 1, diagram_every: 2, exercises: 1, key_ideas: 1, toc: 1, index: 1,
  temperature: 0.7, top_p: 0.9, top_k: 40, repeat_penalty: 1.15, seed: 42, font: 'serif', font_size: 11, line_spacing: 1.35, margin_mm: 20, sources: '' };
function defaults() {
  return { v: 1, xp: 0, streak: 0, lastDay: '', dayXp: {}, done: {}, code: {}, drafts: {}, hints: {}, attempts: {}, cheats: {}, graduated: 0, t: 0,
    settings: { allowPaste: false, unlockAll: false, sound: true, volume: 0.7, theme: 'auto', font: 'calibri', fontSize: 17, codeSize: 14, dailyGoal: 30 },
    writer: { ...WRITER_DEFAULTS }, machine: { src: '' } };
}
function loadState() {
  let s = null;
  try { s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch (e) { s = null; }
  const d = defaults();
  if (!s || typeof s !== 'object') return d;
  return { ...d, ...s, settings: { ...d.settings, ...(s.settings || {}) }, writer: { ...d.writer, ...(s.writer || {}) }, machine: { ...d.machine, ...(s.machine || {}) } };
}
let S = loadState();
BS.S = () => S;
let saveTimer = null;
function save(opts) {
  S.t = Date.now();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) { /* private mode */ }
    if (!(opts && opts.local)) Sync.schedule();
  }, 250);
}
BS.save = save;
function addXp(n) {
  const d = today();
  if (S.lastDay !== d) {
    const y = new Date(); y.setDate(y.getDate() - 1);
    const yd = y.getFullYear() + '-' + String(y.getMonth() + 1).padStart(2, '0') + '-' + String(y.getDate()).padStart(2, '0');
    S.streak = S.lastDay === yd ? S.streak + 1 : 1;
    S.lastDay = d;
  }
  S.xp += n;
  S.dayXp[d] = (S.dayXp[d] || 0) + n;
  const keys = Object.keys(S.dayXp).sort();
  while (keys.length > 60) delete S.dayXp[keys.shift()];
  save();
  updateStats();
}

// ---------------- appearance: theme, font, sizes, fullscreen ----------------
const FONTS = {
  calibri: { label: 'Calibri (default)', css: 'Calibri, Carlito, "Segoe UI", system-ui, sans-serif' },
  nunito: { label: 'Nunito (rounded)', css: 'Nunito, system-ui, sans-serif' },
  atkinson: { label: 'Atkinson Hyperlegible (easy to read)', css: '"Atkinson Hyperlegible", system-ui, sans-serif' },
  lexend: { label: 'Lexend (made for reading)', css: 'Lexend, system-ui, sans-serif' },
  dyslexic: { label: 'OpenDyslexic', css: 'OpenDyslexic, system-ui, sans-serif', app: true },
  merriweather: { label: 'Merriweather (serif)', css: 'Merriweather, Georgia, serif' },
  system: { label: 'System font', css: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
};
if (!IS_APP) for (const k of Object.keys(FONTS)) if (FONTS[k].app) delete FONTS[k];
BS.FONTS = FONTS;
function applyLook() {
  const st = S.settings, root = document.documentElement;
  const dark = st.theme === 'dark' || (st.theme === 'auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  root.dataset.theme = dark ? 'dark' : 'light';
  root.style.setProperty('--font', (FONTS[st.font] || FONTS.calibri).css);
  root.style.setProperty('--fs', st.fontSize + 'px');
  root.style.setProperty('--code-size', st.codeSize + 'px');
  const tb = $('#btn-theme'); if (tb) tb.textContent = dark ? '☀️' : '🌙';
  if (IS_APP && window.BitScribeApp.setDark) try { window.BitScribeApp.setDark(!!dark); } catch (e) {}
  document.querySelectorAll('.CodeMirror').forEach(c => c.CodeMirror && c.CodeMirror.refresh());
}
BS.applyLook = applyLook;
if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyLook);
let appFullscreen = false;
async function toggleFullscreen() {
  if (IS_APP && window.BitScribeApp.setFullscreen) {
    appFullscreen = !appFullscreen;
    try { window.BitScribeApp.setFullscreen(appFullscreen); } catch (e) {}
    return;
  }
  try {
    if (document.fullscreenElement || document.webkitFullscreenElement) await (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else await (document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen).call(document.documentElement);
  } catch (e) { toast('Full screen is not allowed here. Open the app on its own page, or use the Android app.'); }
}
BS.toggleFullscreen = toggleFullscreen;

// ---------------- data ----------------
let COURSE = null, REF = null, ASSETS = null, MODEL = null;
let LESSONS = [], BY_ID = {}, UNITS = [];
const refCache = {};
function unobf(b64) {
  const bin = atob(b64), n = bin.length, u = new Uint8Array(n);
  for (let i = 0; i < n; i++) u[i] = bin.charCodeAt(i) ^ ((i * 7 + 13) & 255);
  return new TextDecoder().decode(u);
}
function refCode(name) { if (!(name in refCache)) refCache[name] = unobf(REF.items[name].code); return refCache[name]; }
const b64bytes = (b64) => { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
BS.refCode = refCode;
async function loadData(onMsg) {
  const get = async (p) => { const r = await fetch(p); if (!r.ok) throw new Error(p + ': ' + r.status); return r.json(); };
  onMsg('Loading the course…');
  [COURSE, REF, ASSETS] = await Promise.all([get('data/course.json'), get('data/ref.json'), get('data/assets.json')]);
  onMsg('Loading the BitNet model…');
  MODEL = await get('data/model.json');
  UNITS = COURSE.units;
  let idx = 0;
  for (const u of UNITS) for (const L of u.lessons) { L.index = idx++; L.unitObj = u; LESSONS.push(L); BY_ID[L.id] = L; }
  Object.assign(BS, { COURSE, REF, ASSETS, LESSONS, BY_ID, UNITS });
}
// Small AFM files rebuilt from Adobe's metrics (only the widths BitScribe uses; the change is noted in each file).
let afmCache = null;
function afmTexts() {
  if (afmCache) return afmCache;
  afmCache = {};
  for (const [name, m] of Object.entries(ASSETS.metrics)) {
    let t = 'StartFontMetrics 4.1\nComment ' + m.copyright + '\nComment MODIFIED by BitScribe: this file keeps only the character widths that BitScribe uses; the original Adobe AFM file has more data. See readme.txt and NOTE.txt.\nFontName ' + name + '\nNotice ' + m.notice + '\nStartCharMetrics ' + m.lines.length + '\n';
    for (const [c, w, n] of m.lines) t += 'C ' + c + ' ; WX ' + w + ' ; N ' + n + ' ;\n';
    afmCache[name] = t + 'EndCharMetrics\nEndFontMetrics\n';
  }
  return afmCache;
}
BS.afmTexts = afmTexts;
function baseFiles() {
  const out = [['models/tiny.bnet', b64bytes(MODEL.bnet)], ['models/tiny.tok', b64bytes(MODEL.tok)]];
  const enc = new TextEncoder();
  for (const [name, text] of Object.entries(afmTexts())) out.push(['fonts/' + name + '.afm', enc.encode(text)]);
  return out;
}
BS.modelBytes = () => ({ bnet: b64bytes(MODEL.bnet), tok: b64bytes(MODEL.tok) });

// lesson kinds
const isCoding = (L) => !L.program && !L.graduation && L.items && L.items.length > 0;
const isProgram = (L) => !!L.program;
// a lesson that writes parts of BitScribe (the intro lessons practise on small functions of their own)
const isProject = (L) => isCoding(L) && L.items.every(it => REF.items[it]);
BS.isCoding = isCoding;
BS.isProject = isProject;
const TOTAL_PARTS = () => REF.order.length;
function partsWritten() { let n = 0; for (const L of LESSONS) if (isProject(L) && S.done[L.id] && S.code[L.id]) n += L.items.length; return n; }
BS.partsWritten = partsWritten;
BS.TOTAL_PARTS = TOTAL_PARTS;
function isUnlocked(L) {
  if (S.settings.unlockAll || L.index === 0 || S.done[L.id]) return true;
  if (L.graduation) return LESSONS.every(x => x === L || x.graduation || S.done[x.id]);
  const prev = LESSONS[L.index - 1];
  return !!S.done[prev.id];
}
function currentLesson() { return LESSONS.find(L => !S.done[L.id] && isUnlocked(L)) || null; }
function updateStats() {
  $('#st-streak').textContent = S.streak || 0;
  $('#st-xp').textContent = S.xp || 0;
  $('#st-parts').textContent = REF ? partsWritten() + '/' + TOTAL_PARTS() : '0';
}
BS.updateStats = updateStats;

// ---------------- Python (Pyodide) in Web Workers ----------------
// Pyodide is the real Python, compiled to WebAssembly. Each Runner is one worker with its own Python.
// The app looks for Pyodide next to the page first; a hosted page that could not include it uses the Pyodide CDN.
const PYODIDE_CDN = 'https://cdn.jsdelivr.net/pyodide/v314.0.8/full/';
function pyodideUrls() {
  const local = new URL('pyodide/', location.href).href;
  return IS_APP ? [local] : [local, PYODIDE_CDN];
}
class Runner {
  constructor(name) { this.name = name; this.w = null; this.jobs = new Map(); this.seq = 0; this.readyP = null; this.state = 'off'; }
  ensure() {
    if (this.readyP) return this.readyP;
    this.readyP = this.start();
    this.readyP.catch(() => { this.readyP = null; });
    return this.readyP;
  }
  start() {
    return new Promise((resolve, reject) => {
      this.state = 'loading';
      let w;
      try { w = new Worker('worker.js'); } catch (e) { this.state = 'off'; reject(e); return; }
      this.w = w;
      w.onmessage = (e) => {
        const m = e.data;
        if (m.type === 'ready') { this.state = 'ready'; BS.pyInfo = m.info; resolve(); return; }
        if (m.type === 'failed') { this.state = 'off'; this.w = null; w.terminate(); reject(new Error(m.msg)); return; }
        const j = this.jobs.get(m.id);
        if (!j) return;
        if (m.type === 'out') { if (j.h.onOut) j.h.onOut(m.text, m.err); if (m.err) j.err += m.text; else j.out += m.text; if (j.out.length > 4e6) j.out = j.out.slice(-2e6); }
        else if (m.type === 'files') { if (j.h.onFiles) j.h.onFiles(m.files); }
        else if (m.type === 'done') { this.jobs.delete(m.id); j.resolve({ ...m.res, files: m.files || [], out: j.out, err: j.err }); }
      };
      w.onerror = (e) => { if (this.state === 'loading') { this.state = 'off'; reject(new Error(e.message || 'the Python worker could not start')); } };
      w.postMessage({ type: 'init', urls: pyodideUrls(), packed: !IS_APP, base: baseFiles(), runtime: ASSETS.runtime, articles: ASSETS.articles,
        items: REF.order.map(n => [n, refCode(n)]) });
    });
  }
  async run(job, handlers) {
    try { await this.ensure(); }
    catch (e) { return { error: { kind: 'startup', msg: e.message }, fails: [], checks: 0, files: [], out: '', err: '' }; }
    const id = ++this.seq;
    return new Promise((resolve) => {
      this.jobs.set(id, { resolve, h: handlers || {}, out: '', err: '' });
      this.w.postMessage({ type: 'run', id, job });
    });
  }
  async call(type, data) {
    await this.ensure();
    const id = ++this.seq;
    return new Promise((resolve) => { this.jobs.set(id, { resolve, h: {}, out: '', err: '' }); this.w.postMessage({ type, id, ...data }); });
  }
  stop() {
    if (!this.w) return;
    this.w.terminate(); this.w = null; this.readyP = null; this.state = 'off';
    for (const [, j] of this.jobs) j.resolve({ stopped: true, error: null, fails: [], checks: 0, files: [], out: j.out, err: j.err });
    this.jobs.clear();
  }
  busy() { return this.jobs.size > 0; }
}
const testRunner = new Runner('main');
BS.Runner = Runner;
BS.testRunner = testRunner;
// start Python early: loading it takes a few seconds
BS.warmUp = () => { setTimeout(() => testRunner.ensure().catch(() => {}), 1200); };

// The learner's whole program, lesson by lesson. Missing parts can be filled with the course's code (hidden) for demos.
// Lines that are not definitions (experiments) are turned into comments when the parts are joined.
function programChunks(opts) {
  opts = opts || {};
  const chunks = [], missing = [];
  const mod = opts.moduleName;
  for (const L of LESSONS) {
    if (!isProject(L)) continue;
    const keepMain = L.items.includes('main');
    const mine = S.done[L.id] && S.code[L.id];
    if (mine) chunks.push({ name: 'your code: ' + L.title, code: S.code[L.id].src, strip: true, keep_main: keepMain, lesson: L.id, module_name: mod });
    else {
      missing.push(L);
      if (opts.fill) for (const it of L.items) chunks.push({ name: 'course code: ' + it, item: it, module_name: mod });
    }
  }
  for (const c of chunks) if (c.module_name === undefined) delete c.module_name;
  return { chunks, missing };
}
BS.programChunks = programChunks;

// The job that tests one lesson. Earlier parts come from the course's code (so every lesson is tested on its own),
// or from the learner's own code when ownEarlier is set (the whole-program check in "My code").
function lessonJob(L, src, ownEarlier) {
  const forbid = L.mustnot || [];
  if (isProgram(L)) return { mode: 'program', chunks: [{ name: 'your code', code: src, mine: true }], argv: ['program.py'], stdin: L.stdin || '', forbid };
  if (!isProject(L)) return { mode: 'test', chunks: [{ name: 'your code', code: src, mine: true }], need: L.need, test: L.test, argv: ['program.py'], forbid };
  const order = REF.order;
  const last = Math.max(...L.items.map(it => order.indexOf(it)));
  const before = order.slice(0, last + 1).filter(x => !L.items.includes(x));
  const chunks = [];
  if (ownEarlier) {
    const covered = new Set();
    for (const P of LESSONS) {
      if (P === L) break;
      if (!isProject(P)) continue;
      if (S.done[P.id] && S.code[P.id]) { chunks.push({ name: 'your code: ' + P.title, code: S.code[P.id].src, strip: true }); P.items.forEach(i => covered.add(i)); }
      else for (const it of P.items) if (before.includes(it)) { chunks.push({ name: 'course code: ' + it, item: it }); covered.add(it); }
    }
    for (const it of before) if (!covered.has(it)) chunks.push({ name: 'course code: ' + it, item: it });
  } else for (const it of before) chunks.push({ name: 'course code: ' + it, item: it });
  chunks.push({ name: 'your code', code: src, mine: true });
  return { mode: 'test', chunks, need: L.need, test: L.test, argv: ['bitscribe.py'], forbid };
}
BS.lessonJob = lessonJob;

// Turn a finished run into something a learner can read.
function interpret(L, res) {
  const r = { pass: false, error: res.error || null, fails: res.fails || [], output: '', expectDiff: null, stopped: !!res.stopped, exitCode: res.exit_code || 0, checks: res.checks || 0 };
  if (res.stopped) return r;
  r.output = (res.out || '').replace(/\n+$/, '');
  if (res.err) r.output += (r.output ? '\n' : '') + res.err.replace(/\n+$/, '');
  if (r.error) return r;
  if (L && isProgram(L)) {
    if (r.exitCode !== 0) { r.fails = ['your program stopped with exit code ' + r.exitCode]; return r; }
    r.pass = L.expect == null || res.out === L.expect;
    if (!r.pass) r.expectDiff = { want: L.expect, got: res.out || '' };
    return r;
  }
  if (r.exitCode !== 0 && !r.fails.length) r.fails = ['the program stopped with sys.exit(' + r.exitCode + ') before the tests had finished' + (res.err ? ': ' + res.err.trim().split('\n').pop() : '')];
  r.pass = r.fails.length === 0 && r.checks > 0 && r.exitCode === 0;
  if (!r.pass && !r.fails.length) r.fails = ['the tests did not run any checks'];
  return r;
}
BS.interpret = interpret;

// ---------------- text rendering (lesson cards) ----------------
const PY_KW = new Set('False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case'.split(' '));
const PY_BUILTIN = new Set('print len range int float str bytes bytearray list dict set tuple bool open sum min max abs round sorted enumerate zip map filter isinstance type super object repr chr ord hex bin any all iter next reversed divmod pow input getattr setattr hasattr self np math sys struct json time codecs dataclass field'.split(' '));
function hlPy(code) {
  let out = '', i = 0;
  const n = code.length;
  while (i < n) {
    const c = code[i];
    if (c === '#') { const e = code.indexOf('\n', i); const j = e < 0 ? n : e; out += `<span class="hl-c">${esc(code.slice(i, j))}</span>`; i = j; continue; }
    if (c === '"' || c === "'") {
      const triple = code.substr(i, 3) === c + c + c;
      let j;
      if (triple) { const e = code.indexOf(c + c + c, i + 3); j = e < 0 ? n : e + 3; }
      else { j = i + 1; while (j < n && code[j] !== c && code[j] !== '\n') j += code[j] === '\\' ? 2 : 1; j = Math.min(n, j + 1); }
      out += `<span class="hl-s">${esc(code.slice(i, j))}</span>`; i = j; continue;
    }
    if (/[0-9]/.test(c) && !/[A-Za-z_]/.test(code[i - 1] || '')) { const m = /^(0x[0-9a-fA-F_]+|0b[01_]+|\d[\d_]*\.?\d*([eE][-+]?\d+)?j?)/.exec(code.slice(i)); out += `<span class="hl-n">${esc(m[0])}</span>`; i += m[0].length; continue; }
    if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_]\w*/.exec(code.slice(i)); const w = m[0];
      // a string prefix like b"..." or f"..."
      if (/^[bBrRfFuU]{1,2}$/.test(w) && (code[i + w.length] === '"' || code[i + w.length] === "'")) {
        const q = code[i + w.length]; let j = i + w.length + 1; while (j < n && code[j] !== q && code[j] !== '\n') j += code[j] === '\\' ? 2 : 1; j = Math.min(n, j + 1);
        out += `<span class="hl-s">${esc(code.slice(i, j))}</span>`; i = j; continue;
      }
      if (PY_KW.has(w)) out += `<span class="hl-k">${w}</span>`;
      else if (PY_BUILTIN.has(w)) out += `<span class="hl-t">${w}</span>`;
      else if (code[i + w.length] === '(' ) out += `<span class="hl-f">${w}</span>`;
      else out += esc(w);
      i += w.length; continue;
    }
    if (c === '@' && (i === 0 || code[i - 1] === '\n' || /^\s*$/.test(code.slice(code.lastIndexOf('\n', i - 1) + 1, i)))) { const m = /^@[\w.]+/.exec(code.slice(i)); if (m) { out += `<span class="hl-p">${esc(m[0])}</span>`; i += m[0].length; continue; } }
    out += esc(c); i++;
  }
  return out;
}
window.hlPy = BS.hlPy = hlPy;
function hlCode(code, lang) {
  if (lang === 'text' || lang === 'txt' || lang === 'pdf') return esc(code);
  return hlPy(code);
}
BS.hlCode = hlCode;
function inline(s) {
  return esc(s).replace(/`([^`]+)`/g, (m, c) => `<code>${c}</code>`).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
}
BS.inline = inline;
function md(text) {
  const lines = text.split('\n');
  let html = '', i = 0, para = [];
  const flush = () => { if (para.length) { html += `<p>${inline(para.join(' '))}</p>`; para = []; } };
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.startsWith('```')) {
      flush();
      const lang = ln.slice(3).trim().toLowerCase();
      const code = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) code.push(lines[i++]);
      i++;
      html += `<pre><code>${hlCode(code.join('\n'), lang)}</code></pre>`;
      continue;
    }
    if (ln.startsWith('[DIAGRAM')) {
      flush();
      const d = Diagrams.parse(ln);
      const svg = d && Diagrams.render(d);
      if (svg) html += svg;
      i++; continue;
    }
    if (/^\s*-\s+/.test(ln)) {
      flush();
      html += '<ul>';
      while (i < lines.length && /^\s*-\s+/.test(lines[i])) { html += `<li>${inline(lines[i].replace(/^\s*-\s+/, ''))}</li>`; i++; }
      html += '</ul>'; continue;
    }
    if (/^\s*\d+\.\s+/.test(ln)) {
      flush();
      html += '<ol>';
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        let item = lines[i].replace(/^\s*\d+\.\s+/, ''); i++;
        while (i < lines.length && /^\s{2,}-\s+/.test(lines[i])) { item += '\n- ' + lines[i].replace(/^\s+-\s+/, ''); i++; }
        const [first, ...subs] = item.split('\n- ');
        html += `<li>${inline(first)}${subs.length ? '<ul>' + subs.map(x => `<li>${inline(x)}</li>`).join('') + '</ul>' : ''}</li>`;
      }
      html += '</ol>'; continue;
    }
    if (!ln.trim()) { flush(); i++; continue; }
    para.push(ln.trim()); i++;
  }
  flush();
  return html;
}
BS.md = md;

// ---------------- code editor ----------------
function makeEditor(host, value, opts) {
  opts = opts || {};
  if (window.CodeMirror) {
    const cm = CodeMirror(host, {
      value: value || '', mode: { name: 'python', version: 3, singleLineStringErrors: false }, theme: 'bs', lineNumbers: true, matchBrackets: true,
      autoCloseBrackets: { pairs: '()[]{}""\'\'' }, indentUnit: 4, tabSize: 4, indentWithTabs: false, styleActiveLine: true, readOnly: !!opts.readOnly, lineWrapping: false,
      gutters: opts.breakpoints ? ['bp-gutter', 'CodeMirror-linenumbers'] : ['CodeMirror-linenumbers'],
      extraKeys: {
        Tab: (c) => c.somethingSelected() ? c.indentSelection('add') : c.replaceSelection('    ', 'end'),
        'Shift-Tab': (c) => c.indentSelection('subtract'),
        Backspace: (c) => {
          // delete a whole level of indentation (4 spaces) at once
          if (c.somethingSelected()) return CodeMirror.Pass;
          const cur = c.getCursor(), line = c.getLine(cur.line), before = line.slice(0, cur.ch);
          if (cur.ch > 0 && /^ +$/.test(before)) { const n = ((cur.ch - 1) % 4) + 1; c.replaceRange('', { line: cur.line, ch: cur.ch - n }, cur); return; }
          return CodeMirror.Pass;
        },
        'Ctrl-Enter': () => opts.onRun && opts.onRun(), 'Cmd-Enter': () => opts.onRun && opts.onRun(),
        'Ctrl-/': (c) => toggleComment(c), 'Cmd-/': (c) => toggleComment(c),
      },
      inputStyle: 'contenteditable', spellcheck: false, autocorrect: false, autocapitalize: false,
    });
    cm.on('beforeChange', (c, ch) => {
      if ((ch.origin === 'paste' || ch.origin === 'drop') && !S.settings.allowPaste && !opts.allowPaste) {
        ch.cancel();
        toast('Pasting is off, so that you type every line yourself. You can turn it on in Profile → Settings.');
      }
    });
    if (opts.onChange) cm.on('changes', () => opts.onChange(cm.getValue()));
    setTimeout(() => cm.refresh(), 30);
    return {
      get: () => cm.getValue(), set: (v) => cm.setValue(v), focus: () => cm.focus(), cm,
      mark(line) { cm.eachLine(l => { cm.removeLineClass(l, 'background', 'cm-errline'); }); if (line > 0 && line <= cm.lineCount()) { cm.addLineClass(line - 1, 'background', 'cm-errline'); cm.scrollIntoView({ line: line - 1, ch: 0 }, 80); } },
      // the stepper's current line
      current(line) { cm.eachLine(l => { cm.removeLineClass(l, 'background', 'cm-curline'); }); if (line > 0 && line <= cm.lineCount()) { cm.addLineClass(line - 1, 'background', 'cm-curline'); cm.scrollIntoView({ line: line - 1, ch: 0 }, 80); } },
    };
  }
  const ta = h('<textarea class="plain-editor" spellcheck="false" autocapitalize="off" autocomplete="off"></textarea>');
  ta.addEventListener('keydown', (e) => { if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); const p = ta.selectionStart; ta.setRangeText('    ', p, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input')); } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && opts.onRun) { e.preventDefault(); opts.onRun(); } });
  ta.value = value || '';
  if (opts.readOnly) ta.readOnly = true;
  ta.addEventListener('paste', (e) => { if (!S.settings.allowPaste && !opts.allowPaste) { e.preventDefault(); toast('Pasting is off. You can turn it on in Profile → Settings.'); } });
  if (opts.onChange) ta.addEventListener('input', () => opts.onChange(ta.value));
  host.appendChild(ta);
  return { get: () => ta.value, set: (v) => { ta.value = v; }, focus: () => ta.focus(), mark() {}, current() {} };
}
function toggleComment(c) {
  const from = c.getCursor('from').line, to = c.getCursor('to').line;
  const lines = []; for (let i = from; i <= to; i++) lines.push(c.getLine(i));
  const all = lines.filter(l => l.trim()).every(l => /^\s*#/.test(l));
  c.operation(() => { for (let i = from; i <= to; i++) { const l = c.getLine(i); if (!l.trim()) continue; const nl = all ? l.replace(/^(\s*)# ?/, '$1') : l.replace(/^(\s*)/, '$1# '); c.replaceRange(nl, { line: i, ch: 0 }, { line: i, ch: l.length }); } });
}
BS.makeEditor = makeEditor;

// ---------------- result panel ----------------
// Where an error happened: the deepest frame in the learner's code, and a readable description.
function errorWhere(err) {
  const frames = err.frames || [];
  const mineIdx = frames.map((f, i) => /^your code/.test(f.file) ? i : -1).filter(i => i >= 0);
  const last = frames[frames.length - 1] || null;
  const mine = mineIdx.length ? frames[mineIdx[mineIdx.length - 1]] : null;
  return { frames, mine, last, inTest: last && last.file === 'test', mineIsLast: mine && mine === last };
}
BS.errorWhere = errorWhere;
const FRIENDLY = {
  NameError: 'Python does not know this name. Check the spelling, and that it was defined (or imported) before it is used.',
  IndentationError: 'Python uses the spaces at the start of a line to group code. Lines inside a def, if, for or while must be indented by the same amount (4 spaces each level).',
  TabError: 'Do not mix tabs and spaces for indentation: use 4 spaces.',
  TypeError: 'A value has the wrong type for what the code does with it (for example adding a number to a string, or calling a function with the wrong number of arguments).',
  AttributeError: 'The object has no attribute or method with that name. Check the spelling, and what kind of object it is.',
  IndexError: 'An index is outside the list or array: remember that indexes start at 0 and the last one is len - 1.',
  KeyError: 'That key is not in the dict. Use .get(key, default) or check with "in" first.',
  ZeroDivisionError: 'Something was divided by zero.',
  ValueError: 'A function got a value of the right type but the wrong kind (like int("twelve")).',
  RecursionError: 'A function calls itself again and again without stopping.',
  UnboundLocalError: 'A variable is used in a function before it has been given a value there.',
};
function errorHtml(err, editor, ctx) {
  ctx = ctx || {};
  let html = '';
  if (err.kind === 'syntax') {
    const mine = /^your code/.test(err.chunk || '');
    const lessonName = err.chunk && err.chunk.startsWith('your code: ') ? ` (in the lesson “${esc(err.chunk.slice(11))}”)` : '';
    html += `<div class="res err"><h4>${err.type === 'IndentationError' || err.type === 'TabError' ? 'The indentation is not right yet' : 'Python cannot read your code yet'}</h4>`;
    html += `<p>${mine && err.line ? `<b>Line ${err.line}${lessonName}:</b> ` : ''}${esc(err.msg)}</p>`;
    if (err.text) html += `<pre class="console">${esc(err.text)}${err.col > 0 ? '\n' + ' '.repeat(Math.max(0, err.col - 1)) + '^'.repeat(Math.max(1, Math.min(40, (err.end_col || err.col + 1) - err.col))) : ''}</pre>`;
    if (FRIENDLY[err.type]) html += `<p class="muted">${esc(FRIENDLY[err.type])}</p>`;
    else html += '<p class="muted">Check the line (and the one before it) for a missing colon, bracket or quote.</p>';
    if (err.internal) html += '<p class="muted">This is a problem in the lesson\'s own test, not in your code. Please report it.</p>';
    html += '</div>';
    if (editor && mine && !ctx.otherLesson) editor.mark(err.line);
    return html;
  }
  if (err.kind === 'missing') {
    if (editor) editor.mark(0);
    return `<div class="res err"><h4>Something is missing</h4><p>Your code does not define ${err.names.map(n => `<code>${esc(n)}</code>`).join(', ')}.</p><p class="muted">Check the spelling: Python names are case-sensitive, and the tests look for exactly these names.</p></div>`;
  }
  if (err.kind === 'forbidden') {
    if (editor) editor.mark(err.line);
    return `<div class="res err"><h4>Write it another way</h4><p>This lesson asks you not to use <code>${esc(err.pattern)}</code> (line ${err.line}). Read the task again for the tool it wants you to practise.</p></div>`;
  }
  if (err.kind === 'output') return `<div class="res err"><h4>Too much output</h4><p>${esc(err.msg)}. A loop may be printing forever.</p></div>`;
  if (err.kind === 'startup') return `<div class="res err"><h4>Python could not start</h4><p>${esc(err.msg)}</p><p class="muted">${IS_APP ? 'Python is built into this app. If it does not start, update “Android System WebView” and Chrome from the Play Store, restart the app and try again.' : 'Python is loaded the first time you run code (about 15 MB). Check the internet connection and press the button again. Python needs an up-to-date browser (Chrome, Edge, Firefox or Safari).'}</p></div>`;
  if (err.kind === 'musthave') return `<div class="res err"><h4>Something is missing</h4>Your code must contain:<pre>${esc(err.missing.join('\n'))}</pre></div>`;
  if (err.kind === 'exception') {
    const w = errorWhere(err);
    const full = err.full || (err.type + ': ' + err.msg);
    let head, body = '';
    if (w.mine) {
      const lessonName = w.mine.file.startsWith('your code: ') ? ` of the lesson “${esc(w.mine.file.slice(11))}”` : '';
      head = w.mineIsLast ? 'Your code stopped with an error' : 'Your code called something that stopped with an error';
      body += `<p>On <b>line ${w.mine.line}</b>${lessonName}${w.mine.func && w.mine.func !== '<module>' ? ` (in <code>${esc(w.mine.func)}</code>)` : ''}:</p><pre class="console">${esc(w.mine.text)}\n${esc(full)}</pre>`;
      if (!w.mineIsLast && w.last) body += `<p class="muted">The error itself happened in ${/^course code/.test(w.last.file) ? 'the course\'s code for <code>' + esc(w.last.func) + '</code>' : esc(w.last.file)}: often that means your code passed it a value of the wrong kind.</p>`;
      if (editor && !ctx.otherLesson && w.mine.file === 'your code') editor.mark(w.mine.line);
    } else if (w.inTest) {
      head = 'The test could not use what your code gave back';
      body += `<pre class="console">${esc(full)}</pre><p>In the test: <code>${esc(w.last.text)}</code></p><p class="muted">Check what your function returns: the right kind of value (a tuple of two? a list? a number?), and not None.</p>`;
    } else {
      head = 'The program stopped with an error';
      body += `<pre class="console">${esc(full)}</pre>`;
      if (w.last) body += `<p class="muted">It happened in ${/^course code/.test(w.last.file) ? 'the course\'s code for <code>' + esc(w.last.func) + '</code>' : esc(w.last.file) + ', line ' + w.last.line}, called by the test. Often that means your function returned something unexpected, or changed something it should not.</p>`;
    }
    if (FRIENDLY[err.type]) body += `<p class="muted">💡 ${esc(FRIENDLY[err.type])}</p>`;
    return `<div class="res err"><h4>${head}</h4>${body}</div>`;
  }
  return `<div class="res err"><h4>Something went wrong</h4><pre class="console">${esc(JSON.stringify(err))}</pre></div>`;
}
BS.errorHtml = errorHtml;
function renderResult(box, L, r, editor, extra) {
  let html = '';
  if (r.stopped) html = `<div class="res info"><h4>Stopped</h4>The program was stopped before it finished.</div>`;
  else if (r.error) {
    // checks that failed before the error usually explain it best ("... should be [..], but it is None"), so show them first
    if (r.fails.length && r.error.kind === 'exception') html += `<div class="res err"><h4>Not yet — keep going!</h4><ul>${r.fails.slice(0, 5).map(f => `<li>${esc(f)}</li>`).join('')}</ul>${r.fails.length > 5 ? `<p class="muted">…and ${r.fails.length - 5} more.</p>` : ''}<p class="muted">After these, the test stopped with an error:</p></div>`;
    html += errorHtml(r.error, editor);
  }
  else if (r.pass) {
    html = `<div class="res ok"><h4>✅ ${isProgram(L) ? 'Your program printed exactly the right text!' : 'All tests passed!'}</h4>${extra || ''}</div>`;
    if (editor) editor.mark(0);
  } else {
    let body = '';
    if (r.fails.length) body += `<ul>${r.fails.slice(0, 8).map(f => `<li>${esc(f)}</li>`).join('')}</ul>${r.fails.length > 8 ? `<p class="muted">…and ${r.fails.length - 8} more.</p>` : ''}`;
    if (r.expectDiff) {
      const w = r.expectDiff.want, g = r.expectDiff.got;
      let k = 0; while (k < w.length && w[k] === g[k]) k++;
      const lineNo = w.slice(0, k).split('\n').length;
      body += `<p>The output is different from what was expected, starting on output line ${lineNo}.</p><div class="grid2"><div><b>Expected</b><pre>${esc(w)}</pre></div><div><b>Your program printed</b><pre>${esc(g || '(nothing)')}</pre></div></div>`;
    }
    if (!body) body = '<p>The tests did not finish. Check the output below.</p>';
    html = `<div class="res err"><h4>Not yet — keep going!</h4>${body}</div>`;
  }
  if (r.output && r.output.trim() && !r.expectDiff) html += `<details ${r.pass ? '' : 'open'}><summary class="muted">What your code printed</summary><pre class="console">${esc(r.output.slice(-6000))}</pre></details>`;
  box.innerHTML = html;
}
BS.renderResult = renderResult;

// ---------------- downloads ----------------
let downloadsCap = undefined;
async function getDownloads() {
  if (downloadsCap !== undefined) return downloadsCap;
  try { downloadsCap = window.claude && window.claude.use ? await window.claude.use('downloads') : null; } catch (e) { downloadsCap = null; }
  return downloadsCap;
}
const MIME = { pdf: 'application/pdf', zip: 'application/zip', txt: 'text/plain', md: 'text/markdown', json: 'application/json', html: 'text/html', py: 'text/x-python' };
async function saveFile(filename, data) {
  const ext = filename.split('.').pop().toLowerCase();
  const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data instanceof Blob ? new Uint8Array(await data.arrayBuffer()) : data;
  if (IS_APP && window.BitScribeApp.saveFile) {
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    try { window.BitScribeApp.saveFile(filename, MIME[ext] || 'application/octet-stream', btoa(bin)); } catch (e) { toast('Saving failed: ' + e.message); }
    return;
  }
  const dl = await getDownloads();
  if (dl) {
    try { await dl.save({ filename, data: new Blob([bytes]) }); toast('Saved ' + filename); }
    catch (e) { if (e && e.code !== 'declined') toast('Could not save: ' + (e.message || e.code)); }
    return;
  }
  try {
    const url = URL.createObjectURL(new Blob([bytes], { type: MIME[ext] || 'application/octet-stream' }));
    const a = h(`<a href="${url}" download="${esc(filename)}"></a>`);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (e) { toast('Downloads are not available here.'); }
}
BS.saveFile = saveFile;
window.__bsSaved = (ok, name) => toast(ok ? 'Saved ' + (name || 'the file') : 'The file was not saved.');
function openPdf(bytes, title) {
  PdfViewer.open(bytes, { title, afm: afmTexts(), onDownload: () => saveFile((title || 'book').replace(/[^\w.-]+/g, '_').replace(/(\.pdf)?$/, '.pdf'), bytes) });
}
BS.openPdf = openPdf;

// ---------------- celebration ----------------
function confetti() {
  const box = h('<div class="confetti"></div>');
  const colors = ['#22b86b', '#2f6fe4', '#f5b72e', '#e5484d', '#7b5cf0', '#18c2c9'];
  for (let i = 0; i < 70; i++) {
    const p = document.createElement('i');
    p.style.left = Math.random() * 100 + 'vw';
    p.style.background = colors[i % colors.length];
    p.style.animationDelay = Math.random() * 0.7 + 's';
    p.style.animationDuration = 1.8 + Math.random() * 1.4 + 's';
    box.appendChild(p);
  }
  document.body.appendChild(box);
  setTimeout(() => box.remove(), 4200);
}
BS.confetti = confetti;

// ---------------- Learn tab: the path ----------------
const ICON = { done: '✓', code: 'py', program: '▶', read: '★', grad: '🎓', lock: '🔒' };
function renderLearn(view) {
  const done = LESSONS.filter(L => S.done[L.id]).length;
  const cur = currentLesson();
  const goal = S.settings.dailyGoal, todayXp = S.dayXp[today()] || 0;
  view.innerHTML = `
    <div class="overview">
      <div class="card">
        <h2 style="margin-top:0">Build a BitNet textbook writer in Python</h2>
        <p class="sub" style="margin:0 0 10px">Learn Python from your very first line, then write every function yourself: a 1.58-bit language model, a tokenizer, web research, planning, page layout, diagrams and PDF files. Then use <b>your</b> program to write textbooks.</p>
        <div class="bar"><i style="width:${(100 * done / LESSONS.length).toFixed(1)}%"></i></div>
        <div class="row" style="margin-top:8px"><span class="muted">${done} of ${LESSONS.length} lessons · ${partsWritten()} of ${TOTAL_PARTS()} parts written by you</span><span class="grow"></span>${cur ? `<button class="btn primary" id="go-cur">${done ? 'Continue' : 'Start'}</button>` : ''}</div>
      </div>
      <div class="card" style="min-width:190px;text-align:center">
        <div class="muted">Today</div>
        <div style="font-size:28px;font-weight:900">${todayXp}<span class="muted" style="font-size:15px"> / ${goal} XP</span></div>
        <div class="bar" style="margin-top:6px"><i style="width:${Math.min(100, 100 * todayXp / goal)}%;background:var(--gold)"></i></div>
      </div>
    </div>
    <div id="units"></div>`;
  const unitsBox = $('#units', view);
  const offs = [0, 46, 70, 46, 0, -46, -70, -46];
  UNITS.forEach((u, ui) => {
    const ud = u.lessons.filter(L => S.done[L.id]).length;
    const wrap = h(`<section class="unit"><div class="unit-head" style="background:${esc(u.color)}"><div><div class="n">Unit ${ui + 1}</div><div class="t">${esc(u.title)}</div><div class="d">${esc(u.desc)}</div></div><div class="count">${ud}/${u.lessons.length}</div></div><div class="path"></div></section>`);
    const path = $('.path', wrap);
    u.lessons.forEach((L, li) => {
      const unlocked = isUnlocked(L), isDone = !!S.done[L.id], isCur = cur === L;
      const icon = isDone ? ICON.done : !unlocked ? ICON.lock : L.graduation ? ICON.grad : isProgram(L) ? ICON.program : isCoding(L) ? ICON.code : ICON.read;
      const color = isDone ? 'var(--gold)' : u.color;
      const n = h(`<div class="node ${unlocked ? '' : 'locked'} ${isCur ? 'current' : ''}" style="transform:translateX(${offs[li % 8]}px)" tabindex="0" role="button" aria-label="${esc(L.title)}${isDone ? ' (done)' : unlocked ? '' : ' (locked)'}">
        ${isCur ? '<div class="start">START</div>' : ''}
        <div class="dot" style="background:${color}">${icon}</div>
        ${isProject(L) ? `<div class="kind">${L.items.length} part${L.items.length > 1 ? 's' : ''}</div>` : ''}
        <div class="lbl">${esc(L.title)}</div></div>`);
      const open = () => { if (!unlocked) { toast('Finish the lessons before this one first (or unlock all lessons in Profile → Settings).'); return; } sound('tap'); location.hash = 'lesson-' + L.id; };
      n.onclick = open;
      n.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } };
      path.appendChild(n);
    });
    unitsBox.appendChild(wrap);
  });
  const go = $('#go-cur', view);
  if (go) go.onclick = () => { location.hash = 'lesson-' + cur.id; };
  if (cur) setTimeout(() => { const c = $('.node.current', view); if (c && window.scrollY < 50) c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 60);
}

// ---------------- a lesson ----------------
let lessonCleanup = null;
function starterCode(L) {
  if (isProgram(L)) return `# ${L.title}\n\n`;
  return `# ${L.title}\n# Write: ${L.items.join(', ')}\n\n`;
}
function renderLesson(view, L) {
  const steps = [];
  for (const c of L.cards) steps.push(c);
  if (isCoding(L) || isProgram(L)) steps.push({ kind: 'code' });
  if (L.graduation) steps.push({ kind: 'graduate' });
  let k = 0, mistakes = 0;
  const wasDone = !!S.done[L.id];
  view.innerHTML = `<div class="lesson-top"><button class="x" aria-label="Close the lesson">✕</button><div class="bar"><i></i></div><span class="muted" id="stepno"></span>${wasDone && steps.some(s => s.kind === 'code') ? '<button class="btn small" id="skip">Go to the code</button>' : ''}</div><div id="stage"></div>`;
  $('.x', view).onclick = () => { location.hash = 'learn'; };
  const stage = $('#stage', view);
  const skip = $('#skip', view);
  if (skip) skip.onclick = () => { k = steps.findIndex(s => s.kind === 'code'); show(); };
  function progress() {
    $('.lesson-top .bar > i', view).style.width = (100 * k / steps.length) + '%';
    $('#stepno', view).textContent = (k + 1) + ' / ' + steps.length;
  }
  function next() { k++; if (k >= steps.length) finish(); else show(); window.scrollTo(0, 0); }
  function show() {
    progress();
    const st = steps[k];
    if (lessonCleanup) { lessonCleanup(); lessonCleanup = null; }
    if (st.kind === 'learn') {
      stage.innerHTML = `<div class="lesson-card card learn md">${k === 0 ? `<div class="muted">${esc(L.unitObj.title)}</div><h2>${esc(L.title)}</h2>` : ''}${md(st.text)}<div class="foot"><button class="btn primary" id="cont">Continue</button></div></div>`;
      const b = $('#cont', stage); b.onclick = next; b.focus({ preventScroll: true });
    } else if (st.kind === 'quiz') showQuiz(st);
    else if (st.kind === 'code') showCode();
    else if (st.kind === 'graduate') showGraduate();
  }
  function showQuiz(q) {
    const order = q.opts.map((o, i) => i).sort(() => Math.random() - 0.5);
    stage.innerHTML = `<div class="lesson-card card quiz"><div class="muted">Quick check</div><h2>${inline(q.q)}</h2><div id="opts"></div><div id="fb"></div><div class="foot"><button class="btn primary" id="check" disabled>Check</button></div></div>`;
    let chosen = -1, answered = false;
    const optsBox = $('#opts', stage);
    order.forEach((oi, pos) => {
      const b = h(`<button class="opt"><span class="pill" style="margin-right:8px">${pos + 1}</span>${inline(q.opts[oi])}</button>`);
      b.onclick = () => { if (answered) return; chosen = oi; $$('.opt', optsBox).forEach(x => x.classList.remove('sel')); b.classList.add('sel'); $('#check', stage).disabled = false; };
      b.dataset.oi = oi;
      optsBox.appendChild(b);
    });
    const check = $('#check', stage);
    const keyh = (e) => { if (/^[1-9]$/.test(e.key) && !answered) { const b = $$('.opt', optsBox)[+e.key - 1]; if (b) b.click(); } else if (e.key === 'Enter' && !check.disabled) check.click(); };
    window.addEventListener('keydown', keyh);
    lessonCleanup = () => window.removeEventListener('keydown', keyh);
    check.onclick = () => {
      if (!answered) {
        answered = true;
        const right = chosen === q.answer;
        $$('.opt', optsBox).forEach(x => { const oi = +x.dataset.oi; if (oi === q.answer) x.classList.add('right'); else if (oi === chosen) x.classList.add('wrong'); });
        $('#fb', stage).innerHTML = `<div class="feedback ${right ? 'good' : 'bad'}">${right ? '🎉 Correct!' : 'Not quite.'} ${inline(q.why || '')}</div>`;
        sound(right ? 'correct' : 'wrong');
        if (right) { check.textContent = 'Continue'; }
        else { mistakes++; check.textContent = 'Try again'; }
        check.dataset.right = right ? '1' : '';
      } else if (check.dataset.right) next();
      else showQuiz(q);
    };
  }
  function showCode() {
    const saved = S.code[L.id] && S.code[L.id].src;
    const draft = S.drafts[L.id];
    const blank = starterCode(L);
    const start = draft != null ? draft : saved != null ? saved : blank;
    const hintsShown = S.hints[L.id] || 0;
    const learnCards = L.cards.filter(c => c.kind === 'learn');
    const heavy = (L.testMs || 0) > 3000;
    stage.innerHTML = `
      <div class="code-layout">
        <div class="card taskbox">
          <div class="muted">${esc(L.unitObj.title)} · ${esc(L.title)}</div>
          <h3>Your task</h3>
          <ol class="task-list">${L.task.map(t => `<li>${inline(t)}</li>`).join('')}</ol>
          ${isProject(L) ? `<div class="parts">${L.items.map(it => `<span class="pill blue">${esc(it)}</span>`).join('')}</div><p class="muted">Write all of ${L.items.length > 1 ? 'these parts' : 'this part'} in full. The tests compare your code with the course's own version; the earlier parts of BitScribe are already there for your code to use.</p>` : ''}
          ${heavy ? `<p class="hint">⏱️ This test runs the BitNet model with your code and with the course's code, so it takes a while: about ${fmtTime(L.testMs / 1000 * 1.2)} on a fast computer, and a few times longer on a phone.</p>` : ''}
          <div id="hints"></div>
          ${L.hints.length ? `<button class="btn small" id="hint-btn">Show a hint (${hintsShown}/${L.hints.length})</button>` : ''}
          ${L.solution ? '<button class="btn small cheat" id="sol-btn" disabled></button><div id="sol-box" class="sol-box" hidden></div>' : ''}
          <details class="review"><summary>Read the lesson again</summary><div class="md" style="margin-top:8px">${learnCards.map(c => md(c.text)).join('<hr style="border:0;border-top:2px solid var(--line);margin:14px 0">')}</div></details>
        </div>
        <div>
          <div class="card editor-card">
            <div class="editor-bar"><span class="name">${isProgram(L) ? 'program.py' : esc(L.id) + '.py' + (isProject(L) ? ' — ' + esc(L.items[0]) + (L.items.length > 1 ? ' …' : '') : '')}</span><span class="grow"></span>
              <button class="btn small" id="reset" title="Start again with an empty editor">Clear</button>
              <button class="btn primary" id="run">▶ Run tests</button></div>
            <div id="ed"></div>
            <div class="results" id="results"><p class="muted" style="margin:0">Write the code, then press <b>Run tests</b> (or Ctrl+Enter). ${isProject(L) ? 'Python runs your code together with the rest of BitScribe and tests it.' : isProgram(L) ? 'Python runs your program and compares what it prints.' : 'Python runs your code and tests it.'} <span id="pystate"></span></p></div>
          </div>
        </div>
      </div>`;
    const ps = $('#pystate', stage);
    if (ps && testRunner.state !== 'ready') { ps.textContent = '(Python is loading in the background…)'; testRunner.ensure().then(() => { if (ps.isConnected) ps.textContent = '(Python is ready.)'; }).catch(() => {}); }
    const solBtn = $('#sol-btn', stage), solBox = $('#sol-box', stage);
    const solState = () => {
      if (!solBtn) return;
      const n = S.attempts[L.id] || 0, open = n >= SOL_AFTER || !!S.cheats[L.id];
      solBtn.disabled = !open;
      solBtn.innerHTML = !open ? `🔒 Show the solution <span class="sol-count">after ${SOL_AFTER} tries · ${n}/${SOL_AFTER}</span>` : solBox.hidden ? '👀 Show the solution' : '🙈 Hide the solution';
      solBtn.title = open ? 'See the course\'s answer, then type it in yourself' : `Run the tests ${SOL_AFTER - n} more time${SOL_AFTER - n === 1 ? '' : 's'} first`;
    };
    if (solBtn) {
      solBtn.onclick = () => {
        if (solBtn.disabled) return;
        if (!solBox.hidden) { solBox.hidden = true; solState(); return; }
        if (!S.cheats[L.id]) { S.cheats[L.id] = 1; save(); }
        solBox.innerHTML = `<p class="muted" style="margin:0 0 8px">The course's answer. Read it, then <b>type it into the editor yourself</b> — typing it is how it sticks. You can't copy it from here${S.done[L.id] ? '' : ', and this lesson now gives its base XP without the no-help bonus'}.</p><div class="code-view sol-code">${hlPy(unobf(L.solution))}</div>`;
        solBox.hidden = false;
        solState();
        sound('tap');
      };
      solBox.addEventListener('copy', (e) => e.preventDefault());
      solBox.addEventListener('cut', (e) => e.preventDefault());
      solBox.addEventListener('dragstart', (e) => e.preventDefault());
      solState();
    }
    const failedTry = () => { S.attempts[L.id] = (S.attempts[L.id] || 0) + 1; save(); solState(); };
    const hintsBox = $('#hints', stage);
    const showHints = (n) => { hintsBox.innerHTML = L.hints.slice(0, n).map(t => `<div class="hint">💡 ${inline(t)}</div>`).join(''); };
    showHints(hintsShown);
    const hb = $('#hint-btn', stage);
    if (hb) {
      if (hintsShown >= L.hints.length) hb.disabled = true;
      hb.onclick = () => { const n = Math.min(L.hints.length, (S.hints[L.id] || 0) + 1); S.hints[L.id] = n; save(); showHints(n); hb.textContent = `Show a hint (${n}/${L.hints.length})`; if (n >= L.hints.length) hb.disabled = true; };
    }
    let draftTimer = null;
    const ed = makeEditor($('#ed', stage), start, { onChange: (v) => { clearTimeout(draftTimer); draftTimer = setTimeout(() => { S.drafts[L.id] = v; save({ local: true }); }, 600); }, onRun: () => run() });
    $('#reset', stage).onclick = async () => {
      if (await modal('<h3>Clear the editor?</h3><p>Your code in this lesson will be deleted from the editor.</p>', [{ label: 'Cancel', value: false }, { label: 'Clear', value: true, cls: 'danger' }])) { ed.set(blank); ed.focus(); }
    };
    const runBtn = $('#run', stage), results = $('#results', stage);
    let running = false, timer = null;
    const limitMs = Math.max(60000, (L.testMs || 0) * 15);
    async function run() {
      if (running) { testRunner.stop(); return; }
      const src = ed.get();
      S.drafts[L.id] = src; save({ local: true });
      const missingText = (L.musthave || []).filter(m => !src.includes(m));
      if (missingText.length) { results.innerHTML = errorHtml({ kind: 'musthave', missing: missingText }); sound('wrong'); failedTry(); return; }
      if (isCoding(L)) {
        const bad = /(^|[^\w.])(ref\s*\.|course_reference|_getframe|gc\.get_objects)/.exec(src);
        if (bad) { results.innerHTML = `<div class="res err"><h4>Write it yourself</h4><code>${esc(bad[2])}</code> belongs to the course's checker. The tests only pass with your own code.</div>`; return; }
      }
      running = true; runBtn.textContent = '■ Stop'; runBtn.classList.remove('primary'); runBtn.classList.add('danger');
      const t0 = Date.now();
      results.innerHTML = `<div class="res info"><div class="row"><div class="spin" style="width:22px;height:22px;border-width:3px"></div><b id="rs">${testRunner.state === 'ready' ? 'Running the tests…' : 'Starting Python… (only the first time)'}</b><span class="grow"></span><span class="muted" id="rt">0 s</span></div><pre class="console hidden" id="live"></pre></div>`;
      timer = setInterval(() => {
        const t = $('#rt', results); if (t) t.textContent = fmtTime((Date.now() - t0) / 1000);
        const s = $('#rs', results); if (s && testRunner.state === 'ready' && /Starting/.test(s.textContent)) s.textContent = 'Running the tests…';
        if (Date.now() - t0 > limitMs + (testRunner.state === 'ready' ? 0 : 60000)) testRunner.stop();
      }, 500);
      const job = lessonJob(L, src);
      let liveText = '';
      const res = await testRunner.run(job, {
        onOut: (t) => {
          const keep = t.split('\n').filter(x => /^@@(status|log|plan)/.test(x)).map(x => x.replace(/^@@\w+ /, ''));
          if (keep.length) { liveText = (liveText + keep.join('\n') + '\n').slice(-1500); const lv = $('#live', results); if (lv) { lv.classList.remove('hidden'); lv.textContent = liveText; lv.scrollTop = 1e9; } }
        },
      });
      clearInterval(timer);
      running = false; runBtn.textContent = '▶ Run tests'; runBtn.classList.add('primary'); runBtn.classList.remove('danger');
      if (res.stopped && Date.now() - t0 > limitMs) { failedTry(); results.innerHTML = `<div class="res err"><h4>Stopped after ${fmtTime((Date.now() - t0) / 1000)}</h4>Your code may be stuck in an endless loop. Check your loop conditions, and that every loop variable changes. The Playground's step-by-step mode can show you what happens, line by line.</div>`; return; }
      const r = interpret(L, res);
      if (r.pass) {
        const first = !S.done[L.id];
        const xp = first ? (L.xp || 15) + (S.hints[L.id] || S.cheats[L.id] ? 0 : 5) + (mistakes === 0 ? 5 : 0) : 0;
        S.code[L.id] = { src, t: Date.now() };
        delete S.drafts[L.id];
        if (first) S.done[L.id] = { t: Date.now(), mistakes };
        save();
        if (xp) addXp(xp); else updateStats();
        let extra = first ? `<p><b>+${xp} XP</b>${isProject(L) ? ` · ${partsWritten()} of ${TOTAL_PARTS()} parts of BitScribe are now written by you.` : ''}${r.checks ? ` <span class="muted">(${r.checks} checks)</span>` : ''}</p>` : '<p>Your new version is saved.</p>';
        const pdfFiles = (res.files || []).filter(f => /\.pdf$/.test(f[0]));
        extra += `<div class="row">${pdfFiles.map((f, i) => `<button class="btn small blue" data-pdf="${i}">Open the PDF your code made</button>`).join('')}<span class="grow"></span><button class="btn primary" id="done-next">Continue</button></div>`;
        renderResult(results, L, r, ed, extra);
        $$('[data-pdf]', results).forEach(b => { b.onclick = () => openPdf(pdfFiles[+b.dataset.pdf][1], pdfFiles[+b.dataset.pdf][0].replace(/^\//, '')); });
        $('#done-next', results).onclick = next;
        sound('pass');
        if (first) confetti();
      } else {
        renderResult(results, L, r, ed);
        if (!r.stopped) sound('wrong');
        if (!r.stopped && !(r.error && r.error.kind === 'startup')) failedTry();
      }
    }
    runBtn.onclick = run;
    lessonCleanup = () => { clearTimeout(draftTimer); clearInterval(timer); if (running) testRunner.stop(); };
  }
  function showGraduate() {
    const coding = LESSONS.filter(isProject);
    const mine = coding.filter(x => S.done[x.id] && S.code[x.id]);
    const all = mine.length === coding.length;
    stage.innerHTML = `<div class="lesson-card card" style="text-align:center"><div class="done-icon">🎓</div><h2>Graduation</h2>
      <p>${partsWritten()} of ${TOTAL_PARTS()} parts of BitScribe are written by you, in Python.</p>
      ${all ? '<p>Let Python load your whole program from your own code only, and check that every part is there.</p><button class="btn primary" id="build">Check my program</button>' : `<p class="muted">Finish the ${coding.length - mine.length} coding lesson(s) you have not done yet, then come back.</p>`}
      <div id="gres" style="margin-top:12px;text-align:left"></div><div class="foot"><button class="btn" id="later">Back to the path</button></div></div>`;
    $('#later', stage).onclick = () => { location.hash = 'learn'; };
    const b = $('#build', stage);
    if (b) b.onclick = async () => {
      b.disabled = true; b.textContent = 'Checking…';
      const res = await checkProgram();
      const box = $('#gres', stage);
      if (res.ok) {
        S.graduated = Date.now(); save();
        box.innerHTML = `<div class="res ok"><h4>🎉 Your BitScribe program loads: ${TOTAL_PARTS()} parts, all written by you.</h4>Open the <b>Writer</b> tab and write your first textbook with it. Export your project in <b>My code</b> to run <code>bitscribe.py</code> on your own computer.</div>`;
        sound('complete'); confetti();
        b.textContent = 'Open the Writer'; b.disabled = false; b.onclick = () => { finish(); location.hash = 'writer'; };
      } else {
        box.innerHTML = res.html.replace('</h4>', '</h4><p class="muted">Open that lesson and fix your code there.</p>');
        b.disabled = false; b.textContent = 'Check my program';
      }
    };
  }
  function finish() {
    if (!S.done[L.id]) {
      S.done[L.id] = { t: Date.now(), mistakes };
      const xp = L.graduation ? 50 : (L.xp || 10);
      addXp(xp);
      save();
      sound('complete');
      confetti();
    }
    const nextL = LESSONS[L.index + 1];
    stage.innerHTML = `<div class="lesson-card card" style="text-align:center"><div class="done-icon">🏆</div><h2>Lesson complete!</h2><p class="sub">${esc(L.title)}</p>
      <div class="foot" style="justify-content:center"><button class="btn" id="to-path">Back to the path</button>${nextL && isUnlocked(nextL) ? '<button class="btn primary" id="to-next">Next lesson</button>' : ''}</div></div>`;
    $('.lesson-top .bar > i', view).style.width = '100%';
    $('#to-path', stage).onclick = () => { location.hash = 'learn'; };
    const tn = $('#to-next', stage);
    if (tn) tn.onclick = () => { location.hash = 'lesson-' + nextL.id; };
  }
  show();
}
// Load the learner's whole program (definitions only) and check that every part of BitScribe is defined.
async function checkProgram(opts) {
  const { chunks, missing } = programChunks({ fill: !!(opts && opts.fill), moduleName: 'bitscribe' });
  if (missing.length && !(opts && opts.fill)) return { ok: false, html: `<div class="res info"><h4>${missing.length} lesson(s) still to do</h4>The program needs every part: ${missing.slice(0, 6).map(L => esc(L.title)).join(', ')}${missing.length > 6 ? '…' : ''}.</div>` };
  const need = [...new Set(REF.order.flatMap(n => REF.items[n].defines || []))];
  const test = 'missing = [n for n in ' + JSON.stringify(need) + ' if n not in me]\nt_true(not missing, "these names are not defined anywhere: " + ", ".join(missing[:12]))\n';
  const res = await testRunner.run({ mode: 'test', chunks, need: [], test, argv: ['bitscribe.py'] });
  if (res.stopped) return { ok: false, html: '<div class="res info">Stopped.</div>' };
  if (res.error) return { ok: false, html: errorHtml(res.error, null, { otherLesson: true }) };
  if (res.fails && res.fails.length) return { ok: false, html: `<div class="res err"><h4>Something is missing</h4>${esc(res.fails[0])}</div>` };
  return { ok: true, ms: res.ms, chunks: chunks.length };
}
BS.checkProgram = checkProgram;

// ---------------- Profile tab ----------------
function renderProfile(view) {
  const st = S.settings;
  const done = LESSONS.filter(L => S.done[L.id]).length;
  const days = Object.keys(S.dayXp).sort().slice(-14);
  view.innerHTML = `
    <h1>Profile</h1>
    <div class="statgrid">
      <div class="stat"><div class="k">Streak</div><div class="v">🔥 ${S.streak}</div></div>
      <div class="stat"><div class="k">Total XP</div><div class="v">⚡ ${S.xp}</div></div>
      <div class="stat"><div class="k">Lessons</div><div class="v">${done}/${LESSONS.length}</div></div>
      <div class="stat"><div class="k">Parts by you</div><div class="v">🧩 ${partsWritten()}/${TOTAL_PARTS()}</div></div>
      <div class="stat"><div class="k">Graduated</div><div class="v">${S.graduated ? '🎓 Yes' : '—'}</div></div>
    </div>
    ${days.length ? `<div class="card" style="margin-top:14px"><h3>XP in the last days</h3><div style="display:flex;gap:6px;align-items:flex-end;height:90px">${days.map(d => { const v = S.dayXp[d]; const mx = Math.max(...days.map(x => S.dayXp[x]), 1); return `<div style="flex:1;text-align:center"><div style="height:${Math.max(4, 70 * v / mx)}px;background:var(--green);border-radius:6px" title="${v} XP"></div><div class="muted" style="font-size:11px">${d.slice(8)}</div></div>`; }).join('')}</div></div>` : ''}
    <div class="grid2" style="margin-top:14px">
      <div class="card">
        <h3>Look</h3>
        <label class="field"><span>Theme</span><select id="s-theme"><option value="auto">Automatic (like my device)</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
        <label class="field"><span>Font</span><select id="s-font">${Object.entries(FONTS).map(([k, f]) => `<option value="${k}">${esc(f.label)}</option>`).join('')}</select></label>
        <label class="field"><span>Text size: <b id="v-fs">${st.fontSize}px</b></span><input type="range" id="s-fs" min="13" max="26" step="1" style="width:100%"></label>
        <label class="field"><span>Code size: <b id="v-cs">${st.codeSize}px</b></span><input type="range" id="s-cs" min="11" max="24" step="1" style="width:100%"></label>
        <button class="btn small" id="s-full">⛶ Full screen</button>
      </div>
      <div class="card">
        <h3>Learning</h3>
        <label class="switch"><input type="checkbox" id="s-sound"> Sounds for right and wrong answers</label>
        <label class="field"><span>Volume</span><input type="range" id="s-vol" min="0" max="1" step="0.05" style="width:100%"></label>
        <label class="switch"><input type="checkbox" id="s-paste"> Allow pasting code into the editor</label>
        <label class="switch"><input type="checkbox" id="s-unlock"> Unlock all lessons</label>
        <label class="field"><span>Daily goal</span><select id="s-goal"><option value="10">10 XP — casual</option><option value="30">30 XP — regular</option><option value="50">50 XP — serious</option><option value="100">100 XP — intense</option></select></label>
      </div>
    </div>
    <div class="card" style="margin-top:14px">
      <h3>Your progress is saved</h3>
      <p class="sub" id="sync-status">${esc(Sync.status())}</p>
      <div class="row"><button class="btn small" id="exp-progress">Download a backup (.json)</button><label class="btn small" style="cursor:pointer">Restore a backup<input type="file" id="imp-progress" accept=".json,application/json" hidden></label><span class="grow"></span><button class="btn small danger" id="reset-all">Reset everything</button></div>
    </div>
    <p class="muted" style="margin-top:14px">BitScribe Python ${IS_APP ? 'for Android' : 'web'} · course with ${LESSONS.length} lessons and ${TOTAL_PARTS()} parts · Python ${esc((BS.pyInfo && BS.pyInfo.python) || '3.14')} and NumPy run in the app with Pyodide (MPL 2.0) · fonts: Carlito, Nunito, Atkinson Hyperlegible, OpenDyslexic, Merriweather and JetBrains Mono (SIL Open Font License) · editor: CodeMirror (MIT).</p>`;
  const bind = (id, key, conv, after) => {
    const e = $('#' + id, view);
    if (e.type === 'checkbox') e.checked = !!st[key]; else e.value = st[key];
    e.addEventListener(e.type === 'range' ? 'input' : 'change', () => { st[key] = e.type === 'checkbox' ? e.checked : conv ? conv(e.value) : e.value; save(); applyLook(); if (after) after(); });
  };
  bind('s-theme', 'theme'); bind('s-font', 'font');
  bind('s-fs', 'fontSize', Number, () => { $('#v-fs', view).textContent = st.fontSize + 'px'; });
  bind('s-cs', 'codeSize', Number, () => { $('#v-cs', view).textContent = st.codeSize + 'px'; });
  bind('s-sound', 'sound', null, () => sound('correct'));
  bind('s-vol', 'volume', Number);
  $('#s-vol', view).addEventListener('change', () => sound('correct'));
  bind('s-paste', 'allowPaste'); bind('s-unlock', 'unlockAll'); bind('s-goal', 'dailyGoal', Number);
  $('#s-full', view).onclick = toggleFullscreen;
  $('#exp-progress', view).onclick = () => saveFile('bitscribe-python-progress-' + today() + '.json', JSON.stringify(S));
  $('#imp-progress', view).onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      if (!data || typeof data !== 'object' || !data.done) throw new Error('not a BitScribe Python backup');
      if (await modal('<h3>Restore this backup?</h3><p>It replaces your current progress on this device.</p>', [{ label: 'Cancel', value: false }, { label: 'Restore', value: true, cls: 'primary' }])) {
        const d = defaults();
        S = { ...d, ...data, settings: { ...d.settings, ...(data.settings || {}) }, writer: { ...d.writer, ...(data.writer || {}) }, machine: { ...d.machine, ...(data.machine || {}) } };
        save(); applyLook(); updateStats(); toast('Progress restored'); route();
      }
    } catch (err) { toast('That file could not be read: ' + err.message); }
  };
  $('#reset-all', view).onclick = async () => {
    if (await modal('<h3>Reset everything?</h3><p>All lessons, XP, your code and your settings will be deleted. This cannot be undone.</p>', [{ label: 'Cancel', value: false }, { label: 'Delete everything', value: true, cls: 'danger' }])) {
      S = defaults(); save(); applyLook(); updateStats(); Sync.resetRemote(); route(); toast('Everything was reset');
    }
  };
}

// ---------------- sync with the Claude account (when this page runs as an artifact) ----------------
const Sync = (() => {
  let db = null, uid = null, state = 'local', timer = null, writing = Promise.resolve(), lastCodeHash = {};
  const unitOf = (lessonId) => (BY_ID[lessonId] ? BY_ID[lessonId].unitObj.id : 'misc');
  async function init() {
    if (IS_APP || !window.claude || !window.claude.use) return;
    try {
      const [d, u] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
      if (!d || !u) return;
      const id = await u.id();
      if (!id) return;
      db = d; uid = id; state = 'loading';
      const base = 'data/users/' + uid;
      const prog = await Promise.race([db.doc(base + '/progress').get(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 10000))]);
      const codes = await db.doc(base + '/progress').collection('units').get().catch(() => null);
      merge(prog && prog.exists ? prog.data() : null, codes ? codes.docs.map(x => x.data()) : []);
      state = 'synced';
      for (const u2 of UNITS) lastCodeHash[u2.id] = JSON.stringify(unitCode(u2.id));
      schedule(true);
    } catch (e) { state = db ? 'error' : 'local'; }
  }
  function unitCode(unitId) { const o = {}; for (const [id, c] of Object.entries(S.code)) if (unitOf(id) === unitId) o[id] = c; return o; }
  function merge(p, units) {
    let changed = false;
    if (p) {
      for (const [id, v] of Object.entries(p.done || {})) if (!S.done[id]) { S.done[id] = v; changed = true; }
      if ((p.xp || 0) > S.xp) { S.xp = p.xp; changed = true; }
      if ((p.lastDay || '') > (S.lastDay || '')) { S.lastDay = p.lastDay; S.streak = p.streak || 0; changed = true; }
      for (const [d, v] of Object.entries(p.dayXp || {})) if ((S.dayXp[d] || 0) < v) { S.dayXp[d] = v; changed = true; }
      if ((p.t || 0) > (S.t || 0)) { S.settings = { ...S.settings, ...(p.settings || {}) }; S.writer = { ...S.writer, ...(p.writer || {}) }; changed = true; }
      if (p.graduated && !S.graduated) { S.graduated = p.graduated; changed = true; }
      for (const [id, n] of Object.entries(p.hints || {})) if ((S.hints[id] || 0) < n) { S.hints[id] = n; changed = true; }
      for (const k of ['attempts', 'cheats']) { S[k] = S[k] || {}; for (const [id, n] of Object.entries(p[k] || {})) if ((S[k][id] || 0) < n) { S[k][id] = n; changed = true; } }
    }
    for (const u of units) for (const [id, c] of Object.entries((u && u.lessons) || {})) {
      if (!S.code[id] || (c.t || 0) > (S.code[id].t || 0)) { S.code[id] = c; changed = true; }
    }
    if (changed) { try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) {} applyLook(); updateStats(); if (!(location.hash || '').startsWith('#lesson-')) route(); }
  }
  function schedule(now) {
    if (!db || state === 'loading') return;
    clearTimeout(timer);
    timer = setTimeout(push, now ? 100 : 2500);
  }
  function push() {
    writing = writing.then(async () => {
      try {
        const base = 'data/users/' + uid;
        const p = { xp: S.xp, streak: S.streak, lastDay: S.lastDay, dayXp: S.dayXp, done: S.done, hints: S.hints, attempts: S.attempts, cheats: S.cheats, settings: S.settings, writer: { ...S.writer, sources: (S.writer.sources || '').slice(0, 60000) }, graduated: S.graduated, t: S.t };
        await db.doc(base + '/progress').set(JSON.parse(JSON.stringify(p)));
        for (const u of UNITS) {
          const c = unitCode(u.id), j = JSON.stringify(c);
          if (lastCodeHash[u.id] === j) continue;
          await db.doc(base + '/progress').collection('units').doc(u.id).set({ lessons: c });
          lastCodeHash[u.id] = j;
        }
        state = 'synced';
      } catch (e) { state = 'error'; }
      const ss = $('#sync-status'); if (ss) ss.textContent = status();
    });
  }
  async function resetRemote() {
    if (!db) return;
    try {
      const base = 'data/users/' + uid;
      await db.doc(base + '/progress').delete();
      for (const u of UNITS) await db.doc(base + '/progress').collection('units').doc(u.id).delete();
      lastCodeHash = {};
    } catch (e) {}
  }
  function status() {
    if (IS_APP) return 'Saved on this device. Use “Download a backup” to move your progress to another device.';
    if (state === 'synced') return 'Saved in this browser and in your Claude account, so it follows you to your other devices.';
    if (state === 'loading') return 'Loading your progress from your Claude account…';
    if (state === 'error') return 'Saved in this browser. Your Claude account could not be reached right now.';
    return 'Saved in this browser. Use “Download a backup” to move your progress to another device.';
  }
  return { init, schedule, status, resetRemote };
})();
BS.Sync = Sync;

// ---------------- router ----------------
let currentTab = '';
function route() {
  const hash = (location.hash || '#learn').slice(1);
  const view = $('#view');
  if (lessonCleanup) { lessonCleanup(); lessonCleanup = null; }
  if (BS.onLeave) { const f = BS.onLeave; BS.onLeave = null; f(); }
  let tab = hash;
  if (hash.startsWith('lesson-')) {
    const L = BY_ID[hash.slice(7)];
    if (L && isUnlocked(L)) { tab = 'learn'; setTab(tab); renderLesson(view, L); window.scrollTo(0, 0); return; }
    tab = 'learn';
  }
  if (!['learn', 'playground', 'writer', 'project', 'profile'].includes(tab)) tab = 'learn';
  setTab(tab);
  if (tab === 'learn') renderLearn(view);
  else if (tab === 'profile') renderProfile(view);
  else if (BS.views && BS.views[tab]) BS.views[tab](view);
  if (currentTab !== tab) window.scrollTo(0, 0);
  currentTab = tab;
}
BS.route = route;
function setTab(tab) { $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab)); }
window.addEventListener('hashchange', route);
// Android back button: close a dialog, leave a lesson, or go back to Learn. Returns true if handled.
window.__bsBack = () => {
  const pv = $('.pdfv'); if (pv) { $('.pdfv-close', pv).click(); return true; }
  const m = $('.modal-bg'); if (m) { m.remove(); BS.modalOpen = 0; return true; }
  const hash = (location.hash || '#learn').slice(1);
  if (hash !== 'learn' && hash !== '') { location.hash = 'learn'; return true; }
  return false;
};

// ---------------- boot ----------------
async function boot() {
  applyLook();
  $$('#tabs button').forEach(b => { b.onclick = () => { location.hash = b.dataset.tab; }; });
  $('#logo').onclick = () => { location.hash = 'learn'; };
  $('#btn-theme').onclick = () => { const dark = document.documentElement.dataset.theme === 'dark'; S.settings.theme = dark ? 'light' : 'dark'; save(); applyLook(); };
  $('#btn-full').onclick = toggleFullscreen;
  try {
    await loadData((m) => { const e = $('#boot-msg'); if (e) e.textContent = m; });
  } catch (e) {
    $('#view').innerHTML = `<div class="card"><h2>BitScribe Python could not load</h2><p>${esc(e.message)}</p><p>Reload the page to try again.</p></div>`;
    return;
  }
  updateStats();
  route();
  Sync.init();
  BS.warmUp();
}
document.addEventListener('DOMContentLoaded', boot);
})();
