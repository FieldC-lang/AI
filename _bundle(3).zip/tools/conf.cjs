// Conformance: run each snippet in PyVM and in CPython, compare stdout + final error line.
const vm = require('../pyvm.js'), fs = require('fs'), cp = require('child_process'), path = require('path');
const file = process.argv[2] || path.join(__dirname, 'conf_cases.txt');
const cases = fs.readFileSync(file, 'utf8').split(/^#---.*$/m).map(s => s.replace(/^\n/, '')).filter(s => s.trim());
let bad = 0;
cases.forEach((src, i) => {
  let stdin = '';
  const m = /^#stdin: (.*)\n/.exec(src);
  if (m) stdin = m[1].replace(/\\n/g, '\n');
  const r = vm.run(src, { stdin });
  const mine = r.out + (r.error ? r.error.text : '') + (r.status === 'limit' ? 'LIMIT' : '');
  const py = cp.spawnSync('python3', ['-c', src], { input: stdin + '\n', encoding: 'utf8' });
  const theirs = py.stdout + (py.status ? py.stderr.trim().split('\n').pop() : '');
  if (mine !== theirs) { bad++; console.log('--- case ' + i + ' DIFF\n' + src + '\n  mine:   ' + JSON.stringify(mine) + '\n  python: ' + JSON.stringify(theirs)); }
});
console.log(cases.length + ' cases, ' + bad + ' differ');
process.exit(bad ? 1 : 0);
