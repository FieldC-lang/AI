import itertools, sys
sys.path.insert(0, 'tools')
import microbit_lib as m
W = m.WORDS
def rule(p):
    seq = list(p); out = []
    while len(out) < 4:
        nxt = seq[-2] if len(seq) >= 2 else seq[-1]
        if nxt == "end": break
        out.append(nxt); seq.append(nxt)
    return " ".join(out)
bad = 0; n = 0; minmargin = 9
for L in range(1, 5):
    for p in itertools.product(W, repeat=L):
        n += 1
        got = m.generate(" ".join(p), 4)
        if got != rule(p):
            bad += 1; print("MISMATCH", p, repr(got), repr(rule(p)))
print(n, "prompts,", bad, "mismatches")
for p in ["red", "red blue", "red red blue", "red end", "end", "blue blue red", ""]:
    print(repr(p), "->", repr(m.generate(p, 4)))
# margins
model = m.load_model(m.MODEL)
for L in range(1, 9):
    for p in itertools.product(range(3), repeat=L) if L <= 6 else []:
        cache = {"k": [], "v": []}
        for i, t in enumerate(p):
            lg = m.forward(t, i, model, cache)
        s = sorted(lg); minmargin = min(minmargin, s[-1]-s[-2])
print("min logit margin", minmargin)
cache = {"k": [], "v": []}
print(m.forward(0, 0, model, cache)); print(m.forward(1, 1, model, cache))
