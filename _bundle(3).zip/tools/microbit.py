import math

WORDS = ["red", "blue", "end"]

MODEL = bytes([
    77, 66, 1, 8, 3, 8, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 16, 85, 85, 1,
    85, 169, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85,
    85, 8, 169, 85, 85, 85, 169, 85, 85, 85, 85, 85,
    85, 85, 85, 85, 85, 85, 8, 149, 85, 101, 85, 89,
    85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 8,
    85, 85, 85, 85, 85, 85, 85, 85, 149, 85, 101, 85,
    89, 85, 85, 85, 8, 85, 85, 85, 85, 85, 85, 85,
    85, 85, 129, 85, 33, 85, 9, 85, 85, 8, 85, 85,
    85, 85, 85, 85, 85, 85, 85, 149, 85, 101, 85, 89,
    85, 85, 8, 85, 85, 85, 85, 85, 85, 85, 85, 85,
    149, 85, 101, 85, 89, 85, 85, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0,
])

LAYERS = ["q", "k", "v", "o", "gate", "up", "down"]
SPEEDS = [math.pi / 2, 0.3]


def weight_at(packed, i):
    byte = packed[i // 4]
    shift = 6 - 2 * (i % 4)
    return ((byte >> shift) & 3) - 1


def read_table(data, pos, rows, dim):
    table = []
    for r in range(rows):
        table.append(list(data[pos:pos + dim]))
        pos += dim
    return table, pos


def load_model(data):
    if data[0] != 77 or data[1] != 66:
        raise ValueError("not a MicroBit file")
    dim = data[3]
    vocab = data[4]
    model = {"dim": dim, "vocab": vocab}
    pos = 8
    model["embed"], pos = read_table(data, pos, vocab, dim)
    size = dim * dim // 4
    for name in LAYERS:
        gamma = data[pos] / 8
        packed = data[pos + 1:pos + 1 + size]
        model[name] = (gamma, packed)
        pos += 1 + size
    model["head"], pos = read_table(data, pos, vocab, dim)
    return model


def bitlinear(x, layer):
    gamma, packed = layer
    top = 0.00001
    for v in x:
        top = max(top, abs(v))
    scale = 127 / top
    xq = [round(v * scale) for v in x]
    n = len(x)
    out = []
    for row in range(n):
        acc = 0
        for col in range(n):
            w = weight_at(packed, row * n + col)
            if w == 1:
                acc += xq[col]
            elif w == -1:
                acc -= xq[col]
        out.append(acc * gamma / scale)
    return out


def encode(text):
    ids = []
    for word in text.split():
        if word not in WORDS:
            raise ValueError("unknown word: " + word)
        ids.append(WORDS.index(word))
    return ids


def rmsnorm(x):
    total = 0.0
    for v in x:
        total += v * v
    rms = math.sqrt(total / len(x) + 0.00001)
    return [v / rms for v in x]


def softmax(scores):
    top = max(scores)
    exps = [math.exp(s - top) for s in scores]
    total = sum(exps)
    return [e / total for e in exps]


def rotate(vec, pos):
    out = list(vec)
    for pair in range(len(SPEEDS)):
        angle = pos * SPEEDS[pair]
        c = math.cos(angle)
        s = math.sin(angle)
        a = vec[2 * pair]
        b = vec[2 * pair + 1]
        out[2 * pair] = a * c - b * s
        out[2 * pair + 1] = a * s + b * c
    return out


def attention(x, pos, model, cache):
    q = rotate(bitlinear(x, model["q"]), pos)
    k = rotate(bitlinear(x, model["k"]), pos)
    v = bitlinear(x, model["v"])
    cache["k"].append(k)
    cache["v"].append(v)
    scores = []
    for old_k in cache["k"]:
        dot = 0.0
        for a, b in zip(q, old_k):
            dot += a * b
        scores.append(dot / math.sqrt(len(q)))
    probs = softmax(scores)
    mix = [0.0] * len(x)
    for p, old_v in zip(probs, cache["v"]):
        for i in range(len(mix)):
            mix[i] += p * old_v[i]
    return bitlinear(rmsnorm(mix), model["o"])


def ffn(x, model):
    gate = bitlinear(x, model["gate"])
    up = bitlinear(x, model["up"])
    inner = []
    for g, u in zip(gate, up):
        g = max(g, 0.0)
        inner.append(g * g * u)
    return bitlinear(rmsnorm(inner), model["down"])


def forward(token, pos, model, cache):
    x = [float(v) for v in model["embed"][token]]
    a = attention(rmsnorm(x), pos, model, cache)
    x = [xi + ai for xi, ai in zip(x, a)]
    f = ffn(rmsnorm(x), model)
    x = [xi + fi for xi, fi in zip(x, f)]
    x = rmsnorm(x)
    logits = []
    for row in model["head"]:
        total = 0.0
        for w, v in zip(row, x):
            total += w * v
        logits.append(total)
    return logits


def argmax(values):
    best = 0
    for i in range(len(values)):
        if values[i] > values[best]:
            best = i
    return best


def generate(prompt, max_new):
    model = load_model(MODEL)
    cache = {"k": [], "v": []}
    logits = []
    pos = 0
    for token in encode(prompt):
        logits = forward(token, pos, model, cache)
        pos += 1
    words = []
    while pos > 0 and len(words) < max_new:
        token = argmax(logits)
        if WORDS[token] == "end":
            break
        words.append(WORDS[token])
        logits = forward(token, pos, model, cache)
        pos += 1
    return " ".join(words)


print(generate(input(), 4))
