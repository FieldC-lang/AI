# Builds the 175 MicroBit model bytes (hand-authored weights, not trained).
def mat(rows, gamma):
    w = [[0]*8 for _ in range(8)]
    for r, cols in rows.items():
        for c, val in cols.items():
            w[r][c] = val
    flat = [v for row in w for v in row]
    out = [int(gamma*8)]
    for i in range(0, 64, 4):
        b = 0
        for j in range(4):
            b = (b << 2) | (flat[i+j] + 1)
        out.append(b)
    return out
tok = {0:1, 1:1, 2:1}
ntok = {0:-1, 1:-1, 2:-1}
header = [77, 66, 1, 8, 3, 8, 1, 0]
embed = []
for t in range(3):
    embed += [1 if i == t else 0 for i in range(8)]
q = mat({1: ntok, 2: tok}, 2.0)
k = mat({0: tok, 2: tok}, 1.0)
v = mat({0:{0:1}, 1:{1:1}, 2:{2:1}}, 1.0)
o = mat({4:{0:1}, 5:{1:1}, 6:{2:1}}, 1.0)
gate = mat({4:{4:1,5:-1,6:-1}, 5:{4:-1,5:1,6:-1}, 6:{4:-1,5:-1,6:1}}, 1.0)
up = mat({4:{4:1}, 5:{5:1}, 6:{6:1}}, 1.0)
down = mat({4:{4:1}, 5:{5:1}, 6:{6:1}}, 1.0)
head = []
for t in range(3):
    head += [1 if i == 4+t else 0 for i in range(8)]
data = header + embed + q + k + v + o + gate + up + down + head
assert len(data) == 175, len(data)
if __name__ == "__main__":
    lines = []
    for i in range(0, len(data), 12):
        lines.append("    " + ", ".join(str(b) for b in data[i:i+12]) + ",")
    print("MODEL = bytes([\n" + "\n".join(lines) + "\n])")
