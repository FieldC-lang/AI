const vm = require('../pyvm.js'), fs = require('fs'), cp = require('child_process');
const src = fs.readFileSync(__dirname + '/microbit.py', 'utf8');
for (const p of ['red', 'red blue', 'red red blue', 'red end', 'end', 'blue blue red end', '', 'green']) {
  const t0 = Date.now();
  const r = vm.run(src, { stdin: p, trace: true });
  const py = cp.spawnSync('python3', [__dirname + '/microbit.py'], { input: p + '\n', encoding: 'utf8' });
  const pyOut = py.stdout + (py.status ? py.stderr.trim().split('\n').pop() : '');
  const mine = r.out + (r.error ? r.error.text : '');
  console.log(JSON.stringify(p), r.status, JSON.stringify(mine), mine === pyOut ? 'OK' : 'DIFF ' + JSON.stringify(pyOut), 'ticks', r.ticks, 'peak', r.peak, 'live', r.live, (Date.now() - t0) + 'ms');
}
