// Verifies every lesson step against the emulator, and (with --py) the visible programs against CPython.
const fs = require('fs'), path = require('path'), cp = require('child_process');
const root = path.join(__dirname, '..');
globalThis.PyVM = require('../pyvm.js'); globalThis.ENGINE = require('../engine.js');
const Emu = require('../emu.js');
fs.readdirSync(root).filter(f => /^lessons\d+\.js$/.test(f)).sort().forEach(f => require(path.join(root, f)));
const verbose = process.argv.includes('-v'), usePy = process.argv.includes('--py');
let bad = 0, n = 0, pyRuns = 0, byType = {};
const fail = (where, msg) => { bad++; console.log('FAIL ' + where + ': ' + msg); };
function py(src, stdin) {
  pyRuns++;
  const r = cp.spawnSync('python3', ['-c', src], { input: (stdin || '') + '\n', encoding: 'utf8' });
  return r.stdout.replace(/\s+$/, '') + (r.status ? '\n!' + r.stderr.trim().split('\n').pop() : '');
}
function vmText(p) { const r = PyVM.run(p.src, { stdin: p.stdin }); return r.out.replace(/\s+$/, '') + (r.error ? '\n!' + r.error.text : '') + (r.status === 'limit' ? '\n!LIMIT' : ''); }
function same(where, spec, code) {
  if (!usePy) return;
  const p = Emu.program(spec, code), a = vmText(p), b = py(p.src, p.stdin);
  if (a !== b) fail(where, 'emulator and CPython disagree\n  emu: ' + JSON.stringify(a) + '\n  py:  ' + JSON.stringify(b));
}
const ids = {};
for (const u of UNITS) for (const l of u.lessons) {
  if (ids[l.id]) fail(l.id, 'duplicate lesson id'); ids[l.id] = 1;
  if (l.unlock && !ENGINE.parts[l.unlock]) fail(l.id, 'unknown unlock ' + l.unlock);
  l.steps.forEach((s, i) => {
    const where = l.id + '.' + (i + 1) + ' [' + s.t + '] ' + s.title; n++; byType[s.t] = (byType[s.t] || 0) + 1;
    if (!s.title || !s.text) fail(where, 'missing title/text');
    const longLines = (s.code || '').split('\n').concat(...(s.variants || []).map(v => v.code.split('\n'))).filter(x => x.length > 60);
    if (longLines.length) fail(where, 'line longer than 60 chars: ' + longLines[0]);
    try {
      if (s.t === 'learn') {
        const r = Emu.truth(Object.assign({ verify: 'out' }, s));
        if (r.st.error) fail(where, 'learn code errors: ' + r.st.error.text);
        if (verbose) console.log(where + '\n   out=' + JSON.stringify(r.value) + ' clock=' + r.st.clock + ' live=' + r.st.live + ' peak=' + r.st.peak);
        same(where, s);
      } else if (s.t === 'predict' || s.t === 'inspect') {
        const r = Emu.truth(s), hits = s.options.filter(o => o === r.value).length;
        if (new Set(s.options).size !== s.options.length) fail(where, 'duplicate options');
        if (hits !== 1) fail(where, 'truth ' + JSON.stringify(r.value) + ' matches ' + hits + ' options ' + JSON.stringify(s.options));
        if (!s.why || !s.ask) fail(where, 'missing ask/why');
        if (r.st.error && s.verify !== 'error') fail(where, 'unexpected error ' + r.st.error.text);
        if (s.t === 'inspect' && s.stop && Emu.stopIndex(r.p, r.t, s.stop) < 0) fail(where, 'stop line never reached');
        if (verbose) console.log(where + '\n   truth=' + JSON.stringify(r.value) + ' clock=' + r.st.clock + ' live=' + r.st.live);
        same(where, s);
      } else if (s.t === 'duel') {
        const d = Emu.duel(s);
        if (d.winner === 'They tie') fail(where, 'duel ties');
        if (d.rows.some(r => r.st.error)) fail(where, 'duel variant errors');
        if (!s.why || !s.ask) fail(where, 'missing ask/why');
        if (verbose) console.log(where + '\n   ' + d.rows.map(r => r.label + '=' + r.value).join('  ') + '  winner=' + d.winner);
        s.variants.forEach(v => same(where + ' / ' + v.label, s, v.code));
      } else if (s.t === 'experiment') {
        if (typeof s.answer !== 'number' || !s.options[s.answer]) fail(where, 'bad answer index');
        const outs = s.variants.map(v => { const r = Emu.truth(Object.assign({}, s, { verify: 'out' }), v.code); return r.value + (r.st.error ? ' !' + r.st.error.text : ''); });
        if (new Set(outs).size !== outs.length) fail(where, 'variants behave the same: ' + JSON.stringify(outs));
        if (verbose) console.log(where + '\n   ' + s.variants.map((v, k) => v.label + ' => ' + JSON.stringify(outs[k])).join('\n   '));
        s.variants.forEach(v => same(where + ' / ' + v.label, s, v.code));
      } else if (s.t === 'fill' || s.t === 'write') {
        const sol = s.t === 'fill' ? Emu.fillCode(s.code, s.answer) : s.solution;
        const good = Emu.runTests(s, sol), start = Emu.runTests(s, s.t === 'fill' ? Emu.fillCode(s.code, []) : s.code);
        if (!good.every(t => t.pass)) fail(where, 'solution fails its tests ' + JSON.stringify(good.filter(t => !t.pass)));
        if (start.every(t => t.pass)) fail(where, 'starter already passes');
        if (s.t === 'fill') {
          const blanks = (s.code.match(/\[\[\d+\]\]/g) || []).length;
          if (blanks !== s.answer.length) fail(where, 'blank count mismatch');
          s.answer.forEach(a => { if (!s.chips.includes(a)) fail(where, 'answer chip missing: ' + a); });
          // every wrong single-chip substitution must fail
          s.answer.forEach((a, k) => s.chips.filter(c => c !== a).forEach(c => {
            const picks = s.answer.slice(); picks[k] = c;
            if (Emu.runTests(s, Emu.fillCode(s.code, picks)).every(t => t.pass)) fail(where, 'wrong chip also passes: blank ' + (k + 1) + ' = ' + c);
          }));
        } else if (!s.hint) fail(where, 'missing hint');
        if (verbose) console.log(where + '\n   expected: ' + good.map(t => JSON.stringify(t.want)).join(' | '));
        (s.tests || [{ post: s.post, stdin: s.stdin }]).forEach(t => same(where, { pre: s.pre, setup: s.setup, post: t.post, stdin: t.stdin }, sol));
      } else fail(where, 'unknown type');
    } catch (e) { fail(where, 'threw ' + (e.stack || e.msg || e)); }
  });
}
console.log(n + ' steps ' + JSON.stringify(byType) + (usePy ? ', ' + pyRuns + ' CPython comparisons' : '') + ', ' + bad + ' problems');
process.exit(bad ? 1 : 0);
