/* PyVM: a small Python-subset interpreter with a virtual clock and a memory meter.
   Plain ES2017 so it runs in older Android WebViews. */
(function (root) {
'use strict';

function PyError(type, msg) { this.type = type; this.msg = msg; this.line = 0; }
var PAUSE = { pause: true };
var LIMIT = { limit: true };
function E(type, msg) { return new PyError(type, msg); }

// ---------------------------------------------------------------- values
function PyFloat(v) { this.v = v; this.m = 0; }
function PyList(items) { this.items = items; this.id = S.seq++; this.m = 0; }
function PyTuple(items) { this.items = items; this.id = S.seq++; this.m = 0; }
function PyDict() { this.map = new Map(); this.id = S.seq++; this.m = 0; }
function PyBytes(data) { this.data = data; this.id = S.seq++; this.m = 0; }
function PyRange(a, b, c) { this.start = a; this.stop = b; this.step = c; }
function PyFunc(name, params, body, env, locals) { this.name = name; this.params = params; this.body = body; this.env = env; this.locals = locals; }
function PyBuiltin(name, fn) { this.name = name; this.fn = fn; }
function PyModule(name, attrs) { this.name = name; this.attrs = attrs; }
function PyType(name) { this.name = name; }

var S = { seq: 0 };

// ---------------------------------------------------------------- tokenizer
var KEYWORDS = {};
('False None True and as assert break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield').split(' ').forEach(function (k) { KEYWORDS[k] = 1; });
var OPS3 = ['**=', '//=', '>>=', '<<='];
var OPS2 = ['!=', '==', '<=', '>=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '**', '//', '>>', '<<', '->'];
var OPS1 = '+-*/%<>=()[]{},:.&|^~;@';
var NUM_RE = /^(0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+|\d[\d_]*\.[\d_]*(?:[eE][+-]?\d+)?|\.\d[\d_]*(?:[eE][+-]?\d+)?|\d[\d_]*[eE][+-]?\d+|\d[\d_]*)/;
var NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*/;

function syntaxErr(msg, line) { var e = E(/indent/.test(msg) ? 'IndentationError' : 'SyntaxError', msg); e.line = line; return e; }

function tokenize(src) {
  var toks = [], i = 0, n = src.length, line = 1, indents = [0], paren = 0, atStart = true, opens = [];
  src = src.replace(/\r\n?/g, '\n');
  n = src.length;
  while (i < n) {
    if (atStart) {
      var col = 0, j = i;
      while (j < n && (src[j] === ' ' || src[j] === '\t')) { col += src[j] === '\t' ? 8 - (col % 8) : 1; j++; }
      if (j >= n) { i = j; break; }
      if (src[j] === '\n') { i = j + 1; line++; continue; }
      if (src[j] === '#') { while (j < n && src[j] !== '\n') j++; i = j; continue; }
      i = j;
      if (paren === 0) {
        var top = indents[indents.length - 1];
        if (col > top) { indents.push(col); toks.push({ t: 'INDENT', line: line }); }
        else if (col < top) {
          while (col < indents[indents.length - 1]) { indents.pop(); toks.push({ t: 'DEDENT', line: line }); }
          if (col !== indents[indents.length - 1]) throw syntaxErr('unindent does not match any outer indentation level', line);
        }
      }
      atStart = false;
    }
    var c = src[i];
    if (c === '\n') {
      if (paren === 0) { toks.push({ t: 'NEWLINE', line: line }); atStart = true; }
      i++; line++; continue;
    }
    if (c === ' ' || c === '\t') { i++; continue; }
    if (c === '#') { while (i < n && src[i] !== '\n') i++; continue; }
    if (c === '\\' && src[i + 1] === '\n') { i += 2; line++; continue; }
    var rest = src.substr(i, 64);
    var m;
    // strings (with optional prefix)
    var sm = /^([fFrRbB]{0,2})(["'])/.exec(rest);
    if (sm && (sm[1] === '' || /^(f|r|b|fr|rf|br|rb)$/i.test(sm[1]))) {
      var prefix = sm[1].toLowerCase(), q = sm[2];
      var k = i + sm[1].length;
      var triple = src.substr(k, 3) === q + q + q;
      var startLine = line;
      k += triple ? 3 : 1;
      var raw = prefix.indexOf('r') >= 0, out = '';
      for (;;) {
        if (k >= n) throw syntaxErr('unterminated string literal', startLine);
        var ch = src[k];
        if (triple) { if (src.substr(k, 3) === q + q + q) { k += 3; break; } }
        else { if (ch === q) { k++; break; } if (ch === '\n') throw syntaxErr('unterminated string literal', startLine); }
        if (ch === '\n') line++;
        if (ch === '\\' && !raw) {
          var nx = src[k + 1];
          if (nx === 'n') { out += '\n'; k += 2; }
          else if (nx === 't') { out += '\t'; k += 2; }
          else if (nx === 'r') { out += '\r'; k += 2; }
          else if (nx === '0') { out += '\0'; k += 2; }
          else if (nx === '\\' || nx === '\'' || nx === '"') { out += nx; k += 2; }
          else if (nx === 'x') { out += String.fromCharCode(parseInt(src.substr(k + 2, 2), 16)); k += 4; }
          else if (nx === '\n') { k += 2; line++; }
          else { out += '\\'; k++; }
        } else { out += ch; k++; }
      }
      if (prefix.indexOf('b') >= 0) {
        var arr = [];
        for (var bi = 0; bi < out.length; bi++) arr.push(out.charCodeAt(bi) & 255);
        toks.push({ t: 'BYTES', v: arr, line: startLine });
      } else if (prefix.indexOf('f') >= 0) {
        toks.push({ t: 'FSTR', v: splitFString(out, startLine), line: startLine });
      } else toks.push({ t: 'STR', v: out, line: startLine });
      i = k; continue;
    }
    if ((m = NUM_RE.exec(rest)) && /[0-9.]/.test(c) && !(c === '.' && !/\d/.test(src[i + 1] || ''))) {
      var txt = m[1].replace(/_/g, ''), val, isF = false;
      if (/^0[xX]/.test(txt)) val = parseInt(txt.substr(2), 16);
      else if (/^0[bB]/.test(txt)) val = parseInt(txt.substr(2), 2);
      else if (/^0[oO]/.test(txt)) val = parseInt(txt.substr(2), 8);
      else if (/[.eE]/.test(txt)) { val = parseFloat(txt); isF = true; }
      else val = parseInt(txt, 10);
      if (!isF && val > 9007199254740991) throw syntaxErr('whole numbers above 2**53 are not supported in this emulator', line);
      toks.push({ t: 'NUM', v: val, f: isF, line: line });
      i += m[1].length; continue;
    }
    if ((m = NAME_RE.exec(rest))) {
      var word = m[0];
      if (word.length === 64) { var full = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.substr(i)); word = full[0]; }
      toks.push({ t: KEYWORDS[word] ? 'KW' : 'NAME', v: word, line: line });
      i += word.length; continue;
    }
    var op = null, t3 = src.substr(i, 3), t2 = src.substr(i, 2);
    if (OPS3.indexOf(t3) >= 0) op = t3; else if (OPS2.indexOf(t2) >= 0) op = t2; else if (OPS1.indexOf(c) >= 0) op = c;
    if (!op) throw syntaxErr('invalid character ' + JSON.stringify(c), line);
    if (op === '(' || op === '[' || op === '{') { paren++; opens.push({ ch: op, line: line }); }
    if (op === ')' || op === ']' || op === '}') { paren--; opens.pop(); if (paren < 0) throw syntaxErr('unmatched \'' + op + '\'', line); }
    toks.push({ t: 'OP', v: op, line: line });
    i += op.length;
  }
  if (paren > 0) toks.unclosed = opens[opens.length - 1];
  if (toks.length && toks[toks.length - 1].t !== 'NEWLINE') toks.push({ t: 'NEWLINE', line: line });
  while (indents.length > 1) { indents.pop(); toks.push({ t: 'DEDENT', line: line }); }
  toks.push({ t: 'EOF', line: line });
  return toks;
}

function splitFString(s, line) {
  var parts = [], cur = '', i = 0;
  while (i < s.length) {
    var c = s[i];
    if (c === '{') {
      if (s[i + 1] === '{') { cur += '{'; i += 2; continue; }
      var depth = 1, j = i + 1, inq = null;
      while (j < s.length && depth > 0) {
        var d = s[j];
        if (inq) { if (d === inq) inq = null; }
        else if (d === '"' || d === '\'') inq = d;
        else if (d === '{' || d === '[' || d === '(') depth++;
        else if (d === '}' || d === ']' || d === ')') depth--;
        if (depth > 0) j++;
      }
      if (depth !== 0) throw syntaxErr('f-string: expecting \'}\'', line);
      var inner = s.substring(i + 1, j), spec = '', conv = '';
      // split off format spec at the top-level colon
      var lvl = 0, q2 = null, cut = -1;
      for (var k = 0; k < inner.length; k++) {
        var e = inner[k];
        if (q2) { if (e === q2) q2 = null; continue; }
        if (e === '"' || e === '\'') q2 = e;
        else if (e === '(' || e === '[' || e === '{') lvl++;
        else if (e === ')' || e === ']' || e === '}') lvl--;
        else if (e === ':' && lvl === 0) { cut = k; break; }
        else if (e === '!' && lvl === 0 && inner[k + 1] !== '=' && /^![rs](:|$)/.test(inner.substr(k))) { cut = k; break; }
      }
      var exprSrc = inner;
      if (cut >= 0) {
        exprSrc = inner.substring(0, cut);
        var tail = inner.substring(cut);
        if (tail[0] === '!') { conv = tail[1]; tail = tail.substring(2); }
        if (tail[0] === ':') spec = tail.substring(1);
      }
      if (!exprSrc.trim()) throw syntaxErr('f-string: valid expression required before \'}\'', line);
      if (cur) { parts.push(cur); cur = ''; }
      parts.push({ src: exprSrc, conv: conv, spec: spec });
      i = j + 1; continue;
    }
    if (c === '}') {
      if (s[i + 1] === '}') { cur += '}'; i += 2; continue; }
      throw syntaxErr('f-string: single \'}\' is not allowed', line);
    }
    cur += c; i++;
  }
  if (cur) parts.push(cur);
  return parts;
}

// ---------------------------------------------------------------- parser
function Parser(toks) { this.toks = toks; this.p = 0; }
var P = Parser.prototype;
P.peek = function () { return this.toks[this.p]; };
P.isOp = function (v) { var t = this.toks[this.p]; return t.t === 'OP' && t.v === v; };
P.isKw = function (v) { var t = this.toks[this.p]; return t.t === 'KW' && t.v === v; };
P.eatOp = function (v) { if (this.isOp(v)) { this.p++; return true; } return false; };
P.eatKw = function (v) { if (this.isKw(v)) { this.p++; return true; } return false; };
P.fail = function (msg) {
  var t = this.peek(), u = this.toks.unclosed;
  if (u && (t.t === 'EOF' || (t.t === 'NEWLINE' && this.toks[this.p + 1].t === 'EOF') || t.t === 'DEDENT')) throw syntaxErr('\'' + u.ch + '\' was never closed', u.line);
  throw syntaxErr(msg || 'invalid syntax', t.line);
};
P.expectOp = function (v) { if (!this.eatOp(v)) this.fail('expected \'' + v + '\''); };
P.expectKw = function (v) { if (!this.eatKw(v)) this.fail('expected \'' + v + '\''); };
P.name = function () { var t = this.peek(); if (t.t !== 'NAME') this.fail(); this.p++; return t.v; };

P.parseFile = function () {
  var body = [];
  while (this.peek().t !== 'EOF') {
    if (this.peek().t === 'INDENT') this.fail('unexpected indent');
    this.stmt(body);
  }
  return body;
};
P.block = function (kind, line) {
  var body = [];
  if (this.peek().t === 'NEWLINE') {
    this.p++;
    if (this.peek().t !== 'INDENT') this.fail('expected an indented block after ' + kind + ' on line ' + line);
    this.p++;
    while (this.peek().t !== 'DEDENT' && this.peek().t !== 'EOF') this.stmt(body);
    if (this.peek().t === 'DEDENT') this.p++;
  } else this.simpleLine(body);
  return body;
};
P.stmt = function (out) {
  var t = this.peek();
  if (t.t === 'INDENT') this.fail('unexpected indent');
  if (t.t === 'KW') {
    var line = t.line, cond, body;
    switch (t.v) {
      case 'if': {
        this.p++;
        var tests = [], orelse = null;
        cond = this.test(); this.expectOp(':'); body = this.block("'if' statement", line);
        tests.push({ cond: cond, body: body, line: line });
        for (;;) {
          var t2 = this.peek();
          if (this.eatKw('elif')) { cond = this.test(); this.expectOp(':'); tests.push({ cond: cond, body: this.block("'elif' statement", t2.line), line: t2.line }); }
          else if (this.eatKw('else')) { this.expectOp(':'); orelse = this.block("'else' statement", t2.line); break; }
          else break;
        }
        out.push({ k: 'If', line: line, tests: tests, orelse: orelse }); return;
      }
      case 'while': {
        this.p++; cond = this.test(); this.expectOp(':'); body = this.block("'while' statement", line);
        out.push({ k: 'While', line: line, cond: cond, body: body }); return;
      }
      case 'for': {
        this.p++; var target = this.targetList(); this.expectKw('in'); var it = this.testList(); this.expectOp(':');
        out.push({ k: 'For', line: line, target: target, iter: it, body: this.block("'for' statement", line) }); return;
      }
      case 'def': {
        this.p++; var fname = this.name(); this.expectOp('(');
        var params = [];
        while (!this.isOp(')')) {
          if (this.isOp('*')) this.fail('*args is not available in this emulator');
          var pn = this.name(), dflt = null;
          if (this.eatOp(':')) this.test();
          if (this.eatOp('=')) dflt = this.test();
          params.push({ name: pn, dflt: dflt });
          if (!this.eatOp(',')) break;
        }
        this.expectOp(')');
        if (this.eatOp('->')) this.test();
        this.expectOp(':');
        out.push({ k: 'Def', line: line, name: fname, params: params, body: this.block('function definition', line) }); return;
      }
      case 'class': case 'try': case 'with': case 'lambda': case 'yield': case 'nonlocal': case 'except': case 'finally':
        this.fail('\'' + t.v + '\' is not available in this small emulator');
        break;
      case 'elif': case 'else':
        this.fail('invalid syntax');
        break;
    }
  }
  this.simpleLine(out);
};
P.simpleLine = function (out) {
  for (;;) {
    out.push(this.small());
    if (this.eatOp(';')) { if (this.peek().t === 'NEWLINE') break; continue; }
    break;
  }
  if (this.peek().t === 'NEWLINE') this.p++;
  else if (this.peek().t !== 'EOF') this.fail();
};
var AUG = { '+=': '+', '-=': '-', '*=': '*', '/=': '/', '//=': '//', '%=': '%', '**=': '**', '>>=': '>>', '<<=': '<<', '&=': '&', '|=': '|', '^=': '^' };
P.small = function () {
  var t = this.peek(), line = t.line;
  if (t.t === 'KW') {
    switch (t.v) {
      case 'pass': this.p++; return { k: 'Pass', line: line };
      case 'break': this.p++; return { k: 'Break', line: line };
      case 'continue': this.p++; return { k: 'Continue', line: line };
      case 'return': {
        this.p++;
        var v = null;
        if (this.peek().t !== 'NEWLINE' && !this.isOp(';') && this.peek().t !== 'EOF') v = this.testList();
        return { k: 'Return', line: line, value: v };
      }
      case 'import': {
        this.p++;
        var names = [];
        do { var mod = this.name(), as = mod; if (this.eatKw('as')) as = this.name(); names.push({ mod: mod, as: as }); } while (this.eatOp(','));
        return { k: 'Import', line: line, names: names };
      }
      case 'from': {
        this.p++;
        var m2 = this.name(); this.expectKw('import');
        var ns = [];
        do { var nm = this.name(), a2 = nm; if (this.eatKw('as')) a2 = this.name(); ns.push({ name: nm, as: a2 }); } while (this.eatOp(','));
        return { k: 'FromImport', line: line, mod: m2, names: ns };
      }
      case 'global': {
        this.p++;
        var gs = [];
        do { gs.push(this.name()); } while (this.eatOp(','));
        return { k: 'Global', line: line, names: gs };
      }
      case 'assert': {
        this.p++;
        var c = this.test(), msg = null;
        if (this.eatOp(',')) msg = this.test();
        return { k: 'Assert', line: line, cond: c, msg: msg };
      }
      case 'raise': {
        this.p++;
        var ex = null;
        if (this.peek().t !== 'NEWLINE' && this.peek().t !== 'EOF') ex = this.test();
        return { k: 'Raise', line: line, exc: ex };
      }
      case 'del': {
        this.p++;
        return { k: 'Del', line: line, target: this.test() };
      }
    }
  }
  var first = this.testList();
  var nt = this.peek();
  if (nt.t === 'OP' && AUG[nt.v]) {
    this.p++;
    this.checkTarget(first, true);
    return { k: 'Aug', line: line, target: first, op: AUG[nt.v], value: this.testList() };
  }
  if (this.isOp('=')) {
    var targets = [first], value = null;
    while (this.eatOp('=')) { value = this.testList(); targets.push(value); }
    targets.pop();
    for (var i = 0; i < targets.length; i++) this.checkTarget(targets[i], false);
    return { k: 'Assign', line: line, targets: targets, value: value };
  }
  if (this.isOp(':') && first.k === 'Name') { // annotation: x: int = 3
    this.p++; this.test();
    if (this.eatOp('=')) return { k: 'Assign', line: line, targets: [first], value: this.testList() };
    return { k: 'Pass', line: line };
  }
  return { k: 'Expr', line: line, e: first };
};
P.checkTarget = function (n, single) {
  if (n.k === 'Name' || n.k === 'Sub' || n.k === 'Attr') return;
  if (!single && (n.k === 'Tuple' || n.k === 'List')) { for (var i = 0; i < n.items.length; i++) this.checkTarget(n.items[i], false); return; }
  var what = n.k === 'Call' ? 'function call' : (n.k === 'Num' || n.k === 'Str' || n.k === 'Const') ? 'literal' : 'expression';
  throw syntaxErr('cannot assign to ' + what + ' here. Maybe you meant \'==\' instead of \'=\'?', n.line);
};
P.targetList = function () {
  var line = this.peek().line, items = [this.targetAtom()], tuple = false;
  while (this.eatOp(',')) { tuple = true; if (this.isKw('in')) break; items.push(this.targetAtom()); }
  return tuple ? { k: 'Tuple', line: line, items: items } : items[0];
};
P.targetAtom = function () {
  if (this.isOp('(') || this.isOp('[')) {
    var close = this.isOp('(') ? ')' : ']';
    this.p++;
    var line = this.peek().line, items = [];
    while (!this.isOp(close)) { items.push(this.targetAtom()); if (!this.eatOp(',')) break; }
    this.expectOp(close);
    return { k: 'Tuple', line: line, items: items };
  }
  var n = this.primary();
  this.checkTarget(n, true);
  return n;
};
P.testList = function () {
  var line = this.peek().line, first = this.test();
  if (!this.isOp(',')) return first;
  var items = [first];
  while (this.eatOp(',')) {
    var t = this.peek();
    if (t.t === 'NEWLINE' || t.t === 'EOF' || (t.t === 'OP' && (t.v === '=' || t.v === ')' || t.v === ':' || AUG[t.v]))) break;
    items.push(this.test());
  }
  return { k: 'Tuple', line: line, items: items };
};
P.test = function () {
  var a = this.orTest();
  if (this.isKw('if')) {
    var line = this.peek().line; this.p++;
    var c = this.orTest(); this.expectKw('else');
    return { k: 'IfExp', line: line, cond: c, a: a, b: this.test() };
  }
  return a;
};
P.orTest = function () {
  var l = this.andTest();
  while (this.isKw('or')) { var line = this.peek().line; this.p++; l = { k: 'Bool', line: line, op: 'or', l: l, r: this.andTest() }; }
  return l;
};
P.andTest = function () {
  var l = this.notTest();
  while (this.isKw('and')) { var line = this.peek().line; this.p++; l = { k: 'Bool', line: line, op: 'and', l: l, r: this.notTest() }; }
  return l;
};
P.notTest = function () {
  if (this.isKw('not')) { var line = this.peek().line; this.p++; return { k: 'Not', line: line, e: this.notTest() }; }
  return this.comparison();
};
var CMP = { '<': 1, '>': 1, '==': 1, '>=': 1, '<=': 1, '!=': 1 };
P.comparison = function () {
  var first = this.bitOr(), ops = [], rest = [], line = this.peek().line;
  for (;;) {
    var t = this.peek(), op = null;
    if (t.t === 'OP' && CMP[t.v]) { op = t.v; this.p++; }
    else if (t.t === 'KW' && t.v === 'in') { op = 'in'; this.p++; }
    else if (t.t === 'KW' && t.v === 'not' && this.toks[this.p + 1].t === 'KW' && this.toks[this.p + 1].v === 'in') { op = 'not in'; this.p += 2; }
    else if (t.t === 'KW' && t.v === 'is') { this.p++; op = this.eatKw('not') ? 'is not' : 'is'; }
    else break;
    ops.push(op); rest.push(this.bitOr());
  }
  if (!ops.length) return first;
  return { k: 'Compare', line: line, first: first, ops: ops, rest: rest };
};
function binLevel(next, ops) {
  return function () {
    var l = this[next]();
    for (;;) {
      var t = this.peek();
      if (t.t === 'OP' && ops.indexOf(t.v) >= 0) { this.p++; l = { k: 'Bin', line: t.line, op: t.v, l: l, r: this[next]() }; }
      else return l;
    }
  };
}
P.bitOr = binLevel('bitXor', ['|']);
P.bitXor = binLevel('bitAnd', ['^']);
P.bitAnd = binLevel('shift', ['&']);
P.shift = binLevel('arith', ['<<', '>>']);
P.arith = binLevel('term', ['+', '-']);
P.term = binLevel('factor', ['*', '/', '//', '%', '@']);
P.factor = function () {
  var t = this.peek();
  if (t.t === 'OP' && (t.v === '-' || t.v === '+' || t.v === '~')) {
    this.p++;
    var e = this.factor();
    if (t.v === '-' && e.k === 'Num') return { k: 'Num', line: t.line, v: e.v instanceof PyFloat ? new PyFloat(-e.v.v) : -e.v };
    return { k: 'Unary', line: t.line, op: t.v, e: e };
  }
  return this.power();
};
P.power = function () {
  var base = this.primary();
  if (this.isOp('**')) { var line = this.peek().line; this.p++; return { k: 'Bin', line: line, op: '**', l: base, r: this.factor() }; }
  return base;
};
P.primary = function () {
  var n = this.atom();
  for (;;) {
    var t = this.peek();
    if (t.t !== 'OP') return n;
    if (t.v === '(') {
      this.p++;
      var args = [], kws = [];
      while (!this.isOp(')')) {
        if (this.isOp('*') || this.isOp('**')) this.fail('*args is not available in this emulator');
        if (this.peek().t === 'NAME' && this.toks[this.p + 1].t === 'OP' && this.toks[this.p + 1].v === '=') {
          var kn = this.name(); this.p++;
          kws.push({ name: kn, value: this.test() });
        } else {
          if (kws.length) this.fail('positional argument follows keyword argument');
          var a = this.test();
          if (this.isKw('for')) a = this.compTail(a, true, t.line);
          args.push(a);
        }
        if (!this.eatOp(',')) break;
      }
      this.expectOp(')');
      n = { k: 'Call', line: t.line, fn: n, args: args, kws: kws };
    } else if (t.v === '[') {
      this.p++;
      var idx = this.subscript();
      this.expectOp(']');
      n = { k: 'Sub', line: t.line, obj: n, idx: idx };
    } else if (t.v === '.') {
      this.p++;
      n = { k: 'Attr', line: t.line, obj: n, name: this.name() };
    } else return n;
  }
};
P.subscript = function () {
  var line = this.peek().line, lo = null, hi = null, step = null;
  if (!this.isOp(':')) {
    lo = this.test();
    if (!this.isOp(':')) {
      if (this.isOp(',')) this.fail('multi-dimensional indexing is not available; use a[i][j]');
      return lo;
    }
  }
  this.expectOp(':');
  if (!this.isOp(']') && !this.isOp(':')) hi = this.test();
  if (this.eatOp(':')) { if (!this.isOp(']')) step = this.test(); }
  return { k: 'Slice', line: line, lo: lo, hi: hi, step: step };
};
P.compTail = function (elt, gen, line) {
  var gens = [];
  while (this.eatKw('for')) {
    var target = this.targetList(); this.expectKw('in');
    var it = this.orTest(), conds = [];
    while (this.eatKw('if')) conds.push(this.orTest());
    gens.push({ target: target, iter: it, conds: conds });
  }
  return { k: 'Comp', line: line, elt: elt, gens: gens, gen: gen };
};
P.atom = function () {
  var t = this.peek(), line = t.line;
  switch (t.t) {
    case 'NUM': this.p++; return { k: 'Num', line: line, v: t.f ? new PyFloat(t.v) : t.v };
    case 'NAME': this.p++; return { k: 'Name', line: line, id: t.v };
    case 'BYTES': this.p++; return { k: 'Bytes', line: line, v: t.v };
    case 'STR': case 'FSTR': {
      var parts = [], isF = false;
      while (this.peek().t === 'STR' || this.peek().t === 'FSTR') {
        var s = this.peek(); this.p++;
        if (s.t === 'STR') parts.push(s.v);
        else {
          isF = true;
          for (var i = 0; i < s.v.length; i++) {
            var part = s.v[i];
            if (typeof part === 'string') parts.push(part);
            else {
              var sub;
              try { sub = new Parser(tokenize(part.src)); var ex = sub.testList(); if (sub.peek().t !== 'NEWLINE') sub.fail(); parts.push({ e: ex, conv: part.conv, spec: part.spec }); }
              catch (err) { if (err instanceof PyError) { err.line = s.line; err.msg = 'f-string: ' + err.msg; } throw err; }
            }
          }
        }
      }
      if (!isF) return { k: 'Str', line: line, v: parts.join('') };
      return { k: 'FStr', line: line, parts: parts };
    }
    case 'KW':
      if (t.v === 'True') { this.p++; return { k: 'Const', line: line, v: true }; }
      if (t.v === 'False') { this.p++; return { k: 'Const', line: line, v: false }; }
      if (t.v === 'None') { this.p++; return { k: 'Const', line: line, v: null }; }
      if (t.v === 'lambda') this.fail('\'lambda\' is not available in this small emulator; use def');
      this.fail();
      break;
    case 'OP':
      if (t.v === '(') {
        this.p++;
        if (this.eatOp(')')) return { k: 'Tuple', line: line, items: [] };
        var e = this.test();
        if (this.isKw('for')) { e = this.compTail(e, true, line); this.expectOp(')'); return e; }
        if (this.isOp(',')) {
          var items = [e];
          while (this.eatOp(',')) { if (this.isOp(')')) break; items.push(this.test()); }
          this.expectOp(')');
          return { k: 'Tuple', line: line, items: items };
        }
        this.expectOp(')');
        return e;
      }
      if (t.v === '[') {
        this.p++;
        if (this.eatOp(']')) return { k: 'List', line: line, items: [] };
        var e2 = this.test();
        if (this.isKw('for')) { e2 = this.compTail(e2, false, line); this.expectOp(']'); return e2; }
        var li = [e2];
        while (this.eatOp(',')) { if (this.isOp(']')) break; li.push(this.test()); }
        this.expectOp(']');
        return { k: 'List', line: line, items: li };
      }
      if (t.v === '{') {
        this.p++;
        var keys = [], vals = [];
        while (!this.isOp('}')) {
          keys.push(this.test());
          if (!this.isOp(':')) this.fail('sets are not available in this emulator; use a list or dict');
          this.p++;
          vals.push(this.test());
          if (this.isKw('for')) this.fail('dict comprehensions are not available in this emulator');
          if (!this.eatOp(',')) break;
        }
        this.expectOp('}');
        return { k: 'Dict', line: line, keys: keys, vals: vals };
      }
      this.fail();
      break;
  }
  if (t.t === 'NEWLINE' || t.t === 'EOF') this.fail('invalid syntax (the line ends too soon)');
  if (t.t === 'INDENT') this.fail('unexpected indent');
  this.fail();
};

function parse(src) {
  var toks = tokenize(src), body = new Parser(toks).parseFile();
  if (toks.unclosed) throw syntaxErr('\'' + toks.unclosed.ch + '\' was never closed', toks.unclosed.line);
  return body;
}

// ---------------------------------------------------------------- formatting
function floatRepr(x) {
  if (x !== x) return 'nan';
  if (x === Infinity) return 'inf';
  if (x === -Infinity) return '-inf';
  if (x === 0) return (1 / x < 0) ? '-0.0' : '0.0';
  var s = x.toExponential();
  var neg = s[0] === '-';
  if (neg) s = s.substr(1);
  var ei = s.indexOf('e');
  var digits = s.substring(0, ei).replace('.', ''), exp = parseInt(s.substr(ei + 1), 10), out;
  if (exp >= -4 && exp < 16) {
    if (exp < 0) out = '0.' + new Array(-exp).join('0') + digits;
    else if (digits.length <= exp + 1) out = digits + new Array(exp + 2 - digits.length).join('0') + '.0';
    else out = digits.substring(0, exp + 1) + '.' + digits.substr(exp + 1);
  } else {
    var ae = Math.abs(exp);
    out = digits[0] + (digits.length > 1 ? '.' + digits.substr(1) : '') + 'e' + (exp < 0 ? '-' : '+') + (ae < 10 ? '0' + ae : '' + ae);
  }
  return (neg ? '-' : '') + out;
}
// toFixed with Python's round-half-even on exact ties
function fixed(x, nd) {
  if (!isFinite(x)) return x !== x ? 'nan' : (x > 0 ? 'inf' : '-inf');
  if (nd > 20) nd = 20;
  var ax = Math.abs(x), s = ax * Math.pow(10, nd);
  // an exact tie needs x to be a multiple of 1/2**(nd+1); then Python rounds half to even
  if (s < 4503599627370496 && (ax * Math.pow(2, nd + 1)) % 1 === 0 && s % 1 === 0.5) {
    var fl = Math.floor(s), even = (fl % 2 === 0) ? fl : fl + 1;
    return (x < 0 ? '-' : '') + (even / Math.pow(10, nd)).toFixed(nd);
  }
  return x.toFixed(nd);
}
function strRepr(s) {
  var q = (s.indexOf('\'') >= 0 && s.indexOf('"') < 0) ? '"' : '\'';
  var out = q;
  for (var i = 0; i < s.length; i++) {
    var c = s[i], code = s.charCodeAt(i);
    if (c === '\\') out += '\\\\';
    else if (c === q) out += '\\' + q;
    else if (c === '\n') out += '\\n';
    else if (c === '\t') out += '\\t';
    else if (c === '\r') out += '\\r';
    else if (code < 32 || code === 127) out += '\\x' + (code < 16 ? '0' : '') + code.toString(16);
    else out += c;
  }
  return out + q;
}
function bytesRepr(d) {
  var hasS = false, hasD = false, i;
  for (i = 0; i < d.length; i++) { if (d[i] === 39) hasS = true; if (d[i] === 34) hasD = true; }
  var q = (hasS && !hasD) ? '"' : '\'';
  var out = 'b' + q;
  for (i = 0; i < d.length; i++) {
    var b = d[i];
    if (b === 92) out += '\\\\';
    else if (b === q.charCodeAt(0)) out += '\\' + q;
    else if (b === 10) out += '\\n';
    else if (b === 9) out += '\\t';
    else if (b === 13) out += '\\r';
    else if (b < 32 || b >= 127) out += '\\x' + (b < 16 ? '0' : '') + b.toString(16);
    else out += String.fromCharCode(b);
  }
  return out + q;
}
function typeName(v) {
  if (v === null) return 'NoneType';
  var t = typeof v;
  if (t === 'number') return 'int';
  if (t === 'boolean') return 'bool';
  if (t === 'string') return 'str';
  if (v instanceof PyFloat) return 'float';
  if (v instanceof PyList) return 'list';
  if (v instanceof PyTuple) return 'tuple';
  if (v instanceof PyDict) return 'dict';
  if (v instanceof PyBytes) return 'bytes';
  if (v instanceof PyRange) return 'range';
  if (v instanceof PyFunc) return 'function';
  if (v instanceof PyBuiltin) return 'builtin_function_or_method';
  if (v instanceof PyModule) return 'module';
  if (v instanceof PyType) return 'type';
  return 'object';
}
function repr(v) {
  if (v === null) return 'None';
  var t = typeof v;
  if (t === 'number') return String(v);
  if (t === 'boolean') return v ? 'True' : 'False';
  if (t === 'string') return strRepr(v);
  if (v instanceof PyFloat) return floatRepr(v.v);
  if (v instanceof PyList) return '[' + v.items.map(repr).join(', ') + ']';
  if (v instanceof PyTuple) return v.items.length === 1 ? '(' + repr(v.items[0]) + ',)' : '(' + v.items.map(repr).join(', ') + ')';
  if (v instanceof PyDict) { var parts = []; v.map.forEach(function (kv) { parts.push(repr(kv[0]) + ': ' + repr(kv[1])); }); return '{' + parts.join(', ') + '}'; }
  if (v instanceof PyBytes) return bytesRepr(v.data);
  if (v instanceof PyRange) return 'range(' + v.start + ', ' + v.stop + (v.step !== 1 ? ', ' + v.step : '') + ')';
  if (v instanceof PyFunc) return '<function ' + v.name + '>';
  if (v instanceof PyBuiltin) return '<built-in function ' + v.name + '>';
  if (v instanceof PyModule) return '<module \'' + v.name + '\'>';
  if (v instanceof PyType) return '<class \'' + v.name + '\'>';
  return String(v);
}
function str(v) { return typeof v === 'string' ? v : repr(v); }

function groupThousands(s) { return s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function format(v, spec) {
  if (spec === '') return str(v);
  var m = /^(?:(.)?([<>^=]))?([+\- ])?(0)?(\d+)?(,)?(?:\.(\d+))?([bdeEfFgGsx%X])?$/.exec(spec);
  if (!m) throw E('ValueError', 'Invalid format specifier \'' + spec + '\'');
  var fill = m[1] || ' ', align = m[2], sign = m[3] || '-', zero = m[4], width = m[5] ? parseInt(m[5], 10) : 0, comma = m[6], prec = m[7] !== undefined ? parseInt(m[7], 10) : -1, ty = m[8];
  if (zero && !align) { fill = '0'; align = '='; }
  var isNumV = typeof v === 'number' || typeof v === 'boolean' || v instanceof PyFloat;
  var body, neg = false;
  if (!isNumV) {
    if (ty && ty !== 's') throw E('ValueError', 'Unknown format code \'' + ty + '\' for object of type \'' + typeName(v) + '\'');
    body = str(v);
    if (prec >= 0) body = body.substr(0, prec);
    if (!align) align = '<';
  } else {
    var isF = v instanceof PyFloat, x = isF ? v.v : (typeof v === 'boolean' ? (v ? 1 : 0) : v);
    if (ty === 's') throw E('ValueError', 'Unknown format code \'s\' for object of type \'' + typeName(v) + '\'');
    neg = x < 0 || (x === 0 && 1 / x < 0);
    var ax = Math.abs(x);
    var bare = !ty && isF && prec >= 0;
    if (!ty) ty = isF ? (prec >= 0 ? 'g' : 'r') : 'd';
    if (!isF && 'bdxX'.indexOf(ty) >= 0) {
      if (prec >= 0) throw E('ValueError', 'Precision not allowed in integer format specifier');
      body = ty === 'b' ? ax.toString(2) : ty === 'x' ? ax.toString(16) : ty === 'X' ? ax.toString(16).toUpperCase() : String(ax);
    } else if (isF && 'bdxX'.indexOf(ty) >= 0) {
      throw E('ValueError', 'Unknown format code \'' + ty + '\' for object of type \'float\'');
    } else if (ty === 'f' || ty === 'F') body = fixed(ax, prec < 0 ? 6 : prec);
    else if (ty === '%') body = fixed(ax * 100, prec < 0 ? 6 : prec) + '%';
    else if (ty === 'e' || ty === 'E') {
      body = ax.toExponential(prec < 0 ? 6 : prec).replace(/e([+-])(\d)$/, 'e$10$2');
      if (ty === 'E') body = body.toUpperCase();
    } else if (ty === 'r') body = floatRepr(ax);
    else { // g
      var p = prec < 0 ? 6 : (prec === 0 ? 1 : prec);
      if (ax === 0) body = '0';
      else {
        var ex = Math.floor(Math.log(ax) / Math.LN10);
        var es = ax.toExponential(p - 1); ex = parseInt(es.substr(es.indexOf('e') + 1), 10);
        if (ex < -4 || ex >= p) { body = es.replace(/\.?0+e/, 'e').replace(/e([+-])(\d)$/, 'e$10$2'); }
        else { body = ax.toFixed(Math.max(0, p - 1 - ex)); if (body.indexOf('.') >= 0) body = body.replace(/\.?0+$/, ''); }
      }
    }
    if (bare && body.indexOf('.') < 0 && body.indexOf('e') < 0) body += '.0';
    if (comma) { var dot = body.indexOf('.'); body = dot < 0 ? groupThousands(body) : groupThousands(body.substring(0, dot)) + body.substr(dot); }
    if (!align) align = '>';
  }
  var sgn = isNumV ? (neg ? '-' : (sign === '+' ? '+' : sign === ' ' ? ' ' : '')) : '';
  var pad = width - body.length - sgn.length;
  if (pad <= 0) return sgn + body;
  var fillS = new Array(pad + 1).join(fill);
  if (align === '<') return sgn + body + fillS;
  if (align === '=') return sgn + fillS + body;
  if (align === '^') { var left = Math.floor(pad / 2); return new Array(left + 1).join(fill) + sgn + body + new Array(pad - left + 1).join(fill); }
  return fillS + sgn + body;
}

// ---------------------------------------------------------------- core semantics
function isNum(v) { return typeof v === 'number' || typeof v === 'boolean' || v instanceof PyFloat; }
function num(v) { return v instanceof PyFloat ? v.v : (v === true ? 1 : v === false ? 0 : v); }
function chk(x) {
  if (x > 9007199254740991 || x < -9007199254740991) throw E('OverflowError', 'whole number too large for this emulator (limit is 2**53)');
  return x;
}
function truthy(v) {
  if (v === null || v === false || v === 0 || v === '') return false;
  if (v === true) return true;
  if (typeof v === 'object') {
    if (v instanceof PyFloat) return v.v !== 0;
    if (v instanceof PyList || v instanceof PyTuple) return v.items.length > 0;
    if (v instanceof PyDict) return v.map.size > 0;
    if (v instanceof PyBytes) return v.data.length > 0;
    if (v instanceof PyRange) return rangeLen(v) > 0;
  }
  return true;
}
function rangeLen(r) {
  if (r.step > 0) return r.start < r.stop ? Math.ceil((r.stop - r.start) / r.step) : 0;
  return r.start > r.stop ? Math.ceil((r.start - r.stop) / -r.step) : 0;
}
function keyOf(k) {
  if (typeof k === 'string') return 's' + k;
  if (typeof k === 'number') return 'n' + k;
  if (typeof k === 'boolean') return 'n' + (k ? 1 : 0);
  if (k === null) return 'N';
  if (k instanceof PyFloat) return 'n' + k.v;
  if (k instanceof PyTuple) return 't(' + k.items.map(keyOf).join(',') + ')';
  throw E('TypeError', 'cannot use \'' + typeName(k) + '\' as a dict key (unhashable type: \'' + typeName(k) + '\')');
}
function pyEq(a, b) {
  if (a === b) return true;
  if (isNum(a) && isNum(b)) return num(a) === num(b);
  if (a === null || b === null || typeof a !== 'object' || typeof b !== 'object') return false;
  var i;
  if ((a instanceof PyList && b instanceof PyList) || (a instanceof PyTuple && b instanceof PyTuple)) {
    if (a.items.length !== b.items.length) return false;
    for (i = 0; i < a.items.length; i++) if (!pyEq(a.items[i], b.items[i])) return false;
    return true;
  }
  if (a instanceof PyBytes && b instanceof PyBytes) {
    if (a.data.length !== b.data.length) return false;
    for (i = 0; i < a.data.length; i++) if (a.data[i] !== b.data[i]) return false;
    return true;
  }
  if (a instanceof PyDict && b instanceof PyDict) {
    if (a.map.size !== b.map.size) return false;
    var ok = true;
    a.map.forEach(function (kv, key) { var o = b.map.get(key); if (!o || !pyEq(kv[1], o[1])) ok = false; });
    return ok;
  }
  if (a instanceof PyRange && b instanceof PyRange) return pyEq(new PyList(toArray(a)), new PyList(toArray(b)));
  return false;
}
function pyLt(a, b, op) {
  if (isNum(a) && isNum(b)) return num(a) < num(b);
  if (typeof a === 'string' && typeof b === 'string') return a < b;
  if ((a instanceof PyList && b instanceof PyList) || (a instanceof PyTuple && b instanceof PyTuple)) {
    var n = Math.min(a.items.length, b.items.length);
    for (var i = 0; i < n; i++) { if (!pyEq(a.items[i], b.items[i])) return pyLt(a.items[i], b.items[i], op); }
    return a.items.length < b.items.length;
  }
  throw E('TypeError', '\'' + op + '\' not supported between instances of \'' + typeName(a) + '\' and \'' + typeName(b) + '\'');
}
function compare(op, a, b) {
  switch (op) {
    case '==': return pyEq(a, b);
    case '!=': return !pyEq(a, b);
    case '<': return pyLt(a, b, op);
    case '>': return pyLt(b, a, op);
    case '<=': return pyEq(a, b) || pyLt(a, b, op);
    case '>=': return pyEq(a, b) || pyLt(b, a, op);
    case 'is': return a === b;
    case 'is not': return a !== b;
    case 'in': return contains(b, a);
    case 'not in': return !contains(b, a);
  }
}
function contains(c, x) {
  var i;
  if (typeof c === 'string') {
    if (typeof x !== 'string') throw E('TypeError', '\'in <string>\' requires string as left operand, not ' + typeName(x));
    return c.indexOf(x) >= 0;
  }
  if (c instanceof PyList || c instanceof PyTuple) { for (i = 0; i < c.items.length; i++) if (pyEq(c.items[i], x)) return true; return false; }
  if (c instanceof PyDict) return c.map.has(keyOf(x));
  if (c instanceof PyBytes) return c.data.indexOf(num(x)) >= 0;
  if (c instanceof PyRange) { var a = toArray(c); for (i = 0; i < a.length; i++) if (pyEq(a[i], x)) return true; return false; }
  throw E('TypeError', 'argument of type \'' + typeName(c) + '\' is not iterable');
}
function toArray(v) {
  if (v instanceof PyList || v instanceof PyTuple) return v.items;
  if (typeof v === 'string') return v.split('');
  if (v instanceof PyBytes) return v.data;
  if (v instanceof PyRange) {
    var n = rangeLen(v), out = [];
    if (n > 2000000) throw E('MemoryError', 'range is too large to turn into a list in this emulator');
    for (var i = 0; i < n; i++) out.push(v.start + i * v.step);
    return out;
  }
  if (v instanceof PyDict) { var ks = []; v.map.forEach(function (kv) { ks.push(kv[0]); }); return ks; }
  throw E('TypeError', '\'' + typeName(v) + '\' object is not iterable');
}
function intPow(x, y) { var r = 1; for (var i = 0; i < y; i++) { r *= x; if (r > 9007199254740991 || r < -9007199254740991) chk(r); } return r; }
function bitop(op, x, y) {
  if (x >= -2147483648 && x <= 2147483647 && y >= -2147483648 && y <= 2147483647) return op === '&' ? (x & y) : op === '|' ? (x | y) : (x ^ y);
  if (x < 0 || y < 0) throw E('OverflowError', 'bit operations on large negative numbers are not available in this emulator');
  var xh = Math.floor(x / 4294967296), xl = x >>> 0, yh = Math.floor(y / 4294967296), yl = y >>> 0;
  var h = op === '&' ? (xh & yh) : op === '|' ? (xh | yh) : (xh ^ yh), l = op === '&' ? (xl & yl) : op === '|' ? (xl | yl) : (xl ^ yl);
  return (h >>> 0) * 4294967296 + (l >>> 0);
}
function binop(op, a, b) {
  if (isNum(a) && isNum(b)) {
    var isF = a instanceof PyFloat || b instanceof PyFloat, x = num(a), y = num(b), q, r;
    switch (op) {
      case '+': return isF ? new PyFloat(x + y) : chk(x + y);
      case '-': return isF ? new PyFloat(x - y) : chk(x - y);
      case '*': return isF ? new PyFloat(x * y) : chk(x * y);
      case '/': if (y === 0) throw E('ZeroDivisionError', 'division by zero'); return new PyFloat(x / y);
      case '//':
        if (y === 0) throw E('ZeroDivisionError', 'division by zero');
        q = Math.floor(x / y);
        if (!isF) { r = x - q * y; if ((y > 0 && r < 0) || (y < 0 && r > 0)) q -= 1; else if ((y > 0 && r >= y) || (y < 0 && r <= y)) q += 1; return q; }
        return new PyFloat(q);
      case '%':
        if (y === 0) throw E('ZeroDivisionError', 'division by zero');
        r = x % y;
        if (r !== 0 && ((r < 0) !== (y < 0))) r += y;
        return isF ? new PyFloat(r) : r;
      case '**':
        if (!isF && y >= 0) return intPow(x, y);
        if (x === 0 && y < 0) throw E('ZeroDivisionError', 'zero to a negative power');
        if (x < 0 && y % 1 !== 0) throw E('ValueError', 'negative number to a fractional power gives a complex number (not available here)');
        r = Math.pow(x, y);
        if (!isFinite(r) && isFinite(x) && isFinite(y)) throw E('OverflowError', '(34, \'Numerical result out of range\')');
        return new PyFloat(r);
    }
    if (isF) throw E('TypeError', 'unsupported operand type(s) for ' + op + ': \'' + typeName(a) + '\' and \'' + typeName(b) + '\'');
    switch (op) {
      case '>>': if (y < 0) throw E('ValueError', 'negative shift count'); return Math.floor(x / Math.pow(2, y));
      case '<<': if (y < 0) throw E('ValueError', 'negative shift count'); return chk(x * Math.pow(2, Math.min(y, 1100)));
      case '&': case '|': case '^': return bitop(op, x, y);
    }
  }
  if (op === '+') {
    if (typeof a === 'string' && typeof b === 'string') return a + b;
    if (a instanceof PyList && b instanceof PyList) return new PyList(a.items.concat(b.items));
    if (a instanceof PyTuple && b instanceof PyTuple) return new PyTuple(a.items.concat(b.items));
    if (a instanceof PyBytes && b instanceof PyBytes) return new PyBytes(a.data.concat(b.data));
    if (typeof a === 'string') throw E('TypeError', 'can only concatenate str (not "' + typeName(b) + '") to str');
    if (a instanceof PyList) throw E('TypeError', 'can only concatenate list (not "' + typeName(b) + '") to list');
    if (a instanceof PyTuple) throw E('TypeError', 'can only concatenate tuple (not "' + typeName(b) + '") to tuple');
  }
  if (op === '*') {
    var seq = null, cnt = null;
    if ((typeof b === 'number' || typeof b === 'boolean') && !isNum(a)) { seq = a; cnt = num(b); }
    else if ((typeof a === 'number' || typeof a === 'boolean') && !isNum(b)) { seq = b; cnt = num(a); }
    if (seq !== null && (typeof seq === 'string' || seq instanceof PyList || seq instanceof PyTuple || seq instanceof PyBytes)) {
      if (cnt < 0) cnt = 0;
      var len = typeof seq === 'string' ? seq.length : (seq instanceof PyBytes ? seq.data.length : seq.items.length);
      if (len * cnt > 2000000) throw E('MemoryError', 'that would be too large for this emulator');
      if (typeof seq === 'string') return new Array(cnt + 1).join(seq);
      var src = seq instanceof PyBytes ? seq.data : seq.items, out = [];
      for (var i = 0; i < cnt; i++) for (var j = 0; j < src.length; j++) out.push(src[j]);
      return seq instanceof PyList ? new PyList(out) : seq instanceof PyTuple ? new PyTuple(out) : new PyBytes(out);
    }
    if (typeof a === 'string' || a instanceof PyList || a instanceof PyTuple) throw E('TypeError', 'can\'t multiply sequence by non-int of type \'' + typeName(b) + '\'');
  }
  if (op === '%' && typeof a === 'string') throw E('TypeError', '% text formatting is not available in this emulator; use an f-string');
  throw E('TypeError', 'unsupported operand type(s) for ' + op + ': \'' + typeName(a) + '\' and \'' + typeName(b) + '\'');
}
function seqIndex(len, i, what) {
  if (typeof i === 'boolean') i = i ? 1 : 0;
  if (typeof i !== 'number') throw E('TypeError', what.replace(' assignment', '') + ' indices must be integers or slices, not ' + typeName(i));
  if (i < 0) i += len;
  if (i < 0 || i >= len) throw E('IndexError', (what === 'bytes' ? 'index' : what + ' index') + ' out of range');
  return i;
}
function sliceIdx(sl, len, env) {
  function part(n) { if (!n) return null; var v = ev(n, env); if (v === null) return null; if (typeof v !== 'number') throw E('TypeError', 'slice indices must be integers or None'); return v; }
  var lo = part(sl.lo), hi = part(sl.hi), step = part(sl.step);
  if (step === null) step = 1;
  if (step === 0) throw E('ValueError', 'slice step cannot be zero');
  var out = [], i;
  if (step > 0) {
    lo = lo === null ? 0 : (lo < 0 ? Math.max(0, lo + len) : Math.min(lo, len));
    hi = hi === null ? len : (hi < 0 ? Math.max(0, hi + len) : Math.min(hi, len));
    for (i = lo; i < hi; i += step) out.push(i);
  } else {
    lo = lo === null ? len - 1 : (lo < 0 ? Math.max(-1, lo + len) : Math.min(lo, len - 1));
    hi = hi === null ? -1 : (hi < 0 ? Math.max(-1, hi + len) : Math.min(hi, len - 1));
    for (i = lo; i > hi; i += step) out.push(i);
  }
  return out;
}
function getItem(obj, idxNode, env) {
  var idxs, i, out;
  if (idxNode.k === 'Slice') {
    if (typeof obj === 'string') { idxs = sliceIdx(idxNode, obj.length, env); out = ''; for (i = 0; i < idxs.length; i++) out += obj[idxs[i]]; return out; }
    if (obj instanceof PyList || obj instanceof PyTuple) { idxs = sliceIdx(idxNode, obj.items.length, env); out = []; for (i = 0; i < idxs.length; i++) out.push(obj.items[idxs[i]]); return obj instanceof PyList ? new PyList(out) : new PyTuple(out); }
    if (obj instanceof PyBytes) { idxs = sliceIdx(idxNode, obj.data.length, env); out = []; for (i = 0; i < idxs.length; i++) out.push(obj.data[idxs[i]]); return new PyBytes(out); }
    if (obj instanceof PyRange) { var arr = toArray(obj); idxs = sliceIdx(idxNode, arr.length, env); out = []; for (i = 0; i < idxs.length; i++) out.push(arr[idxs[i]]); return new PyList(out); }
    throw E('TypeError', '\'' + typeName(obj) + '\' object is not subscriptable');
  }
  var idx = ev(idxNode, env);
  if (obj instanceof PyList) return obj.items[seqIndex(obj.items.length, idx, 'list')];
  if (obj instanceof PyDict) { var kv = obj.map.get(keyOf(idx)); if (!kv) throw E('KeyError', repr(idx)); return kv[1]; }
  if (obj instanceof PyTuple) return obj.items[seqIndex(obj.items.length, idx, 'tuple')];
  if (typeof obj === 'string') return obj[seqIndex(obj.length, idx, 'string')];
  if (obj instanceof PyBytes) return obj.data[seqIndex(obj.data.length, idx, 'bytes')];
  if (obj instanceof PyRange) { var n = rangeLen(obj); return obj.start + seqIndex(n, idx, 'range') * obj.step; }
  throw E('TypeError', '\'' + typeName(obj) + '\' object is not subscriptable');
}
function setItem(obj, idxNode, env, value) {
  if (idxNode.k === 'Slice') {
    if (!(obj instanceof PyList)) throw E('TypeError', '\'' + typeName(obj) + '\' object does not support slice assignment');
    var idxs = sliceIdx(idxNode, obj.items.length, env), src = toArray(value).slice();
    if (idxNode.step) throw E('ValueError', 'stepped slice assignment is not available in this emulator');
    var lo = idxs.length ? idxs[0] : (function () { var v = idxNode.lo ? ev(idxNode.lo, env) : 0; if (v < 0) v += obj.items.length; return Math.max(0, Math.min(v, obj.items.length)); })();
    Array.prototype.splice.apply(obj.items, [lo, idxs.length].concat(src));
    return;
  }
  var idx = ev(idxNode, env);
  if (obj instanceof PyList) { obj.items[seqIndex(obj.items.length, idx, 'list assignment').valueOf()] = value; return; }
  if (obj instanceof PyDict) { obj.map.set(keyOf(idx), [idx, value]); return; }
  throw E('TypeError', '\'' + typeName(obj) + '\' object does not support item assignment');
}

// ---------------------------------------------------------------- memory meter
// Sizes follow CPython 3.14 on a 64-bit machine, with exact-fit lists.
function intSize(v) { var a = Math.abs(v); return a < 1073741824 ? 28 : (a < 1152921504606846976 ? 32 : 36); }
function dictSize(n) { return n === 0 ? 64 : n <= 5 ? 184 : n <= 10 ? 272 : n <= 21 ? 464 : n <= 42 ? 832 : 832 + Math.ceil((n - 42) / 43) * 800; }
function shallowSize(v) {
  if (v === null || typeof v === 'boolean') return 0;
  if (typeof v === 'number') return (v >= -5 && v <= 256) ? 0 : intSize(v);
  if (typeof v === 'string') return 41 + v.length;
  if (v instanceof PyFloat) return 24;
  if (v instanceof PyList) return 56 + 8 * v.items.length;
  if (v instanceof PyTuple) return 48 + 8 * v.items.length;
  if (v instanceof PyBytes) return 33 + v.data.length;
  if (v instanceof PyDict) return dictSize(v.map.size);
  if (v instanceof PyRange) return 48;
  return 0;
}
var memTotal = 0, memStrings = null;
function visit(v) {
  if (v === null) return;
  var t = typeof v;
  if (t === 'boolean') return;
  if (t === 'number') { if (v < -5 || v > 256) memTotal += intSize(v); return; }
  if (t === 'string') { if (!memStrings[v]) { memStrings[v] = 1; memTotal += 41 + v.length; } return; }
  if (v.m === undefined) return;
  if (v.m === S.epoch) return;
  v.m = S.epoch;
  var i, it;
  if (v instanceof PyFloat) { memTotal += 24; return; }
  if (v instanceof PyList) { it = v.items; memTotal += 56 + 8 * it.length; for (i = 0; i < it.length; i++) visit(it[i]); return; }
  if (v instanceof PyTuple) { it = v.items; memTotal += 48 + 8 * it.length; for (i = 0; i < it.length; i++) visit(it[i]); return; }
  if (v instanceof PyBytes) { memTotal += 33 + v.data.length; return; }
  if (v instanceof PyDict) { memTotal += dictSize(v.map.size); v.map.forEach(function (kv) { visit(kv[0]); visit(kv[1]); }); return; }
}
function visitEnv(env) { var vars = env.vars; for (var k in vars) visit(vars[k]); }
function liveBytes() {
  S.epoch++; memTotal = 0; memStrings = Object.create(null);
  visitEnv(S.globals);
  for (var i = 0; i < S.frames.length; i++) visitEnv(S.frames[i]);
  return memTotal;
}
function deepSize(v) { S.epoch++; memTotal = 0; memStrings = Object.create(null); visit(v); return memTotal; }
function addrOf(v) { return (v && typeof v === 'object' && v.id !== undefined) ? '0x' + (4096 + v.id * 16).toString(16) : ''; }

// ---------------------------------------------------------------- environments
function Env(parent, fn) { this.vars = Object.create(null); this.parent = parent; this.fn = fn || null; this.globalNames = null; }
function lookup(name, env) {
  var e = env;
  while (e) {
    var v = e.vars[name];
    if (v !== undefined) return v;
    if (e.fn && e.fn.locals[name] && !(e.globalNames && e.globalNames[name])) throw E('UnboundLocalError', 'cannot access local variable \'' + name + '\' where it is not associated with a value');
    e = e.parent;
  }
  v = BUILTINS[name];
  if (v !== undefined) return v;
  throw E('NameError', 'name \'' + name + '\' is not defined');
}
function setVar(name, value, env) {
  if (env.globalNames && env.globalNames[name]) S.globals.vars[name] = value;
  else env.vars[name] = value;
}
function assign(target, value, env) {
  switch (target.k) {
    case 'Name': setVar(target.id, value, env); return;
    case 'Sub': setItem(ev(target.obj, env), target.idx, env, value); return;
    case 'Tuple': case 'List': {
      var arr;
      if (value instanceof PyList || value instanceof PyTuple || typeof value === 'string' || value instanceof PyBytes || value instanceof PyRange || value instanceof PyDict) arr = toArray(value);
      else throw E('TypeError', 'cannot unpack non-iterable ' + typeName(value) + ' object');
      var n = target.items.length;
      if (arr.length < n) throw E('ValueError', 'not enough values to unpack (expected ' + n + ', got ' + arr.length + ')');
      if (arr.length > n) throw E('ValueError', 'too many values to unpack (expected ' + n + ', got ' + arr.length + ')');
      for (var i = 0; i < n; i++) assign(target.items[i], arr[i], env);
      return;
    }
    case 'Attr': throw E('AttributeError', 'cannot set attributes in this emulator');
  }
  throw E('SyntaxError', 'cannot assign to this expression');
}
function collectLocals(body, out) {
  function tgt(t) { if (t.k === 'Name') out[t.id] = 1; else if (t.k === 'Tuple' || t.k === 'List') t.items.forEach(tgt); }
  for (var i = 0; i < body.length; i++) {
    var s = body[i];
    switch (s.k) {
      case 'Assign': s.targets.forEach(tgt); break;
      case 'Aug': tgt(s.target); break;
      case 'For': tgt(s.target); collectLocals(s.body, out); break;
      case 'While': collectLocals(s.body, out); break;
      case 'If': s.tests.forEach(function (t) { collectLocals(t.body, out); }); if (s.orelse) collectLocals(s.orelse, out); break;
      case 'Def': out[s.name] = 1; break;
      case 'Import': s.names.forEach(function (n) { out[n.as] = 1; }); break;
      case 'FromImport': s.names.forEach(function (n) { out[n.as] = 1; }); break;
    }
  }
}

// ---------------------------------------------------------------- execution
var BRK = 1, CONT = 2, RET = 3;
function tick(node, env) {
  if (S.quiet) { if (++S.quietTicks > 20000) throw E('RuntimeError', 'watch expression ran too long'); return; }
  if (S.ticks >= S.maxTicks) throw LIMIT;
  S.curLine = node.line;
  if (S.ticks === S.stopAt) { S.snap = snapshot(env, node.line); throw PAUSE; }
  if (S.trace) {
    S.trace.push(node.line);
    var m = liveBytes();
    S.mem.push(m);
    S.outAt.push(S.outLen);
    var who = S.names.length ? S.names[S.names.length - 1] : '(top level)';
    S.profile[who] = (S.profile[who] || 0) + 1;
  }
  S.ticks++;
}
function execBlock(body, env) {
  for (var i = 0; i < body.length; i++) { var r = execStmt(body[i], env); if (r) return r; }
  return 0;
}
function execStmt(s, env) {
  var r, v, i;
  switch (s.k) {
    case 'Expr': tick(s, env); ev(s.e, env); return 0;
    case 'Assign':
      tick(s, env); v = ev(s.value, env);
      for (i = 0; i < s.targets.length; i++) assign(s.targets[i], v, env);
      return 0;
    case 'Aug': {
      tick(s, env);
      var t = s.target, cur, rhs;
      if (t.k === 'Name') {
        cur = lookup(t.id, env); rhs = ev(s.value, env);
        if (s.op === '+' && cur instanceof PyList) { Array.prototype.push.apply(cur.items, toArray(rhs).slice()); return 0; }
        setVar(t.id, binop(s.op, cur, rhs), env);
      } else if (t.k === 'Sub') {
        var obj = ev(t.obj, env);
        if (t.idx.k === 'Slice') throw E('TypeError', 'augmented assignment to a slice is not available in this emulator');
        var idx = ev(t.idx, env), fake = { k: 'Const', v: idx, line: s.line };
        cur = getItem(obj, fake, env); rhs = ev(s.value, env);
        setItem(obj, fake, env, binop(s.op, cur, rhs));
      } else throw E('SyntaxError', 'cannot assign to this expression');
      return 0;
    }
    case 'If':
      for (i = 0; i < s.tests.length; i++) {
        tick(s.tests[i], env);
        if (truthy(ev(s.tests[i].cond, env))) return execBlock(s.tests[i].body, env);
      }
      return s.orelse ? execBlock(s.orelse, env) : 0;
    case 'While':
      for (;;) {
        tick(s, env);
        if (!truthy(ev(s.cond, env))) return 0;
        r = execBlock(s.body, env);
        if (r === BRK) return 0;
        if (r === RET) return r;
      }
    case 'For': {
      tick(s, env);
      var itv = ev(s.iter, env), first = true, pos = 0, arr = null, rng = null, n = 0;
      if (itv instanceof PyRange) { rng = itv; n = rangeLen(itv); }
      else if (itv instanceof PyList) arr = itv.items; // live view, like Python
      else arr = toArray(itv);
      for (;;) {
        if (!first) tick(s, env);
        first = false;
        if (rng) { if (pos >= n) return 0; v = rng.start + pos * rng.step; }
        else { if (pos >= arr.length) return 0; v = arr[pos]; }
        pos++;
        assign(s.target, v, env);
        r = execBlock(s.body, env);
        if (r === BRK) return 0;
        if (r === RET) return r;
      }
    }
    case 'Def': {
      tick(s, env);
      var locals = Object.create(null), params = [];
      for (i = 0; i < s.params.length; i++) {
        locals[s.params[i].name] = 1;
        params.push({ name: s.params[i].name, has: !!s.params[i].dflt, dflt: s.params[i].dflt ? ev(s.params[i].dflt, env) : null });
      }
      collectLocals(s.body, locals);
      setVar(s.name, new PyFunc(s.name, params, s.body, env, locals), env);
      return 0;
    }
    case 'Return': tick(s, env); S.ret = s.value ? ev(s.value, env) : null; return RET;
    case 'Break': tick(s, env); return BRK;
    case 'Continue': tick(s, env); return CONT;
    case 'Pass': tick(s, env); return 0;
    case 'Import':
      tick(s, env);
      for (i = 0; i < s.names.length; i++) {
        var mod = MODULES[s.names[i].mod];
        if (!mod) throw E('ModuleNotFoundError', 'No module named \'' + s.names[i].mod + '\' (this emulator has: math)');
        setVar(s.names[i].as, mod, env);
      }
      return 0;
    case 'FromImport': {
      tick(s, env);
      var m2 = MODULES[s.mod];
      if (!m2) throw E('ModuleNotFoundError', 'No module named \'' + s.mod + '\' (this emulator has: math)');
      for (i = 0; i < s.names.length; i++) {
        if (!(s.names[i].name in m2.attrs)) throw E('ImportError', 'cannot import name \'' + s.names[i].name + '\' from \'' + s.mod + '\'');
        setVar(s.names[i].as, m2.attrs[s.names[i].name], env);
      }
      return 0;
    }
    case 'Global':
      tick(s, env);
      if (env !== S.globals) { if (!env.globalNames) env.globalNames = Object.create(null); for (i = 0; i < s.names.length; i++) env.globalNames[s.names[i]] = 1; }
      return 0;
    case 'Assert':
      tick(s, env);
      if (!truthy(ev(s.cond, env))) throw E('AssertionError', s.msg ? str(ev(s.msg, env)) : '');
      return 0;
    case 'Raise': {
      tick(s, env);
      if (!s.exc) throw E('RuntimeError', 'No active exception to reraise');
      var ex = ev(s.exc, env);
      if (ex instanceof PyTuple && ex.exc) throw E(ex.exc, ex.items.length ? str(ex.items[0]) : '');
      if (ex instanceof PyBuiltin && EXC_NAMES[ex.name]) throw E(ex.name, '');
      throw E('TypeError', 'exceptions must derive from BaseException');
    }
    case 'Del': {
      tick(s, env);
      var d = s.target;
      if (d.k === 'Name') { if (env.vars[d.id] === undefined) lookup(d.id, env); delete env.vars[d.id]; return 0; }
      if (d.k === 'Sub' && d.idx.k !== 'Slice') {
        var o = ev(d.obj, env), ix = ev(d.idx, env);
        if (o instanceof PyList) { o.items.splice(seqIndex(o.items.length, ix, 'list'), 1); return 0; }
        if (o instanceof PyDict) { if (!o.map.has(keyOf(ix))) throw E('KeyError', repr(ix)); o.map.delete(keyOf(ix)); return 0; }
      }
      throw E('TypeError', 'this kind of del is not available in this emulator');
    }
  }
  throw E('SyntaxError', 'unsupported statement');
}

function callFunction(fn, args, kws) {
  var env = new Env(fn.env, fn), ps = fn.params, i;
  if (args.length > ps.length) throw E('TypeError', fn.name + '() takes ' + ps.length + ' positional argument' + (ps.length === 1 ? '' : 's') + ' but ' + args.length + (args.length === 1 ? ' was' : ' were') + ' given');
  for (i = 0; i < args.length; i++) env.vars[ps[i].name] = args[i];
  if (kws) for (i = 0; i < kws.length; i++) {
    var found = false;
    for (var j = 0; j < ps.length; j++) if (ps[j].name === kws[i][0]) found = true;
    if (!found) throw E('TypeError', fn.name + '() got an unexpected keyword argument \'' + kws[i][0] + '\'');
    if (env.vars[kws[i][0]] !== undefined) throw E('TypeError', fn.name + '() got multiple values for argument \'' + kws[i][0] + '\'');
    env.vars[kws[i][0]] = kws[i][1];
  }
  var missing = [];
  for (i = 0; i < ps.length; i++) if (env.vars[ps[i].name] === undefined) { if (ps[i].has) env.vars[ps[i].name] = ps[i].dflt; else missing.push('\'' + ps[i].name + '\''); }
  if (missing.length) {
    var list = missing.length === 1 ? missing[0] : missing.length === 2 ? missing.join(' and ') : missing.slice(0, -1).join(', ') + ', and ' + missing[missing.length - 1];
    throw E('TypeError', fn.name + '() missing ' + missing.length + ' required positional argument' + (missing.length === 1 ? '' : 's') + ': ' + list);
  }
  if (S.frames.length >= 120) throw E('RecursionError', 'maximum recursion depth exceeded');
  S.frames.push(env);
  S.names.push(fn.name);
  var save = S.curLine;
  var r = execBlock(fn.body, env);
  S.frames.pop();
  S.names.pop();
  S.curLine = save;
  var ret = r === RET ? S.ret : null;
  S.ret = null;
  return ret;
}
function call(f, args, kws) {
  if (f instanceof PyFunc) return callFunction(f, args, kws);
  if (f instanceof PyBuiltin) return f.fn(args, kws || []);
  if (f instanceof PyType) { var b = BUILTINS[f.name]; if (b instanceof PyBuiltin) return b.fn(args, kws || []); }
  throw E('TypeError', '\'' + typeName(f) + '\' object is not callable');
}
function runComp(n, env) {
  var cenv = new Env(env, null), out = [];
  if (!n.gen) cenv.vars['.out'] = new PyList(out);
  S.frames.push(cenv);
  function level(gi) {
    if (gi === n.gens.length) { tick(n, cenv); out.push(ev(n.elt, cenv)); return; }
    var g = n.gens[gi], itv = ev(g.iter, gi === 0 ? env : cenv), arr = null, rng = null, cnt = 0;
    if (itv instanceof PyRange) { rng = itv; cnt = rangeLen(itv); } else { arr = toArray(itv); cnt = -1; }
    for (var pos = 0; rng ? pos < cnt : pos < arr.length; pos++) {
      assign(g.target, rng ? rng.start + pos * rng.step : arr[pos], cenv);
      var ok = true;
      for (var c = 0; c < g.conds.length; c++) if (!truthy(ev(g.conds[c], cenv))) { ok = false; break; }
      if (ok) level(gi + 1);
    }
  }
  level(0);
  S.frames.pop();
  return cenv.vars['.out'] || new PyList(out);
}
function ev(n, env) {
  var a, b, i, v;
  switch (n.k) {
    case 'Num': case 'Str': case 'Const': return n.v;
    case 'Name': return lookup(n.id, env);
    case 'Bin': a = ev(n.l, env); b = ev(n.r, env); return binop(n.op, a, b);
    case 'Sub': return getItem(ev(n.obj, env), n.idx, env);
    case 'Call': {
      var args = [], kws = null, f;
      if (n.fn.k === 'Attr') {
        var obj = ev(n.fn.obj, env);
        for (i = 0; i < n.args.length; i++) args.push(ev(n.args[i], env));
        if (n.kws.length) { kws = []; for (i = 0; i < n.kws.length; i++) kws.push([n.kws[i].name, ev(n.kws[i].value, env)]); }
        if (obj instanceof PyModule) {
          f = obj.attrs[n.fn.name];
          if (f === undefined) throw E('AttributeError', 'module \'' + obj.name + '\' has no attribute \'' + n.fn.name + '\'');
          return call(f, args, kws);
        }
        return callMethod(obj, n.fn.name, args, kws || []);
      }
      f = ev(n.fn, env);
      for (i = 0; i < n.args.length; i++) args.push(ev(n.args[i], env));
      if (n.kws.length) { kws = []; for (i = 0; i < n.kws.length; i++) kws.push([n.kws[i].name, ev(n.kws[i].value, env)]); }
      return call(f, args, kws);
    }
    case 'Compare': {
      a = ev(n.first, env);
      for (i = 0; i < n.ops.length; i++) {
        b = ev(n.rest[i], env);
        if (!compare(n.ops[i], a, b)) return false;
        a = b;
      }
      return true;
    }
    case 'Bool':
      a = ev(n.l, env);
      if (n.op === 'and') return truthy(a) ? ev(n.r, env) : a;
      return truthy(a) ? a : ev(n.r, env);
    case 'Not': return !truthy(ev(n.e, env));
    case 'Unary':
      a = ev(n.e, env);
      if (!isNum(a) || (n.op === '~' && a instanceof PyFloat)) throw E('TypeError', 'bad operand type for unary ' + n.op + ': \'' + typeName(a) + '\'');
      if (n.op === '-') return a instanceof PyFloat ? new PyFloat(-a.v) : -num(a);
      if (n.op === '+') return a instanceof PyFloat ? a : num(a);
      return -num(a) - 1;
    case 'IfExp': return truthy(ev(n.cond, env)) ? ev(n.a, env) : ev(n.b, env);
    case 'List': v = []; for (i = 0; i < n.items.length; i++) v.push(ev(n.items[i], env)); return new PyList(v);
    case 'Tuple': v = []; for (i = 0; i < n.items.length; i++) v.push(ev(n.items[i], env)); return new PyTuple(v);
    case 'Dict': {
      var d = new PyDict();
      for (i = 0; i < n.keys.length; i++) { var key = ev(n.keys[i], env); d.map.set(keyOf(key), [key, ev(n.vals[i], env)]); }
      return d;
    }
    case 'Bytes': return new PyBytes(n.v.slice());
    case 'Comp': return runComp(n, env);
    case 'FStr': {
      var out = '';
      for (i = 0; i < n.parts.length; i++) {
        var p = n.parts[i];
        if (typeof p === 'string') { out += p; continue; }
        v = ev(p.e, env);
        if (p.conv === 'r') v = repr(v); else if (p.conv === 's') v = str(v);
        out += format(v, p.spec);
      }
      return out;
    }
    case 'Attr': {
      a = ev(n.obj, env);
      if (a instanceof PyModule) {
        v = a.attrs[n.name];
        if (v === undefined) throw E('AttributeError', 'module \'' + a.name + '\' has no attribute \'' + n.name + '\'');
        return v;
      }
      if (METHODS[typeName(a)] && METHODS[typeName(a)][n.name]) { var self = a, mname = n.name; return new PyBuiltin(mname, function (args, kws) { return callMethod(self, mname, args, kws); }); }
      throw E('AttributeError', '\'' + typeName(a) + '\' object has no attribute \'' + n.name + '\'');
    }
    case 'Slice': throw E('SyntaxError', 'a slice can only be used inside [ ]');
  }
  throw E('SyntaxError', 'unsupported expression');
}
function callMethod(obj, name, args, kws) {
  var table = METHODS[typeName(obj)];
  if (!table || !table[name]) throw E('AttributeError', '\'' + typeName(obj) + '\' object has no attribute \'' + name + '\'');
  return table[name](obj, args, kws);
}
function argc(name, args, lo, hi) {
  if (args.length < lo || args.length > hi) {
    if (lo === hi) throw E('TypeError', name + '() takes exactly ' + lo + ' argument' + (lo === 1 ? '' : 's') + ' (' + args.length + ' given)');
    throw E('TypeError', name + '() takes from ' + lo + ' to ' + hi + ' arguments (' + args.length + ' given)');
  }
}
function needInt(v, what) { if (typeof v === 'boolean') return v ? 1 : 0; if (typeof v !== 'number') throw E('TypeError', '\'' + typeName(v) + '\' object cannot be interpreted as an integer'); return v; }

// ---------------------------------------------------------------- methods
var METHODS = {
  list: {
    append: function (o, a) { argc('list.append', a, 1, 1); o.items.push(a[0]); return null; },
    pop: function (o, a) {
      if (!o.items.length) throw E('IndexError', 'pop from empty list');
      if (!a.length) return o.items.pop();
      var i = a[0]; if (i < 0) i += o.items.length;
      if (i < 0 || i >= o.items.length) throw E('IndexError', 'pop index out of range');
      return o.items.splice(i, 1)[0];
    },
    index: function (o, a) { for (var i = 0; i < o.items.length; i++) if (pyEq(o.items[i], a[0])) return i; throw E('ValueError', 'list.index(x): x not in list'); },
    count: function (o, a) { var c = 0; for (var i = 0; i < o.items.length; i++) if (pyEq(o.items[i], a[0])) c++; return c; },
    extend: function (o, a) { Array.prototype.push.apply(o.items, toArray(a[0]).slice()); return null; },
    insert: function (o, a) { var i = a[0]; if (i < 0) i = Math.max(0, i + o.items.length); o.items.splice(i, 0, a[1]); return null; },
    copy: function (o) { return new PyList(o.items.slice()); },
    reverse: function (o) { o.items.reverse(); return null; },
    clear: function (o) { o.items.length = 0; return null; },
    sort: function (o, a, kws) { var s = sortedItems(o.items, kws); for (var i = 0; i < s.length; i++) o.items[i] = s[i]; return null; },
    remove: function (o, a) { for (var i = 0; i < o.items.length; i++) if (pyEq(o.items[i], a[0])) { o.items.splice(i, 1); return null; } throw E('ValueError', 'list.remove(x): x not in list'); }
  },
  tuple: {
    index: function (o, a) { for (var i = 0; i < o.items.length; i++) if (pyEq(o.items[i], a[0])) return i; throw E('ValueError', 'tuple.index(x): x not in tuple'); },
    count: function (o, a) { var c = 0; for (var i = 0; i < o.items.length; i++) if (pyEq(o.items[i], a[0])) c++; return c; }
  },
  str: {
    split: function (o, a) {
      if (!a.length || a[0] === null) { var t = o.trim(); return new PyList(t ? t.split(/\s+/) : []); }
      if (a[0] === '') throw E('ValueError', 'empty separator');
      return new PyList(o.split(a[0]));
    },
    join: function (o, a) {
      var arr = toArray(a[0]);
      for (var i = 0; i < arr.length; i++) if (typeof arr[i] !== 'string') throw E('TypeError', 'sequence item ' + i + ': expected str instance, ' + typeName(arr[i]) + ' found');
      return arr.join(o);
    },
    strip: function (o) { return o.trim(); },
    lower: function (o) { return o.toLowerCase(); },
    upper: function (o) { return o.toUpperCase(); },
    startswith: function (o, a) { return o.substr(0, a[0].length) === a[0]; },
    endswith: function (o, a) { return a[0].length <= o.length && o.substr(o.length - a[0].length) === a[0]; },
    replace: function (o, a) { return o.split(a[0]).join(a[1]); },
    find: function (o, a) { return o.indexOf(a[0]); },
    count: function (o, a) { return a[0] === '' ? o.length + 1 : o.split(a[0]).length - 1; },
    isdigit: function (o) { return /^[0-9]+$/.test(o); },
    isalpha: function (o) { return /^[A-Za-z]+$/.test(o); },
    encode: function (o) {
      var out = [];
      for (var i = 0; i < o.length; i++) {
        var c = o.charCodeAt(i);
        if (c < 128) out.push(c);
        else if (c < 2048) out.push(192 | (c >> 6), 128 | (c & 63));
        else if (c >= 0xd800 && c < 0xdc00 && i + 1 < o.length) { var cp = 0x10000 + ((c - 0xd800) << 10) + (o.charCodeAt(++i) - 0xdc00); out.push(240 | (cp >> 18), 128 | ((cp >> 12) & 63), 128 | ((cp >> 6) & 63), 128 | (cp & 63)); }
        else out.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
      }
      return new PyBytes(out);
    }
  },
  dict: {
    get: function (o, a) { var kv = o.map.get(keyOf(a[0])); return kv ? kv[1] : (a.length > 1 ? a[1] : null); },
    keys: function (o) { var r = []; o.map.forEach(function (kv) { r.push(kv[0]); }); return new PyList(r); },
    values: function (o) { var r = []; o.map.forEach(function (kv) { r.push(kv[1]); }); return new PyList(r); },
    items: function (o) { var r = []; o.map.forEach(function (kv) { r.push(new PyTuple([kv[0], kv[1]])); }); return new PyList(r); },
    pop: function (o, a) { var k = keyOf(a[0]), kv = o.map.get(k); if (!kv) { if (a.length > 1) return a[1]; throw E('KeyError', repr(a[0])); } o.map.delete(k); return kv[1]; }
  },
  bytes: {
    hex: function (o) { return o.data.map(function (b) { return (b < 16 ? '0' : '') + b.toString(16); }).join(''); },
    decode: function (o) { return o.data.map(function (b) { return String.fromCharCode(b); }).join(''); }
  }
};
function sortedItems(items, kws) {
  var key = null, rev = false, i;
  for (i = 0; i < kws.length; i++) { if (kws[i][0] === 'key') key = kws[i][1]; else if (kws[i][0] === 'reverse') rev = truthy(kws[i][1]); else throw E('TypeError', 'sort() got an unexpected keyword argument \'' + kws[i][0] + '\''); }
  var dec = items.map(function (v, idx) { return { v: v, k: key ? call(key, [v], null) : v, i: idx }; });
  dec.sort(function (x, y) { if (pyLt(x.k, y.k, '<')) return -1; if (pyLt(y.k, x.k, '<')) return 1; return x.i - y.i; });
  var out = dec.map(function (d) { return d.v; });
  if (rev) { // stable reverse
    dec.sort(function (x, y) { if (pyLt(y.k, x.k, '<')) return -1; if (pyLt(x.k, y.k, '<')) return 1; return x.i - y.i; });
    out = dec.map(function (d) { return d.v; });
  }
  return out;
}

// ---------------------------------------------------------------- builtins
var BUILTINS = Object.create(null), MODULES = Object.create(null), EXC_NAMES = Object.create(null);
function def(name, fn) { BUILTINS[name] = new PyBuiltin(name, fn); }
function kw(kws, name, dflt) { for (var i = 0; i < kws.length; i++) if (kws[i][0] === name) return kws[i][1]; return dflt; }
function emit(text) {
  S.outLen += text.length;
  if (S.outLen > 60000) throw E('MemoryError', 'too much printed output (60,000 characters); is a loop running away?');
  S.out.push(text);
}
def('print', function (a, kws) {
  var sep = kw(kws, 'sep', ' '), end = kw(kws, 'end', '\n');
  if (sep === null) sep = ' ';
  if (end === null) end = '\n';
  emit(a.map(str).join(sep) + end);
  return null;
});
def('input', function (a) {
  if (a.length) emit(str(a[0]));
  if (S.stdinPos >= S.stdin.length) throw E('EOFError', 'EOF when reading a line');
  return S.stdin[S.stdinPos++];
});
def('len', function (a) {
  argc('len', a, 1, 1);
  var v = a[0];
  if (typeof v === 'string') return v.length;
  if (v instanceof PyList || v instanceof PyTuple) return v.items.length;
  if (v instanceof PyDict) return v.map.size;
  if (v instanceof PyBytes) return v.data.length;
  if (v instanceof PyRange) return rangeLen(v);
  throw E('TypeError', 'object of type \'' + typeName(v) + '\' has no len()');
});
def('range', function (a) {
  argc('range', a, 1, 3);
  var s = 0, e, st = 1;
  if (a.length === 1) e = needInt(a[0]); else { s = needInt(a[0]); e = needInt(a[1]); if (a.length === 3) st = needInt(a[2]); }
  if (st === 0) throw E('ValueError', 'range() arg 3 must not be zero');
  return new PyRange(s, e, st);
});
def('abs', function (a) {
  argc('abs', a, 1, 1);
  if (!isNum(a[0])) throw E('TypeError', 'bad operand type for abs(): \'' + typeName(a[0]) + '\'');
  return a[0] instanceof PyFloat ? new PyFloat(Math.abs(a[0].v)) : Math.abs(num(a[0]));
});
function minmax(name, sign) {
  def(name, function (a, kws) {
    var arr = a.length === 1 ? toArray(a[0]) : a, key = kw(kws, 'key', null);
    if (!a.length) throw E('TypeError', name + ' expected at least 1 argument, got 0');
    if (!arr.length) throw E('ValueError', name + '() iterable argument is empty');
    var best = arr[0], bk = key ? call(key, [best], null) : best;
    for (var i = 1; i < arr.length; i++) {
      var k = key ? call(key, [arr[i]], null) : arr[i];
      if (sign > 0 ? pyLt(bk, k, '>') : pyLt(k, bk, '<')) { best = arr[i]; bk = k; }
    }
    return best;
  });
}
minmax('max', 1); minmax('min', -1);
def('sum', function (a) {
  argc('sum', a, 1, 2);
  var arr = toArray(a[0]), total = a.length > 1 ? a[1] : 0;
  for (var i = 0; i < arr.length; i++) {
    if (!isNum(arr[i])) throw E('TypeError', 'unsupported operand type(s) for +: \'' + typeName(total) + '\' and \'' + typeName(arr[i]) + '\'');
    total = binop('+', total, arr[i]);
  }
  return total;
});
function roundHalfEven(x) { var f = Math.floor(x), d = x - f; if (d < 0.5) return f; if (d > 0.5) return f + 1; return f % 2 === 0 ? f : f + 1; }
def('round', function (a) {
  argc('round', a, 1, 2);
  var v = a[0];
  if (!isNum(v)) throw E('TypeError', 'type ' + typeName(v) + ' doesn\'t define __round__ method');
  if (a.length === 1 || a[1] === null) {
    if (!(v instanceof PyFloat)) return num(v);
    if (!isFinite(v.v)) throw E(v.v !== v.v ? 'ValueError' : 'OverflowError', v.v !== v.v ? 'cannot convert float NaN to integer' : 'cannot convert float infinity to integer');
    return chk(roundHalfEven(v.v));
  }
  var nd = needInt(a[1]);
  if (!(v instanceof PyFloat)) { if (nd >= 0) return num(v); var p = Math.pow(10, -nd); return roundHalfEven(num(v) / p) * p; }
  if (nd < 0) { var p2 = Math.pow(10, -nd); return new PyFloat(roundHalfEven(v.v / p2) * p2); }
  return new PyFloat(parseFloat(fixed(v.v, nd)));
});
def('int', function (a) {
  if (!a.length) return 0;
  var v = a[0];
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v instanceof PyFloat) {
    if (v.v !== v.v) throw E('ValueError', 'cannot convert float NaN to integer');
    if (!isFinite(v.v)) throw E('OverflowError', 'cannot convert float infinity to integer');
    return chk(v.v < 0 ? Math.ceil(v.v) : Math.floor(v.v));
  }
  if (typeof v === 'string') {
    var base = a.length > 1 ? needInt(a[1]) : 10, s = v.trim().replace(/_/g, '');
    var ok = base === 10 ? /^[+-]?\d+$/.test(s) : base === 2 ? /^[+-]?(0[bB])?[01]+$/.test(s) : base === 16 ? /^[+-]?(0[xX])?[0-9a-fA-F]+$/.test(s) : false;
    if (!ok) throw E('ValueError', 'invalid literal for int() with base ' + base + ': ' + repr(v));
    if (base !== 10) s = s.replace(/^([+-]?)0[bBxX]/, '$1');
    return chk(parseInt(s, base));
  }
  throw E('TypeError', 'int() argument must be a string, a bytes-like object or a real number, not \'' + typeName(v) + '\'');
});
def('float', function (a) {
  if (!a.length) return new PyFloat(0);
  var v = a[0];
  if (v instanceof PyFloat) return v;
  if (typeof v === 'number' || typeof v === 'boolean') return new PyFloat(num(v));
  if (typeof v === 'string') {
    var s = v.trim().toLowerCase();
    if (/^[+-]?(inf|infinity)$/.test(s)) return new PyFloat(s[0] === '-' ? -Infinity : Infinity);
    if (s === 'nan') return new PyFloat(NaN);
    if (!/^[+-]?(\d+\.?\d*([e][+-]?\d+)?|\.\d+([e][+-]?\d+)?)$/.test(s)) throw E('ValueError', 'could not convert string to float: ' + repr(v));
    return new PyFloat(parseFloat(s));
  }
  throw E('TypeError', 'float() argument must be a string or a real number, not \'' + typeName(v) + '\'');
});
def('str', function (a) { return a.length ? str(a[0]) : ''; });
def('repr', function (a) { argc('repr', a, 1, 1); return repr(a[0]); });
def('bool', function (a) { return a.length ? truthy(a[0]) : false; });
def('list', function (a) { return new PyList(a.length ? toArray(a[0]).slice() : []); });
def('tuple', function (a) { return new PyTuple(a.length ? toArray(a[0]).slice() : []); });
def('dict', function (a, kws) {
  var d = new PyDict();
  if (a.length) {
    if (a[0] instanceof PyDict) a[0].map.forEach(function (kv, k) { d.map.set(k, [kv[0], kv[1]]); });
    else toArray(a[0]).forEach(function (pair) { var p = toArray(pair); d.map.set(keyOf(p[0]), [p[0], p[1]]); });
  }
  kws.forEach(function (p) { d.map.set(keyOf(p[0]), [p[0], p[1]]); });
  return d;
});
def('bytes', function (a) {
  if (!a.length) return new PyBytes([]);
  var v = a[0], out = [], i;
  if (typeof v === 'number') { if (v < 0) throw E('ValueError', 'negative count'); if (v > 2000000) throw E('MemoryError', 'too large for this emulator'); for (i = 0; i < v; i++) out.push(0); return new PyBytes(out); }
  if (typeof v === 'string') throw E('TypeError', 'string argument without an encoding');
  var arr = toArray(v);
  for (i = 0; i < arr.length; i++) {
    var b = arr[i];
    if (typeof b === 'boolean') b = b ? 1 : 0;
    if (typeof b !== 'number') throw E('TypeError', '\'' + typeName(b) + '\' object cannot be interpreted as an integer');
    if (b < 0 || b > 255) throw E('ValueError', 'bytes must be in range(0, 256)');
    out.push(b);
  }
  return new PyBytes(out);
});
def('bin', function (a) { var v = needInt(a[0]); return (v < 0 ? '-' : '') + '0b' + Math.abs(v).toString(2); });
def('hex', function (a) { var v = needInt(a[0]); return (v < 0 ? '-' : '') + '0x' + Math.abs(v).toString(16); });
def('ord', function (a) { if (typeof a[0] !== 'string' || a[0].length !== 1) throw E('TypeError', 'ord() expected a character'); return a[0].charCodeAt(0); });
def('chr', function (a) { return String.fromCharCode(needInt(a[0])); });
def('enumerate', function (a) {
  var arr = toArray(a[0]), start = a.length > 1 ? a[1] : 0;
  return new PyList(arr.map(function (v, i) { return new PyTuple([start + i, v]); }));
});
def('zip', function (a) {
  var arrs = a.map(toArray), n = arrs.length ? Math.min.apply(null, arrs.map(function (x) { return x.length; })) : 0, out = [];
  for (var i = 0; i < n; i++) out.push(new PyTuple(arrs.map(function (x) { return x[i]; })));
  return new PyList(out);
});
def('reversed', function (a) { return new PyList(toArray(a[0]).slice().reverse()); });
def('sorted', function (a, kws) { return new PyList(sortedItems(toArray(a[0]).slice(), kws)); });
def('type', function (a) { argc('type', a, 1, 1); return new PyType(typeName(a[0])); });
def('isinstance', function (a) {
  var names = (a[1] instanceof PyTuple ? a[1].items : [a[1]]).map(function (t) { return t instanceof PyBuiltin || t instanceof PyType ? t.name : ''; });
  var tn = typeName(a[0]);
  return names.indexOf(tn) >= 0 || (tn === 'bool' && names.indexOf('int') >= 0);
});
def('id', function (a) { return (a[0] && a[0].id !== undefined) ? 4096 + a[0].id * 16 : 0; });
def('divmod', function (a) { return new PyTuple([binop('//', a[0], a[1]), binop('%', a[0], a[1])]); });
def('pow', function (a) { return binop('**', a[0], a[1]); });
['ValueError', 'TypeError', 'IndexError', 'KeyError', 'ZeroDivisionError', 'RuntimeError', 'Exception', 'AssertionError', 'OverflowError', 'NameError', 'NotImplementedError', 'StopIteration'].forEach(function (name) {
  EXC_NAMES[name] = 1;
  def(name, function (a) { var t = new PyTuple(a.slice()); t.exc = name; return t; });
});

function mathFn(name, f, check) {
  return new PyBuiltin(name, function (a) {
    argc('math.' + name, a, 1, 1);
    if (!isNum(a[0])) throw E('TypeError', 'must be real number, not ' + typeName(a[0]));
    var x = num(a[0]);
    if (check) check(x);
    var r = f(x);
    if (!isFinite(r) && isFinite(x)) throw E('OverflowError', 'math range error');
    return new PyFloat(r);
  });
}
MODULES.math = new PyModule('math', {
  pi: new PyFloat(Math.PI), e: new PyFloat(Math.E), inf: new PyFloat(Infinity), nan: new PyFloat(NaN),
  sqrt: mathFn('sqrt', Math.sqrt, function (x) { if (x < 0) throw E('ValueError', 'expected a nonnegative input, got ' + floatRepr(x)); }),
  exp: mathFn('exp', Math.exp),
  log: mathFn('log', Math.log, function (x) { if (x <= 0) throw E('ValueError', 'expected a positive input' + (x === 0 ? '' : ', got ' + floatRepr(x))); }),
  log2: mathFn('log2', function (x) { return Math.log(x) / Math.LN2; }, function (x) { if (x <= 0) throw E('ValueError', 'expected a positive input'); }),
  cos: mathFn('cos', Math.cos), sin: mathFn('sin', Math.sin), tan: mathFn('tan', Math.tan), tanh: mathFn('tanh', function (x) { var e = Math.exp(2 * x); return isFinite(e) ? (e - 1) / (e + 1) : 1; }),
  fabs: mathFn('fabs', Math.abs),
  floor: new PyBuiltin('floor', function (a) { return chk(Math.floor(num(a[0]))); }),
  ceil: new PyBuiltin('ceil', function (a) { return chk(Math.ceil(num(a[0]))); }),
  isnan: new PyBuiltin('isnan', function (a) { var x = num(a[0]); return x !== x; }),
  isinf: new PyBuiltin('isinf', function (a) { var x = num(a[0]); return x === Infinity || x === -Infinity; })
});

// ---------------------------------------------------------------- snapshots + run
function short(s, n) { return s.length > n ? s.substr(0, n - 1) + '\u2026' : s; }
function snapshot(env, line) {
  var vars = [], seen = Object.create(null);
  function add(scope, e) {
    for (var k in e.vars) {
      if (k[0] === '.') continue;
      var v = e.vars[k];
      if (v instanceof PyFunc || v instanceof PyModule || v instanceof PyBuiltin) continue;
      if (seen[scope + k]) continue;
      seen[scope + k] = 1;
      vars.push({ scope: scope, name: k, type: typeName(v), repr: short(repr(v), 400), bytes: deepSize(v), addr: addrOf(v) });
    }
  }
  var e = env;
  while (e && e !== S.globals) { add(e.fn ? e.fn.name : 'comp', e); e = e.parent; }
  add('', S.globals);
  var stack = [];
  for (var i = 0; i < S.frames.length; i++) if (S.frames[i].fn) stack.push(S.frames[i].fn.name);
  var watch = [];
  if (S.watch && !S.quiet) {
    var saveFrames = S.frames.length, saveNames = S.names.length, saveLine = S.curLine;
    S.quiet = true;
    for (var w = 0; w < S.watch.length; w++) {
      S.quietTicks = 0;
      try { watch.push({ src: S.watch[w].src, repr: repr(ev(S.watch[w].ast, env)) }); }
      catch (err) { if (!(err instanceof PyError)) { S.quiet = false; throw err; } watch.push({ src: S.watch[w].src, repr: null, error: err.type }); }
      S.frames.length = saveFrames; S.names.length = saveNames;
    }
    S.quiet = false; S.curLine = saveLine; S.ret = null;
  }
  return { line: line, vars: vars, stack: stack, watch: watch };
}

function run(src, opts) {
  opts = opts || {};
  S = {
    seq: 0, epoch: 1, ticks: 0, maxTicks: opts.maxTicks || 400000, stopAt: opts.stopAt === undefined ? -1 : opts.stopAt,
    trace: opts.trace ? [] : null, mem: opts.trace ? [] : null, outAt: opts.trace ? [] : null, profile: {}, names: [], watch: null, quiet: false, quietTicks: 0, out: [], outLen: 0, frames: [], ret: null, curLine: 0, snap: null,
    stdin: opts.stdin === undefined || opts.stdin === null ? [] : String(opts.stdin).split('\n'), stdinPos: 0, globals: null
  };
  var res = { status: 'done', out: '', ticks: 0, line: 0, error: null, vars: [], stack: [], watch: [], trace: null, mem: null, outAt: null, profile: null, live: 0, peak: 0 };
  var genv = new Env(null, null);
  S.globals = genv;
  try {
    var ast = parse(src);
    if (opts.watch && opts.watch.length) {
      S.watch = opts.watch.map(function (w) { var p = new Parser(tokenize(w)); return { src: w, ast: p.testList() }; });
    }
    execBlock(ast, genv);
    res.line = 0;
    S.snap = snapshot(genv, 0);
  } catch (err) {
    if (err === PAUSE) { res.status = 'paused'; }
    else if (err === LIMIT) { res.status = 'limit'; S.snap = snapshot(S.frames.length ? S.frames[S.frames.length - 1] : genv, S.curLine); }
    else if (err instanceof PyError) {
      if (!err.line) err.line = S.curLine;
      res.status = 'error';
      res.error = { type: err.type, msg: err.msg, line: err.line, text: err.type + (err.msg ? ': ' + err.msg : '') };
      S.snap = S.globals ? snapshot(S.frames.length ? S.frames[S.frames.length - 1] : genv, err.line) : null;
    } else if (err instanceof RangeError) {
      res.status = 'error';
      res.error = { type: 'RecursionError', msg: 'maximum recursion depth exceeded', line: S.curLine, text: 'RecursionError: maximum recursion depth exceeded' };
    } else throw err;
  }
  res.out = S.out.join('');
  res.ticks = S.ticks;
  if (S.snap) { res.vars = S.snap.vars; res.stack = S.snap.stack; res.line = S.snap.line; res.watch = S.snap.watch; }
  res.live = liveBytes();
  if (S.trace) {
    S.mem.push(res.live);
    S.outAt.push(S.outLen);
    res.trace = S.trace; res.mem = S.mem; res.outAt = S.outAt; res.profile = S.profile;
    var pk = 0;
    for (var i = 0; i < S.mem.length; i++) if (S.mem[i] > pk) pk = S.mem[i];
    res.peak = pk;
  }
  res.get = (function (g) { return function (name) { var v = g.vars[name]; return v === undefined ? undefined : repr(v); }; })(genv);
  return res;
}

var api = { run: run, parse: parse, floatRepr: floatRepr };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.PyVM = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
