/* Emu: glue between lesson steps and PyVM. Pure logic (no DOM), shared by the app and the test harness. */
(function (root) {
'use strict';
var VM = root.PyVM || (typeof require !== 'undefined' ? require('./pyvm.js') : null);
var ENGINE = root.ENGINE || (typeof require !== 'undefined' ? require('./engine.js') : null);
var hideCache = {};

function lineCount(s) { return s === '' ? 0 : s.split('\n').length; }
function preSource(spec) {
  var chunks = [];
  if (spec.pre) {
    var m = /^(upto|thru):(\w+)$/.exec(spec.pre);
    if (!m) throw new Error('bad pre: ' + spec.pre);
    chunks.push(ENGINE[m[1]](m[2]));
  }
  if (spec.setup) chunks.push(spec.setup.replace(/\s+$/, ''));
  return chunks.join('\n');
}
// spec: {pre, setup, code, post, stdin, watch}
function program(spec, codeOverride) {
  var pre = preSource(spec);
  var code = (codeOverride === undefined ? spec.code : codeOverride).replace(/\s+$/, '');
  var post = spec.post ? spec.post.replace(/\s+$/, '') : '';
  var off = pre ? lineCount(pre) : 0;
  var src = (pre ? pre + '\n' : '') + code + (post ? '\n' + post : '') + '\n';
  if (!(pre in hideCache)) {
    var names = {};
    if (pre) { var r = VM.run(pre + '\n', {}); for (var i = 0; i < r.vars.length; i++) names[r.vars[i].name] = 1; }
    hideCache[pre] = names;
  }
  return { src: src, off: off, n: lineCount(code), stdin: spec.stdin || '', watch: spec.watch || null, hide: hideCache[pre], show: spec.show || null };
}
function visible(p, line) { return line > p.off && line <= p.off + p.n; }
function trace(p) {
  var res = VM.run(p.src, { stdin: p.stdin, trace: true, watch: p.watch });
  var first = -1, stops = [], i, tr = res.trace || [];
  for (i = 0; i < tr.length; i++) if (visible(p, tr[i])) { if (first < 0) first = i; stops.push(i); }
  if (first < 0) first = Math.min(res.ticks, tr.length);
  var base = res.mem && res.mem.length > first ? res.mem[first] : 0;
  if (!p.off) { first = 0; base = 0; }
  var peaks = [], pk = 0;
  if (res.mem) for (i = 0; i < res.mem.length; i++) { var v = res.mem[i] - base; if (i >= first && v > pk) pk = v; peaks.push(pk); }
  return { res: res, first: first, stops: stops, base: base, peaks: peaks };
}
function filterVars(p, vars) {
  var out = [];
  for (var i = 0; i < vars.length; i++) {
    var v = vars[i];
    if (v.name[0] === '_') continue;
    if (!v.scope && p.hide[v.name] && !(p.show && p.show.indexOf(v.name) >= 0)) continue;
    out.push(v);
  }
  return out;
}
// State after `idx` ticks (idx === ticks means the end of the run).
function stateAt(p, t, idx) {
  var res = t.res, end = idx >= res.ticks;
  var r = end ? res : VM.run(p.src, { stdin: p.stdin, stopAt: idx, watch: p.watch });
  var line = end ? (res.error ? res.error.line : 0) : res.trace[idx];
  var st = {
    idx: end ? res.ticks : idx, end: end,
    status: end ? res.status : 'paused',
    line: visible(p, line) ? line - p.off : 0,
    rawLine: line,
    clock: Math.max(0, (end ? res.ticks : idx) - t.first),
    live: Math.max(0, res.mem[end ? res.mem.length - 1 : idx] - t.base),
    peak: t.peaks[end ? t.peaks.length - 1 : idx] || 0,
    out: end ? res.out : res.out.substr(0, res.outAt[idx]),
    vars: filterVars(p, r.vars), stack: r.stack, watch: r.watch,
    error: end ? res.error : null
  };
  if (st.error) st.errorLine = visible(p, st.error.line) ? st.error.line - p.off : 0;
  return st;
}
function nextStop(t, idx) { for (var i = 0; i < t.stops.length; i++) if (t.stops[i] > idx) return t.stops[i]; return t.res.ticks; }
function prevStop(t, idx) { var best = -1; for (var i = 0; i < t.stops.length; i++) { if (t.stops[i] < idx) best = t.stops[i]; else break; } return best; }
function stopLine(p, stop) {
  if (stop.line) return stop.line;
  var lines = p.src.split('\n');
  for (var i = p.off; i < p.off + p.n; i++) if (lines[i].indexOf(stop.match) >= 0) return i - p.off + 1;
  return -1;
}
function stopIndex(p, t, stop) {
  var want = p.off + stopLine(p, stop), hit = stop.hit || 1, tr = t.res.trace;
  for (var i = 0; i < tr.length; i++) if (tr[i] === want && --hit === 0) return i;
  return -1;
}
function trimOut(s) { return s.replace(/\s+$/, ''); }
function hot(profile) { var best = '', n = -1; for (var k in profile) if (profile[k] > n) { n = profile[k]; best = k; } return best; }
function measure(st, t, verify) {
  var m = /^(\w+)(?::(.+))?$/.exec(verify), kind = m[1], arg = m[2], i;
  switch (kind) {
    case 'out': return trimOut(st.out);
    case 'clock': return String(st.clock);
    case 'live': return String(st.live);
    case 'peak': return String(st.peak);
    case 'error': return st.error ? st.error.type : 'No error';
    case 'hot': return hot(t.res.profile);
    case 'watch': return st.watch && st.watch[0] && st.watch[0].repr !== null ? st.watch[0].repr : '(not available)';
    case 'var': case 'bytes':
      for (i = 0; i < st.vars.length; i++) if (st.vars[i].name === arg) return kind === 'var' ? st.vars[i].repr : String(st.vars[i].bytes);
      return '(not defined)';
  }
  throw new Error('bad verify: ' + verify);
}
// Truth for a predict / inspect step.
function truth(step, codeOverride) {
  var p = program(step, codeOverride), t = trace(p), idx = t.res.ticks;
  if (step.stop) { idx = stopIndex(p, t, step.stop); if (idx < 0) return { value: '(line never reached)', p: p, t: t, st: stateAt(p, t, t.res.ticks) }; }
  var st = stateAt(p, t, idx);
  return { value: measure(st, t, step.verify), p: p, t: t, st: st };
}
// Duel: which variant has the smaller metric.
function duel(step) {
  var rows = step.variants.map(function (v) {
    var p = program(step, v.code), t = trace(p), st = stateAt(p, t, t.res.ticks);
    return { label: v.label, value: Number(measure(st, t, step.metric)), st: st };
  });
  var a = rows[0].value, b = rows[1].value;
  var want = step.want === 'more' ? (a > b ? 0 : b > a ? 1 : 2) : (a < b ? 0 : b < a ? 1 : 2);
  return { rows: rows, winner: want === 2 ? 'They tie' : rows[want].label };
}
// Fill: put the chosen chips into the [[n]] blanks.
function fillCode(code, picks) { return code.replace(/\[\[(\d+)\]\]/g, function (_, n) { var v = picks[Number(n) - 1]; return v === undefined || v === null ? '___' : v; }); }
// Tests for fill / write: expected output comes from the stored solution.
function runTests(step, code) {
  var solution = step.t === 'fill' ? fillCode(step.code, step.answer) : step.solution;
  var tests = step.tests || [{ post: step.post || '', stdin: step.stdin || '' }];
  return tests.map(function (test) {
    function go(c) {
      var spec = { pre: step.pre, setup: step.setup, code: c, post: test.post, stdin: test.stdin };
      var p = program(spec), r = VM.run(p.src, { stdin: p.stdin });
      return { out: trimOut(r.out), error: r.error, status: r.status, p: p };
    }
    var want = go(solution), got = go(code);
    var errLine = got.error ? (visible(got.p, got.error.line) ? got.error.line - got.p.off : 0) : 0;
    return { name: test.name || trimOut(test.post || ''), want: want.out, wantError: want.error, got: got.out, error: got.error, errorLine: errLine, limit: got.status === 'limit', pass: !got.error && got.status === 'done' && !want.error && got.out === want.out };
  });
}
var api = { program: program, trace: trace, stateAt: stateAt, nextStop: nextStop, prevStop: prevStop, stopIndex: stopIndex, stopLine: stopLine, truth: truth, duel: duel, fillCode: fillCode, runTests: runTests, measure: measure, hot: hot };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.Emu = api;
})(typeof window !== 'undefined' ? window : globalThis);
