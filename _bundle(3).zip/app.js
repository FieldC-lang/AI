/* BitLingo Py: interface. Plain ES2017, no dependencies. */
(function () {
'use strict';
var KEY = 'bitlingo_py_progress';
var device = window.BitLingoDevice || null;
var S = { done: {}, xp: 0, streak: 0, lastDay: '', unlockAll: false, play: '', playIn: 'red blue' };
var CONSTS = ['math', 'WORDS', 'MODEL', 'LAYERS', 'SPEEDS'];
var LESSONS = [];
UNITS.forEach(function (u, ui) { u.lessons.forEach(function (l) { l.unit = u; l.unitNo = ui + 1; l.no = LESSONS.length + 1; LESSONS.push(l); }); });
var app = document.getElementById('app');
var view = 'home', player = null, modalEl = null;
var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function loadState() {
  try { var raw = device ? device.load(KEY) : ''; if (raw) { var o = JSON.parse(raw); for (var k in o) if (k in S) S[k] = o[k]; } } catch (e) { /* start fresh */ }
}
function saveState() { try { if (device) device.save(KEY, JSON.stringify(S)); } catch (e) { /* in-memory only */ } }

/* ---------- small helpers ---------- */
function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function h(tag, attrs) {
  var el = document.createElement(tag), k, i;
  if (attrs) for (k in attrs) {
    var v = attrs[k];
    if (v === null || v === undefined || v === false) continue;
    if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (i = 2; i < arguments.length; i++) add(el, arguments[i]);
  return el;
}
function add(el, c) {
  if (c === null || c === undefined || c === false) return;
  if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
  el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
}
function inline(s) {
  return String(s).split('`').map(function (part, i) {
    if (i % 2) return '<code>' + esc(part) + '</code>';
    return esc(part).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
  }).join('');
}
function prose(text) { return text.split('\n\n').map(function (p) { return '<p>' + inline(p).replace(/\n/g, '<br>') + '</p>'; }).join(''); }
function num(n) { n = Math.round(n); return n >= 10000 ? String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',') : String(n); }
function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function today(offset) { var d = new Date(); d.setDate(d.getDate() + (offset || 0)); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
var ICONS = {
  heart: '<path fill="currentColor" d="M12 21s-7.6-4.7-10-9.4C.5 8.300 2.400 4.500 6.200 4.500c2.200 0 3.900 1.200 5.800 3.300 1.900-2.100 3.600-3.300 5.800-3.300 3.800 0 5.700 3.800 4.200 7.100C19.600 16.300 12 21 12 21z"/>',
  flame: '<path fill="currentColor" d="M12.500 2c.8 3.600 5 5.600 5 10.700a5.500 5.500 0 0 1-11 0c0-1.800.7-3.200 1.700-4.300.3 1.700 1 2.600 2 3C9.900 8.200 10.800 5 12.500 2z"/>',
  bolt: '<path fill="currentColor" d="M13.500 2 4.500 13.500h5.700L9 22l9.500-12h-5.800z"/>',
  lock: '<rect x="5" y="10.500" width="14" height="10" rx="2.500" fill="currentColor"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.500" fill="none" stroke="currentColor" stroke-width="2.400" stroke-linecap="round"/>',
  check: '<path d="M5 12.800l4.600 4.600L19.200 7.500" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
  x: '<path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2.800" stroke-linecap="round"/>',
  play: '<path fill="currentColor" d="M7 4.300v15.400a.8.800 0 0 0 1.200.7l12-7.700a.8.800 0 0 0 0-1.400l-12-7.700A.8.800 0 0 0 7 4.300z"/>',
  step: '<path fill="currentColor" d="M5 5.300v13.400a.7.700 0 0 0 1.100.6l9-6.700a.7.700 0 0 0 0-1.200l-9-6.700A.7.700 0 0 0 5 5.300z"/><path d="M18.500 5v14" stroke="currentColor" stroke-width="2.800" stroke-linecap="round"/>',
  back: '<path fill="currentColor" d="M19 5.300v13.400a.7.700 0 0 1-1.100.6l-9-6.700a.7.700 0 0 1 0-1.200l9-6.700a.7.700 0 0 1 1.100.6z"/><path d="M5.500 5v14" stroke="currentColor" stroke-width="2.800" stroke-linecap="round"/>',
  reset: '<path d="M4.500 12a7.500 7.500 0 1 0 2.400-5.500M4.500 4.500v4.800h4.800" fill="none" stroke="currentColor" stroke-width="2.500" stroke-linecap="round" stroke-linejoin="round"/>',
  edit: '<path d="M4 20h4.500L19 9.500 14.500 5 4 15.500z" fill="none" stroke="currentColor" stroke-width="2.300" stroke-linejoin="round"/>',
  learn: '<path d="M4 5.500A2.500 2.500 0 0 1 6.500 3H20v15H6.500A2.500 2.500 0 0 0 4 20.500z M4 20.500A2.500 2.500 0 0 0 6.500 23H20" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linejoin="round" transform="translate(0 -1)"/>',
  file: '<path d="M6 3h8l5 5v13H6z M14 3v5h5 M9 13h7 M9 17h5" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linejoin="round" stroke-linecap="round"/>',
  term: '<rect x="3" y="4.500" width="18" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="2.200"/><path d="M7.500 9.500l3 2.500-3 2.500M12.500 15h4" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"/>',
  info: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.200"/><path d="M12 11v6" stroke="currentColor" stroke-width="2.600" stroke-linecap="round"/><circle cx="12" cy="7.600" r="1.500" fill="currentColor"/>',
  chev: '<path d="M9 5.500l6.500 6.500L9 18.500" fill="none" stroke="currentColor" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"/>',
  trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0z M7 6H4v1.500A3.500 3.500 0 0 0 7.500 11 M17 6h3v1.500a3.500 3.500 0 0 1-3.500 3.500 M12 14v4 M8 20h8" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"/>'
};
function ic(name, size) { size = size || 20; return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" aria-hidden="true">' + ICONS[name] + '</svg>'; }
function icon(name, size) { var s = h('span', { html: ic(name, size) }); return s.firstChild; }
var LOGO = '<svg width="34" height="34" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="9" fill="#5aa9e6"/><path d="M8.500 10h7M12 6.500v7M16.500 22h7" stroke="#131f2b" stroke-width="3" stroke-linecap="round"/><circle cx="21" cy="10" r="3.200" fill="none" stroke="#ffd43b" stroke-width="3"/><circle cx="11" cy="22" r="3.400" fill="#ffd43b"/></svg>';
function toast(msg) { var t = h('div', { class: 'toast', role: 'status', text: msg }); document.body.appendChild(t); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 1800); }
function copyText(text) {
  try {
    if (device && device.copy) { device.copy(text); toast('Copied'); return; }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(function () { toast('Copied'); }, function () { toast('Copy is blocked here'); }); return; }
  } catch (e) { /* fall through */ }
  toast('Copy is not available here');
}

/* ---------- Python highlighting ---------- */
var KW = /^(def|return|if|elif|else|for|while|in|not|and|or|import|from|break|continue|pass|raise|assert|global|del|is|None|True|False)$/;
var BI = /^(print|len|range|round|abs|max|min|sum|int|float|str|list|bytes|zip|enumerate|input|sorted|bool|dict|tuple|isinstance|bin|hex|ord|chr|reversed)$/;
function hl(line) {
  var re = /(#.*$)|(f?"(?:[^"\\]|\\.)*"|f?'(?:[^'\\]|\\.)*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)|([\s\S])/g, m, out = '', prev = '';
  while ((m = re.exec(line))) {
    if (m[1]) out += '<span class="t-c">' + esc(m[1]) + '</span>';
    else if (m[2]) out += '<span class="t-s">' + esc(m[2]) + '</span>';
    else if (m[3]) out += '<span class="t-n">' + m[3] + '</span>';
    else if (m[4]) {
      if (KW.test(m[4])) out += '<span class="t-k">' + m[4] + '</span>';
      else if (prev === 'def') out += '<span class="t-f">' + m[4] + '</span>';
      else if (BI.test(m[4])) out += '<span class="t-b">' + m[4] + '</span>';
      else out += m[4];
      prev = m[4];
    } else out += esc(m[5]);
  }
  return out;
}
function hlBlanks(line, blanks) {
  return line.split(/(\[\[\d+\]\])/).map(function (seg) {
    var m = /^\[\[(\d+)\]\]$/.exec(seg);
    if (!m) return hl(seg);
    var k = Number(m[1]) - 1, v = blanks.picks[k];
    return '<button type="button" class="blank' + (v ? ' full' : '') + (blanks.active() === k ? ' active' : '') + '" data-blank="' + k + '" aria-label="Blank ' + (k + 1) + (v ? ': ' + esc(v) : ', empty') + '">' + (v ? esc(v) : '&nbsp;') + '</button>';
  }).join('');
}
function codeBlock(src) {
  var box = h('div', { class: 'codebox' }), code = h('div', { class: 'code' });
  src.split('\n').forEach(function (line, i) { code.appendChild(h('div', { class: 'ln', html: '<span class="no">' + (i + 1) + '</span><span class="tx">' + (hl(line) || ' ') + '</span>' })); });
  box.appendChild(code); return box;
}

/* ---------- the emulator card ---------- */
function partsBefore(pre) {
  var m = /^(upto|thru):(\w+)$/.exec(pre), out = [], i;
  for (i = 0; i < ENGINE.order.length; i++) {
    var name = ENGINE.order[i];
    if (m[1] === 'upto' && name === m[2]) break;
    if (CONSTS.indexOf(name) < 0) out.push(name);
    if (name === m[2]) break;
  }
  return out;
}
function EmuCard(o) {
  var spec = o.spec || {};
  var C = { idx: -1, p: null, t: null, st: null, busy: false, editing: !!o.editable, variant: 0, ranEnd: {}, locked: o.locked || '', focus: o.focus || null };
  var text = o.code || '', stdin = spec.stdin || '', timer = null, lineEls = [], curEl = null;
  var statusEl = h('span', { class: 'emu-status', 'aria-live': 'polite' });
  var tabsEl = o.variants ? h('div', { class: 'vtabs', role: 'tablist' }) : null;
  var preEl = h('div', { class: 'emu-pre' }), codeWrap = h('div'), postEl = h('div', { class: 'emu-post' });
  var stdinInput = h('input', { type: 'text', id: 'in' + Math.random().toString(36).slice(2), value: stdin, autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', readonly: !o.stdinEditable, oninput: function () { stdin = stdinInput.value; invalidate(); if (o.onStdin) o.onStdin(stdin); } });
  var stdinEl = h('div', { class: 'emu-stdin' }, h('label', { for: stdinInput.id, text: 'Input' }), stdinInput);
  var bRun = cbtn('run', 'play', 'Run', function () { run(); }), bStep = cbtn('', 'step', 'Step', step), bBack = cbtn('', 'back', 'Back', back), bReset = cbtn('', 'reset', 'Reset', reset);
  var ctlEl = h('div', { class: 'emu-ctl' }, bRun, bStep, bBack, bReset);
  var lockEl = h('div', { class: 'emu-lock' });
  var mClock = meter('clock', 'Clock'), mLive = meter('live', 'Memory now'), mPeak = meter('peak', 'Peak memory');
  var metersEl = h('div', { class: 'meters' }, mClock.el, mLive.el, mPeak.el);
  var outPre = h('pre', { class: 'out mono' }), outEl = h('div', { class: 'panel' }, h('div', { class: 'lab', text: 'Output' }), outPre);
  var varsBody = h('div'), varsEl = h('div', { class: 'panel' }, h('div', { class: 'lab', text: 'Variables in memory' }), varsBody);
  var watchEl = h('div', { class: 'panel' }), profEl = h('div', { class: 'panel' });
  C.el = h('section', { class: 'emu', 'aria-label': 'Python emulator' },
    h('div', { class: 'emu-top' }, h('span', { class: 'dots', html: '<i></i><i></i><i></i>' }), h('span', { class: 'emu-name', text: 'Python emulator' }), statusEl),
    tabsEl, preEl, codeWrap, postEl, (spec.stdin !== undefined || o.stdinEditable) ? stdinEl : null, ctlEl, lockEl, metersEl, outEl, varsEl, watchEl, profEl);

  function cbtn(cls, ico, label, fn) { var b = h('button', { type: 'button', class: 'cbtn ' + cls, onclick: fn }); b.innerHTML = ic(ico, 16) + '<span>' + label + '</span>'; return b; }
  function setBtn(b, ico, label) { b.innerHTML = ic(ico, 16) + '<span>' + label + '</span>'; }
  function meter(cls, label) { var n = h('div', { class: 'num' }); return { el: h('div', { class: 'meter ' + cls }, h('div', { class: 'lab', text: label }), n), set: function (v, unit) { n.innerHTML = num(v) + '<small>' + unit + '</small>'; } }; }
  function getCode() {
    if (o.editable) return text;
    if (o.blanks) return Emu.fillCode(o.code, o.blanks.picks);
    if (o.variants) return o.variants[C.variant].code;
    return o.code;
  }
  function specNow() { return { pre: spec.pre, setup: spec.setup, post: o.post, stdin: stdin, watch: spec.watch, show: spec.show }; }
  function blanksFull() { return !o.blanks || o.blanks.picks.every(function (v) { return !!v; }); }
  function invalidate() { stopTimer(); C.p = null; C.t = null; C.st = null; C.idx = -1; C.busy = false; paint(); }
  function stopTimer() { if (timer) { clearTimeout(timer); timer = null; } }
  function compile() { C.p = Emu.program(specNow(), getCode()); C.t = Emu.trace(C.p); C.idx = -1; C.st = null; }
  function hits() {
    if (!o.stop) return [];
    var want = C.p.off + Emu.stopLine(C.p, o.stop), tr = C.t.res.trace, out = [], i;
    for (i = 0; i < tr.length; i++) if (tr[i] === want) out.push(i);
    return out;
  }
  function nextTarget() { var hs = hits(), i; for (i = 0; i < hs.length; i++) if (hs[i] > C.idx) return hs[i]; return C.t.res.ticks; }
  function goTo(idx) {
    C.st = Emu.stateAt(C.p, C.t, idx);
    C.idx = C.st.end ? C.t.res.ticks : idx;
    if (C.st.end) C.ranEnd[C.variant] = true;
    C.busy = false; paint();
    if (o.onChange) o.onChange(C);
  }
  function prepare(then) {
    if (C.busy || C.locked) return;
    if (C.editing) { C.editing = false; }
    if (!C.t || (C.st && C.st.end && then === 'run')) {
      C.busy = true; setStatus('Working...', 'run'); paintButtons();
      setTimeout(function () { try { compile(); } catch (e) { C.busy = false; setStatus('Emulator problem: ' + e.message, 'err'); return; } C.busy = false; paintCode(); finish(); }, 20);
    } else finish();
    function finish() { if (then === 'run') animate(nextTarget()); else if (then === 'step') goTo(Emu.nextStop(C.t, C.idx)); }
  }
  var afterRun = null;
  function run(cb) { afterRun = cb || null; prepare('run'); }
  function step() { if (C.st && C.st.end) return; prepare('step'); }
  function back() {
    if (C.busy || C.locked || !C.t || C.idx < 0) return;
    var pv = Emu.prevStop(C.t, C.idx);
    if (pv < 0) { C.idx = -1; C.st = null; paint(); } else goTo(pv);
  }
  function reset() { if (C.locked) return; stopTimer(); C.busy = false; C.t = null; C.st = null; C.idx = -1; if (o.editable) C.editing = true; paint(); if (C.editing && editor) editor.focus(); }
  function animate(target) {
    var t = C.t, frames = [], i, s;
    for (i = 0; i < t.stops.length; i++) { s = t.stops[i]; if (s > C.idx && s < target) frames.push(s); }
    var max = 44;
    if (frames.length > max) { var pick = []; for (i = 0; i < max; i++) pick.push(frames[Math.floor(i * frames.length / max)]); frames = pick; }
    function done() { timer = null; goTo(target); var cb = afterRun; afterRun = null; if (cb) cb(C); }
    if (reduced || !frames.length) { done(); return; }
    var delay = frames.length <= 10 ? 120 : frames.length <= 24 ? 60 : 26, k = 0;
    C.busy = true; setStatus('Running...', 'run'); paintButtons(); varsBody.innerHTML = '<div class="empty">Running...</div>';
    (function tick() {
      if (k >= frames.length) { done(); return; }
      var f = frames[k++], res = t.res;
      markLine(res.trace[f] - C.p.off, 'cur');
      mClock.set(Math.max(0, f - t.first), 'ticks'); mLive.set(Math.max(0, res.mem[f] - t.base), 'bytes'); mPeak.set(t.peaks[f] || 0, 'bytes');
      outPre.textContent = res.out.substr(0, res.outAt[f]);
      timer = setTimeout(tick, delay);
    })();
  }
  function setStatus(msg, cls) { statusEl.textContent = msg; statusEl.className = 'emu-status ' + (cls || ''); }
  function markLine(n, cls) {
    if (curEl) { curEl.classList.remove('cur'); curEl.classList.remove('err'); curEl = null; }
    var el = lineEls[n - 1]; if (!el) return;
    el.classList.add(cls); curEl = el;
    var box = el.parentNode.parentNode, top = el.offsetTop, bottom = top + el.offsetHeight;
    if (top < box.scrollTop + 21) box.scrollTop = Math.max(0, top - 42);
    else if (bottom > box.scrollTop + box.clientHeight - 21) box.scrollTop = bottom - box.clientHeight + 42;
  }
  var editor = null;
  function paintCode() {
    codeWrap.innerHTML = ''; lineEls = []; curEl = null;
    if (C.editing) {
      editor = h('textarea', { class: 'editor', spellcheck: 'false', autocapitalize: 'off', autocomplete: 'off', autocorrect: 'off', 'aria-label': 'Python code editor', rows: Math.max(6, Math.min(22, text.split('\n').length + 1)) });
      editor.value = text;
      editor.addEventListener('input', function (e) {
        if (e.inputType === 'insertLineBreak' || (e.inputType === 'insertText' && e.data === null)) indentAfterBreak(editor);
        text = editor.value; C.t = null; if (o.onEdit) o.onEdit(text);
      });
      editor.addEventListener('keydown', function (e) { editorKey(editor, e, function () { text = editor.value; C.t = null; if (o.onEdit) o.onEdit(text); }); });
      codeWrap.appendChild(editor); return;
    }
    var src = o.blanks ? o.code : getCode(), bp = 0;
    if (o.stop) { try { bp = Emu.stopLine(C.p || Emu.program(specNow(), src), o.stop); } catch (e) { bp = 0; } }
    var box = h('div', { class: 'codebox' }), code = h('div', { class: 'code' });
    src.split('\n').forEach(function (line, i) {
      var el = h('div', { class: 'ln' + (bp === i + 1 ? ' bp' : '') });
      el.innerHTML = '<span class="no"' + (bp === i + 1 ? ' title="Breakpoint"' : '') + '>' + (i + 1) + '</span><span class="tx">' + ((o.blanks ? hlBlanks(line, o.blanks) : hl(line)) || ' ') + '</span>';
      code.appendChild(el); lineEls.push(el);
    });
    if (o.blanks) code.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('.blank') : null; if (b && !C.busy) o.blanks.onTap(Number(b.getAttribute('data-blank'))); });
    box.appendChild(code); codeWrap.appendChild(box);
  }
  function paintButtons() {
    var off = C.busy || !!C.locked, full = blanksFull(), end = !!(C.st && C.st.end);
    bRun.disabled = off || !full; bStep.disabled = off || !full || end; bBack.disabled = off || C.idx < 0 || !C.t;
    bReset.disabled = off || (o.editable ? C.editing : (C.idx < 0 && !C.st));
    setBtn(bRun, 'play', end ? 'Run again' : 'Run');
    setBtn(bReset, o.editable ? 'edit' : 'reset', o.editable ? 'Edit' : 'Reset');
  }
  function paintTabs() {
    if (!tabsEl) return; tabsEl.innerHTML = '';
    o.variants.forEach(function (v, i) {
      var b = h('button', { type: 'button', class: 'vtab' + (i === C.variant ? ' on' : ''), role: 'tab', 'aria-selected': i === C.variant ? 'true' : 'false', onclick: function () { if (!C.busy) setVariant(i); } }, v.label);
      if (C.ranEnd[i]) b.appendChild(h('span', { class: 'tick', html: ic('check', 15), title: 'Run' }));
      tabsEl.appendChild(b);
    });
  }
  function setVariant(i) { stopTimer(); C.variant = i; C.p = null; C.t = null; C.st = null; C.idx = -1; C.busy = false; paint(); }
  function paint() {
    var st = C.st, i;
    C.el.className = 'emu' + (C.locked ? ' compact' : '');
    paintTabs();
    // what is already loaded
    var notes = [];
    if (spec.pre) { var names = partsBefore(spec.pre); if (names.length) notes.push('<span class="lab">Already loaded from your project:</span> ' + names.map(function (n) { return '<code>' + n + '</code>'; }).join(', ')); }
    if (spec.setup) notes.push('<span class="lab">Already run for you:</span><pre>' + spec.setup.split('\n').map(hl).join('\n') + '</pre>');
    preEl.innerHTML = notes.join('<div style="height:6px"></div>'); preEl.style.display = notes.length ? '' : 'none';
    postEl.innerHTML = o.post ? '<span class="lab">Then the emulator runs:</span><pre>' + o.post.split('\n').map(hl).join('\n') + '</pre>' : ''; postEl.style.display = o.post ? '' : 'none';
    paintCode(); paintButtons();
    lockEl.innerHTML = ''; lockEl.style.display = 'none';
    var lockMsg = C.locked || (!blanksFull() ? 'Fill every blank, then you can run it.' : '');
    if (lockMsg) { lockEl.style.display = ''; lockEl.appendChild(h('div', { class: 'locknote', html: ic('lock', 16) + '<span>' + esc(lockMsg) + '</span>' })); }
    var hide = C.locked ? 'none' : '';
    ctlEl.style.display = hide; metersEl.style.display = hide; outEl.style.display = hide; varsEl.style.display = hide;
    mClock.set(st ? st.clock : 0, 'ticks'); mLive.set(st ? st.live : 0, 'bytes'); mPeak.set(st ? st.peak : 0, 'bytes');
    var f = C.focus || {};
    mClock.el.classList.toggle('focus', f.meter === 'clock'); mLive.el.classList.toggle('focus', f.meter === 'live'); mPeak.el.classList.toggle('focus', f.meter === 'peak');
    outEl.classList.toggle('focus', !!f.out);
    // output
    outPre.innerHTML = '';
    if (!st) outPre.innerHTML = '<span class="dim">' + (C.editing ? 'Press Run to try your code.' : 'Nothing yet. Press Run or Step.') + '</span>';
    else {
      outPre.appendChild(document.createTextNode(st.out));
      if (st.error) outPre.appendChild(h('span', { class: 'e', text: (st.out && st.out.slice(-1) !== '\n' ? '\n' : '') + st.error.text + (st.errorLine ? '  (line ' + st.errorLine + ')' : '') }));
      else if (st.status === 'limit') outPre.appendChild(h('span', { class: 'e', text: 'Stopped: more than 400,000 ticks. Is a loop running forever?' }));
      else if (st.end && !st.out) outPre.innerHTML = '<span class="dim">(this program printed nothing)</span>';
    }
    // lines + status
    if (!st) setStatus(C.editing ? 'Editing' : 'Ready', '');
    else if (st.error) { markLine(st.errorLine, 'err'); setStatus(st.error.type, 'err'); }
    else if (st.status === 'limit') setStatus('Stopped', 'err');
    else if (st.end) setStatus('Finished', 'ok');
    else {
      markLine(st.line, 'cur');
      var hs = o.stop ? hits() : [], hit = hs.indexOf(C.idx);
      setStatus(hit >= 0 ? 'At the breakpoint (stop ' + (hit + 1) + ')' : 'Paused before line ' + st.line, 'run');
    }
    // variables
    varsBody.innerHTML = '';
    if (!st) varsBody.innerHTML = '<div class="empty">Variables appear here as the code runs.</div>';
    else if (!st.vars.length) varsBody.innerHTML = '<div class="empty">No variables of your own yet.</div>';
    else {
      var rows = '<tr><th>Name</th><th>Type</th><th>Value</th><th class="b">Bytes</th><th>Where</th></tr>', scope = null, focusAt = -1;
      if (f.v) for (i = 0; i < st.vars.length; i++) if (st.vars[i].name === f.v) { focusAt = i; break; }
      var scopes = {}; st.vars.forEach(function (x) { scopes[x.scope] = 1; });
      var manyScopes = Object.keys(scopes).length > 1 || !('' in scopes);
      for (i = 0; i < st.vars.length; i++) {
        var v = st.vars[i];
        if (manyScopes && v.scope !== scope) { scope = v.scope; rows += '<tr class="scope"><td colspan="5">' + (scope ? 'inside ' + esc(scope) + '()' : 'top level') + '</td></tr>'; }
        rows += '<tr' + (i === focusAt ? ' class="focus"' : '') + '><td>' + esc(v.name) + '</td><td class="t">' + esc(v.type) + '</td><td class="v"><button type="button" class="vbtn" title="Show the whole value" aria-label="Value of ' + esc(v.name) + ': ' + esc(v.repr.slice(0, 200)) + '">' + esc(v.repr) + '</button></td><td class="b">' + v.bytes + '</td><td class="a">' + (v.addr || '-') + '</td></tr>';
      }
      var wrap = h('div', { class: 'vars-wrap', html: '<table class="vars">' + rows + '</table>' });
      wrap.addEventListener('click', function (e) { if (e.target.classList.contains('vbtn')) e.target.classList.toggle('full'); });
      varsBody.appendChild(wrap);
      var fr = wrap.querySelector('tr.focus'); if (fr) wrap.scrollTop = Math.max(0, fr.offsetTop - 60);
      if (st.stack && st.stack.length) varsBody.appendChild(h('div', { class: 'stack', html: 'Running inside: ' + st.stack.map(function (s) { return '<b>' + esc(s) + '()</b>'; }).join(' &rsaquo; ') }));
    }
    // watch
    watchEl.style.display = 'none';
    if (spec.watch && !C.locked) {
      watchEl.style.display = ''; watchEl.className = 'panel' + (f.watch ? ' focus' : '');
      var w = st && st.watch && st.watch[0];
      watchEl.innerHTML = '<div class="lab">Watch</div><div class="mono" style="font-size:13px">' + esc(spec.watch[0]) + ' = ' + (w && w.repr !== null && w.repr !== undefined ? '<b style="color:var(--yellow)">' + esc(w.repr) + '</b>' : '<span style="color:var(--faint)">not available here</span>') + '</div>';
    }
    // profile
    profEl.style.display = 'none';
    if (o.profile && st && st.end && C.t && C.t.res.profile) {
      var prof = C.t.res.profile, keys = Object.keys(prof).sort(function (a, b) { return prof[b] - prof[a]; }).slice(0, 7), top = prof[keys[0]] || 1;
      if (keys.length > 1) {
        profEl.style.display = ''; profEl.className = 'panel' + (f.profile ? ' focus' : '');
        profEl.innerHTML = '<div class="lab">Time by function (ticks on its own lines)</div><table class="prof">' + keys.map(function (k) { return '<tr><td>' + esc(k) + '</td><td class="barc"><div class="pbar" style="width:' + Math.max(1, Math.round(prof[k] / top * 100)) + '%"></div></td><td class="n">' + num(prof[k]) + '</td></tr>'; }).join('') + '</table>';
      }
    }
  }
  C.run = run; C.reset = reset; C.getCode = getCode; C.setVariant = setVariant; C.repaint = paint; C.invalidate = invalidate;
  C.setCode = function (s) { text = s; C.editing = !!o.editable; invalidate(); };
  C.setStdin = function (s) { stdin = s; stdinInput.value = s; invalidate(); };
  C.unlock = function () { C.locked = ''; paint(); };
  C.setFocus = function (f) { C.focus = f; paint(); };
  paint();
  return C;
}
function indentAfterBreak(ta) {
  var pos = ta.selectionStart, v = ta.value;
  if (v[pos - 1] !== '\n') return;
  var start = v.lastIndexOf('\n', pos - 2) + 1, prev = v.slice(start, pos - 1), ind = /^ */.exec(prev)[0];
  if (/:\s*$/.test(prev)) ind += '    ';
  if (!ind) return;
  ta.value = v.slice(0, pos) + ind + v.slice(pos); ta.selectionStart = ta.selectionEnd = pos + ind.length;
}
function editorKey(ta, e, changed) {
  var s = ta.selectionStart, en = ta.selectionEnd, v = ta.value;
  function put(str, drop) { ta.value = v.slice(0, s - (drop || 0)) + str + v.slice(en); ta.selectionStart = ta.selectionEnd = s - (drop || 0) + str.length; e.preventDefault(); changed(); }
  if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) put('    ');
  else if (e.key === 'Enter' && !e.ctrlKey && !e.metaKey) {
    var start = v.lastIndexOf('\n', s - 1) + 1, line = v.slice(start, s), ind = /^ */.exec(line)[0];
    if (/:\s*$/.test(line)) ind += '    ';
    put('\n' + ind);
  } else if (e.key === 'Backspace' && s === en) {
    var st2 = v.lastIndexOf('\n', s - 1) + 1, before = v.slice(st2, s);
    if (before.length >= 4 && /^ +$/.test(before) && before.length % 4 === 0) put('', 4);
  }
}

/* ---------- choices ---------- */
function Choices(options, mono, onPick) {
  var order = shuffle(options.slice()), sel = null, frozen = false, locked = false, btns = [];
  var el = h('div', { class: 'choices', role: 'group', 'aria-label': 'Answers' });
  order.forEach(function (opt, i) {
    var b = h('button', { type: 'button', class: 'choice' + (mono ? ' mono' : ''), 'aria-pressed': 'false', onclick: function () {
      if (frozen || locked) return;
      sel = opt; btns.forEach(function (x, j) { x.classList.toggle('sel', j === i); x.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
      onPick(opt);
    } }, h('span', { class: 'key', text: 'ABCD'[i] }));
    var val = h('span', { class: 'val' });
    if (mono) val.textContent = opt; else val.innerHTML = inline(opt);
    b.appendChild(val); btns.push(b); el.appendChild(b);
  });
  return {
    el: el, value: function () { return sel; },
    freeze: function () { frozen = true; btns.forEach(function (b) { b.disabled = true; }); },
    setLocked: function (v) { locked = v; el.classList.toggle('locked', v); btns.forEach(function (b) { b.disabled = v; }); },
    mark: function (right) { btns.forEach(function (b, i) { b.classList.remove('sel'); if (order[i] === right) b.classList.add('right'); else if (order[i] === sel) b.classList.add('wrong'); }); }
  };
}
function lockNote(msg) { return h('div', { class: 'locknote', html: ic('lock', 16) + '<span>' + esc(msg) + '</span>' }); }
function focusOf(verify) {
  var m = /^(\w+)(?::(.+))?$/.exec(verify), k = m[1];
  if (k === 'out' || k === 'error') return { out: true };
  if (k === 'clock' || k === 'live' || k === 'peak') return { meter: k };
  if (k === 'hot') return { profile: true };
  if (k === 'watch') return { watch: true };
  return { v: m[2] };
}
function saysOf(step, value) {
  var m = /^(\w+)(?::(.+))?$/.exec(step.verify), k = m[1];
  var label = { out: 'Output', clock: 'Clock', live: 'Memory now', peak: 'Peak memory', error: 'Result', hot: 'Most ticks', watch: step.watch ? step.watch[0] : 'Watch' }[k] || (k === 'bytes' ? 'Bytes of ' + m[2] : m[2]);
  return { label: label, value: value + (step.unit ? ' ' + step.unit : '') };
}
function testList(results) {
  var el = h('div', { class: 'tests' });
  results.forEach(function (r, i) {
    var got = r.error ? r.error.text + (r.errorLine ? ' (line ' + r.errorLine + ')' : '') : r.limit ? 'ran for too long' : (r.got === '' ? '(nothing)' : r.got);
    el.appendChild(h('div', { class: 'test ' + (r.pass ? 'pass' : 'fail') },
      h('div', { class: 'hd', html: ic(r.pass ? 'check' : 'x', 16) + '<span>Test ' + (i + 1) + (r.pass ? ' passed' : ' failed') + '</span>' }),
      h('pre', { class: 'mono', html: (r.name ? esc(r.name) + '\n' : '') + 'expected: <b>' + esc(r.want) + '</b>' + (r.pass ? '' : '\nyours:    <b>' + esc(got) + '</b>') })));
  });
  return el;
}

/* ---------- step types ---------- */
var TAGS = { learn: 'Learn', predict: 'Predict', inspect: 'Investigate', duel: 'Race', experiment: 'Experiment', fill: 'Fill the gaps', write: 'Write code' };
var STEP = {};
STEP.learn = function (s, api) {
  var card = EmuCard({ spec: s, code: s.code, onChange: function (c) { if (c.st && c.st.end) { api.label('Continue'); api.ready(true); } } });
  api.label('Run the code first'); api.ready(false);
  return { els: [card.el], submit: function () { api.finish({ ok: true, silent: true }); } };
};
STEP.predict = function (s, api) {
  var card = EmuCard({ spec: s, code: s.code, stop: s.stop, locked: 'Answer first. The emulator runs this when you press Check.' });
  var ch = Choices(s.options, true, function () { api.ready(true); });
  api.label('Check'); api.ready(false);
  return { els: [card.el, h('div', { class: 'ask', html: inline(s.ask) }), ch.el], submit: function () {
    ch.freeze(); api.busy(); card.unlock(); scrollTo(card.el);
    card.run(function (c) {
      var truth = Emu.measure(c.st, c.t, s.verify); ch.mark(truth); card.setFocus(focusOf(s.verify));
      api.finish({ ok: ch.value() === truth, says: saysOf(s, truth), why: s.why });
    });
  } };
};
STEP.inspect = function (s, api) {
  var open = false, target = -1, card;
  function targetOf(c) { return s.stop ? Emu.stopIndex(c.p, c.t, s.stop) : c.t.res.ticks; }
  var note = lockNote(s.stop ? 'Run the code to the right breakpoint stop to unlock the answers.' : 'Run the code to the end to unlock the answers.');
  var ch = Choices(s.options, true, function () { api.ready(true); });
  ch.setLocked(true);
  card = EmuCard({ spec: s, code: s.code, stop: s.stop, focus: focusOf(s.verify), profile: s.verify === 'hot', onChange: function (c) {
    target = targetOf(c);
    if (!open && target >= 0 && c.idx >= target) { open = true; ch.setLocked(false); if (note.parentNode) note.parentNode.removeChild(note); }
  } });
  api.label('Check'); api.ready(false);
  return { els: [card.el, h('div', { class: 'ask', html: inline(s.ask) }), note, ch.el], submit: function () {
    var value = Emu.measure(Emu.stateAt(card.p, card.t, target), card.t, s.verify);
    ch.freeze(); ch.mark(value);
    api.finish({ ok: ch.value() === value, says: saysOf(s, value), why: s.why });
  } };
};
STEP.duel = function (s, api) {
  var card = EmuCard({ spec: s, variants: s.variants, locked: 'Answer first. Both versions run when you press Check.' });
  var ch = Choices(s.variants.map(function (v) { return v.label; }), false, function () { api.ready(true); });
  var race = h('div');
  api.label('Check'); api.ready(false);
  return { els: [card.el, h('div', { class: 'ask', html: inline(s.ask) }), ch.el, race], submit: function () {
    ch.freeze(); api.busy(); card.unlock(); card.setVariant(0); scrollTo(card.el);
    card.run(function (c0) { var v0 = Number(Emu.measure(c0.st, c0.t, s.metric)); setTimeout(function () { card.setVariant(1); card.run(function (c1) {
      var v1 = Number(Emu.measure(c1.st, c1.t, s.metric)), more = s.want === 'more';
      var win = v0 === v1 ? -1 : ((v0 < v1) !== more ? 0 : 1);
      var d = { rows: [{ label: s.variants[0].label, value: v0 }, { label: s.variants[1].label, value: v1 }], winner: win < 0 ? 'They tie' : s.variants[win].label };
      var max = Math.max(v0, v1, 1), box = h('div', { class: 'race' });
      d.rows.forEach(function (r) {
        var bar = h('i'); box.appendChild(h('div', { class: 'r' + (r.label === d.winner ? ' win' : '') }, h('div', { class: 'rl' }, r.label, h('span', { text: num(r.value) + ' ' + (s.unit || '') })), h('div', { class: 'rb' }, bar)));
        setTimeout(function () { bar.style.width = Math.round(r.value / max * 100) + '%'; }, 40);
      });
      race.appendChild(box); ch.mark(d.winner); card.setFocus({ meter: s.metric });
      api.finish({ ok: ch.value() === d.winner, says: { label: 'Result', value: d.rows.map(function (r) { return r.label + ': ' + num(r.value); }).join('   ') }, why: s.why });
    }); }, reduced ? 0 : 550); });
  } };
};
STEP.experiment = function (s, api) {
  var open = false, note = lockNote('Run both versions to unlock the answers.');
  var ch = Choices(s.options, false, function () { api.ready(true); });
  ch.setLocked(true);
  var card = EmuCard({ spec: s, variants: s.variants, focus: { out: true }, onChange: function (c) {
    if (!open && c.ranEnd[0] && c.ranEnd[1]) { open = true; ch.setLocked(false); if (note.parentNode) note.parentNode.removeChild(note); }
  } });
  api.label('Check'); api.ready(false);
  return { els: [card.el, h('div', { class: 'ask', html: inline(s.ask) }), note, ch.el], submit: function () {
    var right = s.options[s.answer]; ch.freeze(); ch.mark(right);
    api.finish({ ok: ch.value() === right, why: s.why });
  } };
};
STEP.fill = function (s, api) {
  var n = (s.code.match(/\[\[\d+\]\]/g) || []).length, picks = [], active = 0, tries = 0, i;
  for (i = 0; i < n; i++) picks.push(null);
  var t0 = s.tests ? s.tests[0] : { post: s.post, stdin: s.stdin };
  var results = h('div'), extra = h('div', { class: 'rowbtns' });
  var card = EmuCard({ spec: { pre: s.pre, setup: s.setup, stdin: t0.stdin }, code: s.code, post: t0.post, blanks: { picks: picks, active: function () { return active; }, onTap: function (k) { picks[k] = null; active = k; changed(); } } });
  var chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Pieces' });
  s.chips.forEach(function (c) { chips.appendChild(h('button', { type: 'button', class: 'chip', onclick: function () {
    if (active < 0) active = n - 1;
    picks[active] = c; active = picks.indexOf(null); changed();
  } }, c)); });
  function changed() { results.innerHTML = ''; card.invalidate(); api.clear(); api.ready(picks.every(function (v) { return !!v; })); }
  api.label('Check'); api.ready(false);
  return { els: [card.el, h('p', { class: 'note', text: 'Tap a blank to choose it, then tap the piece that belongs there.' }), chips, results, extra], submit: function () {
    var res = Emu.runTests(s, Emu.fillCode(s.code, picks)); api.busy();
    card.run(function () {
      results.innerHTML = ''; results.appendChild(testList(res));
      if (res.every(function (r) { return r.pass; })) { api.finish({ ok: true, why: s.why }); return; }
      tries++;
      api.retry({ title: 'Not yet', body: 'The emulator ran your version and the result does not match. Tap a blank to change it.' });
      if (tries >= 2 && !extra.firstChild) extra.appendChild(h('button', { type: 'button', class: 'btn ghost small', onclick: function () { s.answer.forEach(function (a, k) { picks[k] = a; }); active = -1; changed(); } }, 'Show the answer'));
    });
  } };
};
STEP.write = function (s, api) {
  var t0 = s.tests[0], tries = 0, results = h('div'), hintEl = h('div'), extra = h('div', { class: 'rowbtns' });
  var card = EmuCard({ spec: { pre: s.pre, setup: s.setup, stdin: t0.stdin }, code: s.code, editable: true, post: t0.post, onEdit: function () { api.clear(); } });
  extra.appendChild(h('button', { type: 'button', class: 'btn ghost small', onclick: function () { hintEl.innerHTML = ''; hintEl.appendChild(h('div', { class: 'hint', html: '<b>Hint.</b> ' + inline(s.hint) })); } }, 'Show a hint'));
  api.label('Check'); api.ready(true);
  return { els: [card.el, h('p', { class: 'note', text: 'Type in the box. Run tries your code. Check runs every test.' }), hintEl, extra, results], submit: function () {
    var res = Emu.runTests(s, card.getCode()); api.busy();
    card.run(function () {
      results.innerHTML = ''; results.appendChild(testList(res));
      if (res.every(function (r) { return r.pass; })) { api.finish({ ok: true, why: s.why }); return; }
      tries++;
      var bad = res.filter(function (r) { return !r.pass; })[0];
      api.retry({ title: 'Not yet', body: bad.error ? 'Python stopped with `' + bad.error.text + '`' + (bad.errorLine ? ' on line ' + bad.errorLine : '') + '. Press Edit to fix it.' : 'A test printed something different from what was expected. Press Edit and try again.' });
      if (tries >= 2 && extra.childNodes.length < 2) extra.appendChild(h('button', { type: 'button', class: 'btn ghost small', onclick: function () { card.setCode(s.solution); results.innerHTML = ''; api.clear(); } }, 'Show the solution'));
    });
  } };
};
function scrollTo(el) { try { var top = el.getBoundingClientRect().top + window.pageYOffset - 70; window.scrollTo({ top: top, behavior: reduced ? 'auto' : 'smooth' }); } catch (e) { window.scrollTo(0, 0); } }

/* ---------- lesson player ---------- */
function Player(lesson) {
  var queue = lesson.steps.map(function (s) { return { s: s, retry: false }; }), at = 0, hearts = 5, mistakes = 0, cur = null, state = 'answer';
  var bar = h('i'), heartsEl = h('span', { text: '5' });
  var body = h('main', { class: 'p-body' }), fb = h('div', { class: 'fb', 'aria-live': 'polite' }), main = h('button', { type: 'button', class: 'btn wide', onclick: press });
  var foot = h('footer', { class: 'p-foot' }, h('div', { class: 'p-foot-in' }, fb, h('div', { class: 'foot-row' }, main)));
  var root = h('div', { class: 'player' },
    h('header', { class: 'p-top' }, h('button', { type: 'button', class: 'p-close', 'aria-label': 'Leave lesson', html: ic('x', 22), onclick: askQuit }), h('div', { class: 'p-bar', role: 'progressbar', 'aria-label': 'Lesson progress' }, bar), h('div', { class: 'p-hearts', 'aria-label': 'Hearts left', html: ic('heart', 22) }, heartsEl)),
    body, foot);
  var api = {
    label: function (t) { main.textContent = t; },
    ready: function (v) { if (state === 'answer') main.disabled = !v; },
    busy: function () { main.disabled = true; },
    clear: function () { if (state === 'answer') { fb.innerHTML = ''; fb.style.display = 'none'; foot.className = 'p-foot'; fit(); } },
    retry: function (r) { foot.className = 'p-foot warn'; fb.style.display = ''; fb.innerHTML = '<div class="h">' + esc(r.title) + '</div><p>' + inline(r.body) + '</p>'; main.disabled = false; fit(); },
    finish: function (r) {
      if (r.silent) { next(); return; }
      state = 'next';
      if (!r.ok) { hearts--; mistakes++; heartsEl.textContent = hearts; queue.push({ s: queue[at].s, retry: true }); }
      foot.className = 'p-foot ' + (r.ok ? 'good' : 'bad'); fb.style.display = '';
      fb.innerHTML = '<div class="h">' + (r.ok ? 'Correct' : 'Not quite') + '</div>' + (r.says ? '<div class="says">' + esc(r.says.label) + ': <span class="mono">' + esc(r.says.value) + '</span></div>' : '') + '<p>' + inline(r.why || '') + '</p>' + (!r.ok && hearts > 0 ? '<p style="margin-top:6px;color:var(--muted);font-size:13.500px">This one comes back at the end of the lesson.</p>' : '');
      main.className = 'btn wide ' + (r.ok ? 'green' : 'red'); main.textContent = 'Continue'; main.disabled = false;
      fit();
      try { main.focus({ preventScroll: true }); } catch (e) { /* older WebView */ }
    }
  };
  function fit() { body.style.paddingBottom = (foot.offsetHeight + 28) + 'px'; }
  function press() { if (main.disabled) return; if (state === 'next') next(); else cur.submit(); }
  function next() { at++; if (hearts <= 0) failed(); else if (at >= queue.length) complete(); else show(); }
  function show() {
    var item = queue[at], s = item.s;
    state = 'answer'; body.innerHTML = ''; fb.innerHTML = ''; fb.style.display = 'none'; foot.className = 'p-foot'; main.className = 'btn wide'; main.disabled = true;
    bar.style.width = Math.round(at / queue.length * 100) + '%';
    body.appendChild(h('div', { class: 'tag' + (item.retry ? ' retry' : ''), text: (item.retry ? 'Try again: ' : '') + TAGS[s.t] }));
    body.appendChild(h('h1', { text: s.title }));
    body.appendChild(h('div', { class: 'prose', html: prose(s.text) }));
    try { cur = STEP[s.t](s, api); add(body, cur.els); }
    catch (e) { body.appendChild(h('p', { class: 'note', text: 'This step could not be loaded (' + e.message + ').' })); cur = { submit: function () { api.finish({ ok: true, silent: true }); } }; api.label('Skip'); main.disabled = false; }
    fit(); window.scrollTo(0, 0);
  }
  function complete() {
    var first = !S.done[lesson.id], gain = (first ? 10 : 5) + (mistakes === 0 ? 5 : 0);
    S.done[lesson.id] = true; S.xp += gain;
    if (S.lastDay !== today()) { S.streak = S.lastDay === today(-1) ? S.streak + 1 : 1; S.lastDay = today(); }
    saveState();
    var acc = Math.round((queue.length - mistakes) / queue.length * 100), nextL = LESSONS[lesson.no];
    var el = h('div', { class: 'result' }, h('div', { class: 'badge', html: ic('trophy', 54) }), h('h1', { text: lesson.no === LESSONS.length ? 'You built a language model' : 'Lesson complete' }),
      h('p', { text: lesson.no === LESSONS.length ? 'Every part of BitNet now exists in your own Python file. Open the Project tab to read it top to bottom, or try prompts in the Playground.' : lesson.title + ' is done.' }),
      h('div', { class: 'tiles' }, tile('XP', '+' + gain), tile('Accuracy', acc + '%'), tile('Hearts', hearts + '/5')));
    if (lesson.unlock) el.appendChild(h('div', { class: 'unlock' }, h('div', { class: 'uh', html: 'New in your project: <code>' + lesson.unlock + '</code>' }), codeBlock(ENGINE.parts[lesson.unlock])));
    if (nextL) el.appendChild(h('button', { type: 'button', class: 'btn wide', style: 'margin-bottom:10px', onclick: function () { startLesson(nextL); } }, 'Next lesson'));
    if (lesson.unlock) el.appendChild(h('button', { type: 'button', class: 'btn wide ghost', style: 'margin-bottom:10px', onclick: function () { go('project'); } }, 'See my project'));
    el.appendChild(h('button', { type: 'button', class: 'btn wide ghost', onclick: function () { go('home'); } }, 'Back to lessons'));
    player = null; view = 'result'; app.innerHTML = ''; app.appendChild(el); window.scrollTo(0, 0);
  }
  function failed() {
    var el = h('div', { class: 'result fail' }, h('div', { class: 'badge', html: ic('heart', 54) }), h('h1', { text: 'Out of hearts' }), h('p', { text: 'No harm done. Hearts refill when you start the lesson again, and the emulator will still be there to check every answer.' }),
      h('button', { type: 'button', class: 'btn wide', style: 'margin-bottom:10px', onclick: function () { startLesson(lesson); } }, 'Try again'), h('button', { type: 'button', class: 'btn wide ghost', onclick: function () { go('home'); } }, 'Back to lessons'));
    player = null; view = 'result'; app.innerHTML = ''; app.appendChild(el); window.scrollTo(0, 0);
  }
  function tile(k, v) { return h('div', { class: 'tile' }, h('div', { class: 'k', text: k }), h('div', { class: 'v', text: v })); }
  function askQuit() { modal('Leave this lesson?', 'Your place in this lesson will not be saved.', 'Keep going', 'Leave', function () { player = null; go('home'); }); }
  app.innerHTML = ''; app.appendChild(root); show();
  return { askQuit: askQuit };
}
function modal(title, text, stay, leave, onLeave) {
  closeModal();
  var stayBtn = h('button', { type: 'button', class: 'btn', onclick: closeModal }, stay);
  modalEl = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title, onclick: function (e) { if (e.target === modalEl) closeModal(); } },
    h('div', { class: 'box' }, h('h2', { text: title }), h('p', { text: text }), h('div', { class: 'foot-row' }, stayBtn, h('button', { type: 'button', class: 'btn ghost', onclick: function () { closeModal(); onLeave(); } }, leave))));
  document.body.appendChild(modalEl); stayBtn.focus();
}
function closeModal() { if (modalEl && modalEl.parentNode) modalEl.parentNode.removeChild(modalEl); modalEl = null; }
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modalEl) closeModal(); });

/* ---------- pages ---------- */
function isOpen(l) { return S.unlockAll || l.no === 1 || !!S.done[LESSONS[l.no - 2].id]; }
function nextLesson() { for (var i = 0; i < LESSONS.length; i++) if (!S.done[LESSONS[i].id]) return LESSONS[i]; return null; }
function doneCount() { return LESSONS.filter(function (l) { return S.done[l.id]; }).length; }
function builtParts() { var out = CONSTS.slice(); LESSONS.forEach(function (l) { if (l.unlock && S.done[l.id]) out.push(l.unlock); }); return ENGINE.order.filter(function (n) { return out.indexOf(n) >= 0; }); }
function projectSource() {
  var parts = builtParts(), src = parts.map(function (n) { return ENGINE.parts[n]; }).join('\n\n\n');
  return src + (parts.indexOf('generate') >= 0 ? '\n\n\nprint(generate(input(), 4))' : '\n\n\n# More parts arrive as you finish lessons.\nprint("parts so far:", ' + (parts.length - CONSTS.length) + ')');
}
function startLesson(l) { view = 'lesson'; player = Player(l); }
function shell(content) {
  var tabs = [['home', 'learn', 'Learn'], ['project', 'file', 'Project'], ['play', 'term', 'Playground'], ['about', 'info', 'About']];
  app.innerHTML = '';
  app.appendChild(h('header', { class: 'top' }, h('div', { class: 'brand', html: LOGO + '<span>BitLingo <b>Py</b></span>' }),
    h('div', { class: 'stats' }, h('div', { class: 'stat streak', title: 'Day streak', 'aria-label': S.streak + ' day streak', html: ic('flame', 20) + '<span>' + S.streak + '</span>' }), h('div', { class: 'stat xp', title: 'XP', 'aria-label': S.xp + ' XP', html: ic('bolt', 20) + '<span>' + S.xp + '</span>' }))));
  app.appendChild(h('main', { class: 'page' }, content));
  app.appendChild(h('nav', { class: 'tabs', 'aria-label': 'Sections' }, h('div', { class: 'tabs-in' }, tabs.map(function (t) {
    return h('button', { type: 'button', class: 'tab' + (view === t[0] ? ' on' : ''), 'aria-current': view === t[0] ? 'page' : null, html: ic(t[1], 23) + '<span>' + t[2] + '</span>', onclick: function () { go(t[0]); } });
  }))));
  window.scrollTo(0, 0);
}
function go(name) { closeModal(); player = null; view = name; ({ home: home, project: project, play: play, about: about })[name](); }
function home() {
  var nx = nextLesson(), dc = doneCount(), out = [];
  out.push(h('section', { class: 'hero' }, h('div', { class: 'kicker', text: dc === 0 ? 'Start here' : nx ? 'Up next' : 'Course complete' }),
    h('h1', { text: nx ? (dc === 0 ? 'Build a 1.58-bit language model in Python' : nx.title) : 'You built MicroBit from scratch' }),
    h('p', { text: nx ? (dc === 0 ? 'Every step runs real Python in a built-in emulator with a clock and a memory meter. You answer by running code, not by guessing.' : nx.blurb) : 'Replay any lesson, read your finished file in Project, or try your own prompts in the Playground.' }),
    h('div', { class: 'bar' }, h('i', { style: 'width:' + Math.round(dc / LESSONS.length * 100) + '%' })), h('div', { class: 'barlab', text: dc + ' of ' + LESSONS.length + ' lessons done' }),
    h('button', { type: 'button', class: 'btn yellow wide', onclick: function () { if (nx) startLesson(nx); else go('play'); } }, nx ? (dc === 0 ? 'Start lesson 1' : 'Continue: lesson ' + nx.no) : 'Open the Playground')));
  UNITS.forEach(function (u, ui) {
    var sec = h('section', { class: 'unit' }, h('div', { class: 'unit-head' }, h('span', { class: 'n', text: 'Unit ' + (ui + 1) }), h('h2', { text: u.title })), h('p', { text: u.blurb }));
    u.lessons.forEach(function (l) {
      var open = isOpen(l), done = !!S.done[l.id], isNext = nx && nx.id === l.id;
      sec.appendChild(h('button', { type: 'button', class: 'lesson' + (done ? ' done' : isNext ? ' next' : '') + (open ? '' : ' locked'), disabled: !open, 'aria-label': 'Lesson ' + l.no + ': ' + l.title + (done ? ', done' : open ? '' : ', locked'), onclick: function () { startLesson(l); } },
        h('span', { class: 'node', html: done ? ic('check', 24) : open ? String(l.no) : ic('lock', 20) }),
        h('span', { class: 'body' }, h('div', { class: 'ttl', text: l.title }), h('div', { class: 'sub', text: l.blurb }), l.unlock ? h('span', { class: 'part', text: 'builds ' + l.unlock + '()' }) : null),
        open ? h('span', { class: 'go', html: ic('chev', 20) }) : null));
    });
    out.push(sec);
  });
  shell(out);
}
function project() {
  var built = builtParts(), total = ENGINE.order.length - CONSTS.length, have = built.length - CONSTS.length, out = [];
  var where = {}; LESSONS.forEach(function (l) { if (l.unlock) where[l.unlock] = l; });
  out.push(h('div', { class: 'ph' }, h('h1', { text: 'microbit.py' }), h('p', { text: have + ' of ' + total + ' parts built. Each lesson that builds a part adds it here, in the order Python needs them.' })));
  out.push(h('div', { class: 'rowbtns', style: 'margin-bottom:14px' }, h('button', { type: 'button', class: 'btn small', onclick: function () { S.play = projectSource(); S.playIn = 'red blue'; saveState(); go('play'); } }, 'Run it in the Playground'), h('button', { type: 'button', class: 'btn small ghost', onclick: function () { copyText(projectSource() + '\n'); } }, 'Copy the file')));
  ENGINE.order.forEach(function (name) {
    var isConst = CONSTS.indexOf(name) >= 0, has = built.indexOf(name) >= 0, l = where[name];
    var label = name === 'math' ? 'import math' : isConst ? name : 'def ' + name;
    var card = h('div', { class: 'partcard' + (has ? '' : ' locked') }, h('div', { class: 'hd' }, has ? null : icon('lock', 16), h('code', { text: label }), h('span', { class: 'when', text: isConst ? 'given to you' : (has ? 'built in lesson ' : 'lesson ') + l.no })));
    if (has) card.appendChild(codeBlock(ENGINE.parts[name]));
    out.push(card);
  });
  shell(out);
}
var DEMO = 'def total(values):\n    acc = 0\n    for v in values:\n        acc += v\n    return acc\n\nnumbers = [3, 1, 4, 1, 5]\ncopy = list(numbers)\nprint(total(numbers))\nprint(input().upper())';
function play() {
  var card = EmuCard({ spec: { stdin: S.playIn }, code: S.play || DEMO, editable: true, stdinEditable: true, profile: true, onEdit: function (t) { S.play = t; saveState(); }, onStdin: function (v) { S.playIn = v; saveState(); } });
  function load(src, input) { S.play = src; S.playIn = input; saveState(); card.setCode(src); card.setStdin(input); card.setCode(src); }
  shell([h('div', { class: 'ph' }, h('h1', { text: 'Playground' }), h('p', { text: 'A free editor on the same emulator. Type Python, give it input, then Run or Step and watch the clock and memory.' })),
    h('div', { class: 'rowbtns' }, h('button', { type: 'button', class: 'btn small ghost', onclick: function () { load(projectSource(), 'red blue'); } }, 'Load my project'), h('button', { type: 'button', class: 'btn small ghost', onclick: function () { load(DEMO, 'hello'); } }, 'Load the demo'), h('button', { type: 'button', class: 'btn small ghost', onclick: function () { load('', ''); } }, 'Clear')),
    card.el,
    h('p', { class: 'note', html: 'The <b>Input</b> box is what <code>input()</code> reads. Once you have finished lesson 18, load your project and try prompts made of <code>red</code>, <code>blue</code> and <code>end</code>.' })]);
}
function about() {
  var all = h('button', { type: 'button', class: 'btn small ghost', onclick: function () { S.unlockAll = !S.unlockAll; saveState(); go('about'); } }, S.unlockAll ? 'Lock lessons again' : 'Unlock every lesson');
  var wipe = h('button', { type: 'button', class: 'btn small ghost', onclick: function () { modal('Reset all progress?', 'Lessons, XP, streak and Playground code will be cleared.', 'Keep it', 'Reset', function () { S = { done: {}, xp: 0, streak: 0, lastDay: '', unlockAll: false, play: '', playIn: 'red blue' }; saveState(); go('home'); }); } }, 'Reset progress');
  shell([h('div', { class: 'ph' }, h('h1', { text: 'About' }), h('p', { text: 'What you are building, what the emulator measures, and how it relates to the real BitNet.' })),
    h('section', { class: 'sec', html: '<h2>What you build</h2><p>A complete, working language model called <b>MicroBit</b>, written in plain Python with no libraries except <code>math</code>. It has the same moving parts as Microsoft\'s BitNet b1.58: three-value weights packed at 2 bits each, 8-bit inputs, BitLinear layers, RMSNorm, rotation for position, attention with a KV cache, a squared-ReLU feed-forward step, and a generate loop.</p><p>Its weights were written by hand, not trained. They make it do one small, checkable thing: say the word that came one step before the current one.</p>' +
      '<table class="cmp"><tr><th></th><th>MicroBit (yours)</th><th>BitNet b1.58 2B4T</th></tr><tr><td>Weights</td><td>448 in 7 layers, hand-written</td><td>about 2 billion, trained</td></tr><tr><td>Weight values</td><td>-1, 0, +1</td><td>-1, 0, +1</td></tr><tr><td>Inputs to a layer</td><td>8-bit whole numbers</td><td>8-bit whole numbers</td></tr><tr><td>Words it knows</td><td>3</td><td>128,256 tokens</td></tr><tr><td>Longest text</td><td>a handful of words</td><td>4,096 tokens</td></tr><tr><td>Runs on</td><td>this emulator, or any Python 3</td><td>bitnet.cpp (C++)</td></tr></table>' }),
    h('section', { class: 'sec', html: '<h2>How the emulator counts</h2><p><b>Clock.</b> One tick for each line Python runs. A <code>for</code> line ticks once per item plus once to finish, a <code>while</code> line ticks every time it is checked, and a one-line list builder ticks once per item. Built-in functions such as <code>sum</code> and <code>len</code> are free, which is why they win races against hand-written loops.</p><p><b>Memory.</b> The bytes held by everything your variables can reach, using the sizes CPython 3.14 reports: 28 bytes for a whole number (0 for the small ones from -5 to 256, which Python shares), 24 for a number with a fraction, 56 + 8 per slot for a list, 33 + 1 per byte for <code>bytes</code>. <b>Peak</b> is the highest the meter reached.</p><p>Both meters start at your first visible line. Project code that is already loaded is not charged to you.</p><p>Ticks are a teaching measure, not seconds. They show which version of a program does more work, which is the comparison that matters.</p>' }),
    h('section', { class: 'sec', html: '<h2>What Python it understands</h2><p>The emulator is a small Python written for this app. It covers what the course uses: functions, <code>if</code>, <code>for</code>, <code>while</code>, lists, tuples, dicts, <code>bytes</code>, strings, f-strings, slices, list builders, <code>import math</code>, <code>assert</code> and <code>raise</code>. Every lesson program was checked to print the same thing in real Python 3.14.</p><p>It does not have classes, <code>try</code>, <code>with</code>, <code>lambda</code>, sets or other libraries. Your finished <code>microbit.py</code> uses none of those, so it runs unchanged on a real computer: copy it from the Project tab and run <code>python microbit.py</code>.</p>' }),
    h('section', { class: 'sec', html: '<h2>The real thing</h2><p><b>bitnet.cpp</b> is Microsoft\'s official program for running 1-bit models. It is written in C++, is based on llama.cpp, and ships tuned kernels named I2_S, TL1 and TL2. Its README reports speedups of 1.37x to 5.07x on ARM CPUs and 2.37x to 6.17x on x86 CPUs, with large energy savings.</p><p>The model card for BitNet b1.58 2B4T lists about 0.4 GB of memory for the non-embedding weights and notes that the speed gains need bitnet.cpp rather than a general-purpose library.</p><ul><li><a href="https://github.com/microsoft/BitNet" target="_blank" rel="noopener">github.com/microsoft/BitNet</a></li><li><a href="https://huggingface.co/microsoft/bitnet-b1.58-2B-4T" target="_blank" rel="noopener">huggingface.co/microsoft/bitnet-b1.58-2B-4T</a></li></ul>' }),
    h('section', { class: 'sec' }, h('h2', { text: 'Settings' }), h('p', { text: device ? 'Progress is saved on this device.' : 'In this web preview progress lasts until the page is reloaded. The Android app saves it on the device.' }), h('div', { class: 'rowbtns', style: 'margin-bottom:10px' }, all, wipe))]);
}

window.exitBitLingoPage = function () {
  if (modalEl) { closeModal(); return true; }
  if (view === 'lesson' && player) { player.askQuit(); return true; }
  if (view !== 'home') { go('home'); return true; }
  return false;
};
window.addEventListener('pagehide', saveState);
loadState();
home();
})();
