// BitScribe learning app: course player, emulator runner, progress, settings, sounds.
(function () {
'use strict';
const BS = window.BS = {};
const IS_APP = !!window.BitScribeApp;          // running inside the Android app
BS.IS_APP = IS_APP;

// ---------------- small helpers ----------------
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function h(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }
function toast(msg, ms) {
  const t = h(`<div class="toast" role="status">${esc(msg)}</div>`);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms || 2600);
}
function modal(html, buttons) {
  return new Promise((resolve) => {
    const bg = h(`<div class="modal-bg"><div class="modal" role="dialog" aria-modal="true">${html}<div class="foot"></div></div></div>`);
    const foot = $('.foot', bg);
    (buttons || [{ label: 'OK', value: true, cls: 'primary' }]).forEach(b => {
      const btn = h(`<button class="btn ${b.cls || ''}">${esc(b.label)}</button>`);
      btn.onclick = () => { bg.remove(); BS.modalOpen--; resolve(b.value); };
      foot.appendChild(btn);
    });
    BS.modalOpen = (BS.modalOpen || 0) + 1;
    bg.addEventListener('click', (e) => { if (e.target === bg && buttons && buttons.length > 1) { bg.remove(); BS.modalOpen--; resolve(null); } });
    document.body.appendChild(bg);
    const first = $('.foot .btn:last-child', bg); if (first) first.focus();
  });
}
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fmtTime = (s) => { s = Math.max(0, Math.round(s)); if (s < 60) return s + ' s'; if (s < 3600) return Math.floor(s / 60) + ' min ' + (s % 60) + ' s'; const hh = Math.floor(s / 3600); return hh + ' h ' + Math.floor((s % 3600) / 60) + ' min'; };
Object.assign(BS, { $, $$, esc, h, toast, modal, today, fmtTime });

// ---------------- sounds (made with the Web Audio API, no files needed) ----------------
let actx = null;
function tone(freq, start, dur, type, vol) {
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = type || 'sine'; o.frequency.value = freq;
  const t0 = actx.currentTime + start;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(actx.destination);
  o.start(t0); o.stop(t0 + dur + 0.05);
}
function sound(kind) {
  if (!S.settings.sound) return;
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    const v = 0.18 * (S.settings.volume ?? 0.7);
    if (kind === 'correct') { tone(784, 0, 0.16, 'triangle', v); tone(1175, 0.09, 0.28, 'triangle', v); }
    else if (kind === 'wrong') { tone(220, 0, 0.18, 'square', v * 0.45); tone(165, 0.12, 0.3, 'square', v * 0.45); }
    else if (kind === 'pass') { [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.32, 'triangle', v)); }
    else if (kind === 'complete') { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, i * 0.11, i === 5 ? 0.6 : 0.22, 'triangle', v)); tone(262, 0.55, 0.6, 'sine', v * 0.6); }
    else if (kind === 'tap') tone(660, 0, 0.06, 'sine', v * 0.4);
  } catch (e) { /* audio is optional */ }
}
BS.sound = sound;

// ---------------- state ----------------
const LS_KEY = 'bitscribe.state.v1';
const WRITER_DEFAULTS = { topic: 'The Water Cycle', title: '', audience: 'high school students', author: '', pages: 12, volumes: 1, chapters: 0, sections: 0,
  tokens_per_hit: 400, web: 1, web_sources: 3, diagrams: 1, diagram_every: 2, exercises: 1, key_ideas: 1, toc: 1, index: 1,
  temperature: 0.7, top_p: 0.9, top_k: 40, repeat_penalty: 1.15, seed: 42, font: 'serif', font_size: 11, line_spacing: 1.35, margin_mm: 20, sources: '' };
function defaults() {
  return { v: 1, xp: 0, streak: 0, lastDay: '', dayXp: {}, done: {}, code: {}, drafts: {}, hints: {}, graduated: 0, t: 0,
    settings: { allowPaste: false, unlockAll: false, sound: true, volume: 0.7, theme: 'auto', font: 'calibri', fontSize: 17, codeSize: 14, dailyGoal: 30 },
    writer: { ...WRITER_DEFAULTS }, machine: { src: '' } };
}
function loadState() {
  let s = null;
  try { s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch (e) { s = null; }
  const d = defaults();
  if (!s || typeof s !== 'object') return d;
  return { ...d, ...s, settings: { ...d.settings, ...(s.settings || {}) }, writer: { ...d.writer, ...(s.writer || {}) }, machine: { ...d.machine, ...(s.machine || {}) } };
}
let S = loadState();
BS.S = () => S;
let saveTimer = null;
function save(opts) {
  S.t = Date.now();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) { /* private mode */ }
    if (!(opts && opts.local)) Sync.schedule();
  }, 250);
}
BS.save = save;
function addXp(n) {
  const d = today();
  if (S.lastDay !== d) {
    const y = new Date(); y.setDate(y.getDate() - 1);
    const yd = y.getFullYear() + '-' + String(y.getMonth() + 1).padStart(2, '0') + '-' + String(y.getDate()).padStart(2, '0');
    S.streak = S.lastDay === yd ? S.streak + 1 : 1;
    S.lastDay = d;
  }
  S.xp += n;
  S.dayXp[d] = (S.dayXp[d] || 0) + n;
  const keys = Object.keys(S.dayXp).sort();
  while (keys.length > 60) delete S.dayXp[keys.shift()];
  save();
  updateStats();
}

// ---------------- appearance: theme, font, sizes, fullscreen ----------------
const FONTS = {
  calibri: { label: 'Calibri (default)', css: 'Calibri, Carlito, "Segoe UI", system-ui, sans-serif' },
  nunito: { label: 'Nunito (rounded)', css: 'Nunito, system-ui, sans-serif' },
  atkinson: { label: 'Atkinson Hyperlegible (easy to read)', css: '"Atkinson Hyperlegible", system-ui, sans-serif' },
  lexend: { label: 'Lexend (made for reading)', css: 'Lexend, system-ui, sans-serif' },
  dyslexic: { label: 'OpenDyslexic', css: 'OpenDyslexic, system-ui, sans-serif', app: true },
  merriweather: { label: 'Merriweather (serif)', css: 'Merriweather, Georgia, serif' },
  system: { label: 'System font', css: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
};
if (!IS_APP) for (const k of Object.keys(FONTS)) if (FONTS[k].app) delete FONTS[k];
BS.FONTS = FONTS;
function applyLook() {
  const st = S.settings, root = document.documentElement;
  const dark = st.theme === 'dark' || (st.theme === 'auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  root.dataset.theme = dark ? 'dark' : 'light';
  root.style.setProperty('--font', (FONTS[st.font] || FONTS.calibri).css);
  root.style.setProperty('--fs', st.fontSize + 'px');
  root.style.setProperty('--code-size', st.codeSize + 'px');
  const tb = $('#btn-theme'); if (tb) tb.textContent = dark ? '☀️' : '🌙';
  if (IS_APP && window.BitScribeApp.setDark) try { window.BitScribeApp.setDark(!!dark); } catch (e) {}
  document.querySelectorAll('.CodeMirror').forEach(c => c.CodeMirror && c.CodeMirror.refresh());
}
BS.applyLook = applyLook;
if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyLook);
let appFullscreen = false;
async function toggleFullscreen() {
  if (IS_APP && window.BitScribeApp.setFullscreen) {
    appFullscreen = !appFullscreen;
    try { window.BitScribeApp.setFullscreen(appFullscreen); } catch (e) {}
    return;
  }
  try {
    if (document.fullscreenElement || document.webkitFullscreenElement) await (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else await (document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen).call(document.documentElement);
  } catch (e) { toast('Full screen is not allowed here. Open the app on its own page, or use the Android app.'); }
}
BS.toggleFullscreen = toggleFullscreen;

// ---------------- data ----------------
let COURSE = null, REF = null, ASSETS = null, MODEL = null;
let LESSONS = [], BY_ID = {}, UNITS = [];
const refCache = {};
function unobf(b64) {
  const bin = atob(b64), n = bin.length, u = new Uint8Array(n);
  for (let i = 0; i < n; i++) u[i] = bin.charCodeAt(i) ^ ((i * 7 + 13) & 255);
  return new TextDecoder().decode(u);
}
function refCode(name) { if (!(name in refCache)) refCache[name] = unobf(REF.items[name].code); return refCache[name]; }
let refRenamed = null;
function refProgram() { if (refRenamed === null) refRenamed = unobf(REF.ref); return refRenamed; }
const b64bytes = (b64) => { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
BS.refCode = refCode;
async function loadData(onMsg) {
  const get = async (p) => { const r = await fetch(p); if (!r.ok) throw new Error(p + ': ' + r.status); return r.json(); };
  onMsg('Loading the course…');
  [COURSE, REF, ASSETS] = await Promise.all([get('data/course.json'), get('data/ref.json'), get('data/assets.json')]);
  onMsg('Loading the BitNet model…');
  MODEL = await get('data/model.json');
  UNITS = COURSE.units;
  let idx = 0;
  for (const u of UNITS) for (const L of u.lessons) { L.index = idx++; L.unitObj = u; LESSONS.push(L); BY_ID[L.id] = L; }
  Object.assign(BS, { COURSE, REF, ASSETS, LESSONS, BY_ID, UNITS });
}
// Small AFM files rebuilt from Adobe's metrics (only the widths BitScribe uses; the change is noted in each file).
let afmCache = null;
function afmTexts() {
  if (afmCache) return afmCache;
  afmCache = {};
  for (const [name, m] of Object.entries(ASSETS.metrics)) {
    let t = 'StartFontMetrics 4.1\nComment ' + m.copyright + '\nComment MODIFIED by BitScribe: this file keeps only the character widths that BitScribe uses; the original Adobe AFM file has more data. See readme.txt and NOTE.txt.\nFontName ' + name + '\nNotice ' + m.notice + '\nStartCharMetrics ' + m.lines.length + '\n';
    for (const [c, w, n] of m.lines) t += 'C ' + c + ' ; WX ' + w + ' ; N ' + n + ' ;\n';
    afmCache[name] = t + 'EndCharMetrics\nEndFontMetrics\n';
  }
  return afmCache;
}
BS.afmTexts = afmTexts;
function baseFiles() {
  const out = [['/models/tiny.bnet', b64bytes(MODEL.bnet)], ['/models/tiny.tok', b64bytes(MODEL.tok)]];
  const enc = new TextEncoder();
  for (const [name, text] of Object.entries(afmTexts())) out.push(['/fonts/' + name + '.afm', enc.encode(text)]);
  return out;
}
BS.modelBytes = () => ({ bnet: b64bytes(MODEL.bnet), tok: b64bytes(MODEL.tok) });

// lesson kinds
const isCoding = (L) => !L.program && !L.graduation && L.items && L.items.length > 0;
const isProgram = (L) => !!L.program;
BS.isCoding = isCoding;
const TOTAL_PARTS = () => REF.order.length;
function partsWritten() { let n = 0; for (const L of LESSONS) if (isCoding(L) && S.done[L.id] && S.code[L.id]) n += L.items.length; return n; }
BS.partsWritten = partsWritten;
BS.TOTAL_PARTS = TOTAL_PARTS;
function isUnlocked(L) {
  if (S.settings.unlockAll || L.index === 0 || S.done[L.id]) return true;
  if (L.graduation) return LESSONS.every(x => x === L || x.graduation || S.done[x.id]);
  const prev = LESSONS[L.index - 1];
  return !!S.done[prev.id];
}
function currentLesson() { return LESSONS.find(L => !S.done[L.id] && isUnlocked(L)) || null; }
function updateStats() {
  $('#st-streak').textContent = S.streak || 0;
  $('#st-xp').textContent = S.xp || 0;
  $('#st-parts').textContent = REF ? partsWritten() + '/' + TOTAL_PARTS() : '0';
}
BS.updateStats = updateStats;

// ---------------- the emulator (runs in Web Workers) ----------------
// The worker is made from one blob (compiler + offline web + worker loop), so it needs no extra requests.
let workerUrlP = null;
function workerUrl() {
  if (!workerUrlP) workerUrlP = Promise.all(['bscc.js', 'minweb.js', 'worker.js'].map(f => fetch(f).then(r => { if (!r.ok) throw new Error(f); return r.text(); })))
    .then(parts => URL.createObjectURL(new Blob([parts.join('\n;\n')], { type: 'text/javascript' })))
    .catch(() => 'worker.js');
  return workerUrlP;
}
class Runner {
  constructor(name) { this.name = name; this.w = null; this.jobs = new Map(); this.seq = 0; this.readyP = null; }
  ensure() {
    if (this.readyP) return this.readyP;
    this.readyP = this.start();
    return this.readyP;
  }
  async start() {
    const url = await workerUrl();
    this.w = new Worker(url);
    let resolveReady;
    const ready = new Promise(r => { resolveReady = r; });
    this.w.onmessage = (e) => {
      const m = e.data;
      if (m.type === 'ready') { resolveReady(); return; }
      const j = this.jobs.get(m.id);
      if (!j) return;
      if (m.type === 'out') { if (j.h.onOut) j.h.onOut(m.text, m.err); j.out += m.text; j.err += m.err; }
      else if (m.type === 'compiled') { j.compiled = m; if (j.h.onCompiled) j.h.onCompiled(m); }
      else if (m.type === 'files') { if (j.h.onFiles) j.h.onFiles(m.files); }
      else if (m.type === 'done') { this.jobs.delete(m.id); j.resolve({ ...m, compile: j.compiled, out: j.out, err: j.err }); }
    };
    this.w.onerror = (e) => { console.error('worker error', e); };
    this.w.postMessage({ type: 'init', base: baseFiles(), articles: ASSETS.articles });
    return ready;
  }
  async run(job, handlers) {
    await this.ensure();
    const id = ++this.seq;
    return new Promise((resolve) => {
      this.jobs.set(id, { resolve, h: handlers || {}, out: '', err: '', compiled: null });
      this.w.postMessage({ type: 'run', id, ...job });
    });
  }
  stop() {
    if (!this.w) return;
    this.w.terminate(); this.w = null; this.readyP = null;
    for (const [, j] of this.jobs) j.resolve({ stopped: true, compile: j.compiled, out: j.out, err: j.err });
    this.jobs.clear();
  }
  busy() { return this.jobs.size > 0; }
}
const testRunner = new Runner('tests');
BS.Runner = Runner;
BS.testRunner = testRunner;

// The user's whole program, lesson by lesson. Missing parts can be filled with the course's code (hidden) for demos.
function programChunks(opts) {
  const chunks = [];
  let missing = [];
  for (const L of LESSONS) {
    if (!isCoding(L)) continue;
    const mine = S.done[L.id] && S.code[L.id];
    if (mine && !(opts && opts.refBefore && opts.refBefore.includes(L.id))) chunks.push({ name: 'your code: ' + L.title, code: S.code[L.id].src, renameMain: !!(opts && opts.renameMain), lesson: L.id });
    else {
      missing.push(L);
      if (opts && opts.fill) chunks.push({ name: 'course code: ' + L.title, code: L.items.map(refCode).join('\n'), hidden: true, renameMain: !!(opts && opts.renameMain), lesson: L.id });
    }
  }
  return { chunks, missing };
}
BS.programChunks = programChunks;

// Chunks to test one lesson. Earlier parts come from the course's code (so every lesson is tested on its own),
// or from the learner's own code when `ownEarlier` is set (the whole-program check in "My code").
function lessonChunks(L, src, ownEarlier) {
  if (isProgram(L)) {
    const ch = [{ name: 'your code', code: src, renameMain: !L.expect }];
    if (!L.expect) { ch.push({ name: 'test kit', code: ASSETS.testkit, hidden: true }); ch.push({ name: 'test', code: L.test, hidden: true }); }
    return ch;
  }
  const order = REF.order;
  const last = Math.max(...L.items.map(it => order.indexOf(it)));
  const ch = [];
  if (ownEarlier) {
    for (const P of LESSONS) {
      if (P === L) break;
      if (!isCoding(P)) continue;
      ch.push(S.done[P.id] && S.code[P.id] ? { name: 'your code: ' + P.title, code: S.code[P.id].src, renameMain: true } : { name: 'course code: ' + P.title, code: P.items.map(refCode).join('\n'), hidden: true });
    }
  } else {
    const prior = order.slice(0, last + 1).filter(x => !L.items.includes(x));
    ch.push({ name: 'earlier lessons', code: prior.map(refCode).join('\n'), hidden: true });
  }
  ch.push({ name: 'your code', code: src, renameMain: true });
  const protos = L.items.flatMap(it => REF.items[it].protos);
  if (protos.length) ch.push({ name: 'expected', code: protos.join('\n'), expectProto: true, hidden: true, renameMain: true });
  ch.push({ name: 'reference', code: refProgram(), hidden: true });
  ch.push({ name: 'test kit', code: ASSETS.testkit, hidden: true });
  ch.push({ name: 'test', code: L.test, hidden: true });
  return ch;
}
BS.lessonChunks = lessonChunks;

// Turn a finished test run into something a learner can read.
function interpret(L, res, chunks) {
  const r = { pass: false, compileError: null, fails: [], fault: null, output: '', expectDiff: null, pdfs: [], stopped: !!res.stopped };
  if (res.stopped) return r;
  if (res.compile && !res.compile.ok) { r.compileError = res.compile.error; return r; }
  const lines = (res.out || '').split('\n');
  const user = [];
  for (const ln of lines) {
    if (ln.startsWith('@@FAIL ')) r.fails.push(ln.slice(7));
    else if (ln.startsWith('@@pdf ')) r.pdfs.push(ln.slice(6).trim());
    else if (ln === '@@PASS' || ln.startsWith('@@EXIT')) { /* protocol */ }
    else user.push(ln);
  }
  r.output = user.join('\n').replace(/\n+$/, '');
  if (res.err) r.output += (r.output ? '\n' : '') + res.err;
  if (res.fault) {
    const chunkIdx = (res.fault.lineId >>> 20) - 1, line = res.fault.lineId & 0xfffff;
    const ch = chunks && chunks[chunkIdx];
    r.fault = { msg: res.fault.msg, line: ch && ch.name === 'your code' ? line : 0, where: ch ? ch.name : '', stack: (res.stack || []).filter(f => !/^ref_|^t_|^main$/.test(f)) };
  }
  if (L && L.expect !== null && L.expect !== undefined && L.expect !== '') {
    r.pass = !res.fault && res.out === L.expect;
    if (!r.pass && !res.fault) r.expectDiff = { want: L.expect, got: res.out };
  } else {
    const em = /@@EXIT (-?\d+) (.*)/.exec(res.out || '');
    if (em) {
      // the test expects the program to stop with exit(code) after printing a message to stderr
      r.pass = res.exitCode === +em[1] && (res.err || '').includes(em[2]) && r.fails.length === 0 && !res.fault;
      if (!r.pass && !res.fault && !r.fails.length) r.fails.push(res.exitCode !== +em[1] ? 'the program should stop with exit(' + em[1] + '), but it ' + (res.exitCode === 0 ? 'did not stop that way' : 'stopped with exit code ' + res.exitCode) : 'stderr should contain "' + em[2] + '"');
    } else r.pass = (res.out || '').includes('@@PASS') && r.fails.length === 0 && !res.fault && res.exitCode === 0;
  }
  return r;
}
BS.interpret = interpret;

// ---------------- text rendering (lesson cards) ----------------
const C_KW = /\b(auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|restrict|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while|bool|uint8_t|int8_t|uint16_t|int16_t|uint32_t|int32_t|uint64_t|int64_t|size_t|FILE|Str|NULL)\b/;
function hlC(code) {
  let out = '', i = 0;
  const n = code.length;
  while (i < n) {
    const c = code[i];
    if (c === '/' && code[i + 1] === '/') { const e = code.indexOf('\n', i); const j = e < 0 ? n : e; out += `<span class="hl-c">${esc(code.slice(i, j))}</span>`; i = j; continue; }
    if (c === '/' && code[i + 1] === '*') { const e = code.indexOf('*/', i + 2); const j = e < 0 ? n : e + 2; out += `<span class="hl-c">${esc(code.slice(i, j))}</span>`; i = j; continue; }
    if (c === '"' || c === "'") { let j = i + 1; while (j < n && code[j] !== c && code[j] !== '\n') j += code[j] === '\\' ? 2 : 1; j = Math.min(n, j + 1); out += `<span class="hl-s">${esc(code.slice(i, j))}</span>`; i = j; continue; }
    if (c === '#' && (i === 0 || code[i - 1] === '\n')) { const e = code.indexOf('\n', i); const j = e < 0 ? n : e; out += `<span class="hl-p">${esc(code.slice(i, j))}</span>`; i = j; continue; }
    if (/[0-9]/.test(c) && !/[A-Za-z_]/.test(code[i - 1] || '')) { const m = /^(0x[0-9a-fA-F]+|\d+\.?\d*([eE][-+]?\d+)?)[uUlLfF]*/.exec(code.slice(i)); out += `<span class="hl-n">${esc(m[0])}</span>`; i += m[0].length; continue; }
    if (/[A-Za-z_]/.test(c)) { const m = /^[A-Za-z_]\w*/.exec(code.slice(i)); const w = m[0]; out += C_KW.test(w) && w.length === (C_KW.exec(w) || [''])[0].length ? `<span class="${/^(int|char|float|double|void|long|short|unsigned|signed|bool|size_t|FILE|Str|u?int\d+_t)$/.test(w) ? 'hl-t' : 'hl-k'}">${w}</span>` : esc(w); i += w.length; continue; }
    out += esc(c); i++;
  }
  return out;
}
BS.hlC = hlC;
function inline(s) {
  return esc(s).replace(/`([^`]+)`/g, (m, c) => `<code>${c}</code>`).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
}
function md(text) {
  const lines = text.split('\n');
  let html = '', i = 0, para = [];
  const flush = () => { if (para.length) { html += `<p>${inline(para.join(' '))}</p>`; para = []; } };
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.startsWith('```')) {
      flush();
      const code = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) code.push(lines[i++]);
      i++;
      html += `<pre><code>${hlC(code.join('\n'))}</code></pre>`;
      continue;
    }
    if (ln.startsWith('[DIAGRAM')) {
      flush();
      const d = Diagrams.parse(ln);
      const svg = d && Diagrams.render(d);
      if (svg) html += svg;
      i++; continue;
    }
    if (/^\s*-\s+/.test(ln)) {
      flush();
      html += '<ul>';
      while (i < lines.length && /^\s*-\s+/.test(lines[i])) { html += `<li>${inline(lines[i].replace(/^\s*-\s+/, ''))}</li>`; i++; }
      html += '</ul>'; continue;
    }
    if (/^\s*\d+\.\s+/.test(ln)) {
      flush();
      html += '<ol>';
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        let item = lines[i].replace(/^\s*\d+\.\s+/, ''); i++;
        while (i < lines.length && /^\s{2,}-\s+/.test(lines[i])) { item += '\n- ' + lines[i].replace(/^\s+-\s+/, ''); i++; }
        const [first, ...subs] = item.split('\n- ');
        html += `<li>${inline(first)}${subs.length ? '<ul>' + subs.map(x => `<li>${inline(x)}</li>`).join('') + '</ul>' : ''}</li>`;
      }
      html += '</ol>'; continue;
    }
    if (!ln.trim()) { flush(); i++; continue; }
    para.push(ln.trim()); i++;
  }
  flush();
  return html;
}
BS.md = md;

// ---------------- code editor ----------------
function makeEditor(host, value, opts) {
  opts = opts || {};
  if (window.CodeMirror) {
    const cm = CodeMirror(host, {
      value: value || '', mode: 'text/x-csrc', theme: 'bs', lineNumbers: true, matchBrackets: true, autoCloseBrackets: true,
      indentUnit: 4, tabSize: 4, indentWithTabs: false, styleActiveLine: true, readOnly: !!opts.readOnly, lineWrapping: false,
      extraKeys: { Tab: (c) => c.somethingSelected() ? c.indentSelection('add') : c.replaceSelection('    ', 'end'), 'Ctrl-Enter': () => opts.onRun && opts.onRun(), 'Cmd-Enter': () => opts.onRun && opts.onRun() },
      inputStyle: 'contenteditable', spellcheck: false, autocorrect: false, autocapitalize: false,
    });
    cm.on('beforeChange', (c, ch) => {
      if ((ch.origin === 'paste' || ch.origin === 'drop') && !S.settings.allowPaste && !opts.allowPaste) {
        ch.cancel();
        toast('Pasting is off, so that you type every line yourself. You can turn it on in Profile → Settings.');
      }
    });
    if (opts.onChange) cm.on('changes', () => opts.onChange(cm.getValue()));
    setTimeout(() => cm.refresh(), 30);
    return {
      get: () => cm.getValue(), set: (v) => cm.setValue(v), focus: () => cm.focus(), cm,
      mark(line) { cm.eachLine(l => { cm.removeLineClass(l, 'background', 'cm-errline'); }); if (line > 0 && line <= cm.lineCount()) { cm.addLineClass(line - 1, 'background', 'cm-errline'); cm.scrollIntoView({ line: line - 1, ch: 0 }, 80); } },
    };
  }
  const ta = h('<textarea class="plain-editor" spellcheck="false" autocapitalize="off" autocomplete="off"></textarea>');
  ta.value = value || '';
  if (opts.readOnly) ta.readOnly = true;
  ta.addEventListener('paste', (e) => { if (!S.settings.allowPaste && !opts.allowPaste) { e.preventDefault(); toast('Pasting is off. You can turn it on in Profile → Settings.'); } });
  if (opts.onChange) ta.addEventListener('input', () => opts.onChange(ta.value));
  host.appendChild(ta);
  return { get: () => ta.value, set: (v) => { ta.value = v; }, focus: () => ta.focus(), mark() {} };
}
BS.makeEditor = makeEditor;

// ---------------- result panel ----------------
function renderResult(box, L, r, editor, extra) {
  let html = '';
  if (r.stopped) html = `<div class="res info"><h4>Stopped</h4>The program was stopped before it finished.</div>`;
  else if (r.compileError) {
    const e = r.compileError;
    const mine = e.file === 'your code';
    const caret = mine && e.col >= 0 ? '\n' + ' '.repeat(Math.max(0, e.col)) + '^' : '';
    html = `<div class="res err"><h4>Your code does not compile yet</h4>${mine ? `<b>Line ${e.line}:</b> ` : ''}${esc(e.msg)}${mine && e.src ? `<pre>${esc(e.src)}${caret}</pre>` : ''}${!mine && e.file ? `<div class="muted">Found while compiling ${esc(e.file === 'expected' ? 'the expected function headers' : e.file === 'test' || e.file === 'test kit' ? 'the tests that use your code' : e.file)} — check the names, parameters and struct members you used.</div>` : ''}</div>`;
    if (editor && mine) editor.mark(e.line);
  } else if (r.pass) {
    html = `<div class="res ok"><h4>✅ All tests passed!</h4>${extra || ''}</div>`;
    if (editor) editor.mark(0);
  } else {
    let body = '';
    if (r.fault) {
      body += `<p><b>Your program crashed:</b> ${esc(r.fault.msg)}</p>`;
      if (r.fault.line) { body += `<p>It happened at <b>line ${r.fault.line}</b> of your code.</p>`; if (editor) editor.mark(r.fault.line); }
      else if (/heap overflow/.test(r.fault.msg)) body += `<p class="muted">The test noticed it when it gave the memory back with free(), after your function had run: look for a loop in your code that goes one step too far (&lt;= instead of &lt;?).</p>`;
      else if (r.fault.where && r.fault.where !== 'your code') body += `<p class="muted">It happened inside ${esc(/test/.test(r.fault.where) ? 'the test' : r.fault.where)}${r.fault.stack.length ? ', while running ' + esc(r.fault.stack.slice(0, 3).join(' ← ')) : ''}.</p>`;
    }
    if (r.fails.length) body += `<ul>${r.fails.slice(0, 8).map(f => `<li>${esc(f)}</li>`).join('')}</ul>${r.fails.length > 8 ? `<p class="muted">…and ${r.fails.length - 8} more.</p>` : ''}`;
    if (r.expectDiff) {
      const w = r.expectDiff.want, g = r.expectDiff.got;
      let k = 0; while (k < w.length && w[k] === g[k]) k++;
      const lineNo = w.slice(0, k).split('\n').length;
      body += `<p>The output is different from what was expected, starting on output line ${lineNo}.</p><div class="grid2"><div><b>Expected</b><pre>${esc(w)}</pre></div><div><b>Your program printed</b><pre>${esc(g || '(nothing)')}</pre></div></div>`;
    }
    if (!body) body = '<p>The tests did not finish. Check the output below.</p>';
    html = `<div class="res err"><h4>Not yet — keep going!</h4>${body}</div>`;
  }
  if (r.output && r.output.trim() && !r.expectDiff) html += `<details ${r.pass ? '' : 'open'}><summary class="muted">What your program printed</summary><pre class="console">${esc(r.output.slice(-6000))}</pre></details>`;
  box.innerHTML = html;
}
BS.renderResult = renderResult;

// ---------------- downloads ----------------
let downloadsCap = undefined;
async function getDownloads() {
  if (downloadsCap !== undefined) return downloadsCap;
  try { downloadsCap = window.claude && window.claude.use ? await window.claude.use('downloads') : null; } catch (e) { downloadsCap = null; }
  return downloadsCap;
}
const MIME = { pdf: 'application/pdf', zip: 'application/zip', txt: 'text/plain', md: 'text/markdown', json: 'application/json', html: 'text/html' };
async function saveFile(filename, data) {
  const ext = filename.split('.').pop().toLowerCase();
  const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data instanceof Blob ? new Uint8Array(await data.arrayBuffer()) : data;
  if (IS_APP && window.BitScribeApp.saveFile) {
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    try { window.BitScribeApp.saveFile(filename, MIME[ext] || 'application/octet-stream', btoa(bin)); } catch (e) { toast('Saving failed: ' + e.message); }
    return;
  }
  const dl = await getDownloads();
  if (dl) {
    try { await dl.save({ filename, data: new Blob([bytes]) }); toast('Saved ' + filename); }
    catch (e) { if (e && e.code !== 'declined') toast('Could not save: ' + (e.message || e.code)); }
    return;
  }
  try {
    const url = URL.createObjectURL(new Blob([bytes], { type: MIME[ext] || 'application/octet-stream' }));
    const a = h(`<a href="${url}" download="${esc(filename)}"></a>`);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (e) { toast('Downloads are not available here.'); }
}
BS.saveFile = saveFile;
window.__bsSaved = (ok, name) => toast(ok ? 'Saved ' + (name || 'the file') : 'The file was not saved.');
function openPdf(bytes, title) {
  PdfViewer.open(bytes, { title, afm: afmTexts(), onDownload: () => saveFile((title || 'book').replace(/[^\w.-]+/g, '_').replace(/(\.pdf)?$/, '.pdf'), bytes) });
}
BS.openPdf = openPdf;

// ---------------- celebration ----------------
function confetti() {
  const box = h('<div class="confetti"></div>');
  const colors = ['#22b86b', '#2f6fe4', '#f5b72e', '#e5484d', '#7b5cf0', '#18c2c9'];
  for (let i = 0; i < 70; i++) {
    const p = document.createElement('i');
    p.style.left = Math.random() * 100 + 'vw';
    p.style.background = colors[i % colors.length];
    p.style.animationDelay = Math.random() * 0.7 + 's';
    p.style.animationDuration = 1.8 + Math.random() * 1.4 + 's';
    box.appendChild(p);
  }
  document.body.appendChild(box);
  setTimeout(() => box.remove(), 4200);
}
BS.confetti = confetti;

// ---------------- Learn tab: the path ----------------
const ICON = { done: '✓', code: '{ }', program: '▶', read: '★', grad: '🎓', lock: '🔒' };
function renderLearn(view) {
  const done = LESSONS.filter(L => S.done[L.id]).length;
  const cur = currentLesson();
  const goal = S.settings.dailyGoal, todayXp = S.dayXp[today()] || 0;
  view.innerHTML = `
    <div class="overview">
      <div class="card">
        <h2 style="margin-top:0">Build a BitNet textbook writer in C</h2>
        <p class="sub" style="margin:0 0 10px">Write every function yourself: a 1.58-bit language model, a tokenizer, web research, planning, page layout, diagrams and PDF files. Then use <b>your</b> program to write textbooks.</p>
        <div class="bar"><i style="width:${(100 * done / LESSONS.length).toFixed(1)}%"></i></div>
        <div class="row" style="margin-top:8px"><span class="muted">${done} of ${LESSONS.length} lessons · ${partsWritten()} of ${TOTAL_PARTS()} parts written by you</span><span class="grow"></span>${cur ? `<button class="btn primary" id="go-cur">${done ? 'Continue' : 'Start'}</button>` : ''}</div>
      </div>
      <div class="card" style="min-width:190px;text-align:center">
        <div class="muted">Today</div>
        <div style="font-size:28px;font-weight:900">${todayXp}<span class="muted" style="font-size:15px"> / ${goal} XP</span></div>
        <div class="bar" style="margin-top:6px"><i style="width:${Math.min(100, 100 * todayXp / goal)}%;background:var(--gold)"></i></div>
      </div>
    </div>
    <div id="units"></div>`;
  const unitsBox = $('#units', view);
  const offs = [0, 46, 70, 46, 0, -46, -70, -46];
  UNITS.forEach((u, ui) => {
    const ud = u.lessons.filter(L => S.done[L.id]).length;
    const wrap = h(`<section class="unit"><div class="unit-head" style="background:${esc(u.color)}"><div><div class="n">Unit ${ui + 1}</div><div class="t">${esc(u.title)}</div><div class="d">${esc(u.desc)}</div></div><div class="count">${ud}/${u.lessons.length}</div></div><div class="path"></div></section>`);
    const path = $('.path', wrap);
    u.lessons.forEach((L, li) => {
      const unlocked = isUnlocked(L), isDone = !!S.done[L.id], isCur = cur === L;
      const icon = isDone ? ICON.done : !unlocked ? ICON.lock : L.graduation ? ICON.grad : isProgram(L) ? ICON.program : isCoding(L) ? ICON.code : ICON.read;
      const color = isDone ? 'var(--gold)' : u.color;
      const n = h(`<div class="node ${unlocked ? '' : 'locked'} ${isCur ? 'current' : ''}" style="transform:translateX(${offs[li % 8]}px)" tabindex="0" role="button" aria-label="${esc(L.title)}${isDone ? ' (done)' : unlocked ? '' : ' (locked)'}">
        ${isCur ? '<div class="start">START</div>' : ''}
        <div class="dot" style="background:${color}">${icon}</div>
        ${isCoding(L) ? `<div class="kind">${L.items.length} part${L.items.length > 1 ? 's' : ''}</div>` : ''}
        <div class="lbl">${esc(L.title)}</div></div>`);
      const open = () => { if (!unlocked) { toast('Finish the lessons before this one first (or unlock all lessons in Profile → Settings).'); return; } sound('tap'); location.hash = 'lesson-' + L.id; };
      n.onclick = open;
      n.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } };
      path.appendChild(n);
    });
    unitsBox.appendChild(wrap);
  });
  const go = $('#go-cur', view);
  if (go) go.onclick = () => { location.hash = 'lesson-' + cur.id; };
  if (cur) setTimeout(() => { const c = $('.node.current', view); if (c && window.scrollY < 50) c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 60);
}

// ---------------- a lesson ----------------
let lessonCleanup = null;
function renderLesson(view, L) {
  const steps = [];
  for (const c of L.cards) steps.push(c);
  if (isCoding(L) || isProgram(L)) steps.push({ kind: 'code' });
  if (L.graduation) steps.push({ kind: 'graduate' });
  let k = 0, mistakes = 0;
  const wasDone = !!S.done[L.id];
  view.innerHTML = `<div class="lesson-top"><button class="x" aria-label="Close the lesson">✕</button><div class="bar"><i></i></div><span class="muted" id="stepno"></span>${wasDone && steps.some(s => s.kind === 'code') ? '<button class="btn small" id="skip">Go to the code</button>' : ''}</div><div id="stage"></div>`;
  $('.x', view).onclick = () => { location.hash = 'learn'; };
  const stage = $('#stage', view);
  const skip = $('#skip', view);
  if (skip) skip.onclick = () => { k = steps.findIndex(s => s.kind === 'code'); show(); };
  function progress() {
    $('.lesson-top .bar > i', view).style.width = (100 * k / steps.length) + '%';
    $('#stepno', view).textContent = (k + 1) + ' / ' + steps.length;
  }
  function next() { k++; if (k >= steps.length) finish(); else show(); window.scrollTo(0, 0); }
  function show() {
    progress();
    const st = steps[k];
    if (lessonCleanup) { lessonCleanup(); lessonCleanup = null; }
    if (st.kind === 'learn') {
      stage.innerHTML = `<div class="lesson-card card learn md">${k === 0 ? `<div class="muted">${esc(L.unitObj.title)}</div><h2>${esc(L.title)}</h2>` : ''}${md(st.text)}<div class="foot"><button class="btn primary" id="cont">Continue</button></div></div>`;
      const b = $('#cont', stage); b.onclick = next; b.focus({ preventScroll: true });
    } else if (st.kind === 'quiz') showQuiz(st);
    else if (st.kind === 'code') showCode();
    else if (st.kind === 'graduate') showGraduate();
  }
  function showQuiz(q) {
    const order = q.opts.map((o, i) => i).sort(() => Math.random() - 0.5);
    stage.innerHTML = `<div class="lesson-card card quiz"><div class="muted">Quick check</div><h2>${inline(q.q)}</h2><div id="opts"></div><div id="fb"></div><div class="foot"><button class="btn primary" id="check" disabled>Check</button></div></div>`;
    let chosen = -1, answered = false;
    const optsBox = $('#opts', stage);
    order.forEach((oi, pos) => {
      const b = h(`<button class="opt"><span class="pill" style="margin-right:8px">${pos + 1}</span>${inline(q.opts[oi])}</button>`);
      b.onclick = () => { if (answered) return; chosen = oi; $$('.opt', optsBox).forEach(x => x.classList.remove('sel')); b.classList.add('sel'); $('#check', stage).disabled = false; };
      b.dataset.oi = oi;
      optsBox.appendChild(b);
    });
    const check = $('#check', stage);
    const keyh = (e) => { if (/^[1-9]$/.test(e.key) && !answered) { const b = $$('.opt', optsBox)[+e.key - 1]; if (b) b.click(); } else if (e.key === 'Enter' && !check.disabled) check.click(); };
    window.addEventListener('keydown', keyh);
    lessonCleanup = () => window.removeEventListener('keydown', keyh);
    check.onclick = () => {
      if (!answered) {
        answered = true;
        const right = chosen === q.answer;
        $$('.opt', optsBox).forEach(x => { const oi = +x.dataset.oi; if (oi === q.answer) x.classList.add('right'); else if (oi === chosen) x.classList.add('wrong'); });
        $('#fb', stage).innerHTML = `<div class="feedback ${right ? 'good' : 'bad'}">${right ? '🎉 Correct!' : 'Not quite.'} ${inline(q.why || '')}</div>`;
        sound(right ? 'correct' : 'wrong');
        if (right) { check.textContent = 'Continue'; }
        else { mistakes++; check.textContent = 'Try again'; }
        check.dataset.right = right ? '1' : '';
      } else if (check.dataset.right) next();
      else showQuiz(q);
    };
  }
  function showCode() {
    const saved = S.code[L.id] && S.code[L.id].src;
    const draft = S.drafts[L.id];
    const start = draft != null ? draft : saved != null ? saved : (isProgram(L) ? '#include <stdio.h>\n\n' : `// ${L.title}\n// Write: ${L.items.join(', ')}\n\n`);
    const hintsShown = S.hints[L.id] || 0;
    const learnCards = L.cards.filter(c => c.kind === 'learn');
    stage.innerHTML = `
      <div class="code-layout">
        <div class="card taskbox">
          <div class="muted">${esc(L.unitObj.title)} · ${esc(L.title)}</div>
          <h3>Your task</h3>
          <ol class="task-list">${L.task.map(t => `<li>${inline(t)}</li>`).join('')}</ol>
          ${isCoding(L) ? `<div class="parts">${L.items.map(it => `<span class="pill blue">${esc(it)}</span>`).join('')}</div><p class="muted">Write all of ${L.items.length > 1 ? 'these parts' : 'this part'} in full. The tests compare your code with the course's own version.</p>` : ''}
          <div id="hints"></div>
          ${L.hints.length ? `<button class="btn small" id="hint-btn">Show a hint (${hintsShown}/${L.hints.length})</button>` : ''}
          <details class="review"><summary>Read the lesson again</summary><div class="md" style="margin-top:8px">${learnCards.map(c => md(c.text)).join('<hr style="border:0;border-top:2px solid var(--line);margin:14px 0">')}</div></details>
        </div>
        <div>
          <div class="card editor-card">
            <div class="editor-bar"><span class="name">${isProgram(L) ? 'program.c' : 'bitscribe.c — ' + esc(L.items[0])}${L.items.length > 1 ? ' …' : ''}</span><span class="grow"></span>
              <button class="btn small" id="reset" title="Start again with an empty editor">Clear</button>
              <button class="btn primary" id="run">▶ Run tests</button></div>
            <div id="ed"></div>
            <div class="results" id="results"><p class="muted" style="margin:0">Write the code, then press <b>Run tests</b> (or Ctrl+Enter). The emulator compiles your C to WebAssembly and checks it.</p></div>
          </div>
        </div>
      </div>`;
    const hintsBox = $('#hints', stage);
    const showHints = (n) => { hintsBox.innerHTML = L.hints.slice(0, n).map(t => `<div class="hint">💡 ${inline(t)}</div>`).join(''); };
    showHints(hintsShown);
    const hb = $('#hint-btn', stage);
    if (hb) {
      if (hintsShown >= L.hints.length) hb.disabled = true;
      hb.onclick = () => { const n = Math.min(L.hints.length, (S.hints[L.id] || 0) + 1); S.hints[L.id] = n; save(); showHints(n); hb.textContent = `Show a hint (${n}/${L.hints.length})`; if (n >= L.hints.length) hb.disabled = true; };
    }
    let draftTimer = null;
    const ed = makeEditor($('#ed', stage), start, { onChange: (v) => { clearTimeout(draftTimer); draftTimer = setTimeout(() => { S.drafts[L.id] = v; save({ local: true }); }, 600); }, onRun: () => run() });
    $('#reset', stage).onclick = async () => {
      if (await modal('<h3>Clear the editor?</h3><p>Your code in this lesson will be deleted from the editor.</p>', [{ label: 'Cancel', value: false }, { label: 'Clear', value: true, cls: 'danger' }])) { ed.set(isProgram(L) ? '#include <stdio.h>\n\n' : `// ${L.title}\n\n`); ed.focus(); }
    };
    const runBtn = $('#run', stage), results = $('#results', stage);
    let running = false, timer = null;
    async function run() {
      if (running) { testRunner.stop(); return; }
      const src = ed.get();
      S.drafts[L.id] = src; save({ local: true });
      const missingText = (L.musthave || []).filter(m => !src.includes(m));
      if (missingText.length) { results.innerHTML = `<div class="res err"><h4>Something is missing</h4>Your code must contain:<pre>${esc(missingText.join('\n'))}</pre></div>`; sound('wrong'); return; }
      if (isCoding(L)) {
        const bad = /\bref_\w+/.exec(src);
        if (bad) { results.innerHTML = `<div class="res err"><h4>Write it yourself</h4>Names starting with <code>ref_</code> belong to the course's checker (found <code>${esc(bad[0])}</code>).</div>`; return; }
      }
      running = true; runBtn.textContent = '■ Stop'; runBtn.classList.remove('primary'); runBtn.classList.add('danger');
      const t0 = Date.now();
      results.innerHTML = `<div class="res info"><div class="row"><div class="spin" style="width:22px;height:22px;border-width:3px"></div><b id="rs">Compiling…</b><span class="grow"></span><span class="muted" id="rt">0 s</span></div><pre class="console hidden" id="live"></pre></div>`;
      timer = setInterval(() => { const t = $('#rt', results); if (t) t.textContent = fmtTime((Date.now() - t0) / 1000); if (Date.now() - t0 > 240000) { testRunner.stop(); } }, 500);
      const chunks = lessonChunks(L, src);
      const needsPdf = /@@pdf/.test(L.test || '');
      let liveText = '';
      const res = await testRunner.run({ chunks, argv: ['test'], returnFiles: needsPdf ? '\\.pdf$' : null }, {
        onCompiled: (m) => { const s = $('#rs', results); if (s) s.textContent = m.ok ? 'Running the tests…' : 'Compile error'; },
        onOut: (t) => {
          const keep = t.split('\n').filter(x => /^@@(status|log|plan)/.test(x)).map(x => x.replace(/^@@\w+ /, ''));
          if (keep.length) { liveText = (liveText + keep.join('\n') + '\n').slice(-1500); const lv = $('#live', results); if (lv) { lv.classList.remove('hidden'); lv.textContent = liveText; lv.scrollTop = 1e9; } }
        },
      });
      clearInterval(timer);
      running = false; runBtn.textContent = '▶ Run tests'; runBtn.classList.add('primary'); runBtn.classList.remove('danger');
      if (Date.now() - t0 > 240000 && res.stopped) { results.innerHTML = '<div class="res err"><h4>Stopped after 4 minutes</h4>Your code may be stuck in an endless loop. Check your loop conditions.</div>'; return; }
      const r = interpret(L, res, chunks);
      if (r.pass) {
        const first = !S.done[L.id];
        const xp = first ? (L.xp || 15) + (S.hints[L.id] ? 0 : 5) + (mistakes === 0 ? 5 : 0) : 0;
        S.code[L.id] = { src, t: Date.now() };
        delete S.drafts[L.id];
        if (first) S.done[L.id] = { t: Date.now(), mistakes };
        save();
        if (xp) addXp(xp); else updateStats();
        let extra = first ? `<p><b>+${xp} XP</b>${isCoding(L) ? ` · ${partsWritten()} of ${TOTAL_PARTS()} parts of BitScribe are now written by you.` : ''}</p>` : '<p>Your new version is saved.</p>';
        const pdfFiles = (res.files || []).filter(f => /\.pdf$/.test(f[0]));
        extra += `<div class="row">${pdfFiles.map((f, i) => `<button class="btn small blue" data-pdf="${i}">Open the PDF your code made</button>`).join('')}<span class="grow"></span><button class="btn primary" id="done-next">Continue</button></div>`;
        renderResult(results, L, r, ed, extra);
        $$('[data-pdf]', results).forEach(b => { b.onclick = () => openPdf(pdfFiles[+b.dataset.pdf][1], pdfFiles[+b.dataset.pdf][0].replace(/^\//, '')); });
        $('#done-next', results).onclick = next;
        sound('pass');
        if (first) confetti();
      } else {
        renderResult(results, L, r, ed);
        if (!r.stopped) sound('wrong');
      }
    }
    runBtn.onclick = run;
    lessonCleanup = () => { clearTimeout(draftTimer); if (running) testRunner.stop(); };
  }
  function showGraduate() {
    const coding = LESSONS.filter(isCoding);
    const mine = coding.filter(x => S.done[x.id] && S.code[x.id]);
    const all = mine.length === coding.length;
    stage.innerHTML = `<div class="lesson-card card" style="text-align:center"><div class="done-icon">🎓</div><h2>Graduation</h2>
      <p>${partsWritten()} of ${TOTAL_PARTS()} parts of BitScribe are written by you.</p>
      ${all ? '<p>Let the emulator build your whole program from your own code only.</p><button class="btn primary" id="build">Build my program</button>' : `<p class="muted">Finish the ${coding.length - mine.length} coding lesson(s) you have not done yet, then come back.</p>`}
      <div id="gres" style="margin-top:12px;text-align:left"></div><div class="foot"><button class="btn" id="later">Back to the path</button></div></div>`;
    $('#later', stage).onclick = () => { location.hash = 'learn'; };
    const b = $('#build', stage);
    if (b) b.onclick = async () => {
      b.disabled = true; b.textContent = 'Building…';
      const { chunks } = programChunks({});
      const res = await testRunner.run({ chunks, compileOnly: true });
      const box = $('#gres', stage);
      if (res.compile && res.compile.ok) {
        S.graduated = Date.now(); save();
        box.innerHTML = `<div class="res ok"><h4>🎉 Your BitScribe program compiles: ${TOTAL_PARTS()} parts, all written by you.</h4>Open the <b>Writer</b> tab and write your first textbook with it. Export the project in <b>My code</b> to run it on a real computer.</div>`;
        sound('complete'); confetti();
        b.textContent = 'Open the Writer'; b.disabled = false; b.onclick = () => { finish(); location.hash = 'writer'; };
      } else {
        const e = res.compile && res.compile.error;
        box.innerHTML = `<div class="res err"><h4>Your full program does not compile yet</h4>${e ? `<b>${esc(e.file)}, line ${e.line}:</b> ${esc(e.msg)}${e.src ? `<pre>${esc(e.src)}</pre>` : ''}` : ''}<p class="muted">Open that lesson and fix your code there.</p></div>`;
        b.disabled = false; b.textContent = 'Build my program';
      }
    };
  }
  function finish() {
    if (!S.done[L.id]) {
      S.done[L.id] = { t: Date.now(), mistakes };
      const xp = L.graduation ? 50 : (L.xp || 10);
      addXp(xp);
      save();
      sound('complete');
      confetti();
    }
    const nextL = LESSONS[L.index + 1];
    stage.innerHTML = `<div class="lesson-card card" style="text-align:center"><div class="done-icon">🏆</div><h2>Lesson complete!</h2><p class="sub">${esc(L.title)}</p>
      <div class="foot" style="justify-content:center"><button class="btn" id="to-path">Back to the path</button>${nextL && isUnlocked(nextL) ? '<button class="btn primary" id="to-next">Next lesson</button>' : ''}</div></div>`;
    $('.lesson-top .bar > i', view).style.width = '100%';
    $('#to-path', stage).onclick = () => { location.hash = 'learn'; };
    const tn = $('#to-next', stage);
    if (tn) tn.onclick = () => { location.hash = 'lesson-' + nextL.id; };
  }
  show();
}

// ---------------- Profile tab ----------------
function renderProfile(view) {
  const st = S.settings;
  const done = LESSONS.filter(L => S.done[L.id]).length;
  const days = Object.keys(S.dayXp).sort().slice(-14);
  view.innerHTML = `
    <h1>Profile</h1>
    <div class="statgrid">
      <div class="stat"><div class="k">Streak</div><div class="v">🔥 ${S.streak}</div></div>
      <div class="stat"><div class="k">Total XP</div><div class="v">⚡ ${S.xp}</div></div>
      <div class="stat"><div class="k">Lessons</div><div class="v">${done}/${LESSONS.length}</div></div>
      <div class="stat"><div class="k">Parts by you</div><div class="v">🧩 ${partsWritten()}/${TOTAL_PARTS()}</div></div>
      <div class="stat"><div class="k">Graduated</div><div class="v">${S.graduated ? '🎓 Yes' : '—'}</div></div>
    </div>
    ${days.length ? `<div class="card" style="margin-top:14px"><h3>XP in the last days</h3><div style="display:flex;gap:6px;align-items:flex-end;height:90px">${days.map(d => { const v = S.dayXp[d]; const mx = Math.max(...days.map(x => S.dayXp[x]), 1); return `<div style="flex:1;text-align:center"><div style="height:${Math.max(4, 70 * v / mx)}px;background:var(--green);border-radius:6px" title="${v} XP"></div><div class="muted" style="font-size:11px">${d.slice(8)}</div></div>`; }).join('')}</div></div>` : ''}
    <div class="grid2" style="margin-top:14px">
      <div class="card">
        <h3>Look</h3>
        <label class="field"><span>Theme</span><select id="s-theme"><option value="auto">Automatic (like my device)</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
        <label class="field"><span>Font</span><select id="s-font">${Object.entries(FONTS).map(([k, f]) => `<option value="${k}">${esc(f.label)}</option>`).join('')}</select></label>
        <label class="field"><span>Text size: <b id="v-fs">${st.fontSize}px</b></span><input type="range" id="s-fs" min="13" max="26" step="1" style="width:100%"></label>
        <label class="field"><span>Code size: <b id="v-cs">${st.codeSize}px</b></span><input type="range" id="s-cs" min="11" max="24" step="1" style="width:100%"></label>
        <button class="btn small" id="s-full">⛶ Full screen</button>
      </div>
      <div class="card">
        <h3>Learning</h3>
        <label class="switch"><input type="checkbox" id="s-sound"> Sounds for right and wrong answers</label>
        <label class="field"><span>Volume</span><input type="range" id="s-vol" min="0" max="1" step="0.05" style="width:100%"></label>
        <label class="switch"><input type="checkbox" id="s-paste"> Allow pasting code into the editor</label>
        <label class="switch"><input type="checkbox" id="s-unlock"> Unlock all lessons</label>
        <label class="field"><span>Daily goal</span><select id="s-goal"><option value="10">10 XP — casual</option><option value="30">30 XP — regular</option><option value="50">50 XP — serious</option><option value="100">100 XP — intense</option></select></label>
      </div>
    </div>
    <div class="card" style="margin-top:14px">
      <h3>Your progress is saved</h3>
      <p class="sub" id="sync-status">${esc(Sync.status())}</p>
      <div class="row"><button class="btn small" id="exp-progress">Download a backup (.json)</button><label class="btn small" style="cursor:pointer">Restore a backup<input type="file" id="imp-progress" accept=".json,application/json" hidden></label><span class="grow"></span><button class="btn small danger" id="reset-all">Reset everything</button></div>
    </div>
    <p class="muted" style="margin-top:14px">BitScribe ${IS_APP ? 'for Android' : 'web'} · course with ${LESSONS.length} lessons and ${TOTAL_PARTS()} parts · fonts: Carlito, Nunito, Atkinson Hyperlegible, OpenDyslexic, Merriweather and JetBrains Mono (SIL Open Font License) · editor: CodeMirror (MIT).</p>`;
  const bind = (id, key, conv, after) => {
    const e = $('#' + id, view);
    if (e.type === 'checkbox') e.checked = !!st[key]; else e.value = st[key];
    e.addEventListener(e.type === 'range' ? 'input' : 'change', () => { st[key] = e.type === 'checkbox' ? e.checked : conv ? conv(e.value) : e.value; save(); applyLook(); if (after) after(); });
  };
  bind('s-theme', 'theme'); bind('s-font', 'font');
  bind('s-fs', 'fontSize', Number, () => { $('#v-fs', view).textContent = st.fontSize + 'px'; });
  bind('s-cs', 'codeSize', Number, () => { $('#v-cs', view).textContent = st.codeSize + 'px'; });
  bind('s-sound', 'sound', null, () => sound('correct'));
  bind('s-vol', 'volume', Number);
  $('#s-vol', view).addEventListener('change', () => sound('correct'));
  bind('s-paste', 'allowPaste'); bind('s-unlock', 'unlockAll'); bind('s-goal', 'dailyGoal', Number);
  $('#s-full', view).onclick = toggleFullscreen;
  $('#exp-progress', view).onclick = () => saveFile('bitscribe-progress-' + today() + '.json', JSON.stringify(S));
  $('#imp-progress', view).onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      if (!data || typeof data !== 'object' || !data.done) throw new Error('not a BitScribe backup');
      if (await modal('<h3>Restore this backup?</h3><p>It replaces your current progress on this device.</p>', [{ label: 'Cancel', value: false }, { label: 'Restore', value: true, cls: 'primary' }])) {
        const d = defaults();
        S = { ...d, ...data, settings: { ...d.settings, ...(data.settings || {}) }, writer: { ...d.writer, ...(data.writer || {}) } };
        save(); applyLook(); updateStats(); toast('Progress restored'); route();
      }
    } catch (err) { toast('That file could not be read: ' + err.message); }
  };
  $('#reset-all', view).onclick = async () => {
    if (await modal('<h3>Reset everything?</h3><p>All lessons, XP, your code and your settings will be deleted. This cannot be undone.</p>', [{ label: 'Cancel', value: false }, { label: 'Delete everything', value: true, cls: 'danger' }])) {
      S = defaults(); save(); applyLook(); updateStats(); Sync.resetRemote(); route(); toast('Everything was reset');
    }
  };
}

// ---------------- sync with the Claude account (when this page runs as an artifact) ----------------
const Sync = (() => {
  let db = null, uid = null, state = 'local', timer = null, writing = Promise.resolve(), lastCodeHash = {};
  const unitOf = (lessonId) => (BY_ID[lessonId] ? BY_ID[lessonId].unitObj.id : 'misc');
  async function init() {
    if (IS_APP || !window.claude || !window.claude.use) return;
    try {
      const [d, u] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
      if (!d || !u) return;
      const id = await u.id();
      if (!id) return;
      db = d; uid = id; state = 'loading';
      const base = 'data/users/' + uid;
      const prog = await Promise.race([db.doc(base + '/progress').get(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 10000))]);
      const codes = await db.doc(base + '/progress').collection('units').get().catch(() => null);
      merge(prog && prog.exists ? prog.data() : null, codes ? codes.docs.map(x => x.data()) : []);
      state = 'synced';
      for (const u2 of UNITS) lastCodeHash[u2.id] = JSON.stringify(unitCode(u2.id));
      schedule(true);
    } catch (e) { state = db ? 'error' : 'local'; }
  }
  function unitCode(unitId) { const o = {}; for (const [id, c] of Object.entries(S.code)) if (unitOf(id) === unitId) o[id] = c; return o; }
  function merge(p, units) {
    let changed = false;
    if (p) {
      for (const [id, v] of Object.entries(p.done || {})) if (!S.done[id]) { S.done[id] = v; changed = true; }
      if ((p.xp || 0) > S.xp) { S.xp = p.xp; changed = true; }
      if ((p.lastDay || '') > (S.lastDay || '')) { S.lastDay = p.lastDay; S.streak = p.streak || 0; changed = true; }
      for (const [d, v] of Object.entries(p.dayXp || {})) if ((S.dayXp[d] || 0) < v) { S.dayXp[d] = v; changed = true; }
      if ((p.t || 0) > (S.t || 0)) { S.settings = { ...S.settings, ...(p.settings || {}) }; S.writer = { ...S.writer, ...(p.writer || {}) }; changed = true; }
      if (p.graduated && !S.graduated) { S.graduated = p.graduated; changed = true; }
      for (const [id, n] of Object.entries(p.hints || {})) if ((S.hints[id] || 0) < n) { S.hints[id] = n; changed = true; }
    }
    for (const u of units) for (const [id, c] of Object.entries((u && u.lessons) || {})) {
      if (!S.code[id] || (c.t || 0) > (S.code[id].t || 0)) { S.code[id] = c; changed = true; }
    }
    if (changed) { try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) {} applyLook(); updateStats(); if (!(location.hash || '').startsWith('#lesson-')) route(); }
  }
  function schedule(now) {
    if (!db || state === 'loading') return;
    clearTimeout(timer);
    timer = setTimeout(push, now ? 100 : 2500);
  }
  function push() {
    writing = writing.then(async () => {
      try {
        const base = 'data/users/' + uid;
        const p = { xp: S.xp, streak: S.streak, lastDay: S.lastDay, dayXp: S.dayXp, done: S.done, hints: S.hints, settings: S.settings, writer: { ...S.writer, sources: (S.writer.sources || '').slice(0, 60000) }, graduated: S.graduated, t: S.t };
        await db.doc(base + '/progress').set(JSON.parse(JSON.stringify(p)));
        for (const u of UNITS) {
          const c = unitCode(u.id), j = JSON.stringify(c);
          if (lastCodeHash[u.id] === j) continue;
          await db.doc(base + '/progress').collection('units').doc(u.id).set({ lessons: c });
          lastCodeHash[u.id] = j;
        }
        state = 'synced';
      } catch (e) { state = 'error'; }
      const ss = $('#sync-status'); if (ss) ss.textContent = status();
    });
  }
  async function resetRemote() {
    if (!db) return;
    try {
      const base = 'data/users/' + uid;
      await db.doc(base + '/progress').delete();
      for (const u of UNITS) await db.doc(base + '/progress').collection('units').doc(u.id).delete();
      lastCodeHash = {};
    } catch (e) {}
  }
  function status() {
    if (IS_APP) return 'Saved on this device. Use “Download a backup” to move your progress to another device.';
    if (state === 'synced') return 'Saved in this browser and in your Claude account, so it follows you to your other devices.';
    if (state === 'loading') return 'Loading your progress from your Claude account…';
    if (state === 'error') return 'Saved in this browser. Your Claude account could not be reached right now.';
    return 'Saved in this browser. Use “Download a backup” to move your progress to another device.';
  }
  return { init, schedule, status, resetRemote };
})();
BS.Sync = Sync;

// ---------------- router ----------------
let currentTab = '';
function route() {
  const hash = (location.hash || '#learn').slice(1);
  const view = $('#view');
  if (lessonCleanup) { lessonCleanup(); lessonCleanup = null; }
  if (BS.onLeave) { const f = BS.onLeave; BS.onLeave = null; f(); }
  let tab = hash;
  if (hash.startsWith('lesson-')) {
    const L = BY_ID[hash.slice(7)];
    if (L && isUnlocked(L)) { tab = 'learn'; setTab(tab); renderLesson(view, L); window.scrollTo(0, 0); return; }
    tab = 'learn';
  }
  if (!['learn', 'machine', 'writer', 'project', 'profile'].includes(tab)) tab = 'learn';
  setTab(tab);
  if (tab === 'learn') renderLearn(view);
  else if (tab === 'profile') renderProfile(view);
  else if (BS.views && BS.views[tab]) BS.views[tab](view);
  if (currentTab !== tab) window.scrollTo(0, 0);
  currentTab = tab;
}
BS.route = route;
function setTab(tab) { $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab)); }
window.addEventListener('hashchange', route);
// Android back button: close a dialog, leave a lesson, or go back to Learn. Returns true if handled.
window.__bsBack = () => {
  const pv = $('.pdfv'); if (pv) { $('.pdfv-close', pv).click(); return true; }
  const m = $('.modal-bg'); if (m) { m.remove(); BS.modalOpen = 0; return true; }
  const hash = (location.hash || '#learn').slice(1);
  if (hash !== 'learn' && hash !== '') { location.hash = 'learn'; return true; }
  return false;
};

// ---------------- boot ----------------
async function boot() {
  applyLook();
  $$('#tabs button').forEach(b => { b.onclick = () => { location.hash = b.dataset.tab; }; });
  $('#logo').onclick = () => { location.hash = 'learn'; };
  $('#btn-theme').onclick = () => { const dark = document.documentElement.dataset.theme === 'dark'; S.settings.theme = dark ? 'light' : 'dark'; save(); applyLook(); };
  $('#btn-full').onclick = toggleFullscreen;
  try {
    await loadData((m) => { const e = $('#boot-msg'); if (e) e.textContent = m; });
  } catch (e) {
    $('#view').innerHTML = `<div class="card"><h2>BitScribe could not load</h2><p>${esc(e.message)}</p><p>Reload the page to try again.</p></div>`;
    return;
  }
  updateStats();
  route();
  Sync.init();
}
document.addEventListener('DOMContentLoaded', boot);
})();
