// ARM assembly (GNU syntax) highlighting: a CodeMirror mode for the editor, and hlAsm() for code in the lessons.
(function (G) {
  'use strict';
  const REG = /^(r(1[0-5]|[0-9])|sp|lr|pc|ip|fp|sb|sl|[sS]([12][0-9]|3[01]|[0-9])|[dD](1[0-5]|[0-9])|apsr_nzcv|fpscr|APSR_nzcv|FPSCR)\b/;
  const SHIFT = /^(lsl|lsr|asr|ror|rrx)\b/i;
  // one token from the start of `s`; `st` is {start: true at the beginning of a statement}
  function token(s, st) {
    let m;
    if ((m = /^\s+/.exec(s))) return ['', m[0]];
    if (s[0] === '@' || s.startsWith('//')) return ['comment', s];
    if (s.startsWith('/*')) { const e = s.indexOf('*/', 2); if (e < 0) { st.inBlock = true; return ['comment', s]; } return ['comment', s.slice(0, e + 2)]; }
    if (st.lineStart && s[0] === '#') return ['comment', s];
    if (s[0] === '"') { let j = 1; while (j < s.length && s[j] !== '"') j += s[j] === '\\' ? 2 : 1; return ['string', s.slice(0, j + 1)]; }
    if (s[0] === "'" && s[2] === "'") return ['string', s.slice(0, 3)];
    if (s[0] === "'" && s[1] === '\\' && s[3] === "'") return ['string', s.slice(0, 4)];
    if (s[0] === ';') { st.start = true; return ['operator', ';']; }
    if (st.start && (m = /^([A-Za-z_.$][\w.$]*|\d+)\s*:/.exec(s))) return ['def', m[0]];
    if (st.start && (m = /^\.[A-Za-z_][\w.]*/.exec(s))) { st.start = false; return ['meta', m[0]]; }
    if (st.start && (m = /^[A-Za-z_][\w.]*/.exec(s))) { st.start = false; return ['keyword', m[0]]; }
    if ((m = /^#?-?(0x[0-9a-fA-F]+|0b[01]+|\d+\.\d*(e[-+]?\d+)?|\d+)/i.exec(s)) && (s[0] === '#' || /[\d-]/.test(s[0]))) {
      if (!/^\d+[bf]\b/.test(s) || s[0] === '#') return ['number', m[0]];
    }
    if ((m = /^\d+[bf]\b/.exec(s))) return ['variable-3', m[0]];
    if (s[0] === '#') return ['number', '#'];
    if ((m = /^:(lower16|upper16):/.exec(s))) return ['atom', m[0]];
    if ((m = REG.exec(s))) return ['variable-2', m[0]];
    if ((m = SHIFT.exec(s))) return ['builtin', m[0]];
    if ((m = /^[A-Za-z_.$][\w.$]*/.exec(s))) return ['variable', m[0]];
    if (s[0] === '=') return ['atom', '='];
    if ('{}[]!^'.includes(s[0])) return ['bracket', s[0]];
    return ['operator', s[0]];
  }
  const CLS = { comment: 'hl-c', string: 'hl-s', def: 'hl-d', meta: 'hl-p', keyword: 'hl-k', number: 'hl-n', 'variable-2': 'hl-t', 'variable-3': 'hl-d', builtin: 'hl-b', atom: 'hl-b' };
  const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function hlAsm(code) {
    let out = '';
    const st = { inBlock: false };
    for (const line of String(code).split('\n')) {
      let s = line;
      st.start = true; st.lineStart = true;
      if (st.inBlock) {
        const e = s.indexOf('*/');
        if (e < 0) { out += `<span class="hl-c">${esc(s)}</span>\n`; continue; }
        out += `<span class="hl-c">${esc(s.slice(0, e + 2))}</span>`; s = s.slice(e + 2); st.inBlock = false;
      }
      while (s.length) {
        const [kind, text] = token(s, st);
        if (kind !== '') st.lineStart = false;
        out += kind && CLS[kind] ? `<span class="${CLS[kind]}">${esc(text)}</span>` : esc(text);
        s = s.slice(text.length);
      }
      out += '\n';
    }
    return out.replace(/\n$/, '');
  }
  G.hlAsm = hlAsm;
  G.armToken = token;
  function defineMode(CM) {
    CM.defineMode('armasm', () => ({
      startState: () => ({ start: true, lineStart: true, inBlock: false }),
      token(stream, state) {
        if (stream.sol()) { state.start = true; state.lineStart = true; }
        if (state.inBlock) {
          if (stream.match(/^.*?\*\//)) { state.inBlock = false; return 'comment'; }
          stream.skipToEnd(); return 'comment';
        }
        const rest = stream.string.slice(stream.pos);
        const [kind, text] = token(rest, state);
        stream.pos += Math.max(1, text.length);
        if (kind !== '') state.lineStart = false;
        return kind || null;
      },
      lineComment: '@',
      blockCommentStart: '/*', blockCommentEnd: '*/',
    }));
    CM.defineMIME('text/x-armasm', 'armasm');
  }
  if (G.CodeMirror) defineMode(G.CodeMirror);
  G.defineArmMode = defineMode;
})(typeof window !== 'undefined' ? window : globalThis);
