// ===== BitScribe offline web: answers Wikipedia-style API requests from built-in articles =====
function makeOfflineWeb(articles, userPages) {
  // articles: [{title, text}] where text uses "== Heading ==" lines like Wikipedia plain-text extracts
  const enc = new TextEncoder();
  const words = (s) => (s.toLowerCase().match(/[a-z0-9]+/g) || []).filter(w => w.length > 2);
  const index = articles.map(a => ({ a, t: new Set(words(a.title)), b: words(a.text.slice(0, 4000)) }));
  const json = (o) => ({ status: 200, body: enc.encode(JSON.stringify(o)), type: 'application/json' });
  const search = (q, n) => {
    const qw = words(q);
    const scored = index.map(x => {
      let s = 0;
      for (const w of qw) { if (x.t.has(w)) s += 5; for (const b of x.b) if (b === w || (w.length > 4 && b.startsWith(w.slice(0, -1)))) s += 0.05; }
      if (x.a.title.toLowerCase() === q.toLowerCase()) s += 50;
      return { s, a: x.a };
    }).filter(x => x.s > 0.2).sort((p, q2) => q2.s - p.s).slice(0, n);
    return scored.map(x => x.a);
  };
  return function web(url) {
    let u;
    try { u = new URL(url); } catch (e) { return { status: 0, body: new Uint8Array(0) }; }
    const host = u.hostname;
    const user = (userPages || []).find(p => p.url === url || p.url === url.replace(/\/$/, ''));
    if (user) return { status: 200, body: enc.encode(user.text), type: 'text/html' };
    if (u.pathname.endsWith('/w/api.php')) {
      const P = u.searchParams;
      if (P.get('list') === 'search') {
        const n = Math.min(20, parseInt(P.get('srlimit') || '10', 10) || 10);
        const hits = search(P.get('srsearch') || '', n);
        return json({ batchcomplete: '', query: { searchinfo: { totalhits: hits.length }, search: hits.map((a, i) => ({ ns: 0, title: a.title, pageid: 1000 + articles.indexOf(a), size: a.text.length, wordcount: a.text.split(/\s+/).length, snippet: a.text.slice(0, 120).replace(/\n/g, ' ') })) } });
      }
      if (P.get('prop') === 'extracts') {
        const t = (P.get('titles') || '').trim();
        let a = articles.find(x => x.title.toLowerCase() === t.toLowerCase());
        if (!a) a = search(t, 1)[0];
        if (!a) return json({ batchcomplete: true, query: { pages: [{ ns: 0, title: t, missing: true }] } });
        return json({ batchcomplete: true, query: { pages: [{ pageid: 1000 + articles.indexOf(a), ns: 0, title: a.title, extract: a.text }] } });
      }
      return json({ error: { code: 'badvalue', info: 'The offline web only knows list=search and prop=extracts' } });
    }
    const m = /\/wiki\/(.+)$/.exec(u.pathname);
    if (m) {
      const t = decodeURIComponent(m[1]).replace(/_/g, ' ');
      const a = articles.find(x => x.title.toLowerCase() === t.toLowerCase());
      if (a) {
        const html = '<!DOCTYPE html><html><head><title>' + a.title + '</title></head><body><h1>' + a.title + '</h1>' +
          a.text.split('\n').map(l => { const h = /^==+\s*(.*?)\s*==+$/.exec(l); return h ? '<h2>' + h[1] + '</h2>' : (l.trim() ? '<p>' + l + '</p>' : ''); }).join('\n') + '</body></html>';
        return { status: 200, body: enc.encode(html), type: 'text/html' };
      }
    }
    return { status: 404, body: enc.encode('<html><body><h1>404 - not in the offline web</h1><p>The browser sandbox has no internet, so the emulator uses a built-in offline web. ' + host + ' is not part of it. Real internet works when you run your program natively.</p></body></html>'), type: 'text/html' };
  };
}
if (typeof module !== 'undefined') module.exports = { makeOfflineWeb };
