// BitScribe ARM emulator worker: assembles ARM code with armkit, links it and runs it on the ARMv7 emulator.
// It also runs the step debugger of the Machine tab.
if (typeof ArmKit === 'undefined') importScripts('armkit.js', 'minweb.js');
const K = ArmKit;
let baseFiles = new Map();
let articles = [];
let web = null;
let REF = null;                // the course's code (lightly scrambled, like in the app)
const objCache = new Map();    // assembled units, by key
const userCache = new Map();   // assembled learner units, by text

function unobf(b64) {
  const bin = atob(b64), n = bin.length, u = new Uint8Array(n);
  for (let i = 0; i < n; i++) u[i] = bin.charCodeAt(i) ^ ((i * 7 + 13) & 255);
  return new TextDecoder().decode(u);
}
function refText(key) {
  if (key === 'ref') return unobf(REF.ref);
  if (key === 'testkit') return REF.testkit;
  if (key.startsWith('item:')) return unobf(REF.items[key.slice(5)].asm);
  throw new Error('unknown course unit ' + key);
}
function header(drop) {
  // the constants header without the constants the learner writes in this lesson
  if (!drop || !drop.length) return REF.header;
  const own = new Set(drop);
  return REF.header.split('\n').filter(l => { const m = /\.equ\s+(\w+)\s*,/.exec(l); return !m || !own.has(m[1]); }).join('\n');
}
// u: {name, text | key, hidden, rename, prefix: true (add the constants header), drop: [names], lesson}
function assembleUnit(u) {
  if (u.key) {
    const k = u.key + (u.rename ? '|' + JSON.stringify(u.rename) : '');
    let o = objCache.get(k);
    if (!o) {
      o = K.assemble({ name: u.name, text: refText(u.key), rename: u.rename });
      objCache.set(k, o);
    }
    return { obj: o, pre: 0 };
  }
  const pre = u.prefix ? header(u.drop) + '\n' : '';
  const preLines = pre ? pre.split('\n').length - 1 : 0;
  const text = pre + u.text;
  const ck = (u.rename ? JSON.stringify(u.rename) : '') + '\u0000' + text;
  let o = userCache.get(ck);
  if (!o) {
    o = K.assemble({ name: u.name, text, rename: u.rename });
    userCache.set(ck, o);
    if (userCache.size > 500) userCache.delete(userCache.keys().next().value);
  }
  return { obj: o, pre: preLines };
}
// assemble and link: returns {ok, prog, pre: [header lines per unit], errors, equErr, stage}
function build(units, equCheck) {
  const objs = [], pre = [], errors = [];
  units.forEach((u, i) => {
    let r;
    try { r = assembleUnit(u); } catch (e) { errors.push({ unit: i, unitName: u.name, line: 0, msg: 'could not assemble: ' + e.message }); return; }
    pre.push(r.pre);
    for (const e of r.obj.errors) {
      const line = e.line - r.pre;
      const src = u.text != null && line > 0 ? (u.text.split('\n')[line - 1] || '') : '';
      errors.push({ unit: i, unitName: u.name, line: line > 0 ? line : 0, msg: e.msg, src, inHeader: line <= 0 && r.pre > 0 });
    }
    objs.push({ obj: r.obj, name: u.name, hidden: !!u.hidden });
  });
  if (errors.length) return { ok: false, stage: 'assemble', errors, pre };
  let equErr = [];
  if (equCheck) {
    const o = objs[equCheck.unit].obj;
    for (const e of equCheck.list) {
      if (!(e.name in o.equs)) equErr.push(e.name + ' is missing (write .equ ' + e.name + ', ...)');
      else if (o.equs[e.name] !== e.value) equErr.push(e.name + ' is ' + o.equs[e.name] + ', but it should be ' + e.value);
    }
  }
  const prog = K.link(objs, { libcFuncs: K.LIBC_FUNCS, entry: 'main' });
  if (!prog.ok) return { ok: false, stage: 'link', errors: prog.errors.map(e => ({ unit: e.unit, unitName: e.unit >= 0 && units[e.unit] ? units[e.unit].name : '', line: e.line ? e.line - (pre[e.unit] || 0) : 0, msg: e.msg })), pre, equErr };
  return { ok: true, prog, pre, equErr, objs };
}
function snapshotFiles(files, filter) {
  const out = [];
  for (const [path, node] of files) {
    if (baseFiles.has(path) && !node.dirty) continue;
    if (filter && !filter.test(path)) continue;
    if (!node.data) continue;
    out.push([path, node.data.slice(0, node.size)]);
  }
  return out;
}
function makeFiles(list) {
  const files = new Map();
  for (const [p, d] of baseFiles) files.set(p, { data: d, size: d.length });
  for (const [p, d] of (list || [])) {
    const data = typeof d === 'string' ? new TextEncoder().encode(d) : d;
    files.set(p, { data, size: data.length, dirty: true });
  }
  return files;
}
function faultInfo(f, units, pre) {
  if (!f) return null;
  const u = f.unit >= 0 ? units[f.unit] : null;
  return { msg: f.msg, unit: f.unit, unitName: u ? u.name : '', line: f.line ? f.line - (pre[f.unit] || 0) : 0, func: f.func, abi: !!f.abi, timeout: !!f.timeout, stack: f.stack || [] };
}

// ---------------- the step debugger ----------------
let dbg = null;   // {sess, units, pre, prog, mine, lineAddrs, outBuf, files}
function dbgState(extra) {
  const s = dbg.sess, m = s.m, S = m.S;
  const pc = s.pc >>> 0;
  const w = m.where(pc);
  let insn = '';
  if (m.isCode(pc)) {
    const lab = K.funcAtAny(dbg.prog, pc);
    insn = K.disasm(m.dv0.getUint32(pc - m.B, true), pc, (a) => { const f = K.funcAtAny(dbg.prog, a); return f && f.addr === a && !/^\.L/.test(f.name) ? f.name : null; });
    if (lab && lab.addr === pc) insn = lab.name + ':  ' + insn;
  } else if (pc >= K.LAYOUT.STUB_BASE && pc < K.LAYOUT.STUB_BASE + 4 * dbg.prog.stubs.length) insn = 'the C library function ' + dbg.prog.stubs[(pc - K.LAYOUT.STUB_BASE) >> 2] + ' (runs as one step)';
  else if (pc === (K.LAYOUT.MAGIC_EXIT >>> 0)) insn = 'main has returned';
  const regs = Array.from(S.R); regs[15] = pc | 0;
  const st = {
    type: 'dbg-state', pc, regs, flags: Array.from(S.FL), vi: Array.from(S.VI), insn,
    where: { unit: w.unit, unitName: w.unitName, line: w.line ? w.line - (dbg.pre[w.unit] || 0) : 0, func: w.func, mine: w.unit === dbg.mine },
    stack: s.stack().slice(0, 30), steps: s.steps, done: s.done, exitCode: s.exitCode,
    fault: s.fault ? faultInfo(s.fault, dbg.units, dbg.pre) : null,
  };
  // the memory view: a fixed address, or (by default) the stack around sp
  const memAt = dbg.memAddr != null ? dbg.memAddr >>> 0 : Math.max(dbg.prog.layout.stackLo, Math.min(dbg.prog.layout.stackHi - 128, ((S.R[13] >>> 0) & ~15) - 16)) >>> 0;
  st.mem = readMem(memAt, 128);
  st.memFollow = dbg.memAddr == null;
  return Object.assign(st, extra || {});
}
function readMem(a, n) {
  const m = dbg.sess.m, out = [];
  for (let i = 0; i < n; i++) {
    const p = (a + i) >>> 0;
    const off = p - m.B;
    out.push(off >= 0 && off < m.size ? m.u8[off] : -1);
  }
  return { addr: a, bytes: out };
}
function flushOut() { if (dbg && dbg.outBuf) { self.postMessage({ type: 'dbg-out', text: dbg.outBuf, err: dbg.errBuf }); dbg.outBuf = ''; dbg.errBuf = ''; } else if (dbg && dbg.errBuf) { self.postMessage({ type: 'dbg-out', text: '', err: dbg.errBuf }); dbg.errBuf = ''; } }
function startDebug(m) {
  const units = m.units;
  const b = build(units);
  if (!b.ok) { self.postMessage({ type: 'dbg-state', error: b, done: true }); return; }
  const mine = units.findIndex(u => u.name === 'your code');
  dbg = { units, pre: b.pre, prog: b.prog, mine, outBuf: '', errBuf: '', pause: false, running: false, memAddr: null };
  const files = makeFiles(m.files);
  dbg.files = files;
  dbg.sess = K.debugSession(b.prog, { files, web, argv: m.argv || ['program'], onOut: (t, e) => { if (e) dbg.errBuf += t; else dbg.outBuf += t; }, maxOut: 4e6, stdin: m.stdin ? new TextEncoder().encode(m.stdin) : undefined });
  // which addresses belong to which line of your code (for breakpoints)
  const lines = {};
  const lm = b.prog.lineMap, base = b.prog.layout.textBase;
  for (let i = 0; i < lm.length; i++) {
    const id = lm[i];
    if (!id || (id >>> 20) - 1 !== mine) continue;
    const ln = (id & 0xFFFFF) - (b.pre[mine] || 0);
    (lines[ln] = lines[ln] || []).push(base + 4 * i);
  }
  dbg.lineAddrs = lines;
  // labels you can type in the memory view: all labels of your code, and the global ones of the program
  const syms = {};
  b.objs.forEach((o, ui) => {
    for (const sy of o.obj.symbols) {
      if (ui !== mine && !sy.global) continue;
      if (/^(ref_|\.L|__|t_)/.test(sy.name)) continue;
      const base = b.prog.bases[ui] && b.prog.bases[ui][sy.sec];
      if (base === undefined) continue;
      if (ui === mine || !(sy.name in syms)) syms[sy.name] = (base + sy.off) >>> 0;
    }
  });
  flushOut();
  self.postMessage(dbgState({ started: true, codeLines: Object.keys(lines).map(Number), syms, layout: b.prog.layout }));
}
function dbgRun(cmd, bps) {
  const s = dbg.sess, m = s.m;
  // a breakpoint on a line without an instruction (a label or a comment) stops at the next instruction below it
  const bpAddrs = new Set();
  const codeLines = Object.keys(dbg.lineAddrs).map(Number).sort((a, b) => a - b);
  for (const ln of (bps || [])) {
    const at = codeLines.find(x => x >= ln);
    if (at !== undefined && at - ln < 20) for (const a of dbg.lineAddrs[at]) bpAddrs.add(a | 0);
  }
  const depth0 = s.depth();
  const startPc = s.pc | 0;
  let target = null;
  if (cmd === 'over') {
    // step over a call: run until the instruction after it
    const w = m.isCode(startPc >>> 0) ? K.decode(m.dv0.getUint32((startPc >>> 0) - m.B, true), startPc) : null;
    if (w && (w.k === 'bl' || w.k === 'blxr')) target = (startPc + 4) | 0;
    else { s.step(); flushOut(); self.postMessage(dbgState()); return; }
  }
  dbg.pause = false; dbg.running = true;
  let first = true, total = 0;
  const t0 = Date.now();
  const slice = () => {
    if (!dbg || dbg.sess !== s) return;
    const end = Date.now() + 60;
    let stop = null;
    while (!s.done) {
      for (let k = 0; k < 2000 && !s.done; k++) {
        if (!first) {
          const pc = s.pc | 0;
          if (cmd === 'over' && pc === target && s.depth() <= depth0) { stop = 'step'; break; }
          if (cmd === 'out' && s.depth() < depth0) { stop = 'step'; break; }
          if (bpAddrs.has(pc)) { stop = 'breakpoint'; break; }
        }
        first = false;
        s.step(); total++;
      }
      if (stop || s.done || dbg.pause || Date.now() > end) break;
    }
    flushOut();
    if (stop || s.done || dbg.pause) {
      dbg.running = false;
      self.postMessage(dbgState({ stopped: stop || (dbg.pause ? 'paused' : 'end'), ran: total, ms: Date.now() - t0 }));
      return;
    }
    self.postMessage({ type: 'dbg-progress', steps: s.steps, ran: total });
    setTimeout(slice, 0);
  };
  slice();
}

self.onmessage = (ev) => {
  const m = ev.data;
  if (m.type === 'init') {
    baseFiles = new Map(m.base);
    articles = m.articles || [];
    REF = m.ref;
    web = makeOfflineWeb(articles, []);
    // assemble the big shared units now, so the first test is quick
    if (m.warm) try { assembleUnit({ name: 'reference', key: 'ref' }); assembleUnit({ name: 'test kit', key: 'testkit' }); } catch (e) { /* reported later */ }
    self.postMessage({ type: 'ready', evalOk: K.EVAL_OK });
    return;
  }
  if (m.type === 'dbg-start') { try { startDebug(m); } catch (e) { self.postMessage({ type: 'dbg-state', error: { stage: 'internal', errors: [{ msg: String(e && e.message || e) }] }, done: true }); } return; }
  if (m.type === 'dbg-cmd') {
    if (!dbg) return;
    if (m.cmd === 'pause') { dbg.pause = true; return; }
    if (m.cmd === 'mem') { dbg.memAddr = m.follow ? null : m.addr >>> 0; self.postMessage(dbgState()); return; }
    if (dbg.running) return;
    if (m.cmd === 'step') { dbg.sess.step(); flushOut(); self.postMessage(dbgState()); return; }
    dbgRun(m.cmd, m.bps);
    return;
  }
  if (m.type === 'dbg-files') { if (dbg) self.postMessage({ type: 'dbg-files', files: snapshotFiles(dbg.files, m.filter ? new RegExp(m.filter) : null) }); return; }
  if (m.type !== 'run') return;
  const id = m.id;
  const t0 = performance.now();
  const units = m.units;
  const b = build(units, m.equCheck);
  self.postMessage({ type: 'compiled', id, ok: b.ok, stage: b.stage || 'ok', errors: b.errors || [], equErr: b.equErr || [], ms: performance.now() - t0 });
  if (!b.ok) { self.postMessage({ type: 'done', id, compiled: false }); return; }
  if (m.compileOnly) { self.postMessage({ type: 'done', id, compiled: true, equErr: b.equErr }); return; }
  const files = makeFiles(m.files);
  const runWeb = m.userPages && m.userPages.length ? makeOfflineWeb(articles.concat(m.userPages), []) : web;
  let buf = '', ebuf = '', last = performance.now();
  const snapRe = m.snapshot ? new RegExp(m.snapshot) : null;
  const flush = () => {
    if (buf || ebuf) self.postMessage({ type: 'out', id, text: buf, err: ebuf });
    buf = ''; ebuf = ''; last = performance.now();
  };
  const onOut = (text, isErr) => {
    if (isErr) ebuf += text; else buf += text;
    if (snapRe && !isErr && /@@(status|file|done)/.test(text)) {
      flush();
      const snap = snapshotFiles(files, snapRe);
      if (snap.length) self.postMessage({ type: 'files', id, files: snap });
      return;
    }
    if (buf.length + ebuf.length > 8192 || performance.now() - last > 120) flush();
  };
  let res;
  try {
    res = K.runProgram(b.prog, { files, web: runWeb, argv: m.argv || ['program'], onOut, maxOut: m.maxOut || 20e6, maxSteps: m.maxSteps || 4e11, checkABI: m.checkABI !== false, stdin: m.stdin ? new TextEncoder().encode(m.stdin) : undefined });
  } catch (e) {
    flush();
    self.postMessage({ type: 'done', id, compiled: true, exitCode: -1, fault: { msg: 'the emulator stopped: ' + (e && e.message || e), line: 0, unit: -1 }, files: [] });
    return;
  }
  flush();
  const outFiles = m.returnFiles ? snapshotFiles(files, m.returnFiles === true ? null : new RegExp(m.returnFiles)) : [];
  self.postMessage({
    type: 'done', id, compiled: true, exitCode: res.exitCode, equErr: b.equErr,
    fault: faultInfo(res.fault, units, b.pre), ms: res.ms, steps: res.steps, leaks: res.leaks, files: outFiles,
  });
};
