// BitScribe ARM tools: the Machine (an ARM playground with a step debugger), the Writer (textbook writer)
// and My code (the project and its export).
(function () {
'use strict';
const BS = window.BS;
const { $, $$, esc, h, toast, modal, fmtTime } = BS;
BS.views = BS.views || {};
const S = () => BS.S();

// ---------------- a tiny IndexedDB store for books (optional; the app works without it) ----------------
const Store = (() => {
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((res) => {
      try {
        const r = indexedDB.open('bitscribe-arm-books', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('files');
        r.onsuccess = () => res(r.result);
        r.onerror = () => res(null);
      } catch (e) { res(null); }
    });
    return dbp;
  }
  async function op(mode, fn) {
    const db = await open();
    if (!db) return null;
    return new Promise((res) => {
      try { const tx = db.transaction('files', mode); const st = tx.objectStore('files'); const r = fn(st); tx.oncomplete = () => res(r && r.result); tx.onerror = () => res(null); } catch (e) { res(null); }
    });
  }
  return {
    put: (k, v) => op('readwrite', st => st.put(v, k)),
    get: (k) => op('readonly', st => st.get(k)),
    del: (k) => op('readwrite', st => st.delete(k)),
  };
})();

// ---------------- Machine ----------------
const machineRunner = new BS.Runner('machine');
const dbgRunner = new BS.Runner('debugger');
const hex8 = (v) => '0x' + (v >>> 0).toString(16).toUpperCase().padStart(8, '0');
const fbits = new DataView(new ArrayBuffer(8));
const asFloat = (bits) => { fbits.setInt32(0, bits, true); return fbits.getFloat32(0, true); };
const asDouble = (lo, hi) => { fbits.setInt32(0, lo, true); fbits.setInt32(4, hi, true); return fbits.getFloat64(0, true); };
const fnum = (x) => (Number.isInteger(x) && Math.abs(x) < 1e7 ? x.toFixed(1) : Math.abs(x) >= 1e7 || (Math.abs(x) < 1e-4 && x !== 0) ? x.toExponential(4) : String(+x.toPrecision(7)));
const REG_NAMES = ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'r12', 'sp', 'lr', 'pc'];

BS.views.machine = function (view) {
  const st = S();
  const T = BS.ASSETS.templates;
  if (!st.machine.src) st.machine.src = T.hello.src;
  view.innerHTML = `
    <h1>The Machine</h1>
    <p class="sub">An ARMv7 computer inside this app. Write a program and <b>Run</b> it, or press <b>Debug</b> to run it one instruction at a time and watch the registers, the flags and the memory change. Tick <b>Use my BitScribe code</b> to call the functions you wrote in the lessons.</p>
    <div class="card editor-card">
      <div class="editor-bar">
        <select id="tpl" style="width:auto"><option value="">Examples…</option>${Object.entries(T).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('')}</select>
        <label class="switch" style="margin:0"><input type="checkbox" id="mine" ${st.machine.mine ? 'checked' : ''}> Use my BitScribe code</label>
        <span class="grow"></span>
        <button class="btn" id="mdebug">🐞 Debug</button>
        <button class="btn primary" id="mrun">▶ Run</button>
      </div>
      <div id="med"></div>
      <div id="dbg" class="dbg hidden">
        <div class="dbg-bar">
          <button class="btn small blue" id="d-step" title="Run one instruction (F10)">Step</button>
          <button class="btn small" id="d-over" title="Run a whole function call (bl) as one step">Step over</button>
          <button class="btn small" id="d-out" title="Run until the current function returns">Step out</button>
          <button class="btn small primary" id="d-cont" title="Run until a breakpoint or the end">▶ Continue</button>
          <button class="btn small" id="d-pause" disabled>⏸ Pause</button>
          <button class="btn small danger" id="d-stop">■ Stop</button>
          <span class="muted dbg-tip">Click a line number to set a breakpoint.</span>
        </div>
        <div class="dbg-now"><span id="d-where"></span><code id="d-insn"></code></div>
        <div class="dbg-grid">
          <div class="dbg-box"><h4>Registers</h4><div id="d-regs" class="regs"></div><div id="d-flags" class="flags"></div></div>
          <div class="dbg-box"><h4>Decimal registers <select id="d-vmode"><option value="s">s0–s31 (float)</option><option value="d">d0–d15 (double)</option><option value="x">bits (hex)</option></select></h4><div id="d-vfp" class="vregs"></div></div>
          <div class="dbg-box"><h4>Memory <input type="text" id="d-addr" placeholder="sp, a label or 0x…" spellcheck="false" autocapitalize="off"></h4><div id="d-mem" class="mem"></div></div>
          <div class="dbg-box"><h4>Call stack</h4><div id="d-stack" class="stack"></div><div class="muted" id="d-steps"></div></div>
        </div>
      </div>
      <div class="results">
        <div class="row" style="margin-bottom:8px"><label class="grow">Arguments <input type="text" id="margs" placeholder="for example: --topic Bees" value="${esc(st.machine.args || '')}"></label></div>
        <div class="console" id="mout">Output appears here.</div>
        <div id="mfiles" class="filelist"></div>
      </div>
    </div>`;
  const ed = BS.makeEditor($('#med', view), st.machine.src, { onChange: (v) => { st.machine.src = v; BS.save({ local: true }); if (dbgOn) stopDebug('The code changed, so the debugger stopped.'); }, onRun: () => run(), allowPaste: true, breakpoints: true });
  const cm = ed.cm;
  // breakpoints: a red dot in the gutter
  const bpMarker = () => { const d = document.createElement('div'); d.className = 'bp-dot'; d.textContent = '●'; return d; };
  const toggleBp = (n) => { if (!cm) return; const info = cm.lineInfo(n); cm.setGutterMarker(n, 'bp-gutter', info.gutterMarkers && info.gutterMarkers['bp-gutter'] ? null : bpMarker()); };
  if (cm) cm.on('gutterClick', (c, n) => toggleBp(n));
  const breakpoints = () => { const out = []; if (cm) cm.eachLine(lh => { if (lh.gutterMarkers && lh.gutterMarkers['bp-gutter']) out.push(cm.getLineNumber(lh) + 1); }); return out; };
  $('#tpl', view).onchange = (e) => { const t = T[e.target.value]; if (!t) return; if (dbgOn) stopDebug(); ed.set(t.src); st.machine.src = t.src; $('#mine', view).checked = t.mine; st.machine.mine = t.mine; BS.save({ local: true }); e.target.value = ''; };
  $('#mine', view).onchange = (e) => { st.machine.mine = e.target.checked; BS.save({ local: true }); };
  $('#margs', view).onchange = (e) => { st.machine.args = e.target.value; BS.save({ local: true }); };
  const out = $('#mout', view), runBtn = $('#mrun', view), dbgBtn = $('#mdebug', view), filesBox = $('#mfiles', view);
  let running = false;
  const args = () => ($('#margs', view).value.match(/"[^"]*"|\S+/g) || []).map(a => a.replace(/^"|"$/g, ''));
  // the units of a Machine program: your program, plus (if ticked) your BitScribe code, with BitScribe's main renamed
  function machineUnits() {
    let units = [], note = '';
    const mine = $('#mine', view).checked;
    if (mine) {
      const p = BS.programUnits({ fill: true, renameMain: true });
      units = p.units;
      if (p.missing.length) note = `(${p.missing.length} lesson(s) not done yet: the course's code fills in for those parts)\n`;
    }
    units.push({ name: 'your code', text: ed.get(), prefix: mine });
    return { units, note };
  }
  const printOut = (t, e) => {
    if (t) out.appendChild(document.createTextNode(t));
    if (e) { const s = document.createElement('span'); s.className = 'e'; s.textContent = e; out.appendChild(s); }
    if (out.childNodes.length > 4000) out.removeChild(out.firstChild);
    out.scrollTop = out.scrollHeight;
  };
  const buildError = (ce) => {
    const mine = (ce.errors || []).filter(e => e.unitName === 'your code');
    const e = mine[0] || (ce.errors || [])[0];
    if (!e) return 'The program could not be built.';
    if (mine[0] && mine[0].line) ed.mark(mine[0].line);
    return `${ce.stage === 'link' ? 'Link error' : 'Assembly error'}${e.unitName === 'your code' ? (e.line ? ' on line ' + e.line : '') : ' in ' + e.unitName}: ${e.msg}${e.unitName === 'your code' && e.src ? '\n    ' + e.src : ''}${(ce.errors || []).length > 1 ? `\n(${ce.errors.length - 1} more error${ce.errors.length > 2 ? 's' : ''})` : ''}`;
  };
  const faultText = (f) => `\n[crashed: ${f.msg}${f.unitName === 'your code' && f.line ? ' — line ' + f.line : f.func ? ' — in ' + f.func : ''}${f.stack && f.stack.length ? ' — called from ' + f.stack.slice(0, 3).join(' ← ') : ''}]`;
  async function run() {
    if (dbgOn) { toast('Stop the debugger first (or press Continue).'); return; }
    if (running) { machineRunner.stop(); return; }
    running = true; runBtn.textContent = '■ Stop'; runBtn.classList.replace('primary', 'danger');
    out.innerHTML = ''; filesBox.innerHTML = ''; ed.mark(0);
    const { units, note } = machineUnits();
    if (note) out.appendChild(document.createTextNode(note));
    const t0 = Date.now();
    const res = await machineRunner.run({ units, argv: ['program', ...args()], returnFiles: true, maxSteps: 2e11 }, { onOut: printOut });
    running = false; runBtn.textContent = '▶ Run'; runBtn.classList.replace('danger', 'primary');
    const tail = document.createElement('span');
    tail.className = res.fault || (res.compile && !res.compile.ok) ? 'e' : '';
    if (res.stopped) tail.textContent = '\n[stopped]';
    else if (res.compile && !res.compile.ok) tail.textContent = buildError(res.compile);
    else if (res.fault) { tail.textContent = faultText(res.fault); if (res.fault.unitName === 'your code' && res.fault.line) ed.mark(res.fault.line); }
    else tail.textContent = `\n[finished with exit code ${res.exitCode} in ${fmtTime((Date.now() - t0) / 1000)} · ${res.steps < 1e6 ? res.steps.toLocaleString() + ' instructions' : (res.steps / 1e6).toLocaleString(undefined, { maximumFractionDigits: res.steps < 1e8 ? 1 : 0 }) + ' million instructions'}]`;
    out.appendChild(tail);
    out.scrollTop = out.scrollHeight;
    showFiles(filesBox, res.files || []);
  }
  runBtn.onclick = run;

  // ---------- the step debugger ----------
  let dbgOn = false, dbgBusy = false, last = null, prevRegs = null, prevV = null, syms = {}, layout = null;
  const D = (id) => $('#' + id, view);
  const setBusy = (b) => {
    dbgBusy = b;
    for (const id of ['d-step', 'd-over', 'd-out', 'd-cont']) D(id).disabled = b || (last && last.done);
    D('d-pause').disabled = !b;
  };
  function stopDebug(msg) {
    dbgOn = false; dbgBusy = false;
    dbgRunner.onMsg = null;
    dbgRunner.stop();
    D('dbg').classList.add('hidden');
    dbgBtn.textContent = '🐞 Debug'; dbgBtn.classList.remove('danger');
    runBtn.disabled = false;
    ed.current(0);
    if (cm) cm.setOption('readOnly', false);
    if (msg) toast(msg);
  }
  async function startDebug() {
    if (dbgOn) { stopDebug(); return; }
    if (running) machineRunner.stop();
    out.innerHTML = ''; filesBox.innerHTML = ''; ed.mark(0);
    const { units, note } = machineUnits();
    if (note) out.appendChild(document.createTextNode(note));
    dbgOn = true; last = null; prevRegs = null; prevV = null;
    dbgBtn.textContent = '✕ End debugging'; dbgBtn.classList.add('danger');
    runBtn.disabled = true;
    D('dbg').classList.remove('hidden');
    D('d-where').textContent = 'Assembling…'; D('d-insn').textContent = '';
    setBusy(true); D('d-pause').disabled = true;
    if (cm) cm.setOption('readOnly', true);
    dbgRunner.onMsg = onDbg;
    await dbgRunner.post({ type: 'dbg-start', units, argv: ['program', ...args()] });
  }
  dbgBtn.onclick = startDebug;
  function cmd(c) {
    if (!dbgOn || dbgBusy || (last && last.done)) return;
    setBusy(c !== 'step');
    if (c === 'step') dbgBusy = true;
    dbgRunner.post({ type: 'dbg-cmd', cmd: c, bps: breakpoints() });
  }
  D('d-step').onclick = () => cmd('step');
  D('d-over').onclick = () => cmd('over');
  D('d-out').onclick = () => cmd('out');
  D('d-cont').onclick = () => cmd('cont');
  D('d-pause').onclick = () => dbgRunner.post({ type: 'dbg-cmd', cmd: 'pause' });
  D('d-stop').onclick = () => stopDebug();
  D('d-vmode').onchange = () => { if (last) drawVfp(last); };
  D('d-addr').onchange = () => {
    const t = D('d-addr').value.trim();
    if (!t || t.toLowerCase() === 'sp') { D('d-addr').value = ''; dbgRunner.post({ type: 'dbg-cmd', cmd: 'mem', follow: true }); return; }
    const a = parseAddr(t);
    if (a === null) { toast('Type an address like 0x00020000, a register like sp or r4, or a label of your program.'); return; }
    dbgRunner.post({ type: 'dbg-cmd', cmd: 'mem', addr: a });
  };
  function parseAddr(t) {
    t = String(t || '').trim();
    if (!t || !last) return null;
    const ri = REG_NAMES.indexOf(t.toLowerCase());
    if (ri >= 0) return last.regs[ri] >>> 0;
    if (t.toLowerCase() === 'fp') return last.regs[11] >>> 0;
    const m = /^([A-Za-z_.$][\w.$]*|0x[0-9a-f]+|\d+)\s*(?:([+-])\s*(0x[0-9a-f]+|\d+))?$/i.exec(t);
    if (!m) return null;
    let base;
    if (/^(0x|\d)/i.test(m[1])) base = Number(m[1]);
    else if (m[1] in syms) base = syms[m[1]];
    else { const r2 = REG_NAMES.indexOf(m[1].toLowerCase()); if (r2 < 0) return null; base = last.regs[r2] >>> 0; }
    const off = m[3] ? Number(m[3]) * (m[2] === '-' ? -1 : 1) : 0;
    return (base + off) >>> 0;
  }
  window.addEventListener('keydown', keyh);
  function keyh(e) {
    if (!dbgOn || !document.body.contains(view) || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (e.key === 'F10') { e.preventDefault(); cmd(e.shiftKey ? 'over' : 'step'); }
    else if (e.key === 'F11') { e.preventDefault(); cmd('out'); }
    else if (e.key === 'F5') { e.preventDefault(); cmd('cont'); }
  }
  function onDbg(m) {
    if (!dbgOn) return;
    if (m.type === 'dbg-out') { printOut(m.text, m.err); return; }
    if (m.type === 'dbg-progress') { D('d-steps').textContent = `running… ${m.steps.toLocaleString()} instructions so far`; return; }
    if (m.type === 'dbg-files') { showFiles(filesBox, m.files || []); return; }
    if (m.type !== 'dbg-state') return;
    if (m.error) {
      dbgBusy = false;
      const tail = document.createElement('span'); tail.className = 'e';
      tail.textContent = m.error.stage === 'internal' ? 'The debugger stopped: ' + m.error.errors[0].msg : buildError(m.error);
      out.appendChild(tail);
      stopDebug();
      return;
    }
    if (m.started) { syms = m.syms || {}; layout = m.layout; }
    last = m;
    setBusy(false);
    draw(m);
    if (m.done) {
      setBusy(false);
      const tail = document.createElement('span');
      if (m.fault) { tail.className = 'e'; tail.textContent = faultText(m.fault); if (m.fault.unitName === 'your code' && m.fault.line) ed.mark(m.fault.line); }
      else tail.textContent = `\n[finished with exit code ${m.exitCode} after ${m.steps.toLocaleString()} instructions]`;
      out.appendChild(tail); out.scrollTop = out.scrollHeight;
      dbgRunner.post({ type: 'dbg-files' });
    }
  }
  function draw(m) {
    const w = m.where;
    if (w.mine && w.line) ed.current(w.line); else ed.current(0);
    D('d-where').innerHTML = m.done ? (m.fault ? '💥 The program crashed' : '🏁 The program has finished') + ' · '
      : m.stopped === 'breakpoint' ? '🔴 Breakpoint · ' : m.stopped === 'paused' ? '⏸ Paused · ' : '';
    D('d-where').innerHTML += w.mine ? `line <b>${w.line}</b> of your code${w.func ? ` (in <code>${esc(w.func)}</code>)` : ''}: ` : w.func ? `in <code>${esc(w.func)}</code> (${esc(w.unitName || 'library')}): ` : '';
    D('d-insn').textContent = (m.pc >>> 0 ? hex8(m.pc) + '  ' : '') + (m.insn || '');
    // registers
    let rh = '';
    for (let i = 0; i < 16; i++) {
      const v = m.regs[i], chg = prevRegs && prevRegs[i] !== v && i !== 15;
      rh += `<div class="reg ${chg ? 'chg' : ''}"><span class="rn">${REG_NAMES[i]}</span><span class="rv">${hex8(v)}</span><span class="rd">${i >= 13 ? '' : v | 0}</span></div>`;
    }
    D('d-regs').innerHTML = rh;
    const F = m.flags;
    D('d-flags').innerHTML = ['N', 'Z', 'C', 'V'].map((n, i) => `<span class="flag ${F[i] ? 'on' : ''}" title="${['Negative', 'Zero', 'Carry', 'oVerflow'][i]}">${n} ${F[i] ? 1 : 0}</span>`).join('') + `<span class="muted" style="margin-left:6px">VFP: ${['N', 'Z', 'C', 'V'].map((n, i) => n + (F[4 + i] ? 1 : 0)).join(' ')}</span>`;
    drawVfp(m);
    prevRegs = m.regs.slice();
    // memory
    if (m.mem) {
      const a = m.mem.addr, b = m.mem.bytes;
      let mh = '';
      const sp = m.regs[13] >>> 0;
      for (let r = 0; r < b.length; r += 16) {
        let hx = '', asc = '';
        for (let k = 0; k < 16; k++) {
          const v = b[r + k], addr = (a + r + k) >>> 0;
          hx += (k && k % 4 === 0 ? ' ' : '') + `<span class="${addr === sp ? 'at-sp' : ''}">${v < 0 ? '··' : v.toString(16).padStart(2, '0')}</span> `;
          asc += v >= 32 && v < 127 ? esc(String.fromCharCode(v)) : v < 0 ? ' ' : '.';
        }
        mh += `<div><span class="ma">${hex8(a + r).slice(2)}</span> ${hx}<span class="asc">${asc}</span></div>`;
      }
      D('d-mem').innerHTML = mh + `<div class="muted" style="margin-top:4px">${m.memFollow ? 'Showing the stack around sp. ' : ''}${sp >= a && sp < a + b.length ? 'The byte in blue is where sp points. ' : ''}Words are stored little-endian: the lowest byte first.</div>`;
    }
    D('d-stack').innerHTML = (m.stack.length ? m.stack.map(f => `<div><code>${esc(f.func)}</code> <span class="muted">returns to ${hex8(f.ret)}</span></div>`).join('') : '') + '<div><code>main</code></div>';
    D('d-steps').textContent = `${m.steps.toLocaleString()} instructions run${m.ran ? ` (${m.ran.toLocaleString()} just now${m.ms > 50 ? ', ' + fmtTime(m.ms / 1000) : ''})` : ''}`;
  }
  function drawVfp(m) {
    const mode = D('d-vmode').value, V = m.vi;
    let vh = '';
    if (mode === 'd') for (let i = 0; i < 16; i++) { const val = asDouble(V[2 * i], V[2 * i + 1]); const chg = prevV && (prevV[2 * i] !== V[2 * i] || prevV[2 * i + 1] !== V[2 * i + 1]); vh += `<div class="reg ${chg ? 'chg' : ''}"><span class="rn">d${i}</span><span class="rd">${fnum(val)}</span></div>`; }
    else for (let i = 0; i < 32; i++) { const chg = prevV && prevV[i] !== V[i]; vh += `<div class="reg ${chg ? 'chg' : ''}"><span class="rn">s${i}</span><span class="rd">${mode === 'x' ? hex8(V[i]) : fnum(asFloat(V[i]))}</span></div>`; }
    D('d-vfp').innerHTML = vh;
    prevV = V.slice();
  }
  BS.onLeave = () => { if (running) machineRunner.stop(); if (dbgOn) stopDebug(); window.removeEventListener('keydown', keyh); };
};
function showFiles(box, files) {
  box.innerHTML = '';
  for (const [path, data] of files) {
    if (/\.state$/.test(path)) continue;
    const name = path.replace(/^\//, '');
    const isPdf = /\.pdf$/i.test(name);
    const row = h(`<div class="f"><span class="ic">${isPdf ? '📕' : '📄'}</span><b class="grow">${esc(name)}</b><span class="muted">${(data.length / 1024).toFixed(1)} KB</span>${isPdf ? '<button class="btn small blue" data-a="view">View</button>' : '<button class="btn small" data-a="text">Show</button>'}<button class="btn small" data-a="save">Download</button></div>`);
    const v = $('[data-a=view]', row); if (v) v.onclick = () => BS.openPdf(data, name);
    const t = $('[data-a=text]', row); if (t) t.onclick = () => modal(`<h3>${esc(name)}</h3><pre class="console" style="max-height:60vh">${esc(new TextDecoder().decode(data.slice(0, 200000)))}</pre>`);
    $('[data-a=save]', row).onclick = () => BS.saveFile(name.split('/').pop().replace(/\.(state)$/, '.txt'), data);
    box.appendChild(row);
  }
}
BS.showFiles = showFiles;

// ---------------- Writer ----------------
const writerRunner = new BS.Runner('writer');
let job = null;   // the running (or last) writing job, kept while you switch tabs
function settingsText(w, native) {
  const one = (s) => String(s == null ? '' : s).replace(/[\r\n]+/g, ' ').trim();
  const lines = [
    '# BitScribe settings: one "key = value" per line. Lines starting with # are comments.',
    'topic = ' + one(w.topic), 'title = ' + one(w.title), 'audience = ' + one(w.audience), 'author = ' + one(w.author || 'BitScribe'),
    'model = models/tiny.bnet', 'tokenizer = models/tiny.tok', 'out = book', 'font = ' + (w.font === 'sans' ? 'sans' : 'serif'),
    'user_agent = BitScribe/1.0 (student textbook project' + (native ? '; add your email here' : '') + ')',
    'wiki = ' + (native ? 'en.wikipedia.org' : 'offline.bitscribe'),
    'pages = ' + w.pages, 'volumes = ' + w.volumes, 'chapters = ' + w.chapters, 'sections = ' + w.sections, 'tokens_per_hit = ' + w.tokens_per_hit,
    'web = ' + (w.web ? 1 : 0), 'web_sources = ' + w.web_sources, 'diagrams = ' + (w.diagrams ? 1 : 0), 'diagram_every = ' + w.diagram_every,
    'exercises = ' + (w.exercises ? 1 : 0), 'key_ideas = ' + (w.key_ideas ? 1 : 0), 'toc = ' + (w.toc ? 1 : 0), 'index = ' + (w.index ? 1 : 0), 'resume = 1',
    'temperature = ' + w.temperature, 'top_p = ' + w.top_p, 'top_k = ' + w.top_k, 'repeat_penalty = ' + w.repeat_penalty, 'seed = ' + w.seed,
    'font_size = ' + w.font_size, 'line_spacing = ' + w.line_spacing, 'margin_mm = ' + w.margin_mm,
  ];
  return lines.join('\n') + '\n';
}
BS.settingsText = settingsText;
function userPages(text) {
  // "My sources": blocks separated by a line with --- ; the first line of a block is its title
  return String(text || '').split(/^\s*---\s*$/m).map(b => b.trim()).filter(Boolean).map(b => {
    const nl = b.indexOf('\n');
    return { title: (nl < 0 ? b : b.slice(0, nl)).replace(/^#+\s*/, '').trim().slice(0, 90), text: nl < 0 ? '' : b.slice(nl + 1).trim() };
  }).filter(p => p.title && p.text.length > 40);
}
function estimate(w) {
  const tokens = w.pages * w.volumes * 450 * 1.4;
  const speed = S().writerSpeed || (BS.slowMode ? 1.5 : 60);   // forward passes per second in this browser (measured after a run)
  return tokens * 2.6 / speed;               // prompts are re-read on every hit, so ~2.6 forward passes per new token
}
BS.views.writer = function (view) {
  const st = S(), w = st.writer;
  const coding = BS.LESSONS.filter(BS.isProject);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  view.innerHTML = `
    <div class="hero"><h1>The Writer</h1><div class="sub">One prompt in, a finished textbook out: your BitNet program — written in ARM assembly — researches the topic, plans volumes and chapters, writes every section in many short model “hits”, draws diagrams, and lays out PDFs with contents and an index.</div></div>
    <div class="card" id="prog-status" style="margin-bottom:14px">${missing.length === 0 ? `<b>✅ Your program: all ${BS.TOTAL_PARTS()} parts written by you.</b> The Writer runs exactly your assembly code on the ARM emulator.` : `<b>Your program: ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts written by you.</b> <span class="sub">Until you finish the course, the Writer can run as a <b>demo</b> in which the course's own code fills in the ${missing.length} lesson(s) you have not done yet.</span>`}</div>
    <div class="grid2">
      <div class="card">
        <h3>Your book</h3>
        <label class="field"><span>Topic — the one prompt</span><input type="text" class="big-input" data-k="topic" maxlength="90" placeholder="for example: Volcanoes"></label>
        <label class="field"><span>Title (empty = the topic)</span><input type="text" data-k="title" maxlength="90"></label>
        <div class="grid2"><label class="field"><span>Written for</span><input type="text" data-k="audience" maxlength="90"></label><label class="field"><span>Author line</span><input type="text" data-k="author" maxlength="90" placeholder="BitScribe"></label></div>
        <label class="field"><span>Pages per volume: <b id="v-pages"></b></span><div class="range-row"><input type="range" min="1" max="600" data-k="pages" data-num="1"><input type="number" min="1" max="600" data-k="pages" data-num="1"></div></label>
        <label class="field"><span>Volumes: <b id="v-vols"></b></span><div class="range-row"><input type="range" min="1" max="10" data-k="volumes" data-num="1"><input type="number" min="1" max="10" data-k="volumes" data-num="1"></div></label>
        <p class="muted" id="est"></p>
      </div>
      <div class="card">
        <h3>What goes in</h3>
        <label class="switch"><input type="checkbox" data-k="web"> Research the topic in the encyclopedia first</label>
        <label class="field"><span>Articles to read</span><input type="number" min="0" max="8" data-k="web_sources" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="diagrams"> Diagrams and pictures</label>
        <label class="field"><span>Automatic diagram every … sections</span><input type="number" min="1" max="20" data-k="diagram_every" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="exercises"> Exercises after each chapter</label>
        <label class="switch"><input type="checkbox" data-k="key_ideas"> “Key idea” boxes</label>
        <label class="switch"><input type="checkbox" data-k="toc"> Contents pages</label>
        <label class="switch"><input type="checkbox" data-k="index"> Index</label>
      </div>
    </div>
    <details class="card" style="margin-top:14px"><summary style="cursor:pointer;font-weight:800">More settings: model, layout and your own sources</summary>
      <div class="grid3" style="margin-top:10px">
        <label class="field"><span>Chapters per volume (0 = auto)</span><input type="number" min="0" max="80" data-k="chapters" data-num="1"></label>
        <label class="field"><span>Sections per chapter (0 = auto)</span><input type="number" min="0" max="16" data-k="sections" data-num="1"></label>
        <label class="field"><span>Most tokens per hit</span><input type="number" min="32" max="4000" data-k="tokens_per_hit" data-num="1"></label>
        <label class="field"><span>Temperature</span><input type="number" min="0" max="2" step="0.05" data-k="temperature" data-num="1"></label>
        <label class="field"><span>Top-p</span><input type="number" min="0.05" max="1" step="0.05" data-k="top_p" data-num="1"></label>
        <label class="field"><span>Top-k (0 = off)</span><input type="number" min="0" max="1000" data-k="top_k" data-num="1"></label>
        <label class="field"><span>Repeat penalty</span><input type="number" min="1" max="2" step="0.05" data-k="repeat_penalty" data-num="1"></label>
        <label class="field"><span>Random seed</span><input type="number" data-k="seed" data-num="1"></label>
        <label class="field"><span>Book font</span><select data-k="font"><option value="serif">Times (serif)</option><option value="sans">Helvetica (sans-serif)</option></select></label>
        <label class="field"><span>Font size (pt)</span><input type="number" min="7" max="16" step="0.5" data-k="font_size" data-num="1"></label>
        <label class="field"><span>Line spacing</span><input type="number" min="1" max="2.5" step="0.05" data-k="line_spacing" data-num="1"></label>
        <label class="field"><span>Margins (mm)</span><input type="number" min="8" max="40" data-k="margin_mm" data-num="1"></label>
      </div>
      <label class="field"><span>My own sources (optional). Paste notes or articles you are allowed to use: first line = title, then the text. Separate sources with a line containing only ---</span><textarea data-k="sources" rows="6" placeholder="Photosynthesis notes&#10;Plants make glucose from carbon dioxide and water using light energy..."></textarea></label>
      <p class="muted">The browser cannot reach the internet, so the emulator's “web” is a built-in encyclopedia of ${BS.ASSETS.articles.length} articles plus your own sources. On a Raspberry Pi your exported program reads Wikipedia.</p>
    </details>
    <div class="row" style="margin:16px 0"><button class="btn primary" id="go" style="font-size:16px;padding:14px 22px">✍️ Write my textbook</button><button class="btn" id="stop" hidden>■ Stop</button><button class="btn" id="resume" hidden>Continue writing</button><span class="grow"></span><button class="btn small" id="dl-settings">Download settings.txt</button></div>
    <div id="job"></div>`;
  // bind the form
  $$('[data-k]', view).forEach(inp => {
    const k = inp.dataset.k;
    if (inp.type === 'checkbox') inp.checked = !!w[k]; else inp.value = w[k];
    const ev = inp.type === 'range' || inp.tagName === 'TEXTAREA' || inp.type === 'text' ? 'input' : 'change';
    inp.addEventListener(ev, () => {
      let v = inp.type === 'checkbox' ? (inp.checked ? 1 : 0) : inp.value;
      if (inp.dataset.num) { v = Number(v); if (!isFinite(v)) return; const mn = inp.min !== '' ? Number(inp.min) : -Infinity, mx = inp.max !== '' ? Number(inp.max) : Infinity; v = Math.min(mx, Math.max(mn, v)); }
      w[k] = v;
      $$(`[data-k="${k}"]`, view).forEach(o => { if (o !== inp && o.type !== 'checkbox') o.value = v; });
      BS.save();
      refresh();
    });
  });
  function refresh() {
    $('#v-pages', view).textContent = w.pages;
    $('#v-vols', view).textContent = w.volumes;
    const words = Math.round(w.pages * w.volumes * 450);
    $('#est', view).textContent = `About ${words.toLocaleString()} words in ${w.volumes * w.pages} pages. Estimated writing time on this device's ARM emulator with the small model: ${fmtTime(estimate(w))}${w.pages * w.volumes > 100 ? ' — big books are best written on a Raspberry Pi with the exported program' : ''}.`;
  }
  refresh();
  $('#dl-settings', view).onclick = () => BS.saveFile('settings.txt', settingsText(w, true));
  const go = $('#go', view), stop = $('#stop', view), resume = $('#resume', view), jobBox = $('#job', view);
  go.onclick = () => start(false);
  resume.onclick = () => start(true);
  stop.onclick = () => { if (job && job.running) { writerRunner.stop(); } };
  async function start(cont) {
    if (job && job.running) return;
    if (!w.topic || !String(w.topic).trim()) { toast('Type a topic first.'); return; }
    const miss = BS.LESSONS.filter(BS.isProject).filter(L => !(S().done[L.id] && S().code[L.id]));
    if (miss.length) {
      const ok = await modal(`<h3>Run a demo?</h3><p>You have written ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts. For the other ${miss.length} lesson(s) the course's own code will be used, hidden from you. Your written parts are used as they are.</p><p class="muted">When you finish the course, the Writer runs 100% your code.</p>`, [{ label: 'Cancel', value: false }, { label: 'Run the demo', value: true, cls: 'primary' }]);
      if (!ok) return;
    }
    const prev = cont && job ? job.files : new Map();
    job = { running: true, t0: Date.now(), tWrite: 0, log: [], plan: [], status: 'Starting…', frac: 0, tokens: 0, files: new Map(), results: [], cont, prevFiles: prev, done: null, error: null };
    if (!cont) await Store.del('lastbook');
    built = null;
    renderJob();
    go.disabled = true; stop.hidden = false; resume.hidden = true;
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(true); } catch (e) {}
    const { units } = BS.programUnits({ fill: true });
    const files = [['/settings.txt', settingsText(w, false)]];
    if (cont) for (const [p, d] of prev) if (/\.(md|state)$/.test(p)) files.push([p, d]);
    const sources = userPages(w.sources);
    let buf = '';
    const res = await writerRunner.run({ units, argv: ['bitscribe'], files, userPages: sources, snapshot: '_vol\\d+\\.(md|state|pdf)$', returnFiles: '\\.(pdf|md)$', maxOut: 200e6, checkABI: false, maxSteps: 1e15 }, {
      onCompiled: (m) => { if (!m.ok) { const e = (m.errors || [])[0] || {}; job.error = { msg: (m.stage === 'link' ? 'Link error: ' : 'Assembly error: ') + (e.msg || ''), file: e.unitName, line: e.line }; } else job.status = 'Researching and planning…'; renderJob(); },
      onOut: (t) => {
        buf += t;
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) { handleLine(buf.slice(0, nl)); buf = buf.slice(nl + 1); }
        renderJobSoon();
      },
      onFiles: (fs) => { for (const [p, d] of fs) job.files.set(p, d); renderJobSoon(); },
    });
    if (buf) handleLine(buf);
    job.running = false;
    for (const [p, d] of (res.files || [])) job.files.set(p, d);
    if (res.stopped) job.status = 'Stopped. Press “Continue writing” to carry on from the last finished chapter.';
    else if (res.fault) job.error = { msg: res.fault.msg + (res.fault.func ? ' (in ' + res.fault.func + (res.fault.unitName && /^your code/.test(res.fault.unitName) ? ', ' + res.fault.unitName.replace(/^your code: /, 'lesson “') + '”' + (res.fault.line ? ' line ' + res.fault.line : '') : '') + ')' : '') };
    else if (res.exitCode && !job.error) job.error = { msg: (res.err || 'the program stopped with exit code ' + res.exitCode).trim() };
    if (!res.stopped && !job.error) {
      job.status = 'Finished!';
      const secs = (Date.now() - (job.tWrite || job.t0)) / 1000;
      if (job.tokens > 50 && secs > 5) { S().writerSpeed = Math.round(job.tokens * 2.6 / secs); BS.save({ local: true }); }
      BS.sound('complete'); BS.confetti();
    }
    try { await Store.put('lastbook', { files: [...job.files.entries()], results: job.results, topic: w.topic, t: Date.now() }); } catch (e) {}
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(false); } catch (e) {}
    go.disabled = false; stop.hidden = true; resume.hidden = !(res.stopped || job.error) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  }
  function handleLine(line) {
    if (!line.startsWith('@@')) { if (line.trim()) job.log.push(line); return; }
    const sp = line.indexOf(' ');
    const kind = line.slice(2, sp < 0 ? undefined : sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    if (kind === 'status') {
      job.status = rest;
      if (!job.tWrite) job.tWrite = Date.now();
      const m = /volume (\d+)\/(\d+), chapter (\d+)\/(\d+), section (\d+)\/(\d+)/.exec(rest);
      if (m) { const [V, NV, C, NC, K, NK] = m.slice(1).map(Number); job.frac = ((V - 1) + ((C - 1) + (K - 1) / NK) / NC) / NV; }
    } else if (kind === 'progress') { const m = /tokens (\d+)/.exec(rest); if (m) job.tokens += +m[1]; }
    else if (kind === 'plan') job.plan.push(rest);
    else if (kind === 'log') job.log.push(rest);
    else if (kind === 'file') { const m = /^(\S+)\s+(\d+)/.exec(rest); if (m) job.results.push({ path: '/' + m[1].replace(/^\//, ''), pages: +m[2] }); job.log.push('finished ' + rest.replace(/^\//, '') + ' pages'); }
    else if (kind === 'done') job.log.push(rest);
    if (job.log.length > 300) job.log.splice(0, job.log.length - 300);
  }
  let renderTimer = null, built = null, shownResults = -1;
  function renderJobSoon() { if (!renderTimer) renderTimer = setTimeout(() => { renderTimer = null; renderJob(); }, 400); }
  function buildJob() {
    jobBox.innerHTML = `<div class="card">
      <div class="jerr"></div>
      <div class="row"><b class="grow jstatus"></b><span class="muted jtime"></span></div>
      <div class="bar" style="margin:10px 0"><i class="jbar"></i></div>
      <div class="jfiles"></div>
      <details class="jprev-d"><summary class="muted" style="cursor:pointer">Latest text from the model</summary><div class="preview-text jprev"></div></details>
      <details class="jplan-d"><summary class="muted jplan-s" style="cursor:pointer">The plan</summary><div class="log jplan"></div></details>
      <details><summary class="muted" style="cursor:pointer">Log</summary><div class="log jlog"></div></details>
    </div>`;
    built = { box: jobBox.firstElementChild };
    for (const k of ['jerr', 'jstatus', 'jtime', 'jbar', 'jfiles', 'jprev', 'jprev-d', 'jplan', 'jplan-d', 'jplan-s', 'jlog']) built[k] = $('.' + k, jobBox);
    if (job.running) built['jprev-d'].open = true;
    shownResults = -1;
  }
  function renderJob() {
    if (!job || !document.body.contains(jobBox)) return;
    if (!built || !jobBox.contains(built.box)) buildJob();
    const B = built;
    const elapsed = (Date.now() - job.t0) / 1000;
    let eta = '';
    if (job.running && job.frac > 0.02 && job.tWrite) { const we = (Date.now() - job.tWrite) / 1000; eta = ' · about ' + fmtTime(we * (1 - job.frac) / job.frac) + ' left'; }
    B.jerr.innerHTML = job.error ? `<div class="res err"><h4>The program stopped with an error</h4>${esc(job.error.msg)}${job.error.file ? `<div class="muted">${esc(job.error.file)}${job.error.line ? ', line ' + job.error.line : ''}</div>` : ''}</div>` : '';
    B.jstatus.textContent = job.status;
    B.jtime.textContent = (job.done && !job.running && !job.tokens ? '' : fmtTime(elapsed) + eta + ' · ' + job.tokens.toLocaleString() + ' tokens');
    B.jbar.style.width = (job.running ? Math.max(2, 100 * job.frac) : job.error ? 100 * job.frac : 100).toFixed(1) + '%';
    const pdfs = job.results.filter(r => job.files.has(r.path));
    if (pdfs.length !== shownResults) {
      shownResults = pdfs.length;
      B.jfiles.innerHTML = pdfs.length ? `<h3>Your book</h3><div class="filelist">${pdfs.map((r, i) => `<div class="f"><span class="ic">📕</span><b class="grow">${esc(r.path.slice(1))}</b><span class="muted">${r.pages} pages</span><button class="btn small blue" data-v="${i}">View</button><button class="btn small" data-d="${i}">Download PDF</button><button class="btn small" data-m="${i}">Text (.md)</button></div>`).join('')}</div>` : '';
      $$('[data-v]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.v]; b.onclick = () => BS.openPdf(job.files.get(r.path), r.path.slice(1)); });
      $$('[data-d]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.d]; b.onclick = () => BS.saveFile(r.path.slice(1), job.files.get(r.path)); });
      $$('[data-m]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.m]; const mdp = r.path.replace(/\.pdf$/, '.md'); b.onclick = () => { const d = job.files.get(mdp); if (d) BS.saveFile(mdp.slice(1), d); else toast('The text file is not available.'); }; });
    }
    const md = [...job.files.entries()].filter(([p]) => /\.md$/.test(p)).sort((a, b) => a[0] < b[0] ? -1 : 1).pop();
    const preview = md ? new TextDecoder().decode(md[1].slice(Math.max(0, md[1].length - 2500))) : '';
    B['jprev-d'].hidden = !preview;
    if (B.jprev.textContent !== preview) { B.jprev.textContent = preview; B.jprev.scrollTop = 1e9; }
    B['jplan-d'].hidden = !job.plan.length;
    B['jplan-s'].textContent = 'The plan (' + job.plan.length + ' chapters)';
    const planText = job.plan.join('\n');
    if (B.jplan.textContent !== planText) B.jplan.textContent = planText;
    const logText = job.log.slice(-150).join('\n');
    if (B.jlog.textContent !== logText) { B.jlog.textContent = logText; B.jlog.scrollTop = 1e9; }
  }
  if (job) {
    if (job.running) { go.disabled = true; stop.hidden = false; }
    else resume.hidden = !(job.error || /Stopped/.test(job.status)) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  } else {
    Store.get('lastbook').then(last => {
      if (!last || job || !document.body.contains(jobBox)) return;
      job = { running: false, t0: last.t, tWrite: last.t, log: [], plan: [], status: 'Your last book (' + (last.topic || '') + ')', frac: 1, tokens: 0, files: new Map(last.files || []), results: last.results || [], done: true, error: null };
      resume.hidden = !(job.results.length === 0 && [...job.files.keys()].some(p => /\.state$/.test(p)));
      renderJob();
    });
  }
  const tick = setInterval(() => { if (!document.body.contains(jobBox)) { clearInterval(tick); return; } if (job && job.running) renderJob(); }, 1000);
};

// ---------------- My code: the project ----------------
BS.views.project = function (view) {
  const st = S();
  const coding = BS.LESSONS.filter(BS.isProject);
  const mine = coding.filter(L => st.done[L.id] && st.code[L.id]);
  view.innerHTML = `
    <h1>My code</h1>
    <div class="card">
      <div class="row"><div class="grow"><b>${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts</b> of BitScribe are written by you in ARM assembly (${mine.length} of ${coding.length} coding lessons).</div></div>
      <div class="bar" style="margin:10px 0"><i style="width:${(100 * BS.partsWritten() / BS.TOTAL_PARTS()).toFixed(1)}%"></i></div>
      <div class="row">
        <button class="btn" id="chk">Check that it assembles and links</button>
        <button class="btn" id="alltests">Run every test with my code</button>
        <button class="btn blue" id="export">Export project (.zip)</button>
      </div>
      <div id="pres" style="margin-top:10px"></div>
    </div>
    <div class="card" style="margin-top:14px" id="units"></div>`;
  const unitsBox = $('#units', view);
  for (const u of BS.UNITS) {
    const ls = u.lessons.filter(BS.isCoding);
    if (!ls.length) continue;
    const row = h(`<div class="unit-row"><div class="row"><span class="pill" style="background:${esc(u.color)};color:#fff">${esc(u.title)}</span><span class="muted">${ls.filter(L => st.done[L.id] && st.code[L.id]).length}/${ls.length}</span></div></div>`);
    for (const L of ls) {
      const ok = st.done[L.id] && st.code[L.id];
      const r = h(`<div class="lesson-row"><span>${ok ? '✅' : '⬜'}</span><span class="lt" style="font-weight:800">${esc(L.title)}</span>${L.items.map(i => `<span class="pill ${ok ? 'green' : ''}">${esc(i)}</span>`).join('')}</div>`);
      r.onclick = () => {
        if (!ok) { location.hash = 'lesson-' + L.id; return; }
        modal(`<h3>${esc(L.title)}</h3><div class="code-view">${window.hlAsm(st.code[L.id].src)}</div><p class="muted">To change this code, open the lesson again: it is tested before it is saved.</p>`, [{ label: 'Close', value: 0 }, { label: 'Open the lesson', value: 1, cls: 'primary' }]).then(v => { if (v) location.hash = 'lesson-' + L.id; });
      };
      row.appendChild(r);
    }
    unitsBox.appendChild(row);
  }
  const pres = $('#pres', view);
  $('#chk', view).onclick = async () => {
    const { units, missing } = BS.programUnits({});
    if (missing.length) { pres.innerHTML = `<div class="res info"><h4>${missing.length} lesson(s) still to do</h4>The program needs every part before it can be built on its own: ${missing.slice(0, 6).map(L => esc(L.title)).join(', ')}${missing.length > 6 ? '…' : ''}.</div>`; return; }
    pres.innerHTML = '<div class="res info">Assembling and linking your whole program…</div>';
    const res = await BS.testRunner.run({ units, compileOnly: true });
    if (res.compile && res.compile.ok) { pres.innerHTML = `<div class="res ok"><h4>✅ Your whole program assembles and links</h4>${units.length} lessons of your own code, in ${Math.round(res.compile.ms)} ms.</div>`; BS.sound('pass'); }
    else if (res.compile) pres.innerHTML = BS.errorsHtml({ stage: res.compile.stage, errors: res.compile.errors });
  };
  $('#alltests', view).onclick = async () => {
    const todo = BS.LESSONS.filter(BS.isCoding).filter(L => st.done[L.id] && st.code[L.id]);
    if (!todo.length) { pres.innerHTML = '<div class="res info">Finish a coding lesson first.</div>'; return; }
    let stopped = false, passed = 0;
    const failed = [];
    pres.innerHTML = '<div class="res info"><div class="row"><b id="atp" class="grow">Starting…</b><button class="btn small" id="atstop">Stop</button></div><div class="bar" style="margin-top:8px"><i id="atbar"></i></div></div><div id="atfail"></div>';
    $('#atstop', pres).onclick = () => { stopped = true; BS.testRunner.stop(); };
    for (let i = 0; i < todo.length && !stopped; i++) {
      const L = todo[i];
      $('#atp', pres).textContent = `Testing ${i + 1} of ${todo.length}: ${L.title}`;
      $('#atbar', pres).style.width = (100 * i / todo.length) + '%';
      const res = await BS.testRunner.run(BS.lessonJob(L, st.code[L.id].src, true));
      if (res.stopped) break;
      const r = BS.interpret(L, res);
      if (r.pass) passed++;
      else {
        failed.push(L);
        const ce = r.compileError && r.compileError.errors[0];
        $('#atfail', pres).insertAdjacentHTML('beforeend', `<div class="res err"><b>${esc(L.title)}</b>: ${esc(ce ? ce.msg + ' (' + ce.unitName + (ce.line ? ', line ' + ce.line : '') + ')' : r.fault ? r.fault.msg : r.equErr[0] || r.fails[0] || 'failed')}</div>`);
      }
    }
    $('#atbar', pres).style.width = '100%';
    $('#atp', pres).textContent = stopped ? `Stopped: ${passed} passed, ${failed.length} failed so far.` : `${passed} of ${todo.length} lessons pass with your own code for every earlier part.${failed.length ? ' A lesson can fail here when an earlier function of yours behaves a little differently from the course\'s.' : ''}`;
    if (!stopped && !failed.length) BS.sound('complete');
  };
  $('#export', view).onclick = () => exportZip(pres);
};

// ---------------- export the project as a .zip for a Raspberry Pi (or any ARM Linux computer) ----------------
async function exportZip(box) {
  const st = S(), A = BS.ASSETS;
  const coding = BS.LESSONS.filter(BS.isProject);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  const typeOnly = (L) => L.items.every(it => !BS.REF.items[it] || BS.REF.items[it].kind === 'type' || it === 'includes');
  // bitscribe.inc: the .equ constants you wrote in the type lessons
  let inc = `@ bitscribe.inc - the constants and struct layouts of BitScribe, written in the BitScribe ARM course.\n@ Every source file includes this file. Exported ${BS.today()}.\n\n`;
  const written = new Set();
  for (const L of coding) {
    if (!typeOnly(L)) continue;
    inc += `@ ===== ${L.unitObj.title}: ${L.title} =====\n`;
    if (st.done[L.id] && st.code[L.id]) {
      const src = st.code[L.id].src.replace(/\s+$/, '');
      inc += src + '\n\n';
      for (const m of src.matchAll(/^\s*\.(?:equ|set)\s+(\w+)/gm)) written.add(m[1]);
      for (const m of src.matchAll(/^\s*(\w+)\s*=/gm)) written.add(m[1]);
    } else inc += `@ MISSING - write the .equ lines in the lesson "${L.title}".\n\n`;
  }
  const extra = BS.REF.header.split('\n').filter(l => { const m = /\.equ\s+(\w+)\s*,/.exec(l); return m && !written.has(m[1]); });
  if (extra.length && !missing.length) inc += `@ ===== constants used by the course that no lesson asked for =====\n${extra.join('\n')}\n`;
  else if (extra.length) inc += `@ ===== constants from the course, until you write them in the lessons =====\n${extra.join('\n')}\n`;
  const files = [{ name: 'bitscribe/bitscribe.inc', data: inc }];
  let n = 0;
  const srcNames = [];
  for (const L of coding) {
    if (typeOnly(L)) continue;
    n++;
    const fname = String(n).padStart(3, '0') + '_' + L.id + '.s';
    srcNames.push(fname);
    let s = `@ BitScribe ARM - ${L.unitObj.title}: ${L.title}\n@ Parts: ${L.items.join(', ')}\n@ Written in the BitScribe ARM course. Exported ${BS.today()}.\n\t.syntax unified\n\t.arm\n\t.fpu vfpv3-d16\n\t.include "bitscribe.inc"\n\n`;
    if (st.done[L.id] && st.code[L.id]) s += st.code[L.id].src.replace(/\s+$/, '') + '\n';
    else s += `@ MISSING - write ${L.items.join(', ')} in the lesson "${L.title}". The program will not build until every part is written.\n\t.error "the lesson ${L.title} is not finished yet"\n`;
    s += '\n\t.section .note.GNU-stack,"",%progbits\n';
    files.push({ name: 'bitscribe/src/' + fname, data: s });
  }
  const model = BS.modelBytes();
  files.push(
    { name: 'bitscribe/Makefile', data: A.makefile },
    { name: 'bitscribe/README.md', data: A.readme + (missing.length ? `\n\n## Not finished yet\n\n${missing.length} lesson(s) are still missing (marked MISSING in the src folder). Finish them in the app, then export again.\n` : '') },
    { name: 'bitscribe/settings.txt', data: settingsText(st.writer, true) },
    { name: 'bitscribe/convert.py', data: A.convertPy, exec: true },
    { name: 'bitscribe/models/tiny.bnet', data: model.bnet },
    { name: 'bitscribe/models/tiny.tok', data: model.tok },
    { name: 'bitscribe/models/README.txt', data: A.modelCard },
    { name: 'bitscribe/fonts/readme.txt', data: A.afmReadme },
    { name: 'bitscribe/fonts/NOTE.txt', data: A.fontsNote },
  );
  for (const [nm, t] of Object.entries(BS.afmTexts())) files.push({ name: 'bitscribe/fonts/' + nm + '.afm', data: t });
  const blob = ZipWriter.make(files);
  if (box) box.innerHTML = `<div class="res ok"><h4>Project ready (${(blob.size / 1048576).toFixed(1)} MB)</h4>${missing.length ? `${missing.length} lesson(s) are still missing, so the exported program will not build yet.` : 'Unzip it on a Raspberry Pi (or another ARM Linux computer) and run <code>make</code>. The README also explains how to build it on a PC with an ARM cross-compiler and run it with qemu-arm.'}</div>`;
  await BS.saveFile('bitscribe-arm-project.zip', blob);
}
BS.exportZip = exportZip;
})();
