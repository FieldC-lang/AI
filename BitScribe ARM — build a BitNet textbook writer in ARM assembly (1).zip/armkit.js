// armkit: the ARMv7 assembler, linker, emulator and C library of BitScribe ARM

// ===== asm.js =====
// ===== ArmKit assembler: GNU-syntax ARMv7-A (ARM state) + VFPv3-D16 -> relocatable objects =====
(function (G) {
'use strict';
const K = G.ArmKit = G.ArmKit || {};

class AsmError extends Error { constructor(msg, line) { super(msg); this.line = line; } }
K.AsmError = AsmError;

const CONDS = { eq: 0, ne: 1, cs: 2, hs: 2, cc: 3, lo: 3, mi: 4, pl: 5, vs: 6, vc: 7, hi: 8, ls: 9, ge: 10, lt: 11, gt: 12, le: 13, al: 14 };
const COND_RE = 'eq|ne|cs|hs|cc|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le|al';
const REG = { sp: 13, lr: 14, pc: 15, fp: 11, ip: 12, sl: 10, sb: 9, a1: 0, a2: 1, a3: 2, a4: 3, v1: 4, v2: 5, v3: 6, v4: 7, v5: 8, v6: 9, v7: 10, v8: 11 };
for (let i = 0; i < 16; i++) REG['r' + i] = i;
const DP = { and: 0, eor: 1, sub: 2, rsb: 3, add: 4, adc: 5, sbc: 6, rsc: 7, tst: 8, teq: 9, cmp: 10, cmn: 11, orr: 12, mov: 13, bic: 14, mvn: 15 };
const SHIFT = { lsl: 0, asl: 0, lsr: 1, asr: 2, ror: 3 };

// ---------------- small helpers ----------------
const isIdStart = (c) => /[A-Za-z_.$]/.test(c);
function splitOperands(s) {
  const out = []; let depth = 0, cur = '', q = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) { cur += c; if (c === '\\') { cur += s[++i] || ''; continue; } if (c === q) q = null; continue; }
    if (c === '"' || c === "'") {
      if (c === "'" && /[A-Za-z0-9_]/.test(s[i - 1] || '') ) { cur += c; continue; }
      q = c; cur += c; continue;
    }
    if (c === '[' || c === '{' || c === '(') depth++;
    if (c === ']' || c === '}' || c === ')') depth--;
    if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() || out.length) out.push(cur.trim());
  return out;
}
function stripComment(line) {
  let q = null;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) { if (c === '\\') { i++; continue; } if (c === q) q = null; continue; }
    if (c === '"') { q = c; continue; }
    if (c === "'" && i + 2 < line.length && line[i + 2] === "'") { i += 2; continue; }
    if (c === "'" && line[i + 1] === '\\' && line[i + 3] === "'") { i += 3; continue; }
    if (c === '@') return line.slice(0, i);
    if (c === '/' && line[i + 1] === '/') return line.slice(0, i);
  }
  return line;
}
function parseString(tok, line) {
  // "..." with C escapes -> array of bytes (UTF-8 for non-ASCII)
  tok = tok.trim();
  if (tok[0] !== '"' || tok[tok.length - 1] !== '"' || tok.length < 2) throw new AsmError('expected a string in double quotes, like "Hello\\n"', line);
  const s = tok.slice(1, -1), out = [];
  const enc = new TextEncoder();
  for (let i = 0; i < s.length; i++) {
    let c = s[i];
    if (c !== '\\') { const b = enc.encode(c); for (const x of b) out.push(x); continue; }
    c = s[++i];
    const map = { n: 10, t: 9, r: 13, '0': 0, a: 7, b: 8, f: 12, v: 11, '\\': 92, '"': 34, "'": 39, e: 27 };
    if (c >= '0' && c <= '7') { let v = 0, k = 0; while (k < 3 && s[i] >= '0' && s[i] <= '7') { v = v * 8 + (s.charCodeAt(i) - 48); i++; k++; } i--; out.push(v & 255); continue; }
    if (c === 'x') { let v = 0, k = 0; i++; while (k < 2 && /[0-9a-fA-F]/.test(s[i] || '')) { v = v * 16 + parseInt(s[i], 16); i++; k++; } i--; out.push(v & 255); continue; }
    if (c in map) { out.push(map[c]); continue; }
    out.push(c.charCodeAt(0) & 255);
  }
  return out;
}
K.parseString = parseString;

// ---------------- expressions ----------------
// result: {v: number, sym: null | {name}|{sec, off}}  (sym = relocatable base)
function makeExprParser(ctx) {
  return function parse(text, line) {
    let i = 0; const s = text;
    const ws = () => { while (i < s.length && (s[i] === ' ' || s[i] === '\t')) i++; };
    function primary() {
      ws();
      const c = s[i];
      if (c === '(') { i++; const v = sum(); ws(); if (s[i] !== ')') throw new AsmError('missing ) in "' + text + '"', line); i++; return v; }
      if (c === '-') { i++; const v = primary(); if (v.sym) throw new AsmError('cannot negate a label in "' + text + '"', line); return { v: -v.v | 0, sym: null }; }
      if (c === '+') { i++; return primary(); }
      if (c === '~') { i++; const v = primary(); if (v.sym) throw new AsmError('cannot use ~ on a label', line); return { v: ~v.v, sym: null }; }
      if (c === "'") {
        let ch;
        if (s[i + 1] === '\\') { const m = { n: 10, t: 9, r: 13, '0': 0, '\\': 92, "'": 39, '"': 34 }[s[i + 2]]; ch = m !== undefined ? m : s.charCodeAt(i + 2); i += s[i + 3] === "'" ? 4 : 3; }
        else { ch = s.charCodeAt(i + 1); i += s[i + 2] === "'" ? 3 : 2; }
        return { v: ch, sym: null };
      }
      let m = /^0[xX][0-9a-fA-F]+|^0[bB][01]+|^\d+/.exec(s.slice(i));
      if (m) {
        const t = m[0]; i += t.length;
        // local label reference like 1b / 1f
        if (/^\d+$/.test(t) && (s[i] === 'b' || s[i] === 'f') && !/[A-Za-z0-9_]/.test(s[i + 1] || '')) {
          const dir = s[i]; i++;
          return ctx.localRef(t, dir, line);
        }
        let v = t.startsWith('0x') || t.startsWith('0X') ? parseInt(t.slice(2), 16) : t.startsWith('0b') || t.startsWith('0B') ? parseInt(t.slice(2), 2) : parseInt(t, 10);
        return { v: v | 0, sym: null, big: v };
      }
      m = /^[A-Za-z_.$][A-Za-z0-9_.$]*/.exec(s.slice(i));
      if (m) {
        i += m[0].length;
        if (m[0] === '.') return ctx.here();
        return ctx.symRef(m[0], line);
      }
      throw new AsmError('cannot understand "' + s.slice(i) + '" in "' + text + '"', line);
    }
    function term() {
      let a = primary();
      for (;;) {
        ws();
        const op = s[i] === '<' && s[i + 1] === '<' ? '<<' : s[i] === '>' && s[i + 1] === '>' ? '>>' : '*/%'.includes(s[i] || 'x') ? s[i] : null;
        if (!op) return a;
        i += op.length;
        const b = primary();
        if (a.sym || b.sym) throw new AsmError('only + and - can be used with labels', line);
        a = { v: op === '*' ? Math.imul(a.v, b.v) : op === '/' ? (b.v ? (a.v / b.v) | 0 : 0) : op === '%' ? (b.v ? a.v % b.v : 0) : op === '<<' ? a.v << b.v : a.v >> b.v, sym: null };
      }
    }
    function bits() {
      let a = term();
      for (;;) {
        ws();
        const op = s[i];
        if (op !== '&' && op !== '|' && op !== '^') return a;
        i++;
        const b = term();
        if (a.sym || b.sym) throw new AsmError('only + and - can be used with labels', line);
        a = { v: op === '&' ? a.v & b.v : op === '|' ? a.v | b.v : a.v ^ b.v, sym: null };
      }
    }
    function sum() {
      let a = bits();
      for (;;) {
        ws();
        const op = s[i];
        if (op !== '+' && op !== '-') return a;
        i++;
        const b = bits();
        if (op === '+') {
          if (a.sym && b.sym) throw new AsmError('cannot add two labels', line);
          a = { v: (a.v + b.v) | 0, sym: a.sym || b.sym };
        } else {
          if (b.sym) {
            if (a.sym && ctx.sameBase(a.sym, b.sym)) a = { v: (a.v - b.v) | 0, sym: null };
            else if (a.sym) a = { v: 0, sym: null, pending: true };
            else throw new AsmError('cannot subtract a label from a number', line);
          } else a = { v: (a.v - b.v) | 0, sym: a.sym };
        }
      }
    }
    const r = sum();
    ws();
    if (i < s.length) throw new AsmError('unexpected "' + s.slice(i) + '" in "' + text + '"', line);
    return r;
  };
}

// encodable ARM immediate: returns 12-bit operand2 or -1
function encImm(v) {
  v = v >>> 0;
  for (let rot = 0; rot < 16; rot++) {
    const x = rot ? ((v << (2 * rot)) | (v >>> (32 - 2 * rot))) >>> 0 : v;
    if (x <= 0xff) return (rot << 8) | x;
  }
  return -1;
}
K.encImm = encImm;
// VFP 8-bit float immediates
function vfpImm(value, dbl) {
  if (!isFinite(value) || value === 0) return -1;
  for (let imm = 0; imm < 256; imm++) if (vfpImmValue(imm) === value) return imm;
  return -1;
}
function vfpImmValue(imm) {
  const sign = imm >> 7, b = (imm >> 6) & 1, cde = (imm >> 4) & 3, efgh = imm & 15;
  const exp = (b ? -1 : 0) * 4 + 0; // placeholder, computed below
  const e = ((b ? 0 : 4) | cde) - 3; // exponent in [-3, 4]
  const mant = 1 + efgh / 16;
  const v = mant * Math.pow(2, e);
  return sign ? -v : v;
}
K.vfpImmValue = vfpImmValue;

function parseReg(t, line, what) {
  const k = String(t).trim().toLowerCase();
  if (k in REG) return REG[k];
  throw new AsmError('"' + t + '" is not a register' + (what ? ' (' + what + ')' : '') + '. Registers are r0-r12, sp, lr and pc.', line);
}
function parseVReg(t, line) {
  const k = String(t).trim().toLowerCase();
  let m = /^s(\d+)$/.exec(k);
  if (m && +m[1] < 32) return { kind: 's', n: +m[1] };
  m = /^d(\d+)$/.exec(k);
  if (m && +m[1] < 16) return { kind: 'd', n: +m[1] };
  if (m) throw new AsmError('"' + t + '": this processor (VFPv3-D16) has only d0-d15', line);
  throw new AsmError('"' + t + '" is not a VFP register (s0-s31 or d0-d15)', line);
}
function regList(t, line) {
  t = t.trim();
  if (t[0] !== '{' || t[t.length - 1] !== '}') throw new AsmError('a register list goes in braces, like {r4, r5, lr}', line);
  let mask = 0;
  for (const part of t.slice(1, -1).split(',')) {
    const p = part.trim(); if (!p) continue;
    const d = p.indexOf('-');
    if (d > 0) { const a = parseReg(p.slice(0, d), line), b = parseReg(p.slice(d + 1), line); if (b < a) throw new AsmError('bad register range ' + p, line); for (let k = a; k <= b; k++) mask |= 1 << k; }
    else mask |= 1 << parseReg(p, line);
  }
  return mask;
}
function vregList(t, line) {
  t = t.trim();
  if (t[0] !== '{' || t[t.length - 1] !== '}') throw new AsmError('a register list goes in braces, like {d8, d9} or {s0-s3}', line);
  let kind = null, first = -1, last = -1;
  const regs = [];
  for (const part of t.slice(1, -1).split(',')) {
    const p = part.trim(); if (!p) continue;
    const d = p.indexOf('-');
    if (d > 0) { const a = parseVReg(p.slice(0, d), line), b = parseVReg(p.slice(d + 1), line); if (a.kind !== b.kind) throw new AsmError('mixed register kinds in ' + p, line); for (let k = a.n; k <= b.n; k++) regs.push({ kind: a.kind, n: k }); }
    else regs.push(parseVReg(p, line));
  }
  if (!regs.length) throw new AsmError('empty register list', line);
  kind = regs[0].kind; first = regs[0].n;
  regs.forEach((r, i) => { if (r.kind !== kind || r.n !== first + i) throw new AsmError('VFP register lists must be consecutive registers of one kind, like {d8-d11}', line); });
  last = first + regs.length - 1;
  return { kind, first, count: regs.length };
}

// ---------------- the assembler ----------------
// unit: {name, text, rename: {main: '__user_main'}}
// /* block comments */ become spaces (newlines are kept, so line numbers stay the same)
function stripBlockComments(text) {
  if (text.indexOf('/*') < 0) return text;
  let out = '', i = 0;
  const n = text.length;
  while (i < n) {
    const c = text[i];
    if (c === '"') {   // a string: copy it as it is
      let j = i + 1;
      while (j < n && text[j] !== '"' && text[j] !== '\n') j += text[j] === '\\' ? 2 : 1;
      out += text.slice(i, j + 1); i = j + 1; continue;
    }
    if (c === "'" && text[i + 2] === "'") { out += text.slice(i, i + 3); i += 3; continue; }
    if (c === "'" && text[i + 1] === '\\' && text[i + 3] === "'") { out += text.slice(i, i + 4); i += 4; continue; }
    if (c === '@' || (c === '/' && text[i + 1] === '/')) { const e = text.indexOf('\n', i); const j = e < 0 ? n : e; out += text.slice(i, j); i = j; continue; }
    if (c === '/' && text[i + 1] === '*') { const e = text.indexOf('*/', i + 2); const j = e < 0 ? n : e + 2; out += text.slice(i, j).replace(/[^\n]/g, ' '); i = j; continue; }
    out += c; i++;
  }
  return out;
}
// split a line at ';' (GNU as: a new statement), but not inside strings or character constants
function splitStatements(text) {
  if (text.indexOf(';') < 0) return [text];
  const out = [];
  let cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { cur += c; if (c === '\\') { cur += text[i + 1] || ''; i++; } else if (c === '"') q = false; continue; }
    if (c === '"') { q = true; cur += c; continue; }
    if (c === "'" && text[i + 2] === "'") { cur += text.slice(i, i + 3); i += 2; continue; }
    if (c === "'" && text[i + 1] === '\\' && text[i + 3] === "'") { cur += text.slice(i, i + 4); i += 3; continue; }
    if (c === ';') { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  out.push(cur);
  return out;
}
function assemble(unit) {
  const lines = stripBlockComments(unit.text).split('\n');
  const rename = unit.rename || {};
  const SEC = ['text', 'rodata', 'data', 'bss'];
  const secs = {}; for (const s of SEC) secs[s] = { size: 0, align: 4, bytes: null, relocs: [] };
  secs.discard = { size: 0, align: 1 };
  const symbols = new Map();          // name -> {sec, off, global, defined, equ, value}
  const globals = new Set(), locals = new Set();
  const equs = new Map();             // .equ/.set name -> {v, sym}
  const numLabels = new Map();        // digit -> [{idx, name}]
  const lineInfo = [];                // [textOffset, line]
  const errors = [];
  const pools = { text: [] };         // literal pool entries per section being built
  let pass = 1, cur = 'text', loc = {};
  const lineSec = [];                 // per line: section & offset (pass 1)
  const rn = (name) => (Object.prototype.hasOwnProperty.call(rename, name) ? rename[name] : name);
  const sectionOf = (name) => {
    const n = name.replace(/^"|"$/g, '');
    if (/^\.text/.test(n) || n === 'text') return 'text';
    if (/^\.rodata/.test(n) || /^\.data\.rel\.ro/.test(n)) return 'rodata';
    if (/^\.data/.test(n)) return 'data';
    if (/^\.bss/.test(n) || /^\.tbss/.test(n)) return 'bss';
    return 'discard';
  };
  const ctx = {
    here: () => ({ v: loc[cur], sym: { sec: cur } }),
    sameBase: (a, b) => a.sec && b.sec && a.sec === b.sec,
    symRef: (name, line) => {
      name = rn(name);
      if (equs.has(name)) { const e = equs.get(name); return { v: e.v, sym: e.sym }; }
      const s = symbols.get(name);
      if (s && s.defined) return { v: s.off, sym: { sec: s.sec, name } };
      if (pass === 1) return { v: 0, sym: { name }, unknown: true };
      return { v: 0, sym: { name } };
    },
    localRef: (digit, dir, line) => {
      const defs = numLabels.get(digit) || [];
      let best = null;
      if (dir === 'b') { for (const d of defs) if (d.idx <= ctx.lineIdx) best = d; }
      else { for (const d of defs) if (d.idx > ctx.lineIdx) { best = d; break; } }
      if (!best) { if (pass === 1) return { v: 0, sym: { sec: cur }, unknown: true }; throw new AsmError('no local label ' + digit + ' ' + (dir === 'b' ? 'before' : 'after') + ' this line', line); }
      const s = symbols.get(best.name);
      if (!s || !s.defined) { if (pass === 1) return { v: 0, sym: { sec: cur }, unknown: true }; throw new AsmError('local label ' + digit + ' is not defined', line); }
      return { v: s.off, sym: { sec: s.sec, name: best.name } };
    },
    lineIdx: 0,
  };
  const expr = makeExprParser(ctx);
  const absExpr = (t, line, what) => {
    const e = expr(t, line);
    if (e.sym && !(pass === 1 && e.unknown)) throw new AsmError((what || 'this value') + ' must be a number, not a label: "' + t + '"', line);
    return e.v;
  };
  // byte emitters (pass 2)
  const emit8 = (b) => { const s = secs[cur]; if (cur === 'discard') return; if (pass === 2 && cur !== 'bss') s.bytes[loc[cur]] = b & 255; loc[cur] += 1; };
  const emit32 = (w) => { if (cur === 'discard') return; const o = loc[cur]; if (pass === 2 && cur !== 'bss') { const b = secs[cur].bytes; b[o] = w & 255; b[o + 1] = (w >>> 8) & 255; b[o + 2] = (w >>> 16) & 255; b[o + 3] = (w >>> 24) & 255; } loc[cur] += 4; };
  const emitN = (v, n) => { for (let k = 0; k < n; k++) emit8((n === 8 ? (k < 4 ? v.lo : v.hi) >>> ((k & 3) * 8) : v >>> (k * 8)) & 255); };
  const reloc = (type, target, add, off) => { if (pass === 2) secs[cur].relocs.push({ off: off === undefined ? loc[cur] : off, type, target, add }); };
  const alignTo = (n, fill) => {
    if (cur === 'discard') return;
    const s = secs[cur];
    if (n > s.align) s.align = n;
    while (loc[cur] % n) { if (cur === 'text' && fill === undefined && loc[cur] % 4 === 0) emit32(0xE320F000); else emit8(fill || 0); }
  };
  // literal pools: entries {key, e (expr result), label}
  let pool = [];
  const poolKey = (e) => (e.sym ? (e.sym.name || ('@' + e.sym.sec)) + '+' + e.v : '#' + (e.v >>> 0));
  const flushPool = () => {
    if (!pool.length) return;
    alignTo(4);
    for (const p of pool) {
      if (pass === 1) { p.off = loc[cur]; p.sec = cur; }
      else {
        const e = p.e2 || p.e;
        if (e.sym) { reloc('abs32', e.sym.sec ? { sec: e.sym.sec, local: e.sym.name } : { name: e.sym.name }, e.v); emit32(0); continue; }
        emit32(e.v);
        continue;
      }
      loc[cur] += 4;
    }
    pool = [];
  };
  const ldrSites = [];       // per ldr= site: null (became mov/mvn) or its pool entry (pass 1 decides)
  let ldrSite = 0;

  function defineLabel(name, line) {
    name = rn(name);
    if (/^\d+$/.test(name)) {
      const internal = '.Lnum' + name + '_' + ctx.lineIdx;
      if (pass === 1) { if (!numLabels.has(name)) numLabels.set(name, []); numLabels.get(name).push({ idx: ctx.lineIdx, name: internal }); }
      name = internal;
    }
    if (pass === 1) {
      const old = symbols.get(name);
      if (old && old.defined) throw new AsmError('the label "' + name + '" is defined twice', line);
      if (equs.has(name)) throw new AsmError('"' + name + '" is already a .equ constant', line);
      symbols.set(name, { sec: cur, off: loc[cur], defined: true, global: globals.has(name), line });
    } else {
      const s = symbols.get(name);
      if (s && (s.off !== loc[cur] || s.sec !== cur)) throw new AsmError('internal: label ' + name + ' moved between passes', line);
    }
  }

  // ---- instruction encoders ----
  function condOf(c) { return c === undefined || c === '' ? 14 : CONDS[c]; }
  function op2(ops, line, opts) {
    // returns {bits, I} for operand2 given operand strings (ops array, already split)
    const a = ops[0];
    if (a === undefined) throw new AsmError('missing operand', line);
    if (a[0] === '#') {
      const v = absExpr(a.slice(1), line, 'an immediate');
      const enc = encImm(v);
      return { imm: true, v, enc };
    }
    const rm = parseReg(a, line);
    if (ops.length === 1) return { bits: rm, rm };
    const sh = ops[1].trim().toLowerCase();
    if (sh === 'rrx') return { bits: (3 << 5) | rm, rm };
    const m = /^(lsl|asl|lsr|asr|ror)\s+(.+)$/.exec(sh);
    if (!m) throw new AsmError('cannot understand the shift "' + ops[1] + '" (use lsl, lsr, asr or ror)', line);
    const type = SHIFT[m[1]];
    const amt = m[2].trim();
    if (amt[0] === '#') {
      let n = absExpr(amt.slice(1), line, 'a shift amount');
      if (n < 0 || n > 32 || (n === 32 && (type === 0 || type === 3))) throw new AsmError('shift amount ' + n + ' is out of range', line);
      if (n === 0) return { bits: rm, rm };
      if (n === 32) n = 0;
      return { bits: (n << 7) | (type << 5) | rm, rm };
    }
    const rs = parseReg(amt, line);
    return { bits: (rs << 8) | (type << 5) | 16 | rm, rm, regShift: true };
  }
  function dataProc(base, s, cond, ops, line) {
    let op = DP[base];
    const test = op >= 8 && op <= 11, move = op === 13 || op === 15;
    let rd = 0, rn = 0, rest;
    if (test) { rn = parseReg(ops[0], line); rest = ops.slice(1); s = 1; }
    else if (move) { rd = parseReg(ops[0], line); rest = ops.slice(1); }
    else {
      rd = parseReg(ops[0], line);
      if (ops.length === 2 || (ops.length === 3 && /^(lsl|lsr|asr|ror|rrx)/i.test(ops[2].trim()) && ops[1][0] !== '#' && !(ops[1].trim().toLowerCase() in REG && false))) {
        // two-operand form: add r0, r1  ==> add r0, r0, r1 ; also add r0, r1, lsl #2 (Rd = Rn)
        if (ops.length === 2) { rn = rd; rest = ops.slice(1); }
        else { rn = parseReg(ops[1], line); rest = ops.slice(2); }
      } else { rn = parseReg(ops[1], line); rest = ops.slice(2); }
    }
    if (!rest.length) throw new AsmError(base + ' needs another operand', line);
    const o = op2(rest, line);
    let bits;
    if (o.imm) {
      if (o.enc >= 0) bits = (1 << 25) | o.enc;
      else {
        // try the equivalent instruction with a changed immediate (like GNU as does)
        const v = o.v;
        const alt = { 13: [15, ~v], 15: [13, ~v], 4: [2, -v], 2: [4, -v], 10: [11, -v], 11: [10, -v], 0: [14, ~v], 14: [0, ~v], 5: [6, ~v], 6: [5, ~v] }[op];
        if (alt && encImm(alt[1]) >= 0) { op = alt[0]; bits = (1 << 25) | encImm(alt[1]); }
        else if (op === 13 && !s && (v >>> 0) <= 0xffff) return ((condOf(cond) << 28) | 0x03000000 | ((v >>> 12) & 15) << 16 | rd << 12 | (v & 0xfff)) >>> 0;
        else throw new AsmError('the number ' + v + ' cannot be an immediate here: ARM immediates are an 8-bit value rotated by an even amount (like 255, 0x3FC, 0xFF000000). Use movw/movt or ldr r' + rd + ', =' + v + ' instead.', line);
      }
    } else bits = o.bits;
    return ((condOf(cond) << 28) | (op << 21) | (s ? 1 << 20 : 0) | (rn << 16) | (rd << 12) | bits) >>> 0;
  }
  function shiftInsn(kind, s, cond, ops, line) {
    // lsl r0, r1, #2  ==> mov r0, r1, lsl #2 ; rrx r0, r1 ; lsl r0, r1, r2
    if (kind === 'rrx') return dataProc('mov', s, cond, [ops[0], ops[1], 'rrx'], line);
    if (ops.length === 2) ops = [ops[0], ops[0], ops[1]];
    if (ops.length !== 3) throw new AsmError(kind + ' needs Rd, Rm, #amount (or Rd, Rm, Rs)', line);
    const amt = ops[2].trim();
    if (amt[0] === '#' && absExpr(amt.slice(1), line) === 0 && kind !== 'ror') return dataProc('mov', s, cond, [ops[0], ops[1]], line);
    return dataProc('mov', s, cond, [ops[0], ops[1], kind + ' ' + amt], line);
  }
  // memory operand for LDR/STR family. returns {rn, P, U, W, imm | reg}
  function memOperand(ops, line, opt) {
    const a = ops[0].trim();
    if (a[0] !== '[') throw new AsmError('expected a memory address in brackets like [r1] or [r1, #4]', line);
    const close = a.lastIndexOf(']');
    if (close < 0) throw new AsmError('missing ]', line);
    const inner = splitOperands(a.slice(1, close));
    const wb = a.slice(close + 1).trim() === '!';
    const rn = parseReg(inner[0], line, 'base register');
    let res;
    if (ops.length === 1) {
      // pre-indexed (or plain)
      if (inner.length === 1) res = { rn, P: 1, U: 1, W: wb ? 1 : 0, imm: 0 };
      else res = { rn, P: 1, W: wb ? 1 : 0, ...offsetPart(inner.slice(1), line, opt) };
    } else {
      if (inner.length !== 1) throw new AsmError('post-indexed addressing looks like [r1], #4', line);
      if (wb) throw new AsmError('do not use ! with post-indexed addressing', line);
      res = { rn, P: 0, W: 0, ...offsetPart(ops.slice(1), line, opt) };
    }
    return res;
  }
  function offsetPart(parts, line, opt) {
    const a = parts[0].trim();
    if (a[0] === '#') {
      const v = absExpr(a.slice(1), line, 'an offset');
      return { U: v < 0 || Object.is(v, -0) || /^#\s*-/.test(a) && v === 0 ? (v < 0 ? 0 : (/^#\s*-/.test(a) ? 0 : 1)) : 1, imm: Math.abs(v) };
    }
    let neg = false, r = a;
    if (r[0] === '-') { neg = true; r = r.slice(1); } else if (r[0] === '+') r = r.slice(1);
    const rm = parseReg(r, line, 'offset register');
    let shift = 0;
    if (parts.length > 1) {
      if (opt && opt.noShift) throw new AsmError('this instruction cannot shift its offset register', line);
      const m = /^(lsl|lsr|asr|ror)\s+#(.+)$/i.exec(parts[1].trim());
      const rrx = /^rrx$/i.test(parts[1].trim());
      if (!m && !rrx) throw new AsmError('offset shift looks like lsl #2', line);
      if (rrx) shift = 3 << 5;
      else { let n = absExpr(m[2], line); const t = SHIFT[m[1].toLowerCase()]; if (n === 32 && (t === 1 || t === 2)) n = 0; if (n < 0 || n > 31) throw new AsmError('shift out of range', line); shift = (n << 7) | (t << 5); }
    }
    return { U: neg ? 0 : 1, reg: rm, shift };
  }
  function ldrStr(base, size, cond, ops, line) {
    // size: '', 'b', 'h', 'sb', 'sh', 'd', 't', 'bt'
    const L = base === 'ldr' ? 1 : 0;
    const c = condOf(cond) << 28;
    let rt = parseReg(ops[0], line);
    let rt2 = -1, rest = ops.slice(1);
    if (size === 'd') {
      if (rest.length && rest[0].trim()[0] !== '[' && rest[0].trim()[0] !== '=') { rt2 = parseReg(rest[0], line); rest = rest.slice(1); }
      else rt2 = rt + 1;
      if (rt & 1) throw new AsmError('ldrd/strd need an even first register (r0, r2, r4...)', line);
      if (rt2 !== rt + 1) throw new AsmError('ldrd/strd need two consecutive registers, like r4, r5', line);
    }
    if (!rest.length) throw new AsmError(base + ' needs an address', line);
    const a = rest[0].trim();
    if (a[0] === '=') {
      if (!L || size !== '') throw new AsmError('only ldr (word) can load =constants', line);
      const e = expr(a.slice(1), line);
      const site = ldrSite++;
      if (pass === 1) {
        if (!e.sym && !e.unknown) {
          const enc = encImm(e.v);
          if (enc >= 0) { ldrSites[site] = null; return (c | 0x03A00000 | (rt << 12) | enc) >>> 0; }
          const enc2 = encImm(~e.v);
          if (enc2 >= 0) { ldrSites[site] = null; return (c | 0x03E00000 | (rt << 12) | enc2) >>> 0; }
        }
        const key = poolKey(e);
        let ent = pool.find(p => p.key === key);
        if (!ent) { ent = { key, e }; pool.push(ent); }
        ldrSites[site] = ent;
        return 0;
      }
      const ent = ldrSites[site];
      if (ent === null) {
        if (e.sym) throw new AsmError('internal: constant became a label between passes', line);
        const enc = encImm(e.v);
        if (enc >= 0) return (c | 0x03A00000 | (rt << 12) | enc) >>> 0;
        const enc2 = encImm(~e.v);
        if (enc2 >= 0) return (c | 0x03E00000 | (rt << 12) | enc2) >>> 0;
        throw new AsmError('internal: constant changed between passes', line);
      }
      ent.e2 = e;
      if (!pool.includes(ent)) pool.push(ent);
      const off = ent.off - (loc[cur] + 8);
      if (ent.sec !== cur) throw new AsmError('literal pool in another section', line);
      if (Math.abs(off) > 4095) throw new AsmError('the constant for ldr =... is too far away (more than 4 KB). Put a .ltorg after this function.', line);
      return (c | 0x05100000 | (off >= 0 ? 1 << 23 : 0) | (15 << 16) | (rt << 12) | Math.abs(off)) >>> 0;
    }
    if (a[0] !== '[') {
      // pc-relative literal: ldr r0, label
      const e = expr(a, line);
      if (pass === 1) return 0;
      if (!e.sym || !e.sym.sec || e.sym.sec !== cur) throw new AsmError('ldr from a label works only for labels in the same section; use ldr r' + rt + ', =' + a + ' to load its address, then ldr from [r' + rt + ']', line);
      const off = e.v - (loc[cur] + 8);
      if (size === '' || size === 'b') {
        if (Math.abs(off) > 4095) throw new AsmError('label too far for a pc-relative load', line);
        return (c | (1 << 26) | (1 << 24) | (off >= 0 ? 1 << 23 : 0) | (size === 'b' ? 1 << 22 : 0) | (L << 20) | (15 << 16) | (rt << 12) | Math.abs(off)) >>> 0;
      }
      if (Math.abs(off) > 255) throw new AsmError('label too far for a pc-relative load', line);
      const sh = { h: 1, sb: 2, sh: 3, d: 2 }[size];
      const ab = Math.abs(off);
      return (c | (1 << 24) | (off >= 0 ? 1 << 23 : 0) | (1 << 22) | (size === 'd' ? 0 : L << 20) | (15 << 16) | (rt << 12) | ((ab >> 4) << 8) | (1 << 7) | (sh << 5) | (1 << 4) | (ab & 15)) >>> 0;
    }
    const mo = memOperand(rest, line, { noShift: !(size === '' || size === 'b') });
    if (mo.W && mo.rn === rt && L) throw new AsmError('writeback to the same register you load (' + ops[0] + ') is not allowed', line);
    if (size === '' || size === 'b' || size === 't' || size === 'bt') {
      const B = size === 'b' || size === 'bt' ? 1 : 0;
      let P = mo.P, W = mo.W;
      if (size === 't' || size === 'bt') { if (P) throw new AsmError('ldrt/strt only allow post-indexing', line); W = 1; }
      if (mo.reg === undefined) {
        if (mo.imm > 4095) throw new AsmError('offset ' + mo.imm + ' is too big (max 4095)', line);
        return (c | (1 << 26) | (P << 24) | (mo.U << 23) | (B << 22) | (W << 21) | (L << 20) | (mo.rn << 16) | (rt << 12) | mo.imm) >>> 0;
      }
      return (c | (1 << 26) | (1 << 25) | (P << 24) | (mo.U << 23) | (B << 22) | (W << 21) | (L << 20) | (mo.rn << 16) | (rt << 12) | mo.shift | mo.reg) >>> 0;
    }
    // halfword / signed / doubleword
    let sh, Lb = L;
    if (size === 'h') sh = 1;
    else if (size === 'sb') { if (!L) throw new AsmError('there is no strsb: use strb', line); sh = 2; }
    else if (size === 'sh') { if (!L) throw new AsmError('there is no strsh: use strh', line); sh = 3; }
    else if (size === 'd') { sh = L ? 2 : 3; Lb = 0; }
    if (mo.reg === undefined) {
      if (mo.imm > 255) throw new AsmError('offset ' + mo.imm + ' is too big for ' + base + size + ' (max 255)', line);
      return (c | (mo.P << 24) | (mo.U << 23) | (1 << 22) | (mo.W << 21) | (Lb << 20) | (mo.rn << 16) | (rt << 12) | ((mo.imm >> 4) << 8) | (1 << 7) | (sh << 5) | (1 << 4) | (mo.imm & 15)) >>> 0;
    }
    return (c | (mo.P << 24) | (mo.U << 23) | (mo.W << 21) | (Lb << 20) | (mo.rn << 16) | (rt << 12) | (1 << 7) | (sh << 5) | (1 << 4) | mo.reg) >>> 0;
  }
  function ldmStm(L, mode, cond, ops, line) {
    let a = ops[0].trim(), W = 0;
    if (a.endsWith('!')) { W = 1; a = a.slice(0, -1); }
    const rn = parseReg(a, line);
    const mask = regList(ops.slice(1).join(','), line);
    const modes = L ? { ia: [0, 1], ib: [1, 1], da: [0, 0], db: [1, 0], fd: [0, 1], ed: [1, 1], fa: [0, 0], ea: [1, 0], '': [0, 1] }
      : { ia: [0, 1], ib: [1, 1], da: [0, 0], db: [1, 0], ea: [0, 1], fa: [1, 1], ed: [0, 0], fd: [1, 0], '': [0, 1] };
    const [P, U] = modes[mode];
    return ((condOf(cond) << 28) | (4 << 25) | (P << 24) | (U << 23) | (W << 21) | (L << 20) | (rn << 16) | mask) >>> 0;
  }
  function branchTarget(t, line) {
    const e = expr(t, line);
    return e;
  }
  function encBranch(link, cond, t, line) {
    const c = (condOf(cond) << 28) | (link ? 0x0B000000 : 0x0A000000);
    const e = branchTarget(t, line);
    if (pass === 1) return 0;
    if (!e.sym) throw new AsmError('branch to a number is not supported; branch to a label', line);
    if (e.sym.sec === cur && !(e.sym.name && symbols.get(e.sym.name) && symbols.get(e.sym.name).global && false)) {
      const off = e.v - (loc[cur] + 8);
      if (off & 3) throw new AsmError('branch target is not word-aligned', line);
      if (off < -33554432 || off > 33554428) throw new AsmError('branch target too far', line);
      return (c | ((off >> 2) & 0xFFFFFF)) >>> 0;
    }
    reloc('branch24', e.sym.sec ? { sec: e.sym.sec, local: e.sym.name } : { name: e.sym.name }, e.v);
    return c >>> 0;
  }
  // ---- VFP ----
  function vSD(r) { return r.kind === 's' ? { V: r.n >> 1, X: r.n & 1 } : { V: r.n & 15, X: r.n >> 4 }; }
  function vfp3(base, cond, dt, ops, line) {
    // vadd/vsub/vmul/vdiv/vnmul/vmla/vmls/vnmla/vnmls: Vd, Vn, Vm  (2-operand form: Vd = Vd op Vm)
    if (ops.length === 2) ops = [ops[0], ops[0], ops[1]];
    if (ops.length !== 3) throw new AsmError(base + ' needs three registers', line);
    const d = parseVReg(ops[0], line), n = parseVReg(ops[1], line), m = parseVReg(ops[2], line);
    const sz = d.kind === 'd' ? 1 : 0;
    if (n.kind !== d.kind || m.kind !== d.kind) throw new AsmError('mixing s and d registers in ' + base, line);
    if (dt && dt !== (sz ? 'f64' : 'f32')) throw new AsmError(base + '.' + dt + ' does not match the registers (s registers are .f32, d registers are .f64)', line);
    const D = vSD(d), N = vSD(n), M = vSD(m);
    const enc = { vmla: [0x0E000A00, 0], vmls: [0x0E000A00, 1], vnmls: [0x0E100A00, 0], vnmla: [0x0E100A00, 1], vmul: [0x0E200A00, 0], vnmul: [0x0E200A00, 1],
      vadd: [0x0E300A00, 0], vsub: [0x0E300A00, 1], vdiv: [0x0E800A00, 0] }[base];
    return ((condOf(cond) << 28) | enc[0] | (D.X << 22) | (N.V << 16) | (D.V << 12) | (sz << 8) | (N.X << 7) | (enc[1] << 6) | (M.X << 5) | M.V) >>> 0;
  }
  function vfp2(base, cond, dt, ops, line) {
    const d = parseVReg(ops[0], line);
    const sz = d.kind === 'd' ? 1 : 0;
    const D = vSD(d);
    if (base === 'vcmp' || base === 'vcmpe') {
      const E = base === 'vcmpe' ? 1 : 0;
      const t = (ops[1] || '').trim();
      if (/^#\s*0(\.0*)?$/.test(t)) return ((condOf(cond) << 28) | 0x0EB50A40 | (D.X << 22) | (D.V << 12) | (sz << 8) | (E << 7)) >>> 0;
      const m = parseVReg(t, line); if (m.kind !== d.kind) throw new AsmError('vcmp needs two registers of the same kind', line);
      const M = vSD(m);
      return ((condOf(cond) << 28) | 0x0EB40A40 | (D.X << 22) | (D.V << 12) | (sz << 8) | (E << 7) | (M.X << 5) | M.V) >>> 0;
    }
    const m = parseVReg(ops[1], line);
    if (m.kind !== d.kind) throw new AsmError(base + ' needs two registers of the same kind', line);
    const M = vSD(m);
    const enc = { vabs: 0x0EB00AC0, vneg: 0x0EB10A40, vsqrt: 0x0EB10AC0 }[base];
    return ((condOf(cond) << 28) | enc | (D.X << 22) | (D.V << 12) | (sz << 8) | (M.X << 5) | M.V) >>> 0;
  }
  function vmov(cond, dt, ops, line) {
    const c = condOf(cond) << 28;
    if (ops.length === 3) {
      // vmov Dm, Rt, Rt2  |  vmov Rt, Rt2, Dm
      const a = ops[0].trim().toLowerCase();
      if (/^d\d+$/.test(a)) { const d = parseVReg(a, line); const rt = parseReg(ops[1], line), rt2 = parseReg(ops[2], line); return (c | 0x0C400B10 | (rt2 << 16) | (rt << 12) | ((d.n >> 4) << 5) | (d.n & 15)) >>> 0; }
      const rt = parseReg(ops[0], line), rt2 = parseReg(ops[1], line), d = parseVReg(ops[2], line);
      if (d.kind !== 'd') throw new AsmError('vmov r, r, d needs a d register', line);
      return (c | 0x0C500B10 | (rt2 << 16) | (rt << 12) | ((d.n >> 4) << 5) | (d.n & 15)) >>> 0;
    }
    if (ops.length !== 2) throw new AsmError('vmov needs two operands', line);
    const A = ops[0].trim().toLowerCase(), B = ops[1].trim();
    const isV = (x) => /^[sd]\d+$/i.test(x.trim());
    if (isV(A) && B[0] === '#') {
      const d = parseVReg(A, line);
      const v = parseFloat(B.slice(1));
      const imm = vfpImm(v);
      if (imm < 0) throw new AsmError('vmov' + (dt ? '.' + dt : '') + ' can only load simple numbers like 1.0, 0.5, 2.0, -3.0 or 10.0 (an immediate must be ±m/16 x 2^n). Load other values from memory with vldr.', line);
      const D = vSD(d), sz = d.kind === 'd' ? 1 : 0;
      return (c | 0x0EB00A00 | (D.X << 22) | ((imm >> 4) << 16) | (D.V << 12) | (sz << 8) | (imm & 15)) >>> 0;
    }
    if (isV(A) && isV(B)) {
      const d = parseVReg(A, line), m = parseVReg(B, line);
      if (d.kind !== m.kind) throw new AsmError('vmov between s and d registers is not possible; use vcvt to convert', line);
      const D = vSD(d), M = vSD(m), sz = d.kind === 'd' ? 1 : 0;
      return (c | 0x0EB00A40 | (D.X << 22) | (D.V << 12) | (sz << 8) | (M.X << 5) | M.V) >>> 0;
    }
    if (isV(A)) {   // vmov Sn, Rt
      const n = parseVReg(A, line); if (n.kind !== 's') throw new AsmError('to copy two core registers into a d register use vmov dN, rA, rB', line);
      const rt = parseReg(B, line);
      return (c | 0x0E000A10 | ((n.n >> 1) << 16) | (rt << 12) | ((n.n & 1) << 7)) >>> 0;
    }
    if (isV(B)) {   // vmov Rt, Sn
      const n = parseVReg(B, line); if (n.kind !== 's') throw new AsmError('to copy a d register into core registers use vmov rA, rB, dN', line);
      const rt = parseReg(A, line);
      return (c | 0x0E100A10 | ((n.n >> 1) << 16) | (rt << 12) | ((n.n & 1) << 7)) >>> 0;
    }
    throw new AsmError('vmov needs at least one VFP register (s0-s31 or d0-d15)', line);
  }
  function vcvt(cond, dts, ops, line, round) {
    const c = condOf(cond) << 28;
    const [to, from] = dts;
    const d = parseVReg(ops[0], line), m = parseVReg(ops[1], line);
    const D = vSD(d), M = vSD(m);
    if (to === 'f64' && from === 'f32') { if (d.kind !== 'd' || m.kind !== 's') throw new AsmError('vcvt.f64.f32 needs dN, sM', line); return (c | 0x0EB70AC0 | (D.X << 22) | (D.V << 12) | (M.X << 5) | M.V) >>> 0; }
    if (to === 'f32' && from === 'f64') { if (d.kind !== 's' || m.kind !== 'd') throw new AsmError('vcvt.f32.f64 needs sN, dM', line); return (c | 0x0EB70BC0 | (D.X << 22) | (D.V << 12) | (M.X << 5) | M.V) >>> 0; }
    if ((to === 'f32' || to === 'f64') && (from === 's32' || from === 'u32')) {
      const sz = to === 'f64' ? 1 : 0;
      if (m.kind !== 's' || d.kind !== (sz ? 'd' : 's')) throw new AsmError('vcvt.' + to + '.' + from + ' needs ' + (sz ? 'dN' : 'sN') + ', sM', line);
      return (c | 0x0EB80A40 | (D.X << 22) | (D.V << 12) | (sz << 8) | ((from === 's32' ? 1 : 0) << 7) | (M.X << 5) | M.V) >>> 0;
    }
    if ((to === 's32' || to === 'u32') && (from === 'f32' || from === 'f64')) {
      const sz = from === 'f64' ? 1 : 0;
      if (d.kind !== 's' || m.kind !== (sz ? 'd' : 's')) throw new AsmError('vcvt.' + to + '.' + from + ' needs sN, ' + (sz ? 'dM' : 'sM'), line);
      return (c | 0x0EB80A40 | (1 << 18) | ((to === 's32' ? 1 : 0) << 16) | (D.X << 22) | (D.V << 12) | (sz << 8) | ((round ? 0 : 1) << 7) | (M.X << 5) | M.V) >>> 0;
    }
    throw new AsmError('unsupported conversion vcvt.' + to + '.' + from + ' (use f32, f64, s32 or u32)', line);
  }
  function vldst(L, cond, dt, ops, line) {
    const c = condOf(cond) << 28;
    const d = parseVReg(ops[0], line);
    const D = vSD(d), sz = d.kind === 'd' ? 1 : 0;
    const a = (ops[1] || '').trim();
    if (a[0] !== '[') {
      const e = expr(a, line);
      if (pass === 1) return 0;
      if (!e.sym || e.sym.sec !== cur) throw new AsmError('vldr from a label works only for labels in the same section; load the address with ldr rX, =label then vldr from [rX]', line);
      const off = e.v - ((loc[cur] + 8) & ~3);
      if (off & 3 || Math.abs(off) > 1020) throw new AsmError('label too far for vldr (or not word aligned)', line);
      return (c | 0x0D000A00 | (off >= 0 ? 1 << 23 : 0) | (D.X << 22) | (L << 20) | (15 << 16) | (D.V << 12) | (sz << 8) | (Math.abs(off) >> 2)) >>> 0;
    }
    const close = a.lastIndexOf(']');
    if (a.slice(close + 1).trim() || ops.length > 2) throw new AsmError('vldr/vstr only allow [rN] or [rN, #offset] (no ! or post-indexing)', line);
    const inner = splitOperands(a.slice(1, close));
    const rn = parseReg(inner[0], line);
    let off = 0, neg = false;
    if (inner.length > 1) {
      const t = inner[1].trim();
      if (t[0] !== '#') throw new AsmError('vldr/vstr offsets must be #numbers (a multiple of 4, up to 1020)', line);
      off = absExpr(t.slice(1), line); neg = off < 0 || /^#\s*-/.test(t); off = Math.abs(off);
    }
    if (off & 3) throw new AsmError('vldr/vstr offsets must be a multiple of 4', line);
    if (off > 1020) throw new AsmError('vldr/vstr offset ' + off + ' is too big (max 1020): add it to the base register first', line);
    return (c | 0x0D000A00 | (neg ? 0 : 1 << 23) | (D.X << 22) | (L << 20) | (rn << 16) | (D.V << 12) | (sz << 8) | (off >> 2)) >>> 0;
  }
  function vldmStm(L, mode, cond, ops, line, pushPop) {
    const c = condOf(cond) << 28;
    let rn = 13, W = 1, list;
    if (pushPop) { list = vregList(ops.join(','), line); mode = L ? 'ia' : 'db'; }
    else {
      let a = ops[0].trim(); W = 0;
      if (a.endsWith('!')) { W = 1; a = a.slice(0, -1); }
      rn = parseReg(a, line);
      list = vregList(ops.slice(1).join(','), line);
      if (mode === '') mode = 'ia';
    }
    const P = mode === 'db' ? 1 : 0, U = mode === 'db' ? 0 : 1;
    if (mode === 'db' && !W) throw new AsmError('vldmdb/vstmdb need writeback (!)', line);
    const sz = list.kind === 'd' ? 1 : 0;
    const D = list.kind === 'd' ? { V: list.first & 15, X: list.first >> 4 } : { V: list.first >> 1, X: list.first & 1 };
    const imm8 = list.kind === 'd' ? list.count * 2 : list.count;
    return (c | (6 << 25) | (P << 24) | (U << 23) | (D.X << 22) | (W << 21) | (L << 20) | (rn << 16) | (D.V << 12) | ((10 + sz) << 8) | imm8) >>> 0;
  }

  // ---------------- mnemonic dispatch ----------------
  const M_DP = new RegExp('^(and|eor|sub|rsb|add|adc|sbc|rsc|orr|mov|bic|mvn)(s)?(' + COND_RE + ')?$|^(and|eor|sub|rsb|add|adc|sbc|rsc|orr|mov|bic|mvn)(' + COND_RE + ')(s)$');
  const M_TEST = new RegExp('^(tst|teq|cmp|cmn)(' + COND_RE + ')?$');
  const M_SHIFT = new RegExp('^(lsl|lsr|asr|ror|rrx)(s)?(' + COND_RE + ')?$');
  const M_LDST = new RegExp('^(ldr|str)(' + COND_RE + ')?(b|h|sb|sh|d|t|bt)?(' + COND_RE + ')?$');
  const M_LDM = new RegExp('^(ldm|stm)(' + COND_RE + ')?(ia|ib|da|db|fd|ed|fa|ea)?(' + COND_RE + ')?$');
  const M_B = new RegExp('^(bl|b)(' + COND_RE + ')?$');
  const M_BX = new RegExp('^(bx|blx)(' + COND_RE + ')?$');
  const M_MUL = new RegExp('^(mul|mla|mls|umull|smull|umlal|smlal)(s)?(' + COND_RE + ')?$');
  const M_MISC = new RegExp('^(movw|movt|clz|rev|rev16|revsh|sdiv|udiv|smmulr|smmlar|smmlsr|smmul|smmla|smmls|smlabb|smlabt|smlatb|smlatt|smulbb|smulbt|smultb|smultt|uxtb|uxth|sxtb|sxth|uxtab|uxtah|sxtab|sxtah|bfi|bfc|ubfx|sbfx|adr|push|pop|neg|nop|svc|swi|udf|rbit)(' + COND_RE + ')?$');

  function encodeInsn(mn, ops, line) {
    let m;
    const dot = mn.indexOf('.');
    let base = mn, dts = [];
    if (dot >= 0) { base = mn.slice(0, dot); dts = mn.slice(dot + 1).split('.'); }
    // VFP
    if (base[0] === 'v') {
      const vm = new RegExp('^(vadd|vsub|vmul|vdiv|vnmul|vmla|vmls|vnmla|vnmls|vabs|vneg|vsqrt|vcmpe|vcmp|vmov|vcvtr|vcvt|vldr|vstr|vpush|vpop|vldmia|vldmdb|vstmia|vstmdb|vldm|vstm|vmrs|vmsr)(' + COND_RE + ')?$').exec(base);
      if (!vm) throw new AsmError('unknown instruction "' + mn + '"', line);
      const b = vm[1], cond = vm[2];
      const dt = dts[0] && dts[0].toLowerCase();
      switch (b) {
        case 'vadd': case 'vsub': case 'vmul': case 'vdiv': case 'vnmul': case 'vmla': case 'vmls': case 'vnmla': case 'vnmls': return vfp3(b, cond, dt, ops, line);
        case 'vabs': case 'vneg': case 'vsqrt': case 'vcmp': case 'vcmpe': return vfp2(b, cond, dt, ops, line);
        case 'vmov': return vmov(cond, dt, ops, line);
        case 'vcvt': case 'vcvtr': if (dts.length !== 2) throw new AsmError('vcvt needs two types, like vcvt.f32.s32 s0, s0', line); return vcvt(cond, dts.map(x => x.toLowerCase()), ops, line, b === 'vcvtr');
        case 'vldr': return vldst(1, cond, dt, ops, line);
        case 'vstr': return vldst(0, cond, dt, ops, line);
        case 'vpush': return vldmStm(0, 'db', cond, ops, line, true);
        case 'vpop': return vldmStm(1, 'ia', cond, ops, line, true);
        case 'vldm': case 'vldmia': return vldmStm(1, 'ia', cond, ops, line);
        case 'vldmdb': return vldmStm(1, 'db', cond, ops, line);
        case 'vstm': case 'vstmia': return vldmStm(0, 'ia', cond, ops, line);
        case 'vstmdb': return vldmStm(0, 'db', cond, ops, line);
        case 'vmrs': {
          const c = condOf(cond) << 28;
          const a = ops[0].trim().toLowerCase();
          if ((ops[1] || '').trim().toLowerCase() !== 'fpscr') throw new AsmError('vmrs reads fpscr: vmrs APSR_nzcv, fpscr', line);
          if (a === 'apsr_nzcv') return (c | 0x0EF1FA10) >>> 0;
          return (c | 0x0EF10A10 | (parseReg(a, line) << 12)) >>> 0;
        }
        case 'vmsr': {
          if (ops[0].trim().toLowerCase() !== 'fpscr') throw new AsmError('vmsr writes fpscr: vmsr fpscr, rN', line);
          return ((condOf(cond) << 28) | 0x0EE10A10 | (parseReg(ops[1], line) << 12)) >>> 0;
        }
      }
    }
    if (dts.length) {
      // allow .w/.n width qualifiers from Thumb code, nothing else
      if (dts.every(x => x === 'w' || x === 'n')) dts = [];
      else throw new AsmError('unknown instruction "' + mn + '"', line);
    }
    if ((m = M_DP.exec(base))) {
      const b = m[1] || m[4], s = m[2] || m[6], cond = m[3] || m[5];
      return dataProc(b, !!s, cond, ops, line);
    }
    if ((m = M_TEST.exec(base))) return dataProc(m[1], 1, m[2], ops, line);
    if ((m = M_SHIFT.exec(base))) return shiftInsn(m[1], !!m[2], m[3], ops, line);
    if ((m = M_B.exec(base))) return encBranch(m[1] === 'bl', m[2], ops[0], line);
    if ((m = M_BX.exec(base))) {
      const c = condOf(m[2]) << 28;
      if (m[1] === 'blx' && !(ops[0].trim().toLowerCase() in REG)) throw new AsmError('blx to a label is not supported (it switches to Thumb); use bl', line);
      return (c | (m[1] === 'bx' ? 0x012FFF10 : 0x012FFF30) | parseReg(ops[0], line)) >>> 0;
    }
    if ((m = M_LDST.exec(base))) {
      const cond = m[2] || m[4], size = m[3] || '';
      return ldrStr(m[1], size, cond, ops, line);
    }
    if ((m = M_LDM.exec(base))) return ldmStm(m[1] === 'ldm' ? 1 : 0, m[3] || '', m[2] || m[4], ops, line);
    if ((m = M_MUL.exec(base))) {
      const b = m[1], s = m[2] ? 1 : 0, c = condOf(m[3]) << 28;
      const r = ops.map(x => parseReg(x, line));
      if (b === 'mul') { if (r.length === 2) r.unshift(r[0]); return (c | (s << 20) | (r[0] << 16) | (r[2] << 8) | 0x90 | r[1]) >>> 0; }
      if (b === 'mla') return (c | 0x00200000 | (s << 20) | (r[0] << 16) | (r[3] << 12) | (r[2] << 8) | 0x90 | r[1]) >>> 0;
      if (b === 'mls') return (c | 0x00600000 | (r[0] << 16) | (r[3] << 12) | (r[2] << 8) | 0x90 | r[1]) >>> 0;
      const op = { umull: 4, umlal: 5, smull: 6, smlal: 7 }[b];
      if (r.length !== 4) throw new AsmError(b + ' needs RdLo, RdHi, Rn, Rm', line);
      return (c | (op << 21) | (s << 20) | (r[1] << 16) | (r[0] << 12) | (r[3] << 8) | 0x90 | r[2]) >>> 0;
    }
    if ((m = M_MISC.exec(base))) {
      const b = m[1], c = condOf(m[2]) << 28;
      switch (b) {
        case 'movw': case 'movt': {
          const rd = parseReg(ops[0], line);
          let t = (ops[1] || '').trim();
          if (t[0] === '#') t = t.slice(1).trim();
          else if (!/^:(lower16|upper16):/i.test(t)) throw new AsmError(b + ' needs #value (or :lower16:label / :upper16:label)', line);
          const opc = b === 'movw' ? 0x03000000 : 0x03400000;
          const lm = /^:(lower16|upper16):(.+)$/i.exec(t);
          if (lm) {
            const e = expr(lm[2], line);
            if (!e.sym) { const v = lm[1].toLowerCase() === 'lower16' ? e.v & 0xffff : (e.v >>> 16) & 0xffff; return (c | opc | ((v >> 12) << 16) | (rd << 12) | (v & 0xfff)) >>> 0; }
            reloc(lm[1].toLowerCase() === 'lower16' ? 'movw' : 'movt', e.sym.sec ? { sec: e.sym.sec, local: e.sym.name } : { name: e.sym.name }, e.v);
            return (c | opc | (rd << 12)) >>> 0;
          }
          const v = absExpr(t, line, b + ' value');
          if ((v >>> 0) > 0xffff) throw new AsmError(b + ' takes a 16-bit number (0-65535)', line);
          return (c | opc | ((v >> 12) << 16) | (rd << 12) | (v & 0xfff)) >>> 0;
        }
        case 'clz': return (c | 0x016F0F10 | (parseReg(ops[0], line) << 12) | parseReg(ops[1], line)) >>> 0;
        case 'rbit': return (c | 0x06FF0F30 | (parseReg(ops[0], line) << 12) | parseReg(ops[1], line)) >>> 0;
        case 'rev': return (c | 0x06BF0F30 | (parseReg(ops[0], line) << 12) | parseReg(ops[1], line)) >>> 0;
        case 'rev16': return (c | 0x06BF0FB0 | (parseReg(ops[0], line) << 12) | parseReg(ops[1], line)) >>> 0;
        case 'revsh': return (c | 0x06FF0FB0 | (parseReg(ops[0], line) << 12) | parseReg(ops[1], line)) >>> 0;
        case 'sdiv': case 'udiv': {
          let r = ops.map(x => parseReg(x, line)); if (r.length === 2) r = [r[0], r[0], r[1]];
          return (c | (b === 'sdiv' ? 0x0710F010 : 0x0730F010) | (r[0] << 16) | (r[2] << 8) | r[1]) >>> 0;
        }
        case 'smmul': case 'smmulr': { const r = ops.map(x => parseReg(x, line)); return (c | 0x0750F010 | (b === 'smmulr' ? 32 : 0) | (r[0] << 16) | (r[2] << 8) | r[1]) >>> 0; }
        case 'smmla': case 'smmlar': { const r = ops.map(x => parseReg(x, line)); return (c | 0x07500010 | (b === 'smmlar' ? 32 : 0) | (r[0] << 16) | (r[3] << 12) | (r[2] << 8) | r[1]) >>> 0; }
        case 'smmls': case 'smmlsr': { const r = ops.map(x => parseReg(x, line)); return (c | 0x075000D0 | (b === 'smmlsr' ? 32 : 0) | (r[0] << 16) | (r[3] << 12) | (r[2] << 8) | r[1]) >>> 0; }
        case 'smlabb': case 'smlabt': case 'smlatb': case 'smlatt': {
          const r = ops.map(x => parseReg(x, line)); const N = b[4] === 't' ? 1 : 0, Mb = b[5] === 't' ? 1 : 0;
          return (c | 0x01000080 | (r[0] << 16) | (r[3] << 12) | (r[2] << 8) | (Mb << 6) | (N << 5) | r[1]) >>> 0;
        }
        case 'smulbb': case 'smulbt': case 'smultb': case 'smultt': {
          const r = ops.map(x => parseReg(x, line)); const N = b[4] === 't' ? 1 : 0, Mb = b[5] === 't' ? 1 : 0;
          return (c | 0x01600080 | (r[0] << 16) | (r[2] << 8) | (Mb << 6) | (N << 5) | r[1]) >>> 0;
        }
        case 'uxtb': case 'uxth': case 'sxtb': case 'sxth': case 'uxtab': case 'uxtah': case 'sxtab': case 'sxtah': {
          const add = b.length === 5;
          const rd = parseReg(ops[0], line);
          const rn = add ? parseReg(ops[1], line) : 15;
          const rm = parseReg(ops[add ? 2 : 1], line);
          let rot = 0;
          const rs = ops[add ? 3 : 2];
          if (rs) { const mm = /^ror\s+#(\d+)$/i.exec(rs.trim()); if (!mm || ![0, 8, 16, 24].includes(+mm[1])) throw new AsmError('rotation must be ror #8, #16 or #24', line); rot = +mm[1] / 8; }
          const opc = { sxtb: 0x06A00070, sxth: 0x06B00070, uxtb: 0x06E00070, uxth: 0x06F00070 }[b.replace('a', '')];
          return (c | opc | (rn << 16) | (rd << 12) | (rot << 10) | rm) >>> 0;
        }
        case 'bfi': {
          const rd = parseReg(ops[0], line), rn = parseReg(ops[1], line), lsb = absExpr(ops[2].replace('#', ''), line), w = absExpr(ops[3].replace('#', ''), line);
          if (lsb < 0 || w < 1 || lsb + w > 32) throw new AsmError('bfi: bad lsb/width', line);
          return (c | 0x07C00010 | ((lsb + w - 1) << 16) | (rd << 12) | (lsb << 7) | rn) >>> 0;
        }
        case 'bfc': {
          const rd = parseReg(ops[0], line), lsb = absExpr(ops[1].replace('#', ''), line), w = absExpr(ops[2].replace('#', ''), line);
          if (lsb < 0 || w < 1 || lsb + w > 32) throw new AsmError('bfc: bad lsb/width', line);
          return (c | 0x07C0001F | ((lsb + w - 1) << 16) | (rd << 12) | (lsb << 7)) >>> 0;
        }
        case 'ubfx': case 'sbfx': {
          const rd = parseReg(ops[0], line), rn = parseReg(ops[1], line), lsb = absExpr(ops[2].replace('#', ''), line), w = absExpr(ops[3].replace('#', ''), line);
          if (lsb < 0 || w < 1 || lsb + w > 32) throw new AsmError(b + ': bad lsb/width', line);
          return (c | (b === 'ubfx' ? 0x07E00050 : 0x07A00050) | ((w - 1) << 16) | (rd << 12) | (lsb << 7) | rn) >>> 0;
        }
        case 'adr': {
          const rd = parseReg(ops[0], line);
          const e = expr(ops[1], line);
          if (pass === 1) return 0;
          if (!e.sym || e.sym.sec !== cur) throw new AsmError('adr only works with a label in the same section; use ldr r' + rd + ', =label', line);
          const off = e.v - (loc[cur] + 8);
          const enc = encImm(Math.abs(off));
          if (enc < 0) throw new AsmError('adr: the label is too far away', line);
          return (c | (off >= 0 ? 0x028F0000 : 0x024F0000) | (rd << 12) | enc) >>> 0;
        }
        case 'push': case 'pop': {
          const mask = regList(ops.join(','), line);
          if (mask === 0) throw new AsmError('empty register list', line);
          if ((mask & (mask - 1)) === 0) { // single register: str/ldr
            const r = 31 - Math.clz32(mask);
            return b === 'push' ? (c | 0x052D0004 | (r << 12)) >>> 0 : (c | 0x049D0004 | (r << 12)) >>> 0;
          }
          return b === 'push' ? (c | 0x092D0000 | mask) >>> 0 : (c | 0x08BD0000 | mask) >>> 0;
        }
        case 'neg': return dataProc('rsb', 0, m[2], [ops[0], ops[1] || ops[0], '#0'], line);
        case 'nop': return (c | 0x0320F000) >>> 0;
        case 'svc': case 'swi': { const v = absExpr((ops[0] || '#0').replace('#', ''), line); return (c | 0x0F000000 | (v & 0xFFFFFF)) >>> 0; }
        case 'udf': { const v = absExpr((ops[0] || '#0').replace('#', ''), line); return (0xE7F000F0 | ((v >> 4) << 8) | (v & 15)) >>> 0; }
      }
    }
    // pre-UAL: "movseq" style handled above; "addeqs" handled by M_DP second branch
    throw new AsmError('unknown instruction "' + mn + '"', line);
  }

  // ---------------- directives ----------------
  function directive(d, rest, line) {
    const args = () => splitOperands(rest);
    switch (d) {
      case '.text': cur = 'text'; return;
      case '.data': cur = 'data'; return;
      case '.bss': cur = 'bss'; return;
      case '.section': { const n = splitOperands(rest)[0] || ''; flushIfLeaving(); cur = sectionOf(n); return; }
      case '.pushsection': { cur = sectionOf(splitOperands(rest)[0] || ''); return; }
      case '.popsection': cur = 'text'; return;
      case '.global': case '.globl': for (const n of args()) { const nm = rn(n.trim()); globals.add(nm); const s = symbols.get(nm); if (s) s.global = true; } return;
      case '.local': for (const n of args()) locals.add(rn(n.trim())); return;
      case '.weak': for (const n of args()) { const nm = rn(n.trim()); globals.add(nm); } return;
      case '.extern': case '.type': case '.size': case '.file': case '.ident': case '.eabi_attribute': case '.fnstart': case '.fnend': case '.cantunwind':
      case '.save': case '.pad': case '.vsave': case '.setfp': case '.movsp': case '.personality': case '.personalityindex': case '.handlerdata':
      case '.addrsig': case '.addrsig_sym': case '.syntax': case '.arch': case '.cpu': case '.fpu': case '.arm': case '.code': case '.loc': case '.end':
      case '.object_arch': case '.arch_extension': case '.hidden': case '.protected': case '.internal': case '.tune': case '.thumb_func':
        if (d === '.code' && rest.trim() === '16') throw new AsmError('Thumb code (.code 16) is not supported: write ARM code (.arm)', line);
        if (d === '.syntax' && rest.trim().toLowerCase() === 'divided') return;
        return;
      case '.thumb': throw new AsmError('Thumb code is not supported: write ARM code (.arm)', line);
      case '.p2align': { const a = args(); alignTo(1 << absExpr(a[0], line), a[1] !== undefined && a[1] !== '' ? absExpr(a[1], line) : undefined); return; }
      case '.align': { const a = args(); const n = absExpr(a[0] || '2', line); alignTo(1 << n, a[1] !== undefined && a[1] !== '' ? absExpr(a[1], line) : undefined); return; }
      case '.balign': { const a = args(); alignTo(absExpr(a[0], line), a[1] !== undefined && a[1] !== '' ? absExpr(a[1], line) : undefined); return; }
      case '.word': case '.long': case '.4byte': case '.int':
        for (const a of args()) {
          if (!a) continue;
          const e = expr(a, line);
          if (e.sym && !(pass === 1 && e.unknown) || (e.sym && pass === 2)) {
            if (cur === 'bss') throw new AsmError('.bss can only hold zeros (use .space)', line);
            const s = e.sym.name ? symbols.get(e.sym.name) : null;
            reloc('abs32', e.sym.sec ? { sec: e.sym.sec, local: e.sym.name } : { name: e.sym.name }, e.v);
            emit32(0);
          } else emit32(e.v);
        }
        return;
      case '.short': case '.hword': case '.2byte':
        for (const a of args()) { if (!a) continue; const v = absExpr(a, line); emit8(v); emit8(v >> 8); }
        return;
      case '.byte':
        for (const a of args()) { if (!a) continue; if (a[0] === '"') { for (const b of parseString(a, line)) emit8(b); continue; } emit8(absExpr(a, line)); }
        return;
      case '.ascii': case '.asciz': case '.string':
        for (const a of args()) { if (!a) continue; for (const b of parseString(a, line)) emit8(b); if (d !== '.ascii') emit8(0); }
        return;
      case '.space': case '.skip': case '.zero': {
        const a = args(); const n = absExpr(a[0], line, 'the size'); const fill = a[1] ? absExpr(a[1], line) : 0;
        if (n < 0 || n > 64 * 1024 * 1024) throw new AsmError('bad size for ' + d, line);
        if (cur === 'bss' || cur === 'discard') { loc[cur] += n; return; }
        for (let k = 0; k < n; k++) emit8(fill);
        return;
      }
      case '.fill': {
        const a = args(); const rep = absExpr(a[0], line), size = a[1] ? absExpr(a[1], line) : 1, val = a[2] ? absExpr(a[2], line) : 0;
        for (let k = 0; k < rep; k++) for (let j = 0; j < size; j++) emit8(j < 4 ? val >>> (8 * j) : 0);
        return;
      }
      case '.float': case '.single': for (const a of args()) { if (!a) continue; const f = new Float32Array([parseFloat(a)]); if (isNaN(parseFloat(a))) throw new AsmError('.float needs a number', line); emit32(new Int32Array(f.buffer)[0]); } return;
      case '.double': for (const a of args()) { if (!a) continue; const f = new Float64Array([parseFloat(a)]); const w = new Int32Array(f.buffer); emit32(w[0]); emit32(w[1]); } return;
      case '.quad': case '.8byte': for (const a of args()) { if (!a) continue; const v = BigInt.asUintN(64, BigInt(a.trim())); emit32(Number(v & 0xFFFFFFFFn)); emit32(Number(v >> 32n)); } return;
      case '.equ': case '.set': {
        const a = splitOperands(rest);
        if (a.length < 2) throw new AsmError(d + ' needs a name and a value: ' + d + ' NAME, 42', line);
        const name = rn(a[0].trim());
        const e = expr(a.slice(1).join(','), line);
        equs.set(name, { v: e.v, sym: e.sym, line });
        return;
      }
      case '.comm': case '.lcomm': {
        const a = args(); const name = rn(a[0].trim()), size = absExpr(a[1], line), al = a[2] ? absExpr(a[2], line) : 4;
        const save = cur; cur = 'bss';
        alignTo(Math.max(1, al));
        if (pass === 1) { if (d === '.comm' && !locals.has(name)) globals.add(name); symbols.set(name, { sec: 'bss', off: loc.bss, defined: true, global: d === '.comm' && !locals.has(name), line }); }
        loc.bss += size;
        cur = save;
        return;
      }
      case '.ltorg': case '.pool': if (cur === 'text') flushPool(); return;
      case '.inst': for (const a of args()) emit32(absExpr(a, line)); return;
      case '.macro': case '.endm': case '.rept': case '.endr': case '.irp': case '.if': case '.endif': case '.else': case '.include':
        throw new AsmError(d + ' is not supported by this assembler', line);
      default:
        if (d.startsWith('.cfi_')) return;
        throw new AsmError('unknown directive ' + d, line);
    }
  }
  function flushIfLeaving() { /* pools stay with the text section; flushed at .ltorg or at the end */ }

  function runPass(p) {
    pass = p; cur = 'text';
    loc = { text: 0, rodata: 0, data: 0, bss: 0, discard: 0 };
    ldrSite = 0; pool = [];
    if (p === 2) for (const s of SEC) { secs[s].bytes = s === 'bss' ? null : new Uint8Array(secs[s].size); secs[s].relocs = []; }
    for (let li = 0; li < lines.length; li++) {
      ctx.lineIdx = li;
      const lineNo = li + 1;
      const whole = stripComment(lines[li]).trim();
      if (!whole || whole[0] === '#') continue;
      const stmts = splitStatements(whole);
      for (let si = 0; si < stmts.length; si++) {
      let text = stmts[si].trim();
      if (!text) continue;
      try {
        // labels
        for (;;) {
          const mm = /^([A-Za-z_.$][A-Za-z0-9_.$]*|\d+)\s*:/.exec(text);
          if (!mm) break;
          defineLabel(mm[1], lineNo);
          text = text.slice(mm[0].length).trim();
        }
        if (!text) continue;
        const sp = text.search(/\s/);
        const word = (sp < 0 ? text : text.slice(0, sp)).toLowerCase();
        const rest = sp < 0 ? '' : text.slice(sp + 1).trim();
        if (/^[A-Za-z_.$][\w.$]*\s*=/.test(text) && !word.startsWith('.')) { // NAME = value
          const eq = text.indexOf('=');
          directive('.equ', text.slice(0, eq).trim() + ', ' + text.slice(eq + 1), lineNo);
          continue;
        }
        if (word[0] === '.') { directive(word, rest, lineNo); continue; }
        if (cur !== 'text') throw new AsmError('instructions must be in the .text section (write .text before your code)', lineNo);
        if (loc.text % 4) throw new AsmError('instructions must start at an address that is a multiple of 4 (add .p2align 2 or .align 2 before this code)', lineNo);
        const ops = rest ? splitOperands(rest) : [];
        let w;
        try { w = encodeInsn(word, ops, lineNo); }
        catch (e) {
          if (pass === 2) { lineInfo.push(loc.text, lineNo); emit32(0); } else emit32(0);
          if (si > 0 && e instanceof AsmError && /unknown instruction/.test(e.message)) throw new AsmError(e.message + ". Note: ';' starts a new instruction in ARM assembly (it is not a comment). For comments use @ (or //).", lineNo);
          throw e;
        }
        if (pass === 2) lineInfo.push(loc.text, lineNo);
        emit32(w);
      } catch (e) {
        if (e instanceof AsmError) { if (pass === 2 || !/^(no local label|local label)/.test(e.message)) { if (!errors.some(x => x.line === e.line && x.msg === e.message)) errors.push({ line: e.line || lineNo, msg: e.message }); } if (errors.length > 20) break; }
        else { errors.push({ line: lineNo, msg: 'internal assembler error: ' + e.message }); }
      }
      }
      if (errors.length > 20) break;
    }
    cur = 'text';
    flushPool();
    if (p === 1) for (const s of SEC) secs[s].size = loc[s];
  }
  runPass(1);
  if (!errors.length) runPass(2);
  // mark globals that were declared after the label
  for (const g of globals) { const s = symbols.get(g); if (s) s.global = true; }
  // .global names that are .equ constants: export as absolute symbols
  const absSyms = {};
  for (const [name, e] of equs) if (globals.has(name) && !e.sym) absSyms[name] = e.v;
  const equList = {};
  for (const [name, e] of equs) if (!e.sym) equList[name] = e.v;
  return {
    name: unit.name, hidden: !!unit.hidden, errors,
    sections: { text: { bytes: secs.text.bytes, align: secs.text.align, relocs: secs.text.relocs }, rodata: { bytes: secs.rodata.bytes, align: secs.rodata.align, relocs: secs.rodata.relocs }, data: { bytes: secs.data.bytes, align: secs.data.align, relocs: secs.data.relocs }, bss: { size: secs.bss.size, align: secs.bss.align } },
    symbols: [...symbols.entries()].filter(([n, s]) => s.defined).map(([n, s]) => ({ name: n, sec: s.sec, off: s.off, global: !!s.global, line: s.line })),
    undefinedGlobals: [...globals].filter(g => !symbols.has(g) && !equs.has(g)),
    abs: absSyms, equs: equList, lines: lineInfo,
  };
}
K.assemble = assemble;
K.splitOperands = splitOperands;
})(typeof globalThis !== 'undefined' ? globalThis : this);


// ===== link.js =====
// ===== ArmKit linker: places assembled units in memory, resolves symbols, applies relocations =====
(function (G) {
'use strict';
const K = G.ArmKit = G.ArmKit || {};

const LAYOUT = K.LAYOUT = {
  TEXT_BASE: 0x00010000,   // memory starts here: every address below it faults (NULL page)
  STUB_BASE: 0x00001000,   // C library functions live at these (virtual) addresses
  MAGIC_EXIT: 0x00000F00,  // main returns here -> the program ends
  MAGIC_RET: 0x00000F04,   // callbacks (qsort comparators) return here
  STACK_SIZE: 1 << 20,     // 1 MB stack
  FILE_BASE: 0x00000100,   // FILE* handles are small numbers (using one as memory faults)
};

// units: [{obj (from assemble), name, hidden}] ; libc: {names: Set of function names, data: Set of data names}
function link(units, opts) {
  opts = opts || {};
  const L = LAYOUT;
  const errors = [];
  const libcFuncs = opts.libcFuncs || new Set();
  const libcData = opts.libcData || ['stdin', 'stdout', 'stderr'];
  const err = (unit, line, msg) => { if (errors.length < 30) errors.push({ unit, line, msg }); };
  // 1. global symbol table
  const globals = new Map();     // name -> {u (unit index), sym}
  const localDefs = new Map();   // name -> unit index (non-global labels, for hints)
  units.forEach((u, ui) => {
    for (const s of u.obj.symbols) {
      if (s.name.startsWith('.L')) continue;
      if (!s.global) { if (!localDefs.has(s.name)) localDefs.set(s.name, ui); continue; }
      const old = globals.get(s.name);
      if (old) {
        const a = units[old.u], b = u;
        err(ui, s.line, '"' + s.name + '" is defined twice: in ' + (a.name || 'a unit') + ' and in ' + (b.name || 'another unit') + '. Every global name must be unique.');
        continue;
      }
      globals.set(s.name, { u: ui, sym: s });
    }
    for (const [name, v] of Object.entries(u.obj.abs || {})) {
      if (!globals.has(name)) globals.set(name, { u: ui, abs: v });
    }
  });
  // 2. layout
  const align = (x, a) => (x + a - 1) & ~(a - 1);
  const base = units.map(() => ({ text: 0, rodata: 0, data: 0, bss: 0 }));
  let p = L.TEXT_BASE;
  units.forEach((u, i) => { p = align(p, Math.max(4, u.obj.sections.text.align)); base[i].text = p; p += u.obj.sections.text.bytes.length; });
  const textEnd = p;
  p = align(p, 16);
  const rodataBase = p;
  units.forEach((u, i) => { p = align(p, Math.max(1, u.obj.sections.rodata.align)); base[i].rodata = p; p += u.obj.sections.rodata.bytes.length; });
  p = align(p, 4096);
  const dataBase = p;            // first writable address
  const libcDataAddr = {};
  for (const n of libcData) { libcDataAddr[n] = p; p += 4; }
  units.forEach((u, i) => { p = align(p, Math.max(4, u.obj.sections.data.align)); base[i].data = p; p += u.obj.sections.data.bytes.length; });
  p = align(p, 16);
  const bssBase = p;
  units.forEach((u, i) => { p = align(p, Math.max(4, u.obj.sections.bss.align)); base[i].bss = p; p += u.obj.sections.bss.size; });
  const bssEnd = p;
  const stackLo = align(bssEnd + 4096, 4096);
  const stackHi = stackLo + L.STACK_SIZE;
  const heapBase = stackHi + 4096;
  // 3. stubs for C library functions
  const stubs = [], stubIndex = new Map();
  const stubFor = (name) => {
    if (!stubIndex.has(name)) { stubIndex.set(name, stubs.length); stubs.push(name); }
    return L.STUB_BASE + 4 * stubIndex.get(name);
  };
  // 4. image
  const image = new Uint8Array(heapBase - L.TEXT_BASE);
  units.forEach((u, i) => {
    const o = u.obj.sections;
    image.set(o.text.bytes, base[i].text - L.TEXT_BASE);
    image.set(o.rodata.bytes, base[i].rodata - L.TEXT_BASE);
    image.set(o.data.bytes, base[i].data - L.TEXT_BASE);
  });
  const dv = new DataView(image.buffer);
  const libcHandles = { stdin: L.FILE_BASE, stdout: L.FILE_BASE + 4, stderr: L.FILE_BASE + 8 };
  for (const n of libcData) dv.setUint32(libcDataAddr[n] - L.TEXT_BASE, libcHandles[n] || 0, true);
  const lineOf = (ui, off) => { const ln = u => u; const arr = units[ui].obj.lines; for (let k = 0; k < arr.length; k += 2) if (arr[k] === off) return arr[k + 1]; return 0; };
  const resolveName = (name, ui, sec, off, kind) => {
    const g = globals.get(name);
    if (g) {
      if (g.abs !== undefined) return { addr: g.abs, abs: true };
      return { addr: base[g.u][g.sym.sec] + g.sym.off, sec: g.sym.sec, name };
    }
    if (libcFuncs.has(name)) return { addr: stubFor(name), stub: true, name };
    if (libcDataAddr[name] !== undefined) return { addr: libcDataAddr[name], sec: 'data', name };
    const line = sec === 'text' ? lineOf(ui, off) : 0;
    let hint = '';
    if (localDefs.has(name)) hint = ' You defined the label "' + name + '" in ' + units[localDefs.get(name)].name + ', but other units can only see it if you also write  .global ' + name;
    else hint = units[ui].hidden ? ' (a part of the course code needs it: write the function "' + name + '" and make it .global)' : ' Check the spelling. If it is one of your functions, write it and add  .global ' + name;
    err(ui, line, 'undefined reference to "' + name + '": no unit defines it.' + hint);
    return null;
  };
  units.forEach((u, ui) => {
    for (const secName of ['text', 'rodata', 'data']) {
      const sec = u.obj.sections[secName];
      for (const r of sec.relocs) {
        const P = base[ui][secName] + r.off;
        let S;
        if (r.target.name !== undefined && r.target.sec === undefined) {
          const t = resolveName(r.target.name, ui, secName, r.off, r.type);
          if (!t) continue;
          S = t.addr + r.add;
          if (r.type === 'branch24' && !t.stub && t.sec !== 'text') { err(ui, secName === 'text' ? lineOf(ui, r.off) : 0, 'b/bl can only jump to code, but "' + r.target.name + '" is data'); continue; }
        } else {
          S = base[ui][r.target.sec] + r.add;
          if (r.type === 'branch24' && r.target.sec !== 'text') { err(ui, lineOf(ui, r.off), 'b/bl can only jump to code, but "' + (r.target.local || '?') + '" is data'); continue; }
        }
        const o = P - L.TEXT_BASE;
        const w = dv.getUint32(o, true);
        if (r.type === 'abs32') dv.setUint32(o, (w + S) >>> 0, true);
        else if (r.type === 'branch24') {
          const d = S - (P + 8);
          if (d & 3) { err(ui, lineOf(ui, r.off), 'branch target is not a multiple of 4'); continue; }
          if (d < -33554432 || d > 33554428) { err(ui, lineOf(ui, r.off), 'branch target too far away'); continue; }
          dv.setUint32(o, ((w & 0xFF000000) | ((d >> 2) & 0xFFFFFF)) >>> 0, true);
        } else if (r.type === 'movw' || r.type === 'movt') {
          const v = r.type === 'movw' ? S & 0xFFFF : (S >>> 16) & 0xFFFF;
          dv.setUint32(o, ((w & 0xFFF0F000) | ((v >> 12) << 16) | (v & 0xFFF)) >>> 0, true);
        }
      }
    }
  });
  // 5. symbol and line tables
  const funcs = [];   // [addr, name, unit]
  units.forEach((u, ui) => {
    for (const s of u.obj.symbols) if (s.sec === 'text' && !s.name.startsWith('.L')) funcs.push([base[ui].text + s.off, s.name, ui]);
  });
  funcs.sort((a, b) => a[0] - b[0]);
  // which labels start functions (for names in messages): global labels, and labels that a bl calls
  const fnAddrs = new Set();
  units.forEach((u, ui) => { for (const s of u.obj.symbols) if (s.sec === 'text' && s.global) fnAddrs.add(base[ui].text + s.off); });
  for (let a = L.TEXT_BASE; a < textEnd; a += 4) {
    const w = dv.getUint32(a - L.TEXT_BASE, true);
    if ((w & 0x0F000000) === 0x0B000000 && (w >>> 28) !== 15) { const t = a + 8 + ((w << 8) >> 6); if (t >= L.TEXT_BASE && t < textEnd) fnAddrs.add(t); }
  }
  const fnEntries = funcs.filter(f => fnAddrs.has(f[0]));
  const textWords = (textEnd - L.TEXT_BASE) >> 2;
  const lineMap = new Int32Array(textWords);     // (unit+1) << 20 | line
  units.forEach((u, ui) => {
    const arr = u.obj.lines, b0 = (base[ui].text - L.TEXT_BASE) >> 2;
    for (let k = 0; k < arr.length; k += 2) lineMap[b0 + (arr[k] >> 2)] = ((ui + 1) << 20) | arr[k + 1];
  });
  const symAddr = (name) => { const g = globals.get(name); if (!g) return 0; return g.abs !== undefined ? g.abs : base[g.u][g.sym.sec] + g.sym.off; };
  const entryName = opts.entry || 'main';
  const entry = symAddr(entryName);
  if (!errors.length && opts.needEntry !== false && !entry) err(0, 0, 'there is no function called "' + entryName + '" (write  .global ' + entryName + '  and the label ' + entryName + ':)');
  return {
    ok: errors.length === 0, errors, image, entry,
    layout: { textBase: L.TEXT_BASE, textEnd, rodataBase, dataBase, bssBase, bssEnd, stackLo, stackHi, heapBase, textWords },
    stubs, stubIndex, funcs, fnEntries, lineMap, symAddr, units: units.map(u => ({ name: u.name, hidden: !!u.hidden })), bases: base,
    libcDataAddr,
  };
}
K.link = link;

// name of the function that contains an address
K.funcAt = function (prog, addr) {
  // the function around addr: the nearest function label before it (loop labels are skipped)
  if (prog.fnEntries && prog.fnEntries.length && prog.fnEntries[0][0] <= addr) {
    const f = prog.fnEntries;
    let lo = 0, hi = f.length - 1, best = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (f[m][0] <= addr) { best = m; lo = m + 1; } else hi = m - 1; }
    // but not across the end of a unit: a label in the same unit as addr, or the nearest label of any kind
    const any = K.funcAtAny(prog, addr);
    if (best >= 0 && (!any || f[best][2] === any.unit)) return { name: f[best][1], addr: f[best][0], unit: f[best][2] };
    return any;
  }
  return K.funcAtAny(prog, addr);
};
K.funcAtAny = function (prog, addr) {
  const f = prog.funcs;
  let lo = 0, hi = f.length - 1, best = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (f[m][0] <= addr) { best = m; lo = m + 1; } else hi = m - 1; }
  return best < 0 ? null : { name: f[best][1], addr: f[best][0], unit: f[best][2] };
};
})(typeof globalThis !== 'undefined' ? globalThis : this);


// ===== cpu.js =====
// ===== ArmKit CPU: an ARMv7-A (ARM state) + VFPv3-D16 emulator that translates blocks of machine code to JavaScript =====
(function (G) {
'use strict';
const K = G.ArmKit = G.ArmKit || {};
const LAYOUT = K.LAYOUT;

class CFault extends Error { constructor(msg, pc, extra) { super(msg); this.pc = pc >>> 0; Object.assign(this, extra || {}); } }
class ExitSignal { constructor(code) { this.code = code | 0; } }
K.CFault = CFault; K.ExitSignal = ExitSignal;

const hex = (v) => '0x' + (v >>> 0).toString(16).toUpperCase().padStart(8, '0');
K.hex = hex;
const COND_JS = ['z', '!z', 'c', '!c', 'n', '!n', 'v', '!v', '(c && !z)', '(!c || z)', '(n === v)', '(n !== v)', '(!z && n === v)', '(z || n !== v)', 'true', 'false'];
const COND_NAME = ['eq', 'ne', 'cs', 'cc', 'mi', 'pl', 'vs', 'vc', 'hi', 'ls', 'ge', 'lt', 'gt', 'le', '', 'nv'];
const SH = ['lsl', 'lsr', 'asr', 'ror'];
const ror32 = (x, n) => (n & 31) ? ((x >>> (n & 31)) | (x << (32 - (n & 31)))) >>> 0 : x >>> 0;

// ---------------- helpers used by generated code ----------------
const H = {
  lo: 0, hi: 0,
  umul(a, b) {
    a >>>= 0; b >>>= 0;
    const a0 = a & 0xffff, a1 = a >>> 16, b0 = b & 0xffff, b1 = b >>> 16;
    const p00 = a0 * b0, p01 = a0 * b1, p10 = a1 * b0, p11 = a1 * b1;
    const mid = (p00 >>> 16) + (p01 & 0xffff) + (p10 & 0xffff);
    H.lo = ((mid << 16) | (p00 & 0xffff)) | 0;
    H.hi = (p11 + (p01 >>> 16) + (p10 >>> 16) + (mid >>> 16)) | 0;
  },
  smul(a, b) { H.umul(a, b); H.hi = (H.hi - (a < 0 ? b : 0) - (b < 0 ? a : 0)) | 0; },
  acc(lo, hi) { const l = (H.lo >>> 0) + (lo >>> 0); H.lo = l | 0; H.hi = (H.hi + hi + (l > 0xFFFFFFFF ? 1 : 0)) | 0; },
  lslR: (x, a) => (a >= 32 ? 0 : x << a), lsrR: (x, a) => (a >= 32 ? 0 : (x >>> a) | 0), asrR: (x, a) => (a >= 32 ? x >> 31 : x >> a),
  rorR: (x, a) => ((a & 31) === 0 ? x : (x >>> (a & 31)) | (x << (32 - (a & 31)))),
  lslC: (x, a, c) => (a === 0 ? c : a <= 32 ? ((x >>> (32 - a)) & 1) !== 0 : false),
  lsrC: (x, a, c) => (a === 0 ? c : a <= 32 ? ((x >>> (a - 1)) & 1) !== 0 : false),
  asrC: (x, a, c) => (a === 0 ? c : a < 32 ? ((x >> (a - 1)) & 1) !== 0 : x < 0),
  rorC: (x, a, c) => (a === 0 ? c : ((x >>> ((a - 1) & 31)) & 1) !== 0),
  rev: (x) => ((x << 24) | ((x & 0xff00) << 8) | ((x >>> 8) & 0xff00) | (x >>> 24)) | 0,
  rev16: (x) => (((x & 0x00ff00ff) << 8) | ((x >>> 8) & 0x00ff00ff)) | 0,
  revsh: (x) => ((((x & 0xff) << 24) >> 16) | ((x >>> 8) & 0xff)) | 0,
  rbit(x) { let r = 0; for (let i = 0; i < 32; i++) { r = (r << 1) | (x & 1); x >>>= 1; } return r | 0; },
  // float -> int conversions (round toward zero, saturating, NaN -> 0)
  f2s: (x) => (x !== x ? 0 : x >= 2147483647 ? 2147483647 : x <= -2147483648 ? -2147483648 : x | 0),
  f2u: (x) => (x !== x ? 0 : x >= 4294967295 ? -1 : x <= 0 ? 0 : (x >>> 0) | 0),
  rne(x) { const f = Math.floor(x), d = x - f; return d > 0.5 ? f + 1 : d < 0.5 ? f : (f % 2 === 0 ? f : f + 1); },
  f2sR: (x) => H.f2s(H.rne(x)), f2uR: (x) => H.f2u(H.rne(x)),
};
K.H = H;

// ---------------- decoder ----------------
// returns {k: kind, cond, ...}
function decode(w, pc) {
  w >>>= 0;
  const cond = w >>> 28;
  const d = { w, pc, cond };
  if (cond === 15) { d.k = 'undef'; d.why = 'this instruction (from the "unconditional" group, like blx to a label or pld) is not supported'; return d; }
  const op = (w >>> 25) & 7;
  switch (op) {
    case 0: case 1: {
      if (op === 0) {
        if ((w & 0x0FFFFFF0) === 0x012FFF10) { d.k = 'bx'; d.rm = w & 15; return d; }
        if ((w & 0x0FFFFFF0) === 0x012FFF30) { d.k = 'blxr'; d.rm = w & 15; return d; }
        if ((w & 0x0FFF0FF0) === 0x016F0F10) { d.k = 'clz'; d.rd = (w >>> 12) & 15; d.rm = w & 15; return d; }
        if ((w & 0x0F0000F0) === 0x00000090) {
          d.k = 'mul'; d.op = (w >>> 21) & 7; d.s = (w >>> 20) & 1; d.rd = (w >>> 16) & 15; d.ra = (w >>> 12) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15;
          if (d.op === 2 || (d.op === 3 && d.s)) { d.k = 'undef'; d.why = 'umaal is not supported'; }
          return d;
        }
        if ((w & 0x0E000090) === 0x00000090 && (w & 0x60) !== 0) {
          d.k = 'xfer2'; d.P = (w >>> 24) & 1; d.U = (w >>> 23) & 1; d.I = (w >>> 22) & 1; d.W = (w >>> 21) & 1; d.L = (w >>> 20) & 1;
          d.rn = (w >>> 16) & 15; d.rt = (w >>> 12) & 15; d.sh = (w >>> 5) & 3; d.imm = ((w >>> 4) & 0xF0) | (w & 15); d.rm = w & 15;
          return d;
        }
        if ((w & 0x0F900090) === 0x01000080) { // SMLAxy / SMULxy (halfword multiplies)
          const o = (w >>> 21) & 3;
          if (o === 0 || o === 3) { d.k = 'smulxy'; d.acc = o === 0; d.rd = (w >>> 16) & 15; d.ra = (w >>> 12) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15; d.N = (w >>> 5) & 1; d.M = (w >>> 6) & 1; return d; }
          d.k = 'undef'; d.why = 'this multiply (smlal<x><y>/smulw) is not supported'; return d;
        }
        if ((w & 0x0F900000) === 0x01000000 && !(w & (1 << 20))) { d.k = 'undef'; d.why = 'mrs/msr and other system instructions are not supported'; return d; }
        if ((w & 0x0FB00FF0) === 0x01000090) { d.k = 'undef'; d.why = 'swp is not supported'; return d; }
      } else {
        if ((w & 0x0FF00000) === 0x03000000) { d.k = 'movw'; d.rd = (w >>> 12) & 15; d.imm = ((w >>> 4) & 0xF000) | (w & 0xFFF); return d; }
        if ((w & 0x0FF00000) === 0x03400000) { d.k = 'movt'; d.rd = (w >>> 12) & 15; d.imm = ((w >>> 4) & 0xF000) | (w & 0xFFF); return d; }
        if ((w & 0x0FB00000) === 0x03200000) {
          if ((w & 0x0FFFFF00) === 0x0320F000) { d.k = 'nop'; return d; }
          d.k = 'undef'; d.why = 'msr is not supported'; return d;
        }
      }
      d.k = 'dp'; d.op = (w >>> 21) & 15; d.s = (w >>> 20) & 1; d.rn = (w >>> 16) & 15; d.rd = (w >>> 12) & 15;
      if (op === 1) { const rot = ((w >>> 8) & 15) * 2; d.imm = ror32(w & 255, rot) | 0; d.immRot = rot; }
      else { d.rm = w & 15; d.st = (w >>> 5) & 3; if (w & 16) { d.rs = (w >>> 8) & 15; } else d.sa = (w >>> 7) & 31; }
      if (d.op >= 8 && d.op <= 11 && !d.s) { d.k = 'undef'; d.why = 'system instruction not supported'; }
      return d;
    }
    case 2: case 3: {
      if (op === 3 && (w & 16)) return decodeMedia(w, d);
      d.k = 'xfer'; d.I = (w >>> 25) & 1; d.P = (w >>> 24) & 1; d.U = (w >>> 23) & 1; d.B = (w >>> 22) & 1; d.W = (w >>> 21) & 1; d.L = (w >>> 20) & 1;
      d.rn = (w >>> 16) & 15; d.rt = (w >>> 12) & 15;
      if (d.I) { d.rm = w & 15; d.st = (w >>> 5) & 3; d.sa = (w >>> 7) & 31; } else d.imm = w & 0xFFF;
      return d;
    }
    case 4: {
      d.k = 'ldm'; d.P = (w >>> 24) & 1; d.U = (w >>> 23) & 1; d.S = (w >>> 22) & 1; d.W = (w >>> 21) & 1; d.L = (w >>> 20) & 1; d.rn = (w >>> 16) & 15; d.list = w & 0xFFFF;
      if (d.S) { d.k = 'undef'; d.why = 'ldm/stm with ^ (user registers) is not supported'; }
      if (!d.list) { d.k = 'undef'; d.why = 'ldm/stm with an empty register list'; }
      return d;
    }
    case 5: { d.k = (w >>> 24) & 1 ? 'bl' : 'b'; d.target = (pc + 8 + (((w & 0xFFFFFF) << 8) >> 6)) | 0; return d; }
    case 6: case 7: return decodeCoproc(w, d, op);
  }
  d.k = 'undef'; return d;
}
function decodeMedia(w, d) {
  if ((w & 0x0FF000F0) === 0x07F000F0) { d.k = 'udf'; return d; }
  if ((w & 0x0FF0F0F0) === 0x0710F010) { d.k = 'sdiv'; d.rd = (w >>> 16) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15; return d; }
  if ((w & 0x0FF0F0F0) === 0x0730F010) { d.k = 'udiv'; d.rd = (w >>> 16) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15; return d; }
  if ((w & 0x0FF000D0) === 0x07500010) { d.k = 'smmul'; d.rd = (w >>> 16) & 15; d.ra = (w >>> 12) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15; d.R = (w >>> 5) & 1; d.sub = false; return d; }
  if ((w & 0x0FF000D0) === 0x075000D0) { d.k = 'smmul'; d.rd = (w >>> 16) & 15; d.ra = (w >>> 12) & 15; d.rm = (w >>> 8) & 15; d.rn = w & 15; d.R = (w >>> 5) & 1; d.sub = true; return d; }
  if ((w & 0x0FE00070) === 0x07C00010) { d.k = 'bfi'; d.msb = (w >>> 16) & 31; d.rd = (w >>> 12) & 15; d.lsb = (w >>> 7) & 31; d.rn = w & 15; return d; }
  if ((w & 0x0FE00070) === 0x07E00050) { d.k = 'ubfx'; d.wm1 = (w >>> 16) & 31; d.rd = (w >>> 12) & 15; d.lsb = (w >>> 7) & 31; d.rn = w & 15; return d; }
  if ((w & 0x0FE00070) === 0x07A00050) { d.k = 'sbfx'; d.wm1 = (w >>> 16) & 31; d.rd = (w >>> 12) & 15; d.lsb = (w >>> 7) & 31; d.rn = w & 15; return d; }
  if ((w & 0x0F8000F0) === 0x06800070 && (w & 0x300) === 0) {
    const o = (w >>> 20) & 7; // 2 sxtb 3 sxth 6 uxtb 7 uxth (0/4 = 16-bit pair forms)
    if (o === 2 || o === 3 || o === 6 || o === 7) { d.k = 'ext'; d.sign = o < 4; d.half = (o & 1) === 1; d.rn = (w >>> 16) & 15; d.rd = (w >>> 12) & 15; d.rot = ((w >>> 10) & 3) * 8; d.rm = w & 15; return d; }
  }
  if ((w & 0x0FFF0FF0) === 0x06BF0F30) { d.k = 'rev'; d.f = 'rev'; d.rd = (w >>> 12) & 15; d.rm = w & 15; return d; }
  if ((w & 0x0FFF0FF0) === 0x06BF0FB0) { d.k = 'rev'; d.f = 'rev16'; d.rd = (w >>> 12) & 15; d.rm = w & 15; return d; }
  if ((w & 0x0FFF0FF0) === 0x06FF0FB0) { d.k = 'rev'; d.f = 'revsh'; d.rd = (w >>> 12) & 15; d.rm = w & 15; return d; }
  if ((w & 0x0FFF0FF0) === 0x06FF0F30) { d.k = 'rev'; d.f = 'rbit'; d.rd = (w >>> 12) & 15; d.rm = w & 15; return d; }
  d.k = 'undef'; d.why = 'this media instruction is not supported'; return d;
}
function decodeCoproc(w, d, op) {
  const cp = (w >>> 8) & 15;
  if (op === 7 && (w & (1 << 24))) { d.k = 'svc'; d.imm = w & 0xFFFFFF; return d; }
  if (cp !== 10 && cp !== 11) { d.k = 'undef'; d.why = 'coprocessor instructions other than VFP are not supported'; return d; }
  const dbl = cp === 11;
  if (op === 6) {
    if ((w & 0x0FE00000) === 0x0C400000) { // 64-bit transfers
      d.k = 'vmov64'; d.toArm = (w >>> 20) & 1; d.rt2 = (w >>> 16) & 15; d.rt = (w >>> 12) & 15; d.dbl = dbl;
      const vm = w & 15, M = (w >>> 5) & 1;
      if ((w & 0xD0) !== 0x10) { d.k = 'undef'; return d; }
      d.vm = dbl ? (M << 4) | vm : (vm << 1) | M;
      if (dbl && d.vm > 15) { d.k = 'undef'; d.why = 'only d0-d15 exist on this processor'; }
      return d;
    }
    const P = (w >>> 24) & 1, U = (w >>> 23) & 1, D = (w >>> 22) & 1, W = (w >>> 21) & 1, L = (w >>> 20) & 1;
    const rn = (w >>> 16) & 15, vd = (w >>> 12) & 15, imm8 = w & 255;
    const reg = dbl ? (D << 4) | vd : (vd << 1) | D;
    if (P === 1 && W === 0) { d.k = 'vldr'; d.L = L; d.U = U; d.rn = rn; d.reg = reg; d.dbl = dbl; d.off = imm8 * 4; if (dbl && reg > 15) { d.k = 'undef'; d.why = 'only d0-d15 exist'; } return d; }
    d.k = 'vldm'; d.P = P; d.U = U; d.W = W; d.L = L; d.rn = rn; d.reg = reg; d.dbl = dbl; d.count = dbl ? imm8 >> 1 : imm8;
    if ((P === 1 && U === 1) || (P === 0 && U === 0) || d.count === 0 || (dbl && (imm8 & 1)) || (dbl && reg + d.count > 16) || (!dbl && reg + d.count > 32)) { d.k = 'undef'; d.why = 'bad vldm/vstm register list'; }
    return d;
  }
  // op === 7, bit 24 = 0
  if (w & 16) { // register transfers
    if ((w & 0x0FE00F7F) === 0x0E000A10) { d.k = 'vmovs'; d.toArm = (w >>> 20) & 1; d.rt = (w >>> 12) & 15; d.sn = (((w >>> 16) & 15) << 1) | ((w >>> 7) & 1); return d; }
    if ((w & 0x0FFF0FFF) === 0x0EF10A10) { d.k = 'vmrs'; d.rt = (w >>> 12) & 15; return d; }
    if ((w & 0x0FFF0FFF) === 0x0EE10A10) { d.k = 'vmsr'; d.rt = (w >>> 12) & 15; return d; }
    if ((w & 0x0F900F1F) === 0x0E100B10) { d.k = 'vmovsc'; d.toArm = 1; d.rt = (w >>> 12) & 15; d.dn = (((w >>> 7) & 1) << 4) | ((w >>> 16) & 15); d.x = (w >>> 21) & 1; return d; }
    if ((w & 0x0F900F1F) === 0x0E000B10) { d.k = 'vmovsc'; d.toArm = 0; d.rt = (w >>> 12) & 15; d.dn = (((w >>> 7) & 1) << 4) | ((w >>> 16) & 15); d.x = (w >>> 21) & 1; return d; }
    d.k = 'undef'; d.why = 'this VFP transfer is not supported'; return d;
  }
  // data processing
  const D = (w >>> 22) & 1, vn = (w >>> 16) & 15, vd = (w >>> 12) & 15, N = (w >>> 7) & 1, M = (w >>> 5) & 1, vm = w & 15;
  const R = (v, x) => (dbl ? (x << 4) | v : (v << 1) | x);
  d.dbl = dbl; d.vd = R(vd, D); d.vn = R(vn, N); d.vm = R(vm, M);
  const opc1 = ((w >>> 20) & 0xB), b6 = (w >>> 6) & 1;
  const bad = () => { d.k = 'undef'; d.why = 'only d0-d15 exist on this processor'; return d; };
  switch (opc1) {
    case 0x0: d.k = 'vf3'; d.f = b6 ? 'vmls' : 'vmla'; break;
    case 0x1: d.k = 'vf3'; d.f = b6 ? 'vnmla' : 'vnmls'; break;
    case 0x2: d.k = 'vf3'; d.f = b6 ? 'vnmul' : 'vmul'; break;
    case 0x3: d.k = 'vf3'; d.f = b6 ? 'vsub' : 'vadd'; break;
    case 0x8: if (b6) { d.k = 'undef'; return d; } d.k = 'vf3'; d.f = 'vdiv'; break;
    case 0xB: {
      if (!b6) { d.k = 'vmovi'; d.imm = (((w >>> 16) & 15) << 4) | (w & 15); if (dbl && d.vd > 15) return bad(); return d; }
      const opc2 = (w >>> 16) & 15, b7 = (w >>> 7) & 1;
      if (opc2 === 0) { d.k = 'vf2'; d.f = b7 ? 'vabs' : 'vmov'; }
      else if (opc2 === 1) { d.k = 'vf2'; d.f = b7 ? 'vsqrt' : 'vneg'; }
      else if (opc2 === 4 || opc2 === 5) { d.k = 'vcmp'; d.zero = opc2 === 5; d.E = b7; }
      else if (opc2 === 7 && b7) { d.k = 'vcvt'; d.f = dbl ? 'f32.f64' : 'f64.f32'; d.vd = dbl ? (vd << 1) | D : (D << 4) | vd; }
      else if (opc2 === 8) { d.k = 'vcvt'; d.f = (dbl ? 'f64' : 'f32') + (b7 ? '.s32' : '.u32'); d.vm = (vm << 1) | M; }
      else if (opc2 === 12 || opc2 === 13) { d.k = 'vcvt'; d.f = (opc2 === 13 ? 's32' : 'u32') + (dbl ? '.f64' : '.f32'); d.rz = b7; d.vd = (vd << 1) | D; }
      else { d.k = 'undef'; d.why = 'this VFP conversion (half precision or fixed point) is not supported'; return d; }
      break;
    }
    default: d.k = 'undef'; d.why = 'this VFP instruction is not supported (VFPv3-D16 has no fused multiply-add)'; return d;
  }
  // check D-register numbers
  if (dbl) {
    const chk = [];
    if (d.k === 'vcvt') { if (d.f === 'f32.f64') chk.push(d.vm); else if (d.f.startsWith('f64')) chk.push(d.vd); else chk.push(d.vm); }
    else chk.push(d.vd, d.vm, ...(d.k === 'vf3' ? [d.vn] : []));
    if (chk.some(x => x > 15)) return bad();
  }
  return d;
}
K.decode = decode;

// ---------------- disassembler (for the debugger view) ----------------
function rn_(r) { return ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'r12', 'sp', 'lr', 'pc'][r]; }
function disasm(w, pc, symName) {
  const d = decode(w, pc), c = COND_NAME[d.cond];
  const vr = (n, dbl) => (dbl ? 'd' : 's') + n;
  const list = (m) => { const out = []; for (let i = 0; i < 16; i++) if (m & (1 << i)) out.push(rn_(i)); return '{' + out.join(', ') + '}'; };
  const sh = (d) => (d.rs !== undefined ? ', ' + SH[d.st] + ' ' + rn_(d.rs) : d.st === 3 && d.sa === 0 ? ', rrx' : d.sa || d.st ? ', ' + SH[d.st] + ' #' + (d.sa || 32) : '');
  const tgt = (a) => (symName && symName(a)) || hex(a);
  switch (d.k) {
    case 'dp': {
      const names = ['and', 'eor', 'sub', 'rsb', 'add', 'adc', 'sbc', 'rsc', 'tst', 'teq', 'cmp', 'cmn', 'orr', 'mov', 'bic', 'mvn'];
      const nm = names[d.op] + (d.s && (d.op < 8 || d.op > 11) ? 's' : '') + c;
      const o2 = d.imm !== undefined ? '#' + d.imm : rn_(d.rm) + sh(d);
      if (d.op >= 8 && d.op <= 11) return nm + ' ' + rn_(d.rn) + ', ' + o2;
      if (d.op === 13 || d.op === 15) return nm + ' ' + rn_(d.rd) + ', ' + o2;
      return nm + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + o2;
    }
    case 'movw': case 'movt': return d.k + c + ' ' + rn_(d.rd) + ', #' + d.imm;
    case 'mul': {
      const nm = ['mul', 'mla', 'umaal', 'mls', 'umull', 'umlal', 'smull', 'smlal'][d.op] + (d.s ? 's' : '') + c;
      if (d.op === 0) return nm + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm);
      if (d.op === 1 || d.op === 3) return nm + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm) + ', ' + rn_(d.ra);
      return nm + ' ' + rn_(d.ra) + ', ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm);
    }
    case 'xfer': {
      const nm = (d.L ? 'ldr' : 'str') + (d.B ? 'b' : '') + c;
      if (d.rn === 13 && !d.I && !d.B && d.imm === 4) {   // the one-register push and pop
        if (!d.L && d.P && !d.U && d.W) return 'push' + c + ' {' + rn_(d.rt) + '}';
        if (d.L && !d.P && d.U) return 'pop' + c + ' {' + rn_(d.rt) + '}';
      }
      let off = d.I ? (d.U ? '' : '-') + rn_(d.rm) + sh(d) : d.imm ? '#' + (d.U ? '' : '-') + d.imm : '';
      if (d.rn === 15 && !d.I && d.P && !d.W) return nm + ' ' + rn_(d.rt) + ', [pc, #' + (d.U ? '' : '-') + d.imm + ']  @ ' + hex((pc + 8 + (d.U ? d.imm : -d.imm)));
      if (d.P) return nm + ' ' + rn_(d.rt) + ', [' + rn_(d.rn) + (off ? ', ' + off : '') + ']' + (d.W ? '!' : '');
      return nm + ' ' + rn_(d.rt) + ', [' + rn_(d.rn) + ']' + (off ? ', ' + off : '');
    }
    case 'xfer2': {
      const nm = (d.L ? ['', 'ldrh', 'ldrsb', 'ldrsh'][d.sh] : ['', 'strh', 'ldrd', 'strd'][d.sh]) + c;
      const off = d.I ? (d.imm ? '#' + (d.U ? '' : '-') + d.imm : '') : (d.U ? '' : '-') + rn_(d.rm);
      const rt = (!d.L && d.sh >= 2) ? rn_(d.rt) + ', ' + rn_(d.rt + 1) : rn_(d.rt);
      if (d.P) return nm + ' ' + rt + ', [' + rn_(d.rn) + (off ? ', ' + off : '') + ']' + (d.W ? '!' : '');
      return nm + ' ' + rt + ', [' + rn_(d.rn) + ']' + (off ? ', ' + off : '');
    }
    case 'ldm': {
      if (d.rn === 13 && d.W && d.L && !d.P && d.U) return 'pop' + c + ' ' + list(d.list);
      if (d.rn === 13 && d.W && !d.L && d.P && !d.U) return 'push' + c + ' ' + list(d.list);
      return (d.L ? 'ldm' : 'stm') + (['da', 'ia', 'db', 'ib'][d.P * 2 + d.U]) + c + ' ' + rn_(d.rn) + (d.W ? '!' : '') + ', ' + list(d.list);
    }
    case 'b': case 'bl': return d.k + c + ' ' + tgt(d.target);
    case 'bx': case 'blxr': return (d.k === 'bx' ? 'bx' : 'blx') + c + ' ' + rn_(d.rm);
    case 'clz': return 'clz' + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rm);
    case 'sdiv': case 'udiv': return d.k + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm);
    case 'smmul': return (d.sub ? 'smmls' : d.ra === 15 ? 'smmul' : 'smmla') + (d.R ? 'r' : '') + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm) + (d.ra !== 15 || d.sub ? ', ' + rn_(d.ra) : '');
    case 'smulxy': return (d.acc ? 'smla' : 'smul') + (d.N ? 't' : 'b') + (d.M ? 't' : 'b') + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', ' + rn_(d.rm) + (d.acc ? ', ' + rn_(d.ra) : '');
    case 'ext': return (d.sign ? 's' : 'u') + 'xt' + (d.rn !== 15 ? 'a' : '') + (d.half ? 'h' : 'b') + c + ' ' + rn_(d.rd) + ', ' + (d.rn !== 15 ? rn_(d.rn) + ', ' : '') + rn_(d.rm) + (d.rot ? ', ror #' + d.rot : '');
    case 'bfi': return (d.rn === 15 ? 'bfc' + c + ' ' + rn_(d.rd) : 'bfi' + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rn)) + ', #' + d.lsb + ', #' + (d.msb - d.lsb + 1);
    case 'ubfx': case 'sbfx': return d.k + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rn) + ', #' + d.lsb + ', #' + (d.wm1 + 1);
    case 'rev': return d.f + c + ' ' + rn_(d.rd) + ', ' + rn_(d.rm);
    case 'nop': return 'nop' + c;
    case 'svc': return 'svc' + c + ' #' + d.imm;
    case 'udf': return 'udf #' + (((w >>> 4) & 0xFFF0) | (w & 15));
    case 'vf3': return d.f + c + '.' + (d.dbl ? 'f64' : 'f32') + ' ' + vr(d.vd, d.dbl) + ', ' + vr(d.vn, d.dbl) + ', ' + vr(d.vm, d.dbl);
    case 'vf2': return d.f + c + '.' + (d.dbl ? 'f64' : 'f32') + ' ' + vr(d.vd, d.dbl) + ', ' + vr(d.vm, d.dbl);
    case 'vcmp': return 'vcmp' + (d.E ? 'e' : '') + c + '.' + (d.dbl ? 'f64' : 'f32') + ' ' + vr(d.vd, d.dbl) + ', ' + (d.zero ? '#0' : vr(d.vm, d.dbl));
    case 'vmovi': return 'vmov' + c + '.' + (d.dbl ? 'f64' : 'f32') + ' ' + vr(d.vd, d.dbl) + ', #' + K.vfpImmValue(d.imm);
    case 'vcvt': {
      const [to, from] = d.f.split('.');
      const rv = (t, n) => (t === 'f64' ? 'd' : 's') + n;
      return (d.rz === 0 ? 'vcvtr' : 'vcvt') + c + '.' + d.f + ' ' + rv(to, d.vd) + ', ' + rv(from, d.vm);
    }
    case 'vldr': return (d.L ? 'vldr' : 'vstr') + c + ' ' + vr(d.reg, d.dbl) + ', [' + rn_(d.rn) + (d.off ? ', #' + (d.U ? '' : '-') + d.off : '') + ']';
    case 'vldm': {
      const regs = vr(d.reg, d.dbl) + (d.count > 1 ? '-' + vr(d.reg + d.count - 1, d.dbl) : '');
      if (d.rn === 13 && d.W && d.L && !d.P && d.U) return 'vpop' + c + ' {' + regs + '}';
      if (d.rn === 13 && d.W && !d.L && d.P && !d.U) return 'vpush' + c + ' {' + regs + '}';
      return (d.L ? 'vldm' : 'vstm') + (d.P ? 'db' : 'ia') + c + ' ' + rn_(d.rn) + (d.W ? '!' : '') + ', {' + regs + '}';
    }
    case 'vmovs': return d.toArm ? 'vmov' + c + ' ' + rn_(d.rt) + ', s' + d.sn : 'vmov' + c + ' s' + d.sn + ', ' + rn_(d.rt);
    case 'vmov64': return d.dbl ? (d.toArm ? 'vmov' + c + ' ' + rn_(d.rt) + ', ' + rn_(d.rt2) + ', d' + d.vm : 'vmov' + c + ' d' + d.vm + ', ' + rn_(d.rt) + ', ' + rn_(d.rt2))
      : (d.toArm ? 'vmov' + c + ' ' + rn_(d.rt) + ', ' + rn_(d.rt2) + ', s' + d.vm + ', s' + (d.vm + 1) : 'vmov' + c + ' s' + d.vm + ', s' + (d.vm + 1) + ', ' + rn_(d.rt) + ', ' + rn_(d.rt2));
    case 'vmovsc': return d.toArm ? 'vmov' + c + '.32 ' + rn_(d.rt) + ', d' + d.dn + '[' + d.x + ']' : 'vmov' + c + '.32 d' + d.dn + '[' + d.x + '], ' + rn_(d.rt);
    case 'vmrs': return 'vmrs' + c + ' ' + (d.rt === 15 ? 'APSR_nzcv' : rn_(d.rt)) + ', fpscr';
    case 'vmsr': return 'vmsr' + c + ' fpscr, ' + rn_(d.rt);
    default: return '.word ' + hex(w) + (d.why ? '  @ ' + d.why : '');
  }
}
K.disasm = disasm;

// ---------------- flag liveness (so translated code only computes the N/Z/C/V flags that are really used) ----------------
const FN = 8, FZ = 4, FC = 2, FV = 1, FALL = 15;
const COND_READS = [FZ, FZ, FC, FC, FN, FN, FV, FV, FC | FZ, FC | FZ, FN | FV, FN | FV, FZ | FN | FV, FZ | FN | FV, 0, 0];
function flagUse(d) {
  // returns [reads, writes] (writes only counted when the instruction always runs)
  let rd = COND_READS[d.cond], wr = 0;
  switch (d.k) {
    case 'dp': {
      const logical = [0, 1, 8, 9, 12, 13, 14, 15].includes(d.op);
      if (d.op >= 5 && d.op <= 7) rd |= FC;
      if (d.imm === undefined && d.rs === undefined && d.st === 3 && d.sa === 0) rd |= FC;   // rrx
      if (d.s) {
        if (!logical) wr = FALL;
        else {
          wr = FN | FZ;
          if (d.rs !== undefined) rd |= FC;                  // shift by register: carry may stay unchanged
          else if (d.imm !== undefined ? d.immRot : !(d.st === 0 && d.sa === 0)) wr |= FC;
        }
      }
      break;
    }
    case 'mul': if (d.s) wr = FN | FZ; break;
    case 'xfer': if (d.I && d.st === 3 && d.sa === 0) rd |= FC; break;
    case 'vmrs': if (d.rt === 15) wr = FALL; break;
  }
  if (d.cond !== 14) wr = 0;
  return [rd, wr];
}
// which flags may be read at `pc` before they are overwritten (scans a few instructions of straight-line code)
function flagsNeededAt(m, pc, depth) {
  depth = depth || 0;
  if (!m.isCode(pc)) return FALL;
  let live = 0, killed = 0;
  for (let k = 0; k < 24; k++) {
    if (pc >= m.textEndExec) return live | (FALL & ~killed);
    const d = decode(m.dv0.getUint32(pc - m.B, true), pc);
    const [rd, wr] = flagUse(d);
    live |= rd & ~killed;
    killed |= wr;
    if (killed === FALL) return live;
    if (d.k === 'b') {
      if (depth >= 3 || !m.isCode(d.target)) return live | (FALL & ~killed);
      const sub = flagsNeededAt(m, d.target, depth + 1) & ~killed;
      if (d.cond === 14) return live | sub;
      live |= sub; pc += 4; continue;
    }
    if (d.k === 'bl' && m.isStub(d.target)) { pc += 4; continue; }
    if (isTerminator(d, m) || d.k === 'svc') return live | (FALL & ~killed);
    pc += 4;
  }
  return live | (FALL & ~killed);
}

// ---------------- block translator ----------------
const MAX_BLOCK = 240;
const SCRB = new ArrayBuffer(8), SCRI = new Int32Array(SCRB), SCRF = new Float32Array(SCRB), SCRD = new Float64Array(SCRB);
const REGION_BUDGET = 1200;   // instructions per translated region (one JavaScript function)
const CLOB = 0xDEADBEEF | 0;
// C library functions that are translated straight into JavaScript (same results as the library versions)
const RA = (x) => '(' + x + ' < 0 ? -Math.round(-' + x + ') : Math.round(' + x + '))';
const INLINE = {
  expf: ['f', 'VF[0] = Math.exp(VF[0]);'], logf: ['f', 'VF[0] = Math.log(VF[0]);'], sqrtf: ['f', 'VF[0] = Math.sqrt(VF[0]);'],
  fabsf: ['f', 'VF[0] = Math.abs(VF[0]);'], floorf: ['f', 'VF[0] = Math.floor(VF[0]);'], ceilf: ['f', 'VF[0] = Math.ceil(VF[0]);'], truncf: ['f', 'VF[0] = Math.trunc(VF[0]);'],
  roundf: ['f', '{ const x_ = VF[0]; VF[0] = ' + RA('x_') + '; }'], sinf: ['f', 'VF[0] = Math.sin(VF[0]);'], cosf: ['f', 'VF[0] = Math.cos(VF[0]);'],
  tanf: ['f', 'VF[0] = Math.tan(VF[0]);'], tanhf: ['f', 'VF[0] = Math.tanh(VF[0]);'], atanf: ['f', 'VF[0] = Math.atan(VF[0]);'],
  log2f: ['f', 'VF[0] = Math.log2(VF[0]);'], exp2f: ['f', 'VF[0] = Math.pow(2, VF[0]);'], log10f: ['f', 'VF[0] = Math.log10(VF[0]);'],
  powf: ['f', 'VF[0] = Math.pow(VF[0], VF[1]);'], atan2f: ['f', 'VF[0] = Math.atan2(VF[0], VF[1]);'],
  exp: ['d', 'VD[0] = Math.exp(VD[0]);'], log: ['d', 'VD[0] = Math.log(VD[0]);'], sqrt: ['d', 'VD[0] = Math.sqrt(VD[0]);'], fabs: ['d', 'VD[0] = Math.abs(VD[0]);'],
  floor: ['d', 'VD[0] = Math.floor(VD[0]);'], ceil: ['d', 'VD[0] = Math.ceil(VD[0]);'], trunc: ['d', 'VD[0] = Math.trunc(VD[0]);'],
  round: ['d', '{ const x_ = VD[0]; VD[0] = ' + RA('x_') + '; }'], sin: ['d', 'VD[0] = Math.sin(VD[0]);'], cos: ['d', 'VD[0] = Math.cos(VD[0]);'],
  tan: ['d', 'VD[0] = Math.tan(VD[0]);'], tanh: ['d', 'VD[0] = Math.tanh(VD[0]);'], atan: ['d', 'VD[0] = Math.atan(VD[0]);'],
  pow: ['d', 'VD[0] = Math.pow(VD[0], VD[1]);'], atan2: ['d', 'VD[0] = Math.atan2(VD[0], VD[1]);'],
  lroundf: ['i', '{ const x_ = VF[0]; $W = ' + RA('x_') + ' | 0; }'], lround: ['i', '{ const x_ = VD[0]; $W = ' + RA('x_') + ' | 0; }'],
  isspace: ['i', '{ const c_ = $0; $W = (c_ === 32 || c_ === 9 || c_ === 10 || c_ === 13 || c_ === 11 || c_ === 12) ? 1 : 0; }'],
  isdigit: ['i', '{ const c_ = $0; $W = (c_ >= 48 && c_ <= 57) ? 1 : 0; }'],
  isalpha: ['i', '{ const c_ = $0; $W = ((c_ >= 97 && c_ <= 122) || (c_ >= 65 && c_ <= 90)) ? 1 : 0; }'],
  isalnum: ['i', '{ const c_ = $0; $W = ((c_ >= 97 && c_ <= 122) || (c_ >= 65 && c_ <= 90) || (c_ >= 48 && c_ <= 57)) ? 1 : 0; }'],
  isupper: ['i', '{ const c_ = $0; $W = (c_ >= 65 && c_ <= 90) ? 1 : 0; }'], islower: ['i', '{ const c_ = $0; $W = (c_ >= 97 && c_ <= 122) ? 1 : 0; }'],
  tolower: ['i', '{ const c_ = $0; $W = (c_ >= 65 && c_ <= 90) ? c_ + 32 : c_; }'], toupper: ['i', '{ const c_ = $0; $W = (c_ >= 97 && c_ <= 122) ? c_ - 32 : c_; }'],
  abs: ['i', '{ const c_ = $0; $W = (c_ < 0 ? -c_ : c_) | 0; }'],
};
K.INLINE = INLINE;
function translate(m, entry) {
  const L = m.layout, B = L.textBase;
  const textEnd = m.textEndExec;
  const rd32 = (p) => m.dv0.getUint32(p - B, true);
  // ---- 1. find the region: the basic blocks of the function around `entry` that can be reached with direct jumps
  let fa = B, fb = textEnd;
  if (!m.singleStep) {
    const fl = m.prog.funcs;
    let lo = 0, hi = fl.length - 1, best = -1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (fl[mid][0] <= entry) { best = mid; lo = mid + 1; } else hi = mid - 1; }
    if (best >= 0) { fa = fl[best][0]; for (let k = best + 1; k < fl.length; k++) if (fl[k][0] > fa) { fb = fl[k][0]; break; } }
  }
  const leaders = new Set([entry]);
  const visited = new Set();
  if (m.singleStep) visited.add(entry);
  else {
    const work = [entry];
    let count = 0;
    const inF = (t) => t >= fa && t < fb && m.isCode(t);
    while (work.length && count < REGION_BUDGET) {
      let p = work.pop();
      for (;;) {
        if (visited.has(p) || !inF(p)) break;
        visited.add(p); count++;
        const d = decode(rd32(p), p);
        if (d.k === 'b') {
          if (inF(d.target)) { leaders.add(d.target); work.push(d.target); }
          if (d.cond === 14) break;
          leaders.add(p + 4); p += 4; continue;
        }
        if ((d.k === 'bl' && !m.isStub(d.target)) || d.k === 'blxr' || d.k === 'svc') { leaders.add(p + 4); p += 4; continue; }
        if (d.k === 'xfer' && d.L && d.rt === 15 && d.rn === 15 && d.I && d.P && d.U && !d.W && d.st === 0 && d.sa === 2) {
          // a jump table: ldr pc, [pc, rX, lsl #2] followed by the table of addresses
          for (let t = p + 8, k = 0; k < 512; t += 4, k++) { const a = rd32(t); if (!inF(a) || a <= p) break; leaders.add(a); work.push(a); }
        }
        if (isTerminator(d, m)) { if (d.cond === 14) break; leaders.add(p + 4); }
        p += 4;
      }
    }
  }
  // ---- 2. cut the reached code into basic blocks
  const starts = [...leaders].filter(x => visited.has(x)).sort((x, y) => x - y);
  const region = new Set(starts);
  const blocksIn = [];
  for (const st of starts) {
    const insns = [];
    let p = st;
    for (let k = 0; k < (m.singleStep ? 1 : MAX_BLOCK) && p < textEnd; k++) {
      const d = decode(rd32(p), p);
      insns.push(d);
      p += 4;
      if (isTerminator(d, m) && d.cond === 14) break;
      if (region.has(p) || !visited.has(p)) break;
    }
    blocksIn.push({ start: st, insns, end: p });
  }
  const used = new Set(), written = new Set();
  let flagsUsed = false, fpFlagsUsed = false, hasMem = false;
  const reg = (n, pcv) => { if (n === 15) return '(' + ((pcv + 8) | 0) + ')'; used.add(n); return 'r' + n; };
  const wreg = (n) => { written.add(n); used.add(n); return 'r' + n; };
  const WB = '/*WB*/', RL = '/*RL*/';
  let curIdx = 0, bStart = entry, bLabel = 'L0', curNeed = FALL;
  const LIM = 100000;
  const emitExit = (target, indirectJump) => {
    if (!indirectJump && target === bStart && !m.singleStep) return 'it += ' + curIdx + '; if (it > ' + LIM + ') { next = ' + bStart + '; break D; } continue ' + bLabel + ';';
    if (!indirectJump && region.has(target) && !m.singleStep) return 'it += ' + curIdx + '; next = ' + target + '; continue D;';
    return 'it += ' + curIdx + '; next = ' + target + '; break D;';
  };
  const indirect = (expr, d, kind) => {
    // jump to a computed address: check for Thumb (bit 0) and alignment, detect "bx lr to itself"
    let s = 'it += ' + curIdx + '; next = ' + expr + '; S.jpc = ' + d.pc + ';';
    if (kind === 'bxlr') s += ' if (next === ' + (d.pc | 0) + ') { ip = ' + d.pc + '; throw S.LRLOOP; }';
    s += ' if (next & 3) { ip = ' + d.pc + '; ea = next; throw S.BADJUMP; } break D;';
    return s;
  };
  const SP_CHECK = (n) => (n === 13 ? ' if ((r13 >>> 0) < ' + L.stackLo + ' && (r13 >>> 0) >= ' + (L.stackLo - 0x200000) + ') { ip = ' + '__PC__' + '; throw S.SO; }' : '');
  const memRead = (bytes, signed, addr) => {
    hasMem = true;
    const o = '(' + addr + ') - ' + B;
    if (bytes === 4) return 'dv.getInt32(' + o + ', true)';
    if (bytes === 2) return signed ? 'dv.getInt16(' + o + ', true)' : 'dv.getUint16(' + o + ', true)';
    return signed ? 'dv.getInt8(' + o + ')' : 'dv.getUint8(' + o + ')';
  };
  const memWrite = (bytes, addr, val) => {
    hasMem = true;
    const o = '(' + addr + ') - ' + B;
    if (bytes === 4) return 'dv.setInt32(' + o + ', ' + val + ', true);';
    if (bytes === 2) return 'dv.setInt16(' + o + ', ' + val + ', true);';
    return 'dv.setInt8(' + o + ', ' + val + ');';
  };
  const WCHK = 'if (ea < ' + L.dataBase + ') throw S.WP; ';
  const ACHK = 'if (ea & 3) throw S.ALIGN; ';
  const roConst = (addr, bytes, signed) => {   // value in read-only memory (text/rodata): fold at translation time
    if (addr < B || addr + bytes > L.dataBase) return null;
    const o = addr - B;
    if (bytes === 4) return m.dv0.getInt32(o, true);
    if (bytes === 2) return signed ? m.dv0.getInt16(o, true) : m.dv0.getUint16(o, true);
    return signed ? m.dv0.getInt8(o) : m.dv0.getUint8(o);
  };
  // ---- VFP registers that can live in JavaScript variables (used only as numbers, never as raw bits, no s/d overlap)
  const vKinds = new Map();
  const note = (key, kind) => { let st = vKinds.get(key); if (!st) vKinds.set(key, st = new Set()); st.add(kind); };
  for (const blk of blocksIn) for (const d of blk.insns) {
    const S_ = (n, k) => note('s' + n, k), D_ = (n, k) => note('d' + n, k);
    const V = (n, k) => (d.dbl ? D_(n, k) : S_(n, k));
    switch (d.k) {
      case 'vf3': V(d.vd, 'f'); V(d.vn, 'f'); V(d.vm, 'f'); break;
      case 'vf2': V(d.vd, 'f'); V(d.vm, 'f'); break;
      case 'vcmp': V(d.vd, 'f'); if (!d.zero) V(d.vm, 'f'); break;
      case 'vmovi': V(d.vd, 'f'); break;
      case 'vcvt': {
        const [to, from] = d.f.split('.');
        if (to === 'f64') D_(d.vd, 'f'); else if (to === 'f32') S_(d.vd, 'f'); else S_(d.vd, 'b');
        if (from === 'f64') D_(d.vm, 'f'); else if (from === 'f32') S_(d.vm, 'f'); else S_(d.vm, 'b');
        break;
      }
      case 'vldr': V(d.reg, 'f'); break;
      case 'vldm': for (let i = 0; i < d.count; i++) V(d.reg + i, 'f'); break;
      case 'vmovs': S_(d.sn, 'b'); break;
      case 'vmov64': if (d.dbl) D_(d.vm, 'b'); else { S_(d.vm, 'b'); S_(d.vm + 1, 'b'); } break;
      case 'vmovsc': D_(d.dn, 'b'); break;
    }
  }
  const locS = new Set(), locD = new Set();
  if (!m.singleStep && !m.noVfpLocals) {
    for (let n = 0; n < 32; n++) { const k = vKinds.get('s' + n); if (k && !k.has('b') && !vKinds.has('d' + (n >> 1))) locS.add(n); }
    for (let n = 0; n < 16; n++) { const k = vKinds.get('d' + n); if (k && !k.has('b') && !vKinds.has('s' + 2 * n) && !vKinds.has('s' + (2 * n + 1))) locD.add(n); }
  }
  const usedS = new Set(), wrS = new Set(), usedD = new Set(), wrD = new Set();
  const sR = (n) => { if (locS.has(n)) { usedS.add(n); return 's' + n; } return 'VF[' + n + ']'; };
  const sW = (n, expr, exact) => { if (locS.has(n)) { usedS.add(n); wrS.add(n); return 's' + n + ' = ' + (exact ? expr : 'Math.fround(' + expr + ')') + ';'; } return 'VF[' + n + '] = ' + expr + ';'; };
  const dR = (n) => { if (locD.has(n)) { usedD.add(n); return 'd' + n; } return 'VD[' + n + ']'; };
  const dW = (n, expr) => { if (locD.has(n)) { usedD.add(n); wrD.add(n); return 'd' + n + ' = ' + expr + ';'; } return 'VD[' + n + '] = ' + expr + ';'; };
  // ---- 3. translate every block
  const liveCache = new Map();
  const liveAt = (t) => { if (!liveCache.has(t)) liveCache.set(t, flagsNeededAt(m, t)); return liveCache.get(t); };
  const cases = [];
  let total = 0;
  blocksIn.forEach((blk, bi) => {
    const insns = blk.insns;
    bStart = blk.start; bLabel = 'L' + bi;
    // flags needed after each instruction (backward pass)
    const needAfter = new Array(insns.length).fill(FALL);
    if (!m.singleStep && !m.exactFlags) {
      let live = liveAt(blk.end);
      for (let i = insns.length - 1; i >= 0; i--) {
        const d = insns[i];
        let exitLive = -1;
        if (d.k === 'b') exitLive = m.isCode(d.target) ? liveAt(d.target) : FALL;
        else if (d.k === 'bl' && m.isStub(d.target)) exitLive = -1;
        else if (isTerminator(d, m)) exitLive = FALL;
        if (exitLive >= 0) live = d.cond === 14 ? exitLive : (live | exitLive);
        needAfter[i] = live;
        const [rd, wr] = flagUse(d);
        live = (live & ~wr) | rd;
      }
    }
    const out = [];
    let iCount = 0;
    for (const d of insns) {
      curNeed = needAfter[iCount];
      iCount++; curIdx = iCount;
      const pc = d.pc;
      const cnd = d.cond;
      if (cnd !== 14) flagsUsed = true;
      let code = gen(d, pc);
      if (code === null) code = 'ip = ' + pc + '; throw S.UNDEF;';
      code = code.split('__PC__').join(String(pc));
      if (cnd !== 14) out.push('if (' + COND_JS[cnd] + ') { ' + code + ' }');
      else out.push(code);
    }
    const last = insns[insns.length - 1];
    if (!(isTerminator(last, m) && last.cond === 14)) { curIdx = iCount; out.push(emitExit(blk.end, false)); }
    total += iCount;
    cases.push('case ' + blk.start + ': ' + bLabel + ': for (;;) {\n' + out.join('\n') + '\n}');
  });
  const iCount = total;
  function op2(d, pc, needC) {
    if (d.imm !== undefined) return { v: String(d.imm), c: d.immRot ? (d.imm < 0 ? 'true' : 'false') : null };
    const rm = reg(d.rm, pc);
    if (d.rs !== undefined) {
      const rs = '(' + reg(d.rs, pc) + ' & 255)';
      const f = SH[d.st];
      return { v: 'H.' + f + 'R(' + rm + ', ' + rs + ')', c: needC ? 'H.' + f + 'C(' + rm + ', ' + rs + ', c)' : null };
    }
    const n = d.sa;
    switch (d.st) {
      case 0: if (n === 0) return { v: rm, c: null }; return { v: '(' + rm + ' << ' + n + ')', c: '((' + rm + ' >>> ' + (32 - n) + ') & 1) !== 0' };
      case 1: if (n === 0) return { v: '0', c: '(' + rm + ' < 0)' }; return { v: '((' + rm + ' >>> ' + n + ') | 0)', c: '((' + rm + ' >>> ' + (n - 1) + ') & 1) !== 0' };
      case 2: if (n === 0) return { v: '(' + rm + ' >> 31)', c: '(' + rm + ' < 0)' }; return { v: '(' + rm + ' >> ' + n + ')', c: '((' + rm + ' >> ' + (n - 1) + ') & 1) !== 0' };
      case 3: if (n === 0) { flagsUsed = true; return { v: '((c ? -2147483648 : 0) | (' + rm + ' >>> 1))', c: '((' + rm + ' & 1) !== 0)' }; }
        return { v: '((' + rm + ' >>> ' + n + ') | (' + rm + ' << ' + (32 - n) + '))', c: '((' + rm + ' >>> ' + (n - 1) + ') & 1) !== 0' };
    }
  }
  function addrOffset(d, pc) {
    // register offset with immediate shift (LDR/STR)
    const rm = reg(d.rm, pc), n = d.sa;
    switch (d.st) {
      case 0: return n ? '(' + rm + ' << ' + n + ')' : rm;
      case 1: return n ? '((' + rm + ' >>> ' + n + ') | 0)' : '0';
      case 2: return '(' + rm + ' >> ' + (n || 31) + ')';
      case 3: if (n === 0) { flagsUsed = true; return '((c ? -2147483648 : 0) | (' + rm + ' >>> 1))'; } return '((' + rm + ' >>> ' + n + ') | (' + rm + ' << ' + (32 - n) + '))';
    }
  }
  function gen(d, pc) {
    switch (d.k) {
      case 'nop': return '';
      case 'undef': return 'ip = ' + pc + '; ea = ' + (d.w | 0) + '; throw S.UNDEF;';
      case 'udf': return 'ip = ' + pc + '; throw S.UDF;';
      case 'movw': return d.rd === 15 ? null : wreg(d.rd) + ' = ' + d.imm + ';';
      case 'movt': { if (d.rd === 15) return null; const r = reg(d.rd, pc); wreg(d.rd); return r + ' = (' + r + ' & 65535) | ' + ((d.imm << 16) | 0) + ';'; }
      case 'dp': return genDP(d, pc);
      case 'mul': return genMul(d, pc);
      case 'clz': return wreg(d.rd) + ' = Math.clz32(' + reg(d.rm, pc) + ');';
      case 'rev': return wreg(d.rd) + ' = H.' + d.f + '(' + reg(d.rm, pc) + ');';
      case 'sdiv': { const a = reg(d.rn, pc), b = reg(d.rm, pc); return wreg(d.rd) + ' = ' + b + ' === 0 ? 0 : (' + a + ' / ' + b + ') | 0;'; }
      case 'udiv': { const a = reg(d.rn, pc), b = reg(d.rm, pc); return wreg(d.rd) + ' = ' + b + ' === 0 ? 0 : ((' + a + ' >>> 0) / (' + b + ' >>> 0)) | 0;'; }
      case 'smmul': {
        const a = reg(d.rn, pc), b = reg(d.rm, pc);
        let s = 'H.smul(' + a + ', ' + b + '); ';
        if (d.sub) { const ra = reg(d.ra, pc); s += '{ const l_ = (0 - (H.lo >>> 0)); const borrow_ = H.lo !== 0 ? 1 : 0; let lo_ = (-H.lo) | 0, hi_ = (' + ra + ' - H.hi - borrow_) | 0; ' + (d.R ? 'if ((lo_ >>> 0) >= 2147483648) hi_ = (hi_ + 1) | 0; ' : '') + wreg(d.rd) + ' = hi_; }'; return s; }
        if (d.ra !== 15) { const ra = reg(d.ra, pc); s += 'H.acc(0, ' + ra + '); '; }
        if (d.R) s += 'H.acc(-2147483648, 0); ';
        return s + wreg(d.rd) + ' = H.hi;';
      }
      case 'smulxy': {
        const a = reg(d.rn, pc), b = reg(d.rm, pc);
        const x = d.N ? '(' + a + ' >> 16)' : '((' + a + ' << 16) >> 16)', y = d.M ? '(' + b + ' >> 16)' : '((' + b + ' << 16) >> 16)';
        return wreg(d.rd) + ' = (' + x + ' * ' + y + (d.acc ? ' + ' + reg(d.ra, pc) : '') + ') | 0;';
      }
      case 'ext': {
        const rm = reg(d.rm, pc);
        const v = d.rot ? '((' + rm + ' >>> ' + d.rot + ') | (' + rm + ' << ' + (32 - d.rot) + '))' : rm;
        const e = d.sign ? (d.half ? '((' + v + ' << 16) >> 16)' : '((' + v + ' << 24) >> 24)') : (d.half ? '(' + v + ' & 65535)' : '(' + v + ' & 255)');
        return wreg(d.rd) + ' = ' + (d.rn !== 15 ? '(' + reg(d.rn, pc) + ' + ' + e + ') | 0' : e) + ';';
      }
      case 'bfi': {
        if (d.msb < d.lsb) return null;
        const width = d.msb - d.lsb + 1;
        const mask = width === 32 ? -1 : ((((1 << width) >>> 0) - 1) << d.lsb) | 0;
        const rd = reg(d.rd, pc); wreg(d.rd);
        if (d.rn === 15) return rd + ' = ' + rd + ' & ' + (~mask) + ';';
        return rd + ' = (' + rd + ' & ' + (~mask) + ') | ((' + reg(d.rn, pc) + ' << ' + d.lsb + ') & ' + mask + ');';
      }
      case 'ubfx': case 'sbfx': {
        const width = d.wm1 + 1; if (d.lsb + width > 32) return null;
        const rn = reg(d.rn, pc);
        if (d.k === 'ubfx') return wreg(d.rd) + ' = ' + (width === 32 ? rn : '(' + rn + ' >>> ' + d.lsb + ') & ' + (width === 31 ? 0x7fffffff : ((1 << width) - 1))) + ';';
        return wreg(d.rd) + ' = (' + rn + ' << ' + (32 - d.lsb - width) + ') >> ' + (32 - width) + ';';
      }
      case 'xfer': return genXfer(d, pc);
      case 'xfer2': return genXfer2(d, pc);
      case 'ldm': return genLdm(d, pc);
      case 'b': {
        if (m.isStub(d.target)) return 'it += ' + curIdx + '; next = ' + d.target + '; break D;';
        if (!m.isCode(d.target)) return 'ip = ' + pc + '; ea = ' + d.target + '; throw S.BADJUMP;';
        return emitExit(d.target, false);
      }
      case 'bl': {
        const ret = (pc + 4) | 0;
        if (m.isStub(d.target) && INLINE[m.prog.stubs[(d.target - LAYOUT.STUB_BASE) >> 2]] && !m.noInline) {
          const name = m.prog.stubs[(d.target - LAYOUT.STUB_BASE) >> 2];
          const [kind, code] = INLINE[name];
          // kind: 'f' float result in s0, 'd' double result in d0, 'i' int result in r0
          let s = wreg(14) + ' = ' + ret + '; /*WBV*/ ';
          if (kind === 'i') s += code.split('$0').join(reg(0, pc)).replace('$W', wreg(0)) + ' ';
          else s += code + ' ';
          for (const r of [1, 2, 3, 12]) s += wreg(r) + ' = ' + CLOB + '; ';
          if (kind !== 'i') s += wreg(0) + ' = ' + CLOB + '; ';
          for (let i = kind === 'd' ? 2 : 1; i < 16; i++) s += 'VI[' + i + '] = ' + CLOB + '; ';
          if (kind === 'i') s += 'VI[0] = ' + CLOB + ';';
          return s + ' /*RLV*/';
        }
        if (m.isStub(d.target)) {
          return wreg(14) + ' = ' + ret + '; ' + WB + ' ip = ' + pc + '; S.callLib(' + ((d.target - LAYOUT.STUB_BASE) >> 2) + ', ' + pc + '); dv = S.dv; ' + RL;
        }
        if (!m.isCode(d.target)) return 'ip = ' + pc + '; ea = ' + d.target + '; throw S.BADJUMP;';
        return wreg(14) + ' = ' + ret + '; S.cpush = ' + ret + '; it += ' + curIdx + '; next = ' + d.target + '; break D;';
      }
      case 'bx': return indirect(reg(d.rm, pc), d, d.rm === 14 ? 'bxlr' : 'bx');
      case 'blxr': { const t = reg(d.rm, pc); return 'ea = ' + t + '; ' + wreg(14) + ' = ' + ((pc + 4) | 0) + '; S.cpush = ' + ((pc + 4) | 0) + '; ' + indirect('ea', d, 'blx'); }
      case 'svc': return wreg(0) + ' = r0; ' + WB + ' ip = ' + pc + '; S.svc(' + d.imm + ', ' + pc + '); dv = S.dv; ' + RL;
      // ---- VFP (registers used only as numbers live in JavaScript variables: sN / dN; others in the VF/VD/VI arrays)
      case 'vf3': {
        const R_ = d.dbl ? dR : sR, W_ = d.dbl ? dW : sW, fr = d.dbl ? '' : 'Math.fround';
        const D = R_(d.vd), N = R_(d.vn), M = R_(d.vm);
        const prod = fr + '(' + N + ' * ' + M + ')';
        switch (d.f) {
          case 'vadd': return W_(d.vd, N + ' + ' + M);
          case 'vsub': return W_(d.vd, N + ' - ' + M);
          case 'vmul': return W_(d.vd, N + ' * ' + M);
          case 'vdiv': return W_(d.vd, N + ' / ' + M);
          case 'vnmul': return W_(d.vd, '-(' + N + ' * ' + M + ')');
          case 'vmla': return W_(d.vd, D + ' + ' + prod);
          case 'vmls': return W_(d.vd, D + ' - ' + prod);
          case 'vnmla': return W_(d.vd, '-' + D + ' - ' + prod);
          case 'vnmls': return W_(d.vd, '-' + D + ' + ' + prod);
        }
        return null;
      }
      case 'vf2': {
        if (d.dbl) {
          if (locD.has(d.vd) || locD.has(d.vm)) {
            const M = dR(d.vm);
            switch (d.f) { case 'vmov': return dW(d.vd, M); case 'vabs': return dW(d.vd, 'Math.abs(' + M + ')'); case 'vneg': return dW(d.vd, '-' + M); case 'vsqrt': return dW(d.vd, 'Math.sqrt(' + M + ')'); }
          }
          const dd = d.vd * 2, mm = d.vm * 2;
          switch (d.f) {
            case 'vmov': return 'VI[' + dd + '] = VI[' + mm + ']; VI[' + (dd + 1) + '] = VI[' + (mm + 1) + '];';
            case 'vabs': return 'VI[' + dd + '] = VI[' + mm + ']; VI[' + (dd + 1) + '] = VI[' + (mm + 1) + '] & 2147483647;';
            case 'vneg': return 'VI[' + dd + '] = VI[' + mm + ']; VI[' + (dd + 1) + '] = VI[' + (mm + 1) + '] ^ -2147483648;';
            case 'vsqrt': return 'VD[' + d.vd + '] = Math.sqrt(VD[' + d.vm + ']);';
          }
        }
        if (locS.has(d.vd) || locS.has(d.vm)) {
          const M = sR(d.vm);
          switch (d.f) { case 'vmov': return sW(d.vd, M, true); case 'vabs': return sW(d.vd, 'Math.abs(' + M + ')', true); case 'vneg': return sW(d.vd, '-' + M, true); case 'vsqrt': return sW(d.vd, 'Math.sqrt(' + M + ')'); }
        }
        switch (d.f) {
          case 'vmov': return 'VI[' + d.vd + '] = VI[' + d.vm + '];';
          case 'vabs': return 'VI[' + d.vd + '] = VI[' + d.vm + '] & 2147483647;';
          case 'vneg': return 'VI[' + d.vd + '] = VI[' + d.vm + '] ^ -2147483648;';
          case 'vsqrt': return 'VF[' + d.vd + '] = Math.sqrt(VF[' + d.vm + ']);';
        }
        return null;
      }
      case 'vcmp': {
        fpFlagsUsed = true;
        const R_ = d.dbl ? dR : sR;
        const b = d.zero ? '0' : R_(d.vm);
        return '{ const x_ = ' + R_(d.vd) + ', y_ = ' + b + '; if (x_ < y_) { fn = true; fz = false; fc = false; fv = false; } else if (x_ === y_) { fn = false; fz = true; fc = true; fv = false; } else if (x_ > y_) { fn = false; fz = false; fc = true; fv = false; } else { fn = false; fz = false; fc = true; fv = true; } }';
      }
      case 'vmovi': {
        const val = K.vfpImmValue(d.imm);
        return d.dbl ? dW(d.vd, String(val)) : sW(d.vd, String(val), true);
      }
      case 'vcvt': {
        switch (d.f) {
          case 'f64.f32': return dW(d.vd, sR(d.vm));
          case 'f32.f64': return sW(d.vd, dR(d.vm));
          case 'f32.s32': return sW(d.vd, 'VI[' + d.vm + ']');
          case 'f32.u32': return sW(d.vd, '(VI[' + d.vm + '] >>> 0)');
          case 'f64.s32': return dW(d.vd, 'VI[' + d.vm + ']');
          case 'f64.u32': return dW(d.vd, '(VI[' + d.vm + '] >>> 0)');
          case 's32.f32': return 'VI[' + d.vd + '] = H.f2s' + (d.rz ? '' : 'R') + '(' + sR(d.vm) + ');';
          case 'u32.f32': return 'VI[' + d.vd + '] = H.f2u' + (d.rz ? '' : 'R') + '(' + sR(d.vm) + ');';
          case 's32.f64': return 'VI[' + d.vd + '] = H.f2s' + (d.rz ? '' : 'R') + '(' + dR(d.vm) + ');';
          case 'u32.f64': return 'VI[' + d.vd + '] = H.f2u' + (d.rz ? '' : 'R') + '(' + dR(d.vm) + ');';
        }
        return null;
      }
      case 'vldr': {
        const off = d.U ? d.off : -d.off;
        const k = d.dbl ? d.reg * 2 : d.reg;
        const loc = d.dbl ? locD.has(d.reg) : locS.has(d.reg);
        if (d.rn === 15 && d.L) {
          const a = (((pc + 8) & ~3) + off) | 0;
          const v0 = roConst(a, 4), v1 = d.dbl ? roConst(a + 4, 4) : 0;
          if (v0 !== null && v1 !== null && !(a & 3)) {
            if (loc) { SCRI[0] = v0; SCRI[1] = v1; return d.dbl ? dW(d.reg, String(SCRD[0])) : sW(d.reg, String(SCRF[0]), true); }
            return 'VI[' + k + '] = ' + v0 + ';' + (d.dbl ? ' VI[' + (k + 1) + '] = ' + v1 + ';' : '');
          }
        }
        const base = d.rn === 15 ? String(((pc + 8) & ~3) | 0) : reg(d.rn, pc);
        let s = 'ip = ' + pc + '; ea = (' + base + ' + ' + off + ') | 0; ' + ACHK;
        hasMem = true;
        if (loc) {
          if (d.L) return s + (d.dbl ? dW(d.reg, 'dv.getFloat64(ea - ' + B + ', true)') : sW(d.reg, 'dv.getFloat32(ea - ' + B + ', true)', true));
          return s + WCHK + (d.dbl ? 'dv.setFloat64(ea - ' + B + ', ' + dR(d.reg) + ', true);' : 'dv.setFloat32(ea - ' + B + ', ' + sR(d.reg) + ', true);');
        }
        if (d.L) s += 'VI[' + k + '] = ' + memRead(4, true, 'ea') + ';' + (d.dbl ? ' VI[' + (k + 1) + '] = ' + memRead(4, true, 'ea + 4') + ';' : '');
        else s += WCHK + memWrite(4, 'ea', 'VI[' + k + ']') + (d.dbl ? ' ' + memWrite(4, 'ea + 4', 'VI[' + (k + 1) + ']') : '');
        return s;
      }
      case 'vldm': {
        const words = d.dbl ? d.count * 2 : d.count;
        const rn = reg(d.rn, pc);
        let s = 'ip = ' + pc + '; ea = ' + (d.P ? '(' + rn + ' - ' + words * 4 + ') | 0' : rn) + '; ' + ACHK;
        if (!d.L) s += WCHK;
        hasMem = true;
        for (let i = 0; i < d.count; i++) {
          const r = d.reg + i;
          const off = (d.dbl ? 8 : 4) * i;
          if (d.dbl && locD.has(r)) s += d.L ? dW(r, 'dv.getFloat64(ea + ' + off + ' - ' + B + ', true)') + ' ' : 'dv.setFloat64(ea + ' + off + ' - ' + B + ', ' + dR(r) + ', true); ';
          else if (!d.dbl && locS.has(r)) s += d.L ? sW(r, 'dv.getFloat32(ea + ' + off + ' - ' + B + ', true)', true) + ' ' : 'dv.setFloat32(ea + ' + off + ' - ' + B + ', ' + sR(r) + ', true); ';
          else {
            const k = d.dbl ? r * 2 : r;
            const nw = d.dbl ? 2 : 1;
            for (let j = 0; j < nw; j++) s += d.L ? 'VI[' + (k + j) + '] = ' + memRead(4, true, 'ea + ' + (off + 4 * j)) + '; ' : memWrite(4, 'ea + ' + (off + 4 * j), 'VI[' + (k + j) + ']') + ' ';
          }
        }
        if (d.W) { wreg(d.rn); s += rn + ' = (' + rn + (d.U ? ' + ' : ' - ') + words * 4 + ') | 0;' + SP_CHECK(d.rn); }
        return s;
      }
      case 'vmovs': return d.toArm ? (d.rt === 15 ? null : wreg(d.rt) + ' = VI[' + d.sn + '];') : 'VI[' + d.sn + '] = ' + reg(d.rt, pc) + ';';
      case 'vmov64': {
        const k = d.dbl ? d.vm * 2 : d.vm;
        if (d.toArm) { if (d.rt === 15 || d.rt2 === 15) return null; return wreg(d.rt) + ' = VI[' + k + ']; ' + wreg(d.rt2) + ' = VI[' + (k + 1) + '];'; }
        return 'VI[' + k + '] = ' + reg(d.rt, pc) + '; VI[' + (k + 1) + '] = ' + reg(d.rt2, pc) + ';';
      }
      case 'vmovsc': {
        if (d.dn > 15) return null;
        const k = d.dn * 2 + d.x;
        return d.toArm ? wreg(d.rt) + ' = VI[' + k + '];' : 'VI[' + k + '] = ' + reg(d.rt, pc) + ';';
      }
      case 'vmrs': {
        fpFlagsUsed = true;
        if (d.rt === 15) { flagsUsed = true; return 'n = fn; z = fz; c = fc; v = fv;'; }
        return wreg(d.rt) + ' = (fn ? -2147483648 : 0) | (fz ? 1073741824 : 0) | (fc ? 536870912 : 0) | (fv ? 268435456 : 0) | S.fpscr;';
      }
      case 'vmsr': { fpFlagsUsed = true; const r = reg(d.rt, pc); return 'fn = ' + r + ' < 0; fz = (' + r + ' & 1073741824) !== 0; fc = (' + r + ' & 536870912) !== 0; fv = (' + r + ' & 268435456) !== 0; S.fpscr = ' + r + ' & 268435455;'; }
    }
    return null;
  }
  function genDP(d, pc) {
    const opn = d.op;
    const logical = [0, 1, 8, 9, 12, 13, 14, 15].includes(opn);
    const o2 = op2(d, pc, d.s && logical);
    const a = (opn === 13 || opn === 15) ? null : reg(d.rn, pc);
    const b = o2.v;
    let expr;
    if (d.s || opn === 5 || opn === 6 || opn === 7) flagsUsed = true;
    switch (opn) {
      case 0: case 8: expr = a + ' & ' + b; break;
      case 1: case 9: expr = a + ' ^ ' + b; break;
      case 2: case 10: expr = '(' + a + ' - ' + b + ') | 0'; break;
      case 3: expr = '(' + b + ' - ' + a + ') | 0'; break;
      case 4: case 11: expr = '(' + a + ' + ' + b + ') | 0'; break;
      case 5: expr = '(' + a + ' + ' + b + ' + (c ? 1 : 0)) | 0'; break;
      case 6: expr = '(' + a + ' - ' + b + ' - (c ? 0 : 1)) | 0'; break;
      case 7: expr = '(' + b + ' - ' + a + ' - (c ? 0 : 1)) | 0'; break;
      case 12: expr = a + ' | ' + b; break;
      case 13: expr = b; break;
      case 14: expr = a + ' & ~' + b; break;
      case 15: expr = '~' + b; break;
    }
    const test = opn >= 8 && opn <= 11;
    if (d.rd === 15 && !test) {
      if (d.s) return null; // exception return: not supported
      return indirect('(' + expr + ')', d, (opn === 13 && d.imm === undefined && d.rm === 14 && d.sa === 0 && d.st === 0) ? 'bxlr' : 'dp');
    }
    const dst = test ? null : wreg(d.rd);
    const spc = dst ? SP_CHECK(d.rd) : '';
    if (!d.s) return dst + ' = ' + expr + ';' + spc;
    if (logical) {
      let s = '{ const t_ = ' + expr + '; ' + (curNeed & FN ? 'n = t_ < 0; ' : '') + (curNeed & FZ ? 'z = t_ === 0; ' : '') + (o2.c && (curNeed & FC || d.rs !== undefined) ? 'c = ' + o2.c + '; ' : '');
      return s + (dst ? dst + ' = t_; ' : '') + '}' + spc;
    }
    // arithmetic with flags
    const x = 'x_', y = 'y_';
    let s = '{ const x_ = ' + (opn === 3 || opn === 7 ? b : a) + ', y_ = ' + (opn === 3 || opn === 7 ? a : b) + '; ';
    const NC = curNeed & FC, NV = curNeed & FV;
    switch (opn) {
      case 4: case 11: s += 'const t_ = (x_ + y_) | 0; ' + (NC ? 'c = (x_ >>> 0) + (y_ >>> 0) > 4294967295; ' : '') + (NV ? 'v = ((x_ ^ t_) & (y_ ^ t_)) < 0; ' : ''); break;
      case 2: case 10: case 3: s += 'const t_ = (x_ - y_) | 0; ' + (NC ? 'c = (x_ >>> 0) >= (y_ >>> 0); ' : '') + (NV ? 'v = ((x_ ^ y_) & (x_ ^ t_)) < 0; ' : ''); break;
      case 5: s += 'const ci_ = c ? 1 : 0, t_ = (x_ + y_ + ci_) | 0; ' + (NC ? 'c = (x_ >>> 0) + (y_ >>> 0) + ci_ > 4294967295; ' : '') + (NV ? 'v = ((x_ ^ t_) & (y_ ^ t_)) < 0; ' : ''); break;
      case 6: case 7: s += 'const bi_ = c ? 0 : 1, t_ = (x_ - y_ - bi_) | 0; ' + (NC ? 'c = (x_ >>> 0) - (y_ >>> 0) - bi_ >= 0; ' : '') + (NV ? 'v = ((x_ ^ y_) & (x_ ^ t_)) < 0; ' : ''); break;
    }
    s += (curNeed & FN ? 'n = t_ < 0; ' : '') + (curNeed & FZ ? 'z = t_ === 0; ' : '') + (dst ? dst + ' = t_; ' : '') + '}';
    return s + spc;
  }
  function genMul(d, pc) {
    const a = reg(d.rn, pc), b = reg(d.rm, pc);
    if (d.s) flagsUsed = true;
    switch (d.op) {
      case 0: case 1: case 3: {
        const e = d.op === 0 ? 'Math.imul(' + a + ', ' + b + ')' : d.op === 1 ? '(Math.imul(' + a + ', ' + b + ') + ' + reg(d.ra, pc) + ') | 0' : '(' + reg(d.ra, pc) + ' - Math.imul(' + a + ', ' + b + ')) | 0';
        const dst = wreg(d.rd);
        return d.s ? dst + ' = ' + e + '; n = ' + dst + ' < 0; z = ' + dst + ' === 0;' : dst + ' = ' + e + ';';
      }
      case 4: case 5: case 6: case 7: {
        const signed = d.op >= 6, accum = d.op & 1;
        let s = 'H.' + (signed ? 'smul' : 'umul') + '(' + a + ', ' + b + '); ';
        if (accum) s += 'H.acc(' + reg(d.ra, pc) + ', ' + reg(d.rd, pc) + '); ';
        s += wreg(d.ra) + ' = H.lo; ' + wreg(d.rd) + ' = H.hi;';
        if (d.s) s += ' n = H.hi < 0; z = (H.hi | H.lo) === 0;';
        return s;
      }
    }
    return null;
  }
  function genXfer(d, pc) {
    const bytes = d.B ? 1 : 4;
    if (d.rn === 15 && !d.I && d.P && !d.W && d.L) {
      const a = (pc + 8 + (d.U ? d.imm : -d.imm)) | 0;
      const v = roConst(a, bytes, false);
      if (v !== null) {
        if (d.rt === 15) return indirect(String(v), d, 'ldrpc');
        return wreg(d.rt) + ' = ' + v + ';';
      }
    }
    const base = reg(d.rn, pc);
    const off = d.I ? addrOffset(d, pc) : String(d.imm);
    const sign = d.U ? ' + ' : ' - ';
    const addr = d.P ? (off === '0' ? base : '(' + base + sign + off + ') | 0') : base;
    let s = 'ip = ' + pc + '; ea = ' + addr + '; ';
    const wbExpr = d.P ? 'ea' : '(' + base + sign + off + ') | 0';
    const doWB = !d.P || d.W;
    if (d.L) {
      s += 'const t_ = ' + memRead(bytes, false, 'ea') + '; ';
      if (doWB && d.rn !== 15) { s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn) + ' '; }
      if (d.rt === 15) return '{ ' + s + indirect('t_', d, 'ldrpc') + ' }';
      return '{ ' + s + wreg(d.rt) + ' = t_; }';
    }
    const val = d.rt === 15 ? String((pc + 8) | 0) : reg(d.rt, pc);
    s += WCHK + memWrite(bytes, 'ea', val) + ' ';
    if (doWB && d.rn !== 15) s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn);
    return s;
  }
  function genXfer2(d, pc) {
    const base = reg(d.rn, pc);
    const off = d.I ? String(d.imm) : reg(d.rm, pc);
    const sign = d.U ? ' + ' : ' - ';
    const addr = d.P ? (off === '0' ? base : '(' + base + sign + off + ') | 0') : base;
    const wbExpr = d.P ? 'ea' : '(' + base + sign + off + ') | 0';
    const doWB = !d.P || d.W;
    const dual = !d.L && d.sh >= 2;
    if (d.rn === 15 && d.I && d.P && !d.W && d.L) {
      const a = (pc + 8 + (d.U ? d.imm : -d.imm)) | 0;
      const v = roConst(a, 2, d.sh === 3);
      if (d.sh === 1 || d.sh === 3) { if (v !== null && d.rt !== 15) return wreg(d.rt) + ' = ' + v + ';'; }
      else if (d.sh === 2) { const v8 = roConst(a, 1, true); if (v8 !== null && d.rt !== 15) return wreg(d.rt) + ' = ' + v8 + ';'; }
    }
    let s = 'ip = ' + pc + '; ea = ' + addr + '; ';
    if (dual) {
      if (d.rt & 1 || d.rt === 14) return null;
      s += ACHK;
      if (d.sh === 2) { // LDRD
        s += 'const t0_ = ' + memRead(4, true, 'ea') + ', t1_ = ' + memRead(4, true, 'ea + 4') + '; ';
        if (doWB) s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn) + ' ';
        return '{ ' + s + wreg(d.rt) + ' = t0_; ' + wreg(d.rt + 1) + ' = t1_; }';
      }
      s += WCHK + memWrite(4, 'ea', reg(d.rt, pc)) + ' ' + memWrite(4, 'ea + 4', reg(d.rt + 1, pc)) + ' ';
      if (doWB) s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn);
      return s;
    }
    if (d.rt === 15) return null;
    if (d.L) {
      const rd = d.sh === 1 ? memRead(2, false, 'ea') : d.sh === 2 ? memRead(1, true, 'ea') : memRead(2, true, 'ea');
      s += 'const t_ = ' + rd + '; ';
      if (doWB) s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn) + ' ';
      return '{ ' + s + wreg(d.rt) + ' = t_; }';
    }
    s += WCHK + memWrite(2, 'ea', reg(d.rt, pc)) + ' ';
    if (doWB) s += wreg(d.rn) + ' = ' + wbExpr + ';' + SP_CHECK(d.rn);
    return s;
  }
  function genLdm(d, pc) {
    const regs = []; for (let i = 0; i < 16; i++) if (d.list & (1 << i)) regs.push(i);
    const n = regs.length;
    const rn = reg(d.rn, pc);
    // lowest address
    const start = d.U ? (d.P ? '(' + rn + ' + 4) | 0' : rn) : (d.P ? '(' + rn + ' - ' + 4 * n + ') | 0' : '(' + rn + ' - ' + (4 * n - 4) + ') | 0');
    let s = 'ip = ' + pc + '; ea = ' + start + '; ' + ACHK;
    const newBase = '(' + rn + (d.U ? ' + ' : ' - ') + 4 * n + ') | 0';
    if (d.L) {
      s += '{ ';
      regs.forEach((r, i) => { s += 'const t' + i + '_ = ' + memRead(4, true, 'ea + ' + 4 * i) + '; '; });
      if (d.W) s += wreg(d.rn) + ' = ' + newBase + ';' + SP_CHECK(d.rn) + ' ';
      let pcLoad = null;
      regs.forEach((r, i) => { if (r === 15) pcLoad = 't' + i + '_'; else s += wreg(r) + ' = t' + i + '_; '; });
      if (pcLoad) s += indirect(pcLoad, d, 'ldmpc');
      return s + ' }';
    }
    s += WCHK;
    if (d.W && d.rn === 13 && !d.U) s += 'if ((ea >>> 0) < ' + L.stackLo + ' && (ea >>> 0) >= ' + (L.stackLo - 0x200000) + ') throw S.SO; ';
    regs.forEach((r, i) => { s += memWrite(4, 'ea + ' + 4 * i, r === 15 ? String((pc + 8) | 0) : reg(r, pc)) + ' '; });
    if (d.W) s += wreg(d.rn) + ' = ' + newBase + ';';
    return s;
  }
  // ---- assemble the function
  const regsAll = [...used].sort((a, b) => a - b);
  const wr = [...written].sort((a, b) => a - b);
  const wbRegs = wr.map(r => 'R[' + r + '] = r' + r + ';').join(' ');
  const wbFlags = flagsUsed ? ' FL[0] = n ? 1 : 0; FL[1] = z ? 1 : 0; FL[2] = c ? 1 : 0; FL[3] = v ? 1 : 0;' : '';
  const wbFp = fpFlagsUsed ? ' FL[4] = fn ? 1 : 0; FL[5] = fz ? 1 : 0; FL[6] = fc ? 1 : 0; FL[7] = fv ? 1 : 0;' : '';
  const rlRegs = regsAll.map(r => 'r' + r + ' = R[' + r + '];').join(' ');
  const rlFlags = flagsUsed ? ' n = FL[0] !== 0; z = FL[1] !== 0; c = FL[2] !== 0; v = FL[3] !== 0;' : '';
  const rlFp = fpFlagsUsed ? ' fn = FL[4] !== 0; fz = FL[5] !== 0; fc = FL[6] !== 0; fv = FL[7] !== 0;' : '';
  const wbV = [...wrS].map(n => 'VF[' + n + '] = s' + n + ';').join(' ') + ' ' + [...wrD].map(n => 'VD[' + n + '] = d' + n + ';').join(' ');
  const rlV = [...usedS].map(n => 's' + n + ' = VF[' + n + '];').join(' ') + ' ' + [...usedD].map(n => 'd' + n + ' = VD[' + n + '];').join(' ');
  let body = cases.join('\n');
  body = body.split(WB).join(wbRegs + wbFlags + wbFp + ' ' + wbV).split(RL).join(rlRegs + rlFlags + rlFp + ' ' + rlV).split('/*WBV*/').join(wbV).split('/*RLV*/').join(rlV);
  const decl = (regsAll.length ? 'let ' + regsAll.map(r => 'r' + r + ' = R[' + r + ']').join(', ') + ';\n' : '') +
    (flagsUsed ? 'let n = FL[0] !== 0, z = FL[1] !== 0, c = FL[2] !== 0, v = FL[3] !== 0;\n' : '') +
    (fpFlagsUsed ? 'let fn = FL[4] !== 0, fz = FL[5] !== 0, fc = FL[6] !== 0, fv = FL[7] !== 0;\n' : '') +
    (usedS.size ? 'let ' + [...usedS].map(n => 's' + n + ' = VF[' + n + ']').join(', ') + ';\n' : '') +
    (usedD.size ? 'let ' + [...usedD].map(n => 'd' + n + ' = VD[' + n + ']').join(', ') + ';\n' : '');
  const src = 'const R = S.R, FL = S.FL, VI = S.VI, VF = S.VF, VD = S.VD, H = S.H;\nlet dv = S.dv;\n' + decl +
    'let ea = 0, ip = next, it = 0;\n' +
    'try {\nD: for (;;) {\nif (it > ' + LIM + ') break D;\nswitch (next) {\n' + body + '\ndefault: break D;\n}\n}\n} catch (e) {\n' + wbRegs + ' ' + wbV + '\nS.steps += it;\nreturn S.fault(e, ip, ea);\n}\n' +
    wbRegs + wbFlags + wbFp + ' ' + wbV + '\nS.steps += it;\nreturn next;';
  let fn;
  try { fn = new Function('return function rgn_' + (entry >>> 0).toString(16) + '(S, next) {\n' + src + '\n}')(); }
  catch (e) { throw new Error('internal translator error at ' + hex(entry) + ': ' + e.message + '\n' + src); }
  fn.src = src; fn.count = iCount; fn.starts = starts;
  return fn;
}
function isTerminator(d, m) {
  switch (d.k) {
    case 'b': case 'bx': case 'blxr': case 'udf': case 'undef': return true;
    case 'bl': return !m.isStub(d.target);
    case 'dp': return d.rd === 15 && !(d.op >= 8 && d.op <= 11);
    case 'xfer': return d.L && d.rt === 15;
    case 'ldm': return d.L && (d.list & 0x8000) !== 0;
    case 'svc': return false;
  }
  return false;
}
K.translate = translate;

// ---------------- the interpreter ----------------
// The same instructions as the translator above, run one by one without generating any code. The machine uses it
// where a browser does not allow new Function (a strict Content Security Policy), and the tests use it to check
// the translator. It is several times slower.
let EVAL_OK = true;
try { EVAL_OK = new Function('return 1')() === 1; } catch (e) { EVAL_OK = false; }
K.EVAL_OK = EVAL_OK;
const SHR = [H.lslR, H.lsrR, H.asrR, H.rorR], SHC = [H.lslC, H.lsrC, H.asrC, H.rorC];
function condPass(cond, FL) {
  const n = FL[0] !== 0, z = FL[1] !== 0, c = FL[2] !== 0, v = FL[3] !== 0;
  switch (cond) {
    case 0: return z; case 1: return !z; case 2: return c; case 3: return !c;
    case 4: return n; case 5: return !n; case 6: return v; case 7: return !v;
    case 8: return c && !z; case 9: return !c || z; case 10: return n === v; case 11: return n !== v;
    case 12: return !z && n === v; case 13: return z || n !== v; case 14: return true;
  }
  return false;
}
const KIND_NO = {};
['nop', 'movw', 'movt', 'dp', 'mul', 'clz', 'rev', 'sdiv', 'udiv', 'smmul', 'smulxy', 'ext', 'bfi', 'ubfx', 'sbfx', 'xfer', 'xfer2', 'ldm', 'b', 'bl', 'bx', 'blxr', 'svc', 'udf', 'vf3', 'vf2', 'vcmp', 'vmovi', 'vcvt', 'vldr', 'vldm', 'vmovs', 'vmov64', 'vmovsc', 'vmrs', 'vmsr'].forEach((k, i) => { KIND_NO[k] = i; });
const FN_NO = {};
['vadd', 'vsub', 'vmul', 'vdiv', 'vnmul', 'vmla', 'vmls', 'vnmla', 'vnmls', 'vmov', 'vabs', 'vneg', 'vsqrt', 'f64.f32', 'f32.f64', 'f32.s32', 'f32.u32', 'f64.s32', 'f64.u32', 's32.f32', 'u32.f32', 's32.f64', 'u32.f64'].forEach((k, i) => { FN_NO[k] = i; });
function makeInterp(m) {
  const L = m.layout, B = L.textBase, tw = L.textWords;
  const dataBase = L.dataBase, stackLo = L.stackLo, soLow = L.stackLo - 0x200000;
  const STUB = LAYOUT.STUB_BASE;
  const S = m.S, R = S.R, FL = S.FL, VI = S.VI, VF = S.VF, VD = S.VD;
  const dc = new Array(tw);
  const tmp = new Int32Array(16);
  const maxN = m.singleStep ? 1 : 256;
  let cpc = 0;
  const rv = (n) => (n === 15 ? (cpc + 8) | 0 : R[n]);
  const spCheck = (n) => { if (n === 13 && (R[13] >>> 0) < stackLo && (R[13] >>> 0) >= soLow) throw S.SO; };
  const fn = function interp(S_, pc) {
    let it = 0, ip = pc, ea = 0;
    try {
      for (;;) {
        if (it >= maxN) { S.steps += it; return pc; }
        const i = (pc - B) >>> 2;
        if (i >= tw || (pc & 3) !== 0) { S.steps += it; return pc; }
        let d = dc[i];
        if (d === undefined) { d = dc[i] = decode(m.dv0.getUint32(pc - B, true), pc); d.ki = KIND_NO[d.k] !== undefined ? KIND_NO[d.k] : -1; d.fi = d.f !== undefined && FN_NO[d.f] !== undefined ? FN_NO[d.f] : -1; }
        ip = pc; cpc = pc; it++;
        if (d.cond !== 14 && !condPass(d.cond, FL)) { pc = (pc + 4) | 0; continue; }
        let jump = null, kind = '';     // an indirect jump: its target and kind
        switch (d.ki) {
          case 0: /* nop */ break;
          case 1: /* movw */ if (d.rd === 15) { ea = d.w | 0; throw S.UNDEF; } R[d.rd] = d.imm; break;
          case 2: /* movt */ if (d.rd === 15) { ea = d.w | 0; throw S.UNDEF; } R[d.rd] = (R[d.rd] & 65535) | ((d.imm << 16) | 0); break;
          case 3: /* dp */ {
            const opn = d.op, c = FL[2] !== 0;
            let b, sc;
            if (d.imm !== undefined) { b = d.imm; sc = d.immRot ? d.imm < 0 : c; }
            else {
              const rm = rv(d.rm);
              if (d.rs !== undefined) { const amt = rv(d.rs) & 255; b = SHR[d.st](rm, amt); sc = SHC[d.st](rm, amt, c); }
              else {
                const n = d.sa;
                switch (d.st) {
                  case 0: if (n === 0) { b = rm; sc = c; } else { b = rm << n; sc = ((rm >>> (32 - n)) & 1) !== 0; } break;
                  case 1: if (n === 0) { b = 0; sc = rm < 0; } else { b = (rm >>> n) | 0; sc = ((rm >>> (n - 1)) & 1) !== 0; } break;
                  case 2: if (n === 0) { b = rm >> 31; sc = rm < 0; } else { b = rm >> n; sc = ((rm >> (n - 1)) & 1) !== 0; } break;
                  default: if (n === 0) { b = (c ? -2147483648 : 0) | (rm >>> 1); sc = (rm & 1) !== 0; } else { b = (rm >>> n) | (rm << (32 - n)); sc = ((rm >>> (n - 1)) & 1) !== 0; }
                }
              }
            }
            const a = (opn === 13 || opn === 15) ? 0 : rv(d.rn);
            let t;
            switch (opn) {
              case 0: case 8: t = a & b; break;
              case 1: case 9: t = a ^ b; break;
              case 2: case 10: t = (a - b) | 0; break;
              case 3: t = (b - a) | 0; break;
              case 4: case 11: t = (a + b) | 0; break;
              case 5: t = (a + b + (c ? 1 : 0)) | 0; break;
              case 6: t = (a - b - (c ? 0 : 1)) | 0; break;
              case 7: t = (b - a - (c ? 0 : 1)) | 0; break;
              case 12: t = a | b; break;
              case 13: t = b; break;
              case 14: t = a & ~b; break;
              default: t = ~b;
            }
            const test = opn >= 8 && opn <= 11;
            if (d.rd === 15 && !test) {
              if (d.s) { ea = d.w | 0; throw S.UNDEF; }
              jump = t; kind = (opn === 13 && d.imm === undefined && d.rs === undefined && d.rm === 14 && d.sa === 0 && d.st === 0) ? 'bxlr' : 'dp';
              break;
            }
            if (d.s) {
              switch (opn) {
                case 4: case 11: FL[2] = (a >>> 0) + (b >>> 0) > 4294967295 ? 1 : 0; FL[3] = ((a ^ t) & (b ^ t)) < 0 ? 1 : 0; break;
                case 2: case 10: FL[2] = (a >>> 0) >= (b >>> 0) ? 1 : 0; FL[3] = ((a ^ b) & (a ^ t)) < 0 ? 1 : 0; break;
                case 3: FL[2] = (b >>> 0) >= (a >>> 0) ? 1 : 0; FL[3] = ((b ^ a) & (b ^ t)) < 0 ? 1 : 0; break;
                case 5: FL[2] = (a >>> 0) + (b >>> 0) + (c ? 1 : 0) > 4294967295 ? 1 : 0; FL[3] = ((a ^ t) & (b ^ t)) < 0 ? 1 : 0; break;
                case 6: FL[2] = (a >>> 0) - (b >>> 0) - (c ? 0 : 1) >= 0 ? 1 : 0; FL[3] = ((a ^ b) & (a ^ t)) < 0 ? 1 : 0; break;
                case 7: FL[2] = (b >>> 0) - (a >>> 0) - (c ? 0 : 1) >= 0 ? 1 : 0; FL[3] = ((b ^ a) & (b ^ t)) < 0 ? 1 : 0; break;
                default: FL[2] = sc ? 1 : 0;
              }
              FL[0] = t < 0 ? 1 : 0; FL[1] = t === 0 ? 1 : 0;
            }
            if (!test) { R[d.rd] = t; spCheck(d.rd); }
            break;
          }
          case 4: /* mul */ {
            const a = rv(d.rn), b = rv(d.rm);
            switch (d.op) {
              case 0: case 1: case 3: {
                const t = d.op === 0 ? Math.imul(a, b) : d.op === 1 ? (Math.imul(a, b) + rv(d.ra)) | 0 : (rv(d.ra) - Math.imul(a, b)) | 0;
                R[d.rd] = t;
                if (d.s) { FL[0] = t < 0 ? 1 : 0; FL[1] = t === 0 ? 1 : 0; }
                break;
              }
              case 4: case 5: case 6: case 7: {
                if (d.op >= 6) H.smul(a, b); else H.umul(a, b);
                if (d.op & 1) H.acc(rv(d.ra), rv(d.rd));
                R[d.ra] = H.lo; R[d.rd] = H.hi;
                if (d.s) { FL[0] = H.hi < 0 ? 1 : 0; FL[1] = (H.hi | H.lo) === 0 ? 1 : 0; }
                break;
              }
              default: ea = d.w | 0; throw S.UNDEF;
            }
            break;
          }
          case 5: /* clz */ R[d.rd] = Math.clz32(rv(d.rm)); break;
          case 6: /* rev */ R[d.rd] = H[d.f](rv(d.rm)); break;
          case 7: /* sdiv */ { const a = rv(d.rn), b = rv(d.rm); R[d.rd] = b === 0 ? 0 : (a / b) | 0; break; }
          case 8: /* udiv */ { const a = rv(d.rn), b = rv(d.rm); R[d.rd] = b === 0 ? 0 : ((a >>> 0) / (b >>> 0)) | 0; break; }
          case 9: /* smmul */ {
            H.smul(rv(d.rn), rv(d.rm));
            if (d.sub) {
              const ra = rv(d.ra), borrow = H.lo !== 0 ? 1 : 0;
              const lo = (-H.lo) | 0;
              let hi = (ra - H.hi - borrow) | 0;
              if (d.R && (lo >>> 0) >= 2147483648) hi = (hi + 1) | 0;
              R[d.rd] = hi;
            } else {
              if (d.ra !== 15) H.acc(0, rv(d.ra));
              if (d.R) H.acc(-2147483648, 0);
              R[d.rd] = H.hi;
            }
            break;
          }
          case 10: /* smulxy */ {
            const a = rv(d.rn), b = rv(d.rm);
            const x = d.N ? a >> 16 : (a << 16) >> 16, y = d.M ? b >> 16 : (b << 16) >> 16;
            R[d.rd] = (x * y + (d.acc ? rv(d.ra) : 0)) | 0;
            break;
          }
          case 11: /* ext */ {
            const rm = rv(d.rm);
            const v = d.rot ? (rm >>> d.rot) | (rm << (32 - d.rot)) : rm;
            const e = d.sign ? (d.half ? (v << 16) >> 16 : (v << 24) >> 24) : (d.half ? v & 65535 : v & 255);
            R[d.rd] = d.rn !== 15 ? (rv(d.rn) + e) | 0 : e;
            break;
          }
          case 12: /* bfi */ {
            if (d.msb < d.lsb) { ea = d.w | 0; throw S.UNDEF; }
            const width = d.msb - d.lsb + 1;
            const mask = width === 32 ? -1 : ((((1 << width) >>> 0) - 1) << d.lsb) | 0;
            const old = rv(d.rd);
            R[d.rd] = d.rn === 15 ? old & ~mask : (old & ~mask) | ((rv(d.rn) << d.lsb) & mask);
            break;
          }
          case 13: /* ubfx */ case 14: /* sbfx */ {
            const width = d.wm1 + 1;
            if (d.lsb + width > 32) { ea = d.w | 0; throw S.UNDEF; }
            const rn = rv(d.rn);
            if (d.k === 'ubfx') R[d.rd] = width === 32 ? rn : (rn >>> d.lsb) & (width === 31 ? 0x7fffffff : ((1 << width) - 1));
            else R[d.rd] = (rn << (32 - d.lsb - width)) >> (32 - width);
            break;
          }
          case 15: /* xfer */ {
            const base = rv(d.rn);
            let off;
            if (d.I) {
              const rm = rv(d.rm), n = d.sa;
              switch (d.st) {
                case 0: off = n ? rm << n : rm; break;
                case 1: off = n ? (rm >>> n) | 0 : 0; break;
                case 2: off = rm >> (n || 31); break;
                default: off = n === 0 ? ((FL[2] ? -2147483648 : 0) | (rm >>> 1)) : (rm >>> n) | (rm << (32 - n));
              }
            } else off = d.imm;
            const sum = d.U ? (base + off) | 0 : (base - off) | 0;
            ea = d.P ? sum : base;
            const wb = (!d.P || d.W) && d.rn !== 15;
            if (d.L) {
              const t = d.B ? S.dv.getUint8(ea - B) : S.dv.getInt32(ea - B, true);
              if (wb) { R[d.rn] = sum; spCheck(d.rn); }
              if (d.rt === 15) { jump = t; kind = 'ldrpc'; break; }
              R[d.rt] = t;
            } else {
              const val = d.rt === 15 ? (pc + 8) | 0 : R[d.rt];
              if (ea < dataBase) throw S.WP;
              if (d.B) S.dv.setInt8(ea - B, val); else S.dv.setInt32(ea - B, val, true);
              if (wb) { R[d.rn] = sum; spCheck(d.rn); }
            }
            break;
          }
          case 16: /* xfer2 */ {
            const base = rv(d.rn);
            const off = d.I ? d.imm : rv(d.rm);
            const sum = d.U ? (base + off) | 0 : (base - off) | 0;
            ea = d.P ? sum : base;
            const wb = !d.P || d.W;
            if (!d.L && d.sh >= 2) {    // ldrd / strd
              if ((d.rt & 1) || d.rt === 14) { ea = d.w | 0; throw S.UNDEF; }
              if (ea & 3) throw S.ALIGN;
              if (d.sh === 2) {
                const t0 = S.dv.getInt32(ea - B, true), t1 = S.dv.getInt32(ea + 4 - B, true);
                if (wb) { R[d.rn] = sum; spCheck(d.rn); }
                R[d.rt] = t0; R[d.rt + 1] = t1;
              } else {
                if (ea < dataBase) throw S.WP;
                S.dv.setInt32(ea - B, rv(d.rt), true); S.dv.setInt32(ea + 4 - B, rv(d.rt + 1), true);
                if (wb) { R[d.rn] = sum; spCheck(d.rn); }
              }
              break;
            }
            if (d.rt === 15) { ea = d.w | 0; throw S.UNDEF; }
            if (d.L) {
              const t = d.sh === 1 ? S.dv.getUint16(ea - B, true) : d.sh === 2 ? S.dv.getInt8(ea - B) : S.dv.getInt16(ea - B, true);
              if (wb) { R[d.rn] = sum; spCheck(d.rn); }
              R[d.rt] = t;
            } else {
              if (ea < dataBase) throw S.WP;
              S.dv.setInt16(ea - B, R[d.rt], true);
              if (wb) { R[d.rn] = sum; spCheck(d.rn); }
            }
            break;
          }
          case 17: /* ldm */ {
            const list = d.list;
            let n = 0;
            for (let k = 0; k < 16; k++) if (list & (1 << k)) n++;
            const rn = rv(d.rn);
            ea = d.U ? (d.P ? (rn + 4) | 0 : rn) : (d.P ? (rn - 4 * n) | 0 : (rn - (4 * n - 4)) | 0);
            if (ea & 3) throw S.ALIGN;
            const newBase = d.U ? (rn + 4 * n) | 0 : (rn - 4 * n) | 0;
            if (d.L) {
              let j = 0;
              for (let k = 0; k < 16; k++) if (list & (1 << k)) { tmp[j] = S.dv.getInt32(ea + 4 * j - B, true); j++; }
              if (d.W) { R[d.rn] = newBase; spCheck(d.rn); }
              j = 0;
              for (let k = 0; k < 16; k++) if (list & (1 << k)) { if (k === 15) { jump = tmp[j]; kind = 'ldmpc'; } else R[k] = tmp[j]; j++; }
            } else {
              if (ea < dataBase) throw S.WP;
              if (d.W && d.rn === 13 && !d.U && (ea >>> 0) < stackLo && (ea >>> 0) >= soLow) throw S.SO;
              let j = 0;
              for (let k = 0; k < 16; k++) if (list & (1 << k)) { S.dv.setInt32(ea + 4 * j - B, k === 15 ? (pc + 8) | 0 : R[k], true); j++; }
              if (d.W) R[d.rn] = newBase;
            }
            break;
          }
          case 18: /* b */ {
            if (m.isStub(d.target)) { S.steps += it; return d.target; }
            if (!m.isCode(d.target)) { ea = d.target; throw S.BADJUMP; }
            S.steps += it; return d.target;
          }
          case 19: /* bl */ {
            const ret = (pc + 4) | 0;
            if (m.isStub(d.target)) { R[14] = ret; S.callLib((d.target - STUB) >> 2, pc); break; }
            if (!m.isCode(d.target)) { ea = d.target; throw S.BADJUMP; }
            R[14] = ret; S.cpush = ret; S.steps += it; return d.target;
          }
          case 20: /* bx */ jump = rv(d.rm); kind = d.rm === 14 ? 'bxlr' : 'bx'; break;
          case 21: /* blxr */ { const t = rv(d.rm); ea = t; R[14] = (pc + 4) | 0; S.cpush = (pc + 4) | 0; jump = t; kind = 'blx'; break; }
          case 22: /* svc */ S.svc(d.imm, pc); break;
          case 23: /* udf */ throw S.UDF;
          // ---- VFP
          case 24: /* vf3 */ {
            if (d.dbl) {
              const N = VD[d.vn], M = VD[d.vm], D = VD[d.vd];
              let r;
              switch (d.fi) {
                case 0: /* vadd */ r = N + M; break; case 1: /* vsub */ r = N - M; break; case 2: /* vmul */ r = N * M; break; case 3: /* vdiv */ r = N / M; break;
                case 4: /* vnmul */ r = -(N * M); break; case 5: /* vmla */ r = D + N * M; break; case 6: /* vmls */ r = D - N * M; break;
                case 7: /* vnmla */ r = -D - N * M; break; case 8: /* vnmls */ r = -D + N * M; break;
                default: ea = d.w | 0; throw S.UNDEF;
              }
              VD[d.vd] = r;
            } else {
              const N = VF[d.vn], M = VF[d.vm], D = VF[d.vd];
              let r;
              switch (d.fi) {
                case 0: /* vadd */ r = N + M; break; case 1: /* vsub */ r = N - M; break; case 2: /* vmul */ r = N * M; break; case 3: /* vdiv */ r = N / M; break;
                case 4: /* vnmul */ r = -(N * M); break; case 5: /* vmla */ r = D + Math.fround(N * M); break; case 6: /* vmls */ r = D - Math.fround(N * M); break;
                case 7: /* vnmla */ r = -D - Math.fround(N * M); break; case 8: /* vnmls */ r = -D + Math.fround(N * M); break;
                default: ea = d.w | 0; throw S.UNDEF;
              }
              VF[d.vd] = r;
            }
            break;
          }
          case 25: /* vf2 */ {
            if (d.dbl) {
              const dd = d.vd * 2, mm = d.vm * 2;
              switch (d.fi) {
                case 9: /* vmov */ VI[dd] = VI[mm]; VI[dd + 1] = VI[mm + 1]; break;
                case 10: /* vabs */ { const lo = VI[mm], hi = VI[mm + 1] & 2147483647; VI[dd] = lo; VI[dd + 1] = hi; break; }
                case 11: /* vneg */ { const lo = VI[mm], hi = VI[mm + 1] ^ -2147483648; VI[dd] = lo; VI[dd + 1] = hi; break; }
                case 12: /* vsqrt */ VD[d.vd] = Math.sqrt(VD[d.vm]); break;
                default: ea = d.w | 0; throw S.UNDEF;
              }
            } else {
              switch (d.fi) {
                case 9: /* vmov */ VI[d.vd] = VI[d.vm]; break;
                case 10: /* vabs */ VI[d.vd] = VI[d.vm] & 2147483647; break;
                case 11: /* vneg */ VI[d.vd] = VI[d.vm] ^ -2147483648; break;
                case 12: /* vsqrt */ VF[d.vd] = Math.sqrt(VF[d.vm]); break;
                default: ea = d.w | 0; throw S.UNDEF;
              }
            }
            break;
          }
          case 26: /* vcmp */ {
            const x = d.dbl ? VD[d.vd] : VF[d.vd], y = d.zero ? 0 : (d.dbl ? VD[d.vm] : VF[d.vm]);
            if (x < y) { FL[4] = 1; FL[5] = 0; FL[6] = 0; FL[7] = 0; }
            else if (x === y) { FL[4] = 0; FL[5] = 1; FL[6] = 1; FL[7] = 0; }
            else if (x > y) { FL[4] = 0; FL[5] = 0; FL[6] = 1; FL[7] = 0; }
            else { FL[4] = 0; FL[5] = 0; FL[6] = 1; FL[7] = 1; }
            break;
          }
          case 27: /* vmovi */ { const val = K.vfpImmValue(d.imm); if (d.dbl) VD[d.vd] = val; else VF[d.vd] = val; break; }
          case 28: /* vcvt */ {
            switch (d.fi) {
              case 13: /* f64.f32 */ VD[d.vd] = VF[d.vm]; break;
              case 14: /* f32.f64 */ VF[d.vd] = VD[d.vm]; break;
              case 15: /* f32.s32 */ VF[d.vd] = VI[d.vm]; break;
              case 16: /* f32.u32 */ VF[d.vd] = VI[d.vm] >>> 0; break;
              case 17: /* f64.s32 */ VD[d.vd] = VI[d.vm]; break;
              case 18: /* f64.u32 */ VD[d.vd] = VI[d.vm] >>> 0; break;
              case 19: /* s32.f32 */ VI[d.vd] = d.rz ? H.f2s(VF[d.vm]) : H.f2sR(VF[d.vm]); break;
              case 20: /* u32.f32 */ VI[d.vd] = d.rz ? H.f2u(VF[d.vm]) : H.f2uR(VF[d.vm]); break;
              case 21: /* s32.f64 */ VI[d.vd] = d.rz ? H.f2s(VD[d.vm]) : H.f2sR(VD[d.vm]); break;
              case 22: /* u32.f64 */ VI[d.vd] = d.rz ? H.f2u(VD[d.vm]) : H.f2uR(VD[d.vm]); break;
              default: ea = d.w | 0; throw S.UNDEF;
            }
            break;
          }
          case 29: /* vldr */ {
            const off = d.U ? d.off : -d.off;
            const k = d.dbl ? d.reg * 2 : d.reg;
            const base = d.rn === 15 ? ((pc + 8) & ~3) | 0 : R[d.rn];
            ea = (base + off) | 0;
            if (ea & 3) throw S.ALIGN;
            if (d.L) { VI[k] = S.dv.getInt32(ea - B, true); if (d.dbl) VI[k + 1] = S.dv.getInt32(ea + 4 - B, true); }
            else {
              if (ea < dataBase) throw S.WP;
              S.dv.setInt32(ea - B, VI[k], true);
              if (d.dbl) S.dv.setInt32(ea + 4 - B, VI[k + 1], true);
            }
            break;
          }
          case 30: /* vldm */ {
            const words = d.dbl ? d.count * 2 : d.count;
            const rn = rv(d.rn);
            ea = d.P ? (rn - words * 4) | 0 : rn;
            if (ea & 3) throw S.ALIGN;
            if (!d.L && ea < dataBase) throw S.WP;
            const k0 = d.dbl ? d.reg * 2 : d.reg;
            for (let j = 0; j < words; j++) {
              if (d.L) VI[k0 + j] = S.dv.getInt32(ea + 4 * j - B, true);
              else S.dv.setInt32(ea + 4 * j - B, VI[k0 + j], true);
            }
            if (d.W) { R[d.rn] = d.U ? (rn + words * 4) | 0 : (rn - words * 4) | 0; spCheck(d.rn); }
            break;
          }
          case 31: /* vmovs */
            if (d.toArm) { if (d.rt === 15) { ea = d.w | 0; throw S.UNDEF; } R[d.rt] = VI[d.sn]; }
            else VI[d.sn] = rv(d.rt);
            break;
          case 32: /* vmov64 */ {
            const k = d.dbl ? d.vm * 2 : d.vm;
            if (d.toArm) {
              if (d.rt === 15 || d.rt2 === 15) { ea = d.w | 0; throw S.UNDEF; }
              const lo = VI[k], hi = VI[k + 1];
              R[d.rt] = lo; R[d.rt2] = hi;
            } else { const lo = rv(d.rt), hi = rv(d.rt2); VI[k] = lo; VI[k + 1] = hi; }
            break;
          }
          case 33: /* vmovsc */ {
            if (d.dn > 15) { ea = d.w | 0; throw S.UNDEF; }
            const k = d.dn * 2 + d.x;
            if (d.toArm) R[d.rt] = VI[k]; else VI[k] = rv(d.rt);
            break;
          }
          case 34: /* vmrs */
            if (d.rt === 15) { FL[0] = FL[4]; FL[1] = FL[5]; FL[2] = FL[6]; FL[3] = FL[7]; }
            else R[d.rt] = (FL[4] ? -2147483648 : 0) | (FL[5] ? 1073741824 : 0) | (FL[6] ? 536870912 : 0) | (FL[7] ? 268435456 : 0) | S.fpscr;
            break;
          case 35: /* vmsr */ {
            const r = rv(d.rt);
            FL[4] = r < 0 ? 1 : 0; FL[5] = (r & 1073741824) !== 0 ? 1 : 0; FL[6] = (r & 536870912) !== 0 ? 1 : 0; FL[7] = (r & 268435456) !== 0 ? 1 : 0;
            S.fpscr = r & 268435455;
            break;
          }
          default: ea = d.w | 0; throw S.UNDEF;     // 'undef' and anything the interpreter does not know
        }
        if (jump !== null) {
          // an indirect jump: bx, a return, ldr pc or a computed branch
          S.jpc = pc;
          if (kind === 'bxlr' && jump === pc) throw S.LRLOOP;
          if (jump & 3) { ea = jump; throw S.BADJUMP; }
          S.steps += it;
          return jump;
        }
        pc = (pc + 4) | 0;
      }
    } catch (e) {
      S.steps += it;
      return S.fault(e, ip, ea);
    }
  };
  fn.starts = [];
  fn.count = 0;
  return fn;
}
K.makeInterp = makeInterp;

// ---------------- the machine ----------------
// prog: result of K.link; libc: K.makeLibc factory
class Machine {
  constructor(prog, opts) {
    opts = opts || {};
    this.prog = prog;
    const L = this.layout = prog.layout;
    this.B = L.textBase;
    this.textEndExec = L.textEnd;
    this.singleStep = !!opts.singleStep;
    this.interp = !!opts.interp || !EVAL_OK || !!K.FORCE_INTERP;   // no new Function: interpret instead of translating
    this.interpFn = null;
    this.checkABI = opts.checkABI !== false;
    const initial = Math.max(prog.image.length + (opts.heapInitial || (1 << 20)), 1 << 21);
    this.size = (initial + 0xFFFF) & ~0xFFFF;
    this.maxSize = opts.maxMemory || (1 << 30);
    this.buf = new ArrayBuffer(this.size);
    this.u8 = new Uint8Array(this.buf);
    this.u8.set(prog.image);
    this.dv0 = new DataView(prog.image.buffer, prog.image.byteOffset, prog.image.byteLength);   // read-only text/rodata (translation)
    const vbuf = new ArrayBuffer(16 * 8);
    const S = this.S = {
      R: new Int32Array(16), FL: new Int32Array(8), VI: new Int32Array(vbuf), VF: new Float32Array(vbuf), VD: new Float64Array(vbuf),
      dv: new DataView(this.buf), H, steps: 0, cpush: 0, fpscr: 0, jpc: 0,
      WP: { kind: 'wp' }, ALIGN: { kind: 'align' }, SO: { kind: 'so' }, UNDEF: { kind: 'undef' }, UDF: { kind: 'udf' }, BADJUMP: { kind: 'badjump' }, LRLOOP: { kind: 'lrloop' },
      fault: (e, ip, ea) => this.memFault(e, ip, ea),
      callLib: (k, pc) => this.callLib(k, pc),
      svc: (imm, pc) => this.svc(imm, pc),
    };
    this.blocks = new Array(L.textWords);
    this.thunks = [];
    this.frames = [];     // shadow call stack: {ret, target, saved}
    this.lib = null;
    this.maxSteps = opts.maxSteps || Infinity;
    this.deadline = opts.deadline || Infinity;
    this.depth = 0;
    this.compiled = 0;
    this.nextCheck = 20000000;
  }
  isStub(a) { return a >= LAYOUT.STUB_BASE && a < LAYOUT.STUB_BASE + 4 * this.prog.stubs.length; }
  isCode(a) { return a >= this.B && a < this.layout.textEnd && (a & 3) === 0; }
  // grow memory (called by malloc); keeps the same addresses
  ensure(endAddr) {
    const need = endAddr - this.B;
    if (need <= this.size) return true;
    if (need > this.maxSize) return false;
    let ns = this.size;
    while (ns < need) ns = Math.min(this.maxSize, ns * 2);
    ns = (ns + 0xFFFF) & ~0xFFFF;
    let nb;
    try { nb = new ArrayBuffer(ns); } catch (e) { return false; }
    new Uint8Array(nb).set(this.u8);
    this.buf = nb; this.u8 = new Uint8Array(nb); this.size = ns;
    this.S.dv = new DataView(nb);
    if (this.lib && this.lib.refresh) this.lib.refresh();
    return true;
  }
  lineIdAt(pc) {
    const i = (pc - this.B) >> 2;
    if (i < 0 || i >= this.prog.lineMap.length) return 0;
    return this.prog.lineMap[i];
  }
  where(pc) {
    const id = this.lineIdAt(pc);
    const unit = id ? (id >>> 20) - 1 : -1;
    const f = K.funcAt(this.prog, pc);
    return { pc, unit, line: id & 0xFFFFF, func: f ? f.name : null, unitName: unit >= 0 ? this.prog.units[unit].name : null };
  }
  memFault(e, ip, ea) {
    if (e instanceof CFault || e instanceof ExitSignal) throw e;
    const S = this.S;
    const a = ea >>> 0;
    let msg;
    if (e === S.WP && a < this.B) msg = this.addrMsg(a, 'write to');
    else if (e === S.WP) msg = 'tried to write to address ' + hex(a) + ', which is read-only (it is in ' + (a >= this.layout.rodataBase && a < this.layout.dataBase ? 'the .rodata constants, like a string written with .asciz' : a >= this.B && a < this.layout.textEnd ? 'the program code (.text)' : 'memory that does not exist') + '). Only .data, .bss, the stack and malloc memory can be changed.';
    else if (e === S.ALIGN) msg = 'alignment fault: the address ' + hex(a) + ' is not a multiple of 4. ldrd, strd, ldm, stm, push, pop, vldr and vstr need addresses that are multiples of 4.';
    else if (e === S.SO) msg = 'stack overflow: the stack pointer went below the bottom of the 1 MB stack. Too much recursion, or a too-big local array (use malloc for big arrays)?';
    else if (e === S.UDF) msg = 'the program ran a udf (undefined instruction) - this is used to mark code that must never run';
    else if (e === S.UNDEF) { const d = decode(ea, ip); msg = 'the processor found something it cannot run at ' + hex(ip) + ' (the word ' + hex(ea) + ')' + (d.why ? ': ' + d.why : ' - is data being run as code? (missing bx lr / pop {pc} at the end of a function?)'); }
    else if (e === S.BADJUMP) msg = this.badJumpMsg(a);
    else if (e === S.LRLOOP) msg = 'infinite loop: "bx lr" jumped to itself, because lr holds the address of this very instruction. That happens when a function calls another function (bl changes lr) without saving lr first. Start the function with push {lr} (or push {r4, lr}) and end it with pop {pc} (or pop {r4, pc}).';
    else if (e instanceof RangeError) msg = this.addrMsg(a, 'access');
    else if (e && e.message && /Maximum call stack|too much recursion/i.test(e.message)) msg = 'the emulator ran out of stack (too many nested callbacks)';
    else throw e;
    throw new CFault(msg, ip, { addr: a });
  }
  addrMsg(a, what) {
    a >>>= 0;
    const L = this.layout;
    let msg = 'segmentation fault: the program tried to ' + what + ' address ' + hex(a);
    if (a < 0x1000) msg += ' - a NULL pointer (or NULL plus a small offset). A pointer (or a register used as a pointer) was 0: check that malloc/fopen worked, and that the right register holds the address.';
    else if (a === 0xDEADBEEF || (a & 0xFFFF0000) === 0xDEAD0000) msg += '. That value is left over from a function call: after a bl, the registers r0-r3 and r12 hold garbage (the called function may change them). Keep values that must survive a call in r4-r11 (and save those with push/pop).';
    else if (a < this.B) msg += ', which is not memory (it is below the program). A pointer is wrong - maybe a number was used as an address?';
    else if (a >= L.bssEnd && a < L.stackLo) msg += ', just below the stack: stack overflow?';
    else msg += ', which is outside the memory the program owns. Check array indexes, loop limits and pointer maths (did you forget to multiply an index by 4 for words?).';
    return msg;
  }
  badJumpMsg(a) {
    a >>>= 0;
    if (a & 1) return 'the program jumped to address ' + hex(a) + ', which is odd: that would switch to Thumb mode, which this emulator does not run. Is the value in the register really a code address?';
    if (a === 0) return 'the program jumped to address 0 (NULL): a function pointer or a return address is NULL. Did you pop more values than you pushed, or call through a NULL function pointer?';
    return 'the program jumped to address ' + hex(a) + ', which is not code. Usually this means a bad return address: the stack is unbalanced (push and pop must use the same registers), lr was not saved before a bl, or something overwrote the saved lr on the stack.';
  }
  // ---- running
  run(entry, maxSteps) {
    const S = this.S, B = this.B, tw = this.layout.textWords;
    let pc = entry | 0;
    const blocks = this.blocks;
    const STUB = LAYOUT.STUB_BASE, nStubs = this.prog.stubs.length;
    const depth0 = this.frames.length;
    let count = 0;
    for (;;) {
      const i = (pc - B) >>> 2;
      if (i < tw && (pc & 3) === 0) {
        let f = blocks[i];
        if (f === undefined) {
          f = this.interp ? (this.interpFn || (this.interpFn = makeInterp(this))) : translate(this, pc); this.compiled++;
          for (const st of f.starts) { const j = (st - B) >>> 2; if (blocks[j] === undefined) blocks[j] = f; }
          blocks[i] = f;
        }
        pc = f(S, pc);
        if (S.cpush !== 0) { this.pushFrame(S.cpush, pc); S.cpush = 0; }
        else if (this.frames.length > depth0 && pc === this.frames[this.frames.length - 1].ret) this.popFrame(pc);
        if (S.steps > this.nextCheck || (++count & 4095) === 0) { this.checkTime(); this.nextCheck = S.steps + 20000000; }
        continue;
      }
      if (pc === (LAYOUT.MAGIC_EXIT | 0) || pc === (LAYOUT.MAGIC_RET | 0)) return pc;
      if (pc >= STUB && pc < STUB + 4 * nStubs && (pc & 3) === 0) {
        const k = (pc - STUB) >> 2;
        this.callLib(k, S.R[14] - 4);
        pc = S.R[14];
        if (pc & 1) throw new CFault(this.badJumpMsg(pc), pc);
        if (this.frames.length > depth0 && pc === this.frames[this.frames.length - 1].ret) this.popFrame(pc);
        continue;
      }
      throw new CFault(this.badJumpMsg(pc), S.jpc || pc, { addr: pc >>> 0 });
    }
  }
  // the debugger: run exactly one instruction at pc (a C library call counts as one); returns the next pc.
  // Needs a machine made with singleStep: true, so every instruction is its own little function.
  stepOnce(pc) {
    const S = this.S, B = this.B;
    pc |= 0;
    const i = (pc - B) >>> 2;
    if (i < this.layout.textWords && (pc & 3) === 0) {
      let f = this.blocks[i];
      if (f === undefined) { f = this.interp ? (this.interpFn || (this.interpFn = makeInterp(this))) : translate(this, pc); this.compiled++; this.blocks[i] = f; }
      S.jpc = 0;
      const next = f(S, pc);
      if (S.cpush !== 0) { this.pushFrame(S.cpush, next); S.cpush = 0; }
      else if (this.frames.length && next === this.frames[this.frames.length - 1].ret) this.popFrame(next);
      return next;
    }
    if (pc === (LAYOUT.MAGIC_EXIT | 0) || pc === (LAYOUT.MAGIC_RET | 0)) return pc;
    const STUB = LAYOUT.STUB_BASE;
    if (pc >= STUB && pc < STUB + 4 * this.prog.stubs.length && (pc & 3) === 0) {
      this.callLib((pc - STUB) >> 2, S.R[14] - 4);
      const next = S.R[14];
      if (next & 1) throw new CFault(this.badJumpMsg(next), pc);
      if (this.frames.length && next === this.frames[this.frames.length - 1].ret) this.popFrame(next);
      return next;
    }
    throw new CFault(this.badJumpMsg(pc), S.jpc || pc, { addr: pc >>> 0 });
  }
  checkTime() {
    if (this.S.steps > this.maxSteps) throw new CFault('the program ran for more than ' + Math.round(this.maxSteps / 1e6) + ' million instructions without finishing. Is there a loop that never ends (check the loop condition and that the counter changes)?', this.S.R[15], { timeout: true });
    if (this.deadline !== Infinity && Date.now() > this.deadline) throw new CFault('the program ran for too long without finishing (a loop that never ends?)', 0, { timeout: true });
  }
  pushFrame(ret, target) {
    const R = this.S.R;
    const f = { ret: ret | 0, target: target | 0, sp: R[13] };
    if (this.checkABI) f.saved = [R[4], R[5], R[6], R[7], R[8], R[9], R[10], R[11]];
    this.frames.push(f);
    if (this.frames.length > 200000) throw new CFault('stack overflow: more than 200000 functions are running at the same time (endless recursion?)', target);
  }
  popFrame(pc) {
    const f = this.frames.pop();
    if (!this.checkABI || !f) return;
    const R = this.S.R;
    const fn = K.funcAt(this.prog, f.target);
    const name = fn ? fn.name : hex(f.target);
    const bad = [];
    for (let i = 0; i < 8; i++) if (R[4 + i] !== f.saved[i]) bad.push('r' + (4 + i));
    if (R[13] !== f.sp) {
      throw new CFault('the function "' + name + '" returned with a different stack pointer: sp was ' + hex(f.sp) + ' when it was called but ' + hex(R[13]) + ' when it returned (' + (R[13] - f.sp > 0 ? 'popped ' + (R[13] - f.sp) + ' bytes too many' : 'left ' + (f.sp - R[13]) + ' bytes on the stack') + '). Every push needs a matching pop, and every "sub sp" a matching "add sp".', f.target, { abi: true, func: name });
    }
    if (bad.length) {
      throw new CFault('the function "' + name + '" changed ' + bad.join(', ') + ' and did not put ' + (bad.length > 1 ? 'them' : 'it') + ' back. A function may change r0-r3 and r12 freely, but r4-r11 must have their old values when it returns: save them with push {' + bad.join(', ') + ', lr} at the start and restore them with pop {' + bad.join(', ') + ', pc} at the end.', f.target, { abi: true, func: name });
    }
  }
  // call an ARM function from JavaScript (qsort comparators): returns r0
  callFunction(addr, args) {
    const S = this.S, R = S.R;
    const saveLr = R[14], save = Array.from(R);
    for (let i = 0; i < 4; i++) R[i] = args[i] | 0;
    R[14] = LAYOUT.MAGIC_RET;
    this.depth++;
    if (this.depth > 50) throw new CFault('callbacks are nested too deeply', addr);
    this.pushFrame(LAYOUT.MAGIC_RET, addr);
    try { this.run(addr); }
    finally { this.depth--; }
    this.popFrame(LAYOUT.MAGIC_RET);
    const r0 = R[0];
    for (let i = 4; i < 14; i++) R[i] = save[i];   // (callee-saved registers were checked by the frame check)
    R[14] = saveLr;
    return r0;
  }
  callLib(k, pc) {
    let t = this.thunks[k];
    if (t === undefined) {
      const name = this.prog.stubs[k];
      t = this.thunks[k] = this.lib.makeThunk(name);
      if (!t) throw new CFault('the C library function "' + name + '" is not available in this emulator', pc);
    }
    t(pc);
  }
  svc(imm, pc) {
    const R = this.S.R;
    const nr = R[7];
    if (nr === 1 || nr === 248) throw new ExitSignal(R[0]);
    if (nr === 4) { R[0] = this.lib.sysWrite(R[0], R[1], R[2], pc); return; }
    if (nr === 3) { R[0] = this.lib.sysRead(R[0], R[1], R[2], pc); return; }
    throw new CFault('svc: Linux system call number ' + nr + ' (in r7) is not supported here. Supported: 1 (exit), 3 (read), 4 (write).', pc);
  }
}
K.Machine = Machine;
})(typeof globalThis !== 'undefined' ? globalThis : this);


// ===== libc.js =====
// ===== ArmKit C library: the functions an ARM program can call with bl (printf, malloc, fopen, popen("curl ..."), ...) =====
// Arguments arrive the AAPCS way: r0-r3 then the stack, floats in s0-s15 / d0-d7; variadic functions use only r0-r3 and the stack.
(function (G) {
'use strict';
const K = G.ArmKit = G.ArmKit || {};
const { CFault, ExitSignal, LAYOUT, hex } = K;

// ---- signatures: return type ':' argument types. i = int/pointer, l = 64-bit int, f = float, d = double, v = void, ... = variadic
// a leading '!' means "base procedure call standard" (floats in core registers, used by the __aeabi helpers)
const SIGS = {
  printf: 'i:i...', fprintf: 'i:ii...', sprintf: 'i:ii...', snprintf: 'i:iii...', dprintf: 'i:ii...',
  vprintf: 'i:ii', vfprintf: 'i:iii', vsprintf: 'i:iii', vsnprintf: 'i:iiii',
  sscanf: 'i:ii...', scanf: 'i:i...', fscanf: 'i:ii...',
  puts: 'i:i', putchar: 'i:i', fputs: 'i:ii', fputc: 'i:ii', putc: 'i:ii', getchar: 'i:', fgetc: 'i:i', getc: 'i:i', ungetc: 'i:ii', fgets: 'i:iii',
  fopen: 'i:ii', fclose: 'i:i', fread: 'i:iiii', fwrite: 'i:iiii', fseek: 'i:iii', ftell: 'i:i', rewind: 'v:i', feof: 'i:i', ferror: 'i:i', clearerr: 'v:i',
  fflush: 'i:i', remove: 'i:i', rename: 'i:ii', popen: 'i:ii', pclose: 'i:i', perror: 'v:i',
  malloc: 'i:i', calloc: 'i:ii', realloc: 'i:ii', free: 'v:i', exit: 'v:i', _exit: 'v:i', abort: 'v:', atexit: 'i:i',
  abs: 'i:i', labs: 'i:i', llabs: 'l:l', atoi: 'i:i', atol: 'i:i', atoll: 'l:i', atof: 'd:i',
  strtol: 'i:iii', strtoul: 'i:iii', strtoll: 'l:iii', strtoull: 'l:iii', strtod: 'd:ii', strtof: 'f:ii',
  rand: 'i:', srand: 'v:i', getenv: 'i:i', system: 'i:i', qsort: 'v:iiii', bsearch: 'i:iiiii',
  memcmp: 'i:iii', bcmp: 'i:iii', memchr: 'i:iii', memcpy: 'i:iii', memmove: 'i:iii', memset: 'i:iii',
  strlen: 'i:i', strnlen: 'i:ii', strcpy: 'i:ii', strncpy: 'i:iii', strcat: 'i:ii', strncat: 'i:iii', strcmp: 'i:ii', strncmp: 'i:iii',
  strcasecmp: 'i:ii', strncasecmp: 'i:iii', strchr: 'i:ii', strrchr: 'i:ii', strstr: 'i:ii', strdup: 'i:i', strndup: 'i:ii',
  strspn: 'i:ii', strcspn: 'i:ii', strpbrk: 'i:ii', strerror: 'i:i', strtok: 'i:ii', strtok_r: 'i:iii', stpcpy: 'i:ii',
  isalpha: 'i:i', isdigit: 'i:i', isalnum: 'i:i', isspace: 'i:i', isupper: 'i:i', islower: 'i:i', ispunct: 'i:i', isprint: 'i:i',
  isxdigit: 'i:i', iscntrl: 'i:i', isgraph: 'i:i', tolower: 'i:i', toupper: 'i:i',
  time: 'i:i', clock: 'i:', sleep: 'i:i', usleep: 'i:i',
  __assert_fail: 'v:iiii', __live_blocks: 'i:', __heap_check: 'i:',
  ldexp: 'd:di', ldexpf: 'f:fi', lround: 'i:d', lroundf: 'i:f', frexp: 'd:di', frexpf: 'f:fi', modf: 'd:di', modff: 'f:fi',
  __aeabi_idiv: 'i:ii', __aeabi_uidiv: 'i:ii', __aeabi_idivmod: 'q:ii', __aeabi_uidivmod: 'q:ii', __aeabi_ldivmod: 'q:ll', __aeabi_uldivmod: 'q:ll',
  __aeabi_memcpy: 'v:iii', __aeabi_memcpy4: 'v:iii', __aeabi_memcpy8: 'v:iii', __aeabi_memmove: 'v:iii', __aeabi_memmove4: 'v:iii', __aeabi_memmove8: 'v:iii',
  __aeabi_memset: 'v:iii', __aeabi_memset4: 'v:iii', __aeabi_memset8: 'v:iii', __aeabi_memclr: 'v:ii', __aeabi_memclr4: 'v:ii', __aeabi_memclr8: 'v:ii',
  __aeabi_f2lz: '!l:f', __aeabi_f2ulz: '!l:f', __aeabi_d2lz: '!l:d', __aeabi_d2ulz: '!l:d',
  __aeabi_l2f: '!f:l', __aeabi_ul2f: '!f:l', __aeabi_l2d: '!d:l', __aeabi_ul2d: '!d:l', __aeabi_lmul: 'l:ll', __aeabi_llsl: 'l:li', __aeabi_llsr: 'l:li', __aeabi_lasr: 'l:li',
};
for (const n of 'exp log log2 log10 sin cos tan asin acos atan sinh cosh tanh sqrt fabs floor ceil round trunc cbrt erf exp2 expm1 log1p'.split(' ')) { SIGS[n] = 'd:d'; SIGS[n + 'f'] = 'f:f'; }
for (const n of 'pow atan2 fmod hypot fmin fmax copysign'.split(' ')) { SIGS[n] = 'd:dd'; SIGS[n + 'f'] = 'f:ff'; }
K.LIBC_SIGS = SIGS;
K.LIBC_FUNCS = new Set(Object.keys(SIGS));
const parsed = {};
function parseSig(name) {
  if (parsed[name]) return parsed[name];
  let s = SIGS[name];
  const base = s[0] === '!'; if (base) s = s.slice(1);
  const [ret, a] = s.split(':');
  const variadic = a.endsWith('...');
  const args = (variadic ? a.slice(0, -3) : a).split('');
  return (parsed[name] = { ret, args, variadic, base: base || variadic });
}

// ---------------- number formatting (exact, like glibc) ----------------
const _f64 = new Float64Array(1), _u32 = new Uint32Array(_f64.buffer);
function decompose(v) { _f64[0] = v; const lo = _u32[0], hi = _u32[1]; const e = (hi >>> 20) & 0x7ff; let mant = (BigInt(hi & 0xfffff) << 32n) | BigInt(lo); if (e === 0) return [mant, -1074]; return [mant | (1n << 52n), e - 1075]; }
function ratOf(v) { const [m, e] = decompose(v); return e >= 0 ? [m << BigInt(e), 1n] : [m, 1n << BigInt(-e)]; }
function roundDiv(n, d) { let q = n / d; const r = n % d; const t = 2n * r; if (t > d || (t === d && (q & 1n) === 1n)) q += 1n; return q; }
function fmtFixed(v, prec) { const [n, d] = ratOf(v); const q = roundDiv(n * (10n ** BigInt(prec)), d); let s = q.toString(); if (prec > 0) { s = s.padStart(prec + 1, '0'); s = s.slice(0, s.length - prec) + '.' + s.slice(s.length - prec); } return s; }
function fmtExp(v, prec) {
  if (v === 0) return [prec > 0 ? '0.' + '0'.repeat(prec) : '0', 0];
  const [n, d] = ratOf(v);
  let X = Math.floor(Math.log10(v));
  const pow10 = (k) => 10n ** BigInt(Math.abs(k));
  const ge = (k) => k >= 0 ? n >= d * pow10(k) : n * pow10(k) >= d;
  while (!ge(X)) X--; while (ge(X + 1)) X++;
  const sh = prec - X;
  let q = sh >= 0 ? roundDiv(n * pow10(sh), d) : roundDiv(n, d * pow10(sh));
  if (q >= 10n ** BigInt(prec + 1)) { X++; const sh2 = prec - X; q = sh2 >= 0 ? roundDiv(n * pow10(sh2), d) : roundDiv(n, d * pow10(sh2)); }
  const s = q.toString();
  return [prec > 0 ? s[0] + '.' + s.slice(1) : s, X];
}
function expStr(X, upper) { return (upper ? 'E' : 'e') + (X < 0 ? '-' : '+') + String(Math.abs(X)).padStart(2, '0'); }
function fmtFloat(v, conv, prec, flags) {
  const upper = conv === conv.toUpperCase();
  const neg = v < 0 || (v === 0 && 1 / v < 0);
  let a = Math.abs(v), body;
  if (!isFinite(a)) body = isNaN(a) ? 'nan' : 'inf';
  else {
    const c = conv.toLowerCase();
    if (prec < 0) prec = 6;
    if (c === 'f') body = fmtFixed(a, prec);
    else if (c === 'e') { const [m, X] = fmtExp(a, prec); body = m + expStr(X, false); }
    else {
      let P = prec === 0 ? 1 : prec;
      const X = a === 0 ? 0 : fmtExp(a, P - 1)[1];
      if (P > X && X >= -4) body = fmtFixed(a, P - 1 - X); else { const [m, X2] = fmtExp(a, P - 1); body = m + expStr(X2, false); }
      if (!flags.includes('#')) { let [mm, ee] = body.split('e'); if (mm.includes('.')) { mm = mm.replace(/0+$/, ''); if (mm.endsWith('.')) mm = mm.slice(0, -1); } body = ee !== undefined ? mm + 'e' + ee : mm; }
    }
    if (flags.includes('#') && !body.includes('.') && c !== 'g') body = body.replace(/^(\d+)/, '$1.');
  }
  if (upper) body = body.toUpperCase();
  return [neg ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : '', body];
}
function erfImpl(x) {
  const s = x < 0 ? -1 : 1; x = Math.abs(x);
  if (x < 0.5) { let sum = x, term = x; for (let n = 1; n < 30; n++) { term *= -x * x / n; sum += term / (2 * n + 1); } return s * 2 / Math.sqrt(Math.PI) * sum; }
  const t = 1 / (1 + 0.5 * x);
  const y = 1 - t * Math.exp(-x * x - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
  return s * y;
}

// ---------------- the library, bound to one machine ----------------
K.makeLibc = function (m, env) {
  env = env || {};
  const B = m.B, L = m.layout;
  const enc = new TextEncoder();
  const S = m.S, R = S.R, VF = S.VF, VD = S.VD, VI = S.VI;
  const SCR = new ArrayBuffer(8), SI = new Int32Array(SCR), SF = new Float32Array(SCR), SD = new Float64Array(SCR);   // scratch for bit casts
  let u8 = m.u8, dv = S.dv;
  const refresh = () => { u8 = m.u8; dv = m.S.dv; };
  const safe = env.safe !== false;
  const files = env.files || new Map();
  let curPc = 0, curName = '';
  const fault = (msg) => new CFault(msg, curPc);
  // ---- pointer checks (addresses are real ARM addresses; u8 index = address - B)
  const bad = (a, who, what) => fault(who + '(): ' + (what || 'the pointer') + ' ' + hex(a) + ' does not point to memory the program owns' +
    ((a >>> 0) < 0x1000 ? ' (it is ' + ((a >>> 0) >= LAYOUT.FILE_BASE && (a >>> 0) < 0x1000 ? 'a FILE* handle, not a memory address' : 'NULL or almost NULL') + ')' : (a >>> 0) === 0xDEADBEEF ? ' (that value is garbage left over from an earlier function call: r0-r3 do not survive a bl)' : ''));
  const ix = (a, n, who, what) => { a >>>= 0; if (a < B || a + n > B + m.size) throw bad(a, who, what); return a - B; };
  const ixw = (a, n, who, what) => { a >>>= 0; if (a < B || a + n > B + m.size) throw bad(a, who, what); if (a < L.dataBase && n > 0) throw fault(who + '(): cannot write to ' + hex(a) + ': that memory is read-only (code or a constant from .rodata/.asciz). Copy the text into a buffer in .data, .bss, the stack or malloc memory first.'); return a - B; };
  const cstrLen = (a, who) => {
    const i0 = ix(a, 1, who || curName, 'the string');
    const e = u8.indexOf(0, i0);
    if (e < 0) throw fault((who || curName) + '(): a string at ' + hex(a) + ' never ends (there is no 0 byte after it). Strings need a 0 at the end: use .asciz, not .ascii.');
    return e - i0;
  };
  const cbytes = (a, who) => { const n = cstrLen(a, who); const i = a - B; return u8.subarray(i, i + n); };
  const cstr = (a, who) => { if (!a) throw fault((who || curName) + '(): the string pointer is NULL (0)'); return new TextDecoder().decode(cbytes(a, who)); };
  const latin = (a, who) => { const b = cbytes(a, who); let s = ''; for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return s; };
  const rd32 = (a) => dv.getInt32(ix(a, 4, curName), true);
  const wr32 = (a, v) => dv.setInt32(ixw(a, 4, curName), v, true);
  // ---- stdout / stderr
  const decOut = new TextDecoder('utf-8'), decErr = new TextDecoder('utf-8');
  let outBytes = [], errBytes = [], lastFlush = Date.now(), totalOut = 0;
  const maxOut = env.maxOut || 50e6;
  const flush = () => {
    if (outBytes.length) { const t = decOut.decode(new Uint8Array(outBytes), { stream: true }); outBytes = []; env.onOut && env.onOut(t, false); }
    if (errBytes.length) { const t = decErr.decode(new Uint8Array(errBytes), { stream: true }); errBytes = []; env.onOut && env.onOut(t, true); }
    lastFlush = Date.now();
  };
  const writeStd = (bytes, isErr) => {
    totalOut += bytes.length;
    if (totalOut > maxOut) throw fault('your program printed more than ' + (maxOut / 1e6) + ' MB of text - is a loop printing forever?');
    const arr = isErr ? errBytes : outBytes;
    for (let i = 0; i < bytes.length; i++) arr.push(bytes[i]);
    if (arr.length > 16384 || Date.now() - lastFlush > 40 || isErr) flush();
  };
  // ---- heap (blocks: [size][magic] then the bytes, then a red zone of 0xFD bytes)
  const heapStart = (L.heapBase + 15) & ~15;
  let heapTop = heapStart;
  const freeLists = new Map();
  let liveBlocks = 0, liveBytes = 0, peakBytes = 0;
  const MAGIC = 0xA110C8ED | 0, FREED = 0xF4EEF4EE | 0;
  const RED = safe ? 8 : 0;
  const malloc = (n) => {
    n = n >>> 0;
    if (n > 0x40000000) return 0;
    const usz = (Math.max(n, 1) + 7) & ~7;
    const bsz = usz + RED;
    let p = 0;
    const fl = freeLists.get(bsz);
    if (fl && fl.length) p = fl.pop();
    else {
      if (!m.ensure(heapTop + 8 + bsz + 64)) return 0;
      refresh();
      p = heapTop + 8; heapTop = heapTop + 8 + bsz;
    }
    const i = p - B;
    dv.setUint32(i - 8, n, true); dv.setInt32(i - 4, MAGIC, true);
    if (safe) { u8.fill(0xCD, i, i + usz); u8.fill(0xFD, i + usz, i + bsz); if (usz > n) u8.fill(0xFD, i + n, i + usz); }
    liveBlocks++; liveBytes += n; if (liveBytes > peakBytes) peakBytes = liveBytes;
    return p;
  };
  const blockOK = (p, who) => {
    p >>>= 0;
    if (p < heapStart || p >= heapTop || (p & 7)) throw fault(who + '() was given ' + hex(p) + ', a pointer that malloc never gave out' + (p >= L.stackLo && p < L.stackHi ? ' (it points into the stack)' : p < L.dataBase && p >= B ? ' (it points to code or constants)' : ''));
    const i = p - B;
    const mg = dv.getInt32(i - 4, true);
    if (mg === FREED) throw fault(who + '() was called on memory that was already freed (double free)');
    if (mg !== MAGIC) throw fault(who + '() was given ' + hex(p) + ', which is not the start of a malloc block');
    const n = dv.getUint32(i - 8, true);
    if (safe) {
      const usz = (Math.max(n, 1) + 7) & ~7;
      for (let k = i + n; k < i + usz + RED; k++) if (u8[k] !== 0xFD) throw fault('heap overflow: your program wrote past the end of a malloc block of ' + n + ' bytes (found by ' + who + '). Check your loop limits and the sizes you pass to malloc (4 bytes per int or float!).');
    }
    return n;
  };
  const free = (p) => {
    if (!p) return;
    const n = blockOK(p, 'free');
    const usz = (Math.max(n, 1) + 7) & ~7;
    dv.setInt32((p >>> 0) - B - 4, FREED, true);
    const bsz = usz + RED;
    let fl = freeLists.get(bsz); if (!fl) { fl = []; freeLists.set(bsz, fl); } fl.push(p >>> 0);
    liveBlocks--; liveBytes -= n;
  };
  const heapCheck = () => {
    if (!safe) return 0;
    let p = heapStart + 8;
    while (p < heapTop) {
      const i = p - B;
      const n = dv.getUint32(i - 8, true), mg = dv.getInt32(i - 4, true);
      if (mg !== MAGIC && mg !== FREED) throw fault('heap overflow: your program wrote past the end of a malloc block and damaged the next block. Check your loop limits and array sizes.');
      const usz = (Math.max(n, 1) + 7) & ~7;
      if (mg === MAGIC) for (let k = i + n; k < i + usz + RED; k++) if (u8[k] !== 0xFD) throw fault('heap overflow: your program wrote past the end of an array of ' + n + ' bytes made with malloc. Check your loop limits (blt or ble?) and array sizes (4 bytes per int or float!).');
      p += usz + RED + 8;
    }
    return 1;
  };
  const allocStr = (str) => { const b = enc.encode(str); const p = malloc(b.length + 1); u8.set(b, p - B); u8[p - B + b.length] = 0; liveBlocks--; liveBytes -= b.length + 1; return p; };
  // ---- varargs readers
  // base standard: a virtual list made of r0-r3 followed by the stack; 64-bit values are 8-aligned
  class VA {
    constructor(off) { this.off = off; this.sp = R[13] >>> 0; }
    i32() { const o = this.off; this.off += 4; if (o < 16) return R[o >> 2]; return dv.getInt32(ix(this.sp + o - 16, 4, curName, 'an argument on the stack'), true); }
    i64() { this.off = (this.off + 7) & ~7; const lo = this.i32() >>> 0, hi = this.i32(); return (BigInt(hi) << 32n) | BigInt(lo); }
    f64() { this.off = (this.off + 7) & ~7; const lo = this.i32(), hi = this.i32(); SI[0] = lo; SI[1] = hi; return SD[0]; }
  }
  // a va_list (a pointer into memory)
  class VAP {
    constructor(a) { this.a = a >>> 0; }
    i32() { const v = dv.getInt32(ix(this.a, 4, curName, 'the va_list'), true); this.a += 4; return v; }
    i64() { this.a = (this.a + 7) & ~7; const lo = this.i32() >>> 0, hi = this.i32(); return (BigInt(hi) << 32n) | BigInt(lo); }
    f64() { this.a = (this.a + 7) & ~7; const i = ix(this.a, 8, curName, 'the va_list'); this.a += 8; return dv.getFloat64(i, true); }
  }
  // ---- printf
  const format = (fp, ap) => {
    const out = [];
    let p = ix(fp, 1, curName, 'the format string');
    const pushS = (s) => { for (let i = 0; i < s.length; i++) out.push(s.charCodeAt(i) & 255); };
    const pad = (sign, body, flags, width, numeric) => {
      const len = sign.length + body.length;
      if (width > len) {
        if (flags.includes('-')) { pushS(sign); pushS(body); pushS(' '.repeat(width - len)); return; }
        if (flags.includes('0') && numeric) { pushS(sign); pushS('0'.repeat(width - len)); pushS(body); return; }
        pushS(' '.repeat(width - len)); pushS(sign); pushS(body); return;
      }
      pushS(sign); pushS(body);
    };
    for (;;) {
      if (p >= u8.length) throw fault(curName + '(): the format string never ends (no 0 byte)');
      const c = u8[p++];
      if (c === 0) break;
      if (c !== 37) { out.push(c); continue; }
      let flags = '';
      while (u8[p] && '-+ #0'.includes(String.fromCharCode(u8[p]))) flags += String.fromCharCode(u8[p++]);
      let width = 0, prec = -1;
      if (u8[p] === 42) { p++; width = ap.i32(); if (width < 0) { flags += '-'; width = -width; } }
      else while (u8[p] >= 48 && u8[p] <= 57) width = width * 10 + (u8[p++] - 48);
      if (u8[p] === 46) { p++; prec = 0; if (u8[p] === 42) { p++; prec = ap.i32(); } else while (u8[p] >= 48 && u8[p] <= 57) prec = prec * 10 + (u8[p++] - 48); }
      let len = '';
      while (u8[p] && 'hlLzjt'.includes(String.fromCharCode(u8[p]))) len += String.fromCharCode(u8[p++]);
      const conv = String.fromCharCode(u8[p++]);
      const wide = len === 'll' || len === 'j' || len === 'L';
      switch (conv) {
        case 'd': case 'i': {
          let v = wide ? BigInt.asIntN(64, ap.i64()) : BigInt(ap.i32());
          if (len === 'h') v = BigInt.asIntN(16, v); if (len === 'hh') v = BigInt.asIntN(8, v);
          const neg = v < 0n; let s = (neg ? -v : v).toString();
          if (prec >= 0) { s = s.padStart(prec, '0'); if (prec === 0 && v === 0n) s = ''; }
          pad(neg ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : '', s, prec >= 0 ? flags.replace('0', '') : flags, width, true);
          break;
        }
        case 'u': case 'x': case 'X': case 'o': {
          let v = wide ? BigInt.asUintN(64, ap.i64()) : BigInt(ap.i32() >>> 0);
          if (len === 'h') v = BigInt.asUintN(16, v); if (len === 'hh') v = BigInt.asUintN(8, v);
          let s = v.toString(conv === 'u' ? 10 : conv === 'o' ? 8 : 16);
          if (conv === 'X') s = s.toUpperCase();
          if (prec >= 0) { s = s.padStart(prec, '0'); if (prec === 0 && v === 0n) s = ''; }
          let pre = '';
          if (flags.includes('#') && v !== 0n) pre = conv === 'x' ? '0x' : conv === 'X' ? '0X' : conv === 'o' ? '0' : '';
          pad(pre, s, prec >= 0 ? flags.replace('0', '') : flags, width, true);
          break;
        }
        case 'c': pad('', String.fromCharCode(ap.i32() & 255), flags, width, false); break;
        case 's': {
          const sp = ap.i32() >>> 0;
          let bytes;
          if (!sp) bytes = [...enc.encode('(null)')];
          else {
            const i0 = ix(sp, 1, curName, 'the string for %s');
            let e = i0; while (e < u8.length && u8[e] !== 0 && (prec < 0 || e - i0 < prec)) e++;
            if (e >= u8.length) throw fault(curName + '(): the string for %s never ends');
            bytes = u8.subarray(i0, e);
          }
          const n = bytes.length;
          if (width > n && !flags.includes('-')) pushS(' '.repeat(width - n));
          for (let i = 0; i < n; i++) out.push(bytes[i]);
          if (width > n && flags.includes('-')) pushS(' '.repeat(width - n));
          break;
        }
        case 'f': case 'F': case 'e': case 'E': case 'g': case 'G': case 'a': case 'A': {
          const v = ap.f64(); const [sign, body] = fmtFloat(v, conv, prec, flags);
          pad(sign, body, isFinite(v) ? flags : flags.replace('0', ''), width, true); break;
        }
        case 'p': { const v = ap.i32() >>> 0; pad('', v ? '0x' + v.toString(16) : '(nil)', flags, width, false); break; }
        case '%': out.push(37); break;
        case 'n': { const ptr = ap.i32(); wr32(ptr, out.length); break; }
        default: pushS('%' + flags + len + conv);
      }
    }
    return out;
  };
  const toMem = (dst, n, bytes) => {
    if (n > 0) { const k = Math.min(bytes.length, n - 1); const i = ixw(dst, k + 1, curName, 'the destination buffer'); for (let j = 0; j < k; j++) u8[i + j] = bytes[j]; u8[i + k] = 0; }
    return bytes.length;
  };
  // ---- files
  const norm = (path) => {
    let s = path.replace(/\\/g, '/');
    if (!s.startsWith('/')) s = '/' + s;
    const parts = [];
    for (const x of s.split('/')) { if (!x || x === '.') continue; if (x === '..') parts.pop(); else parts.push(x); }
    return '/' + parts.join('/');
  };
  const handles = new Map();
  const FB = LAYOUT.FILE_BASE;
  handles.set(FB, { std: 'in', pos: 0, node: { data: env.stdin || new Uint8Array(0), size: (env.stdin || []).length }, r: true });
  handles.set(FB + 4, { std: 'out', w: true });
  handles.set(FB + 8, { std: 'err', w: true });
  let nextHandle = FB + 16; const freeHandles = [];
  const newHandle = () => { if (freeHandles.length) return freeHandles.pop(); if (nextHandle >= 0xFF0) throw fault('too many open files (did you forget fclose?)'); const h = nextHandle; nextHandle += 4; return h; };
  const H = (f, who) => {
    const h = handles.get(f >>> 0);
    if (!h) throw fault(who + '() was given a FILE* that is not open' + (f === 0 ? ' (it is NULL - did fopen fail? Always check if fopen returned 0)' : ' (' + hex(f) + ')'));
    return h;
  };
  const nodeRead = (node, pos, n) => {
    if (node.data) return node.data.subarray(pos, Math.min(node.size, pos + n));
    if (node.file) {
      const end = Math.min(node.size, pos + n);
      if (end <= pos) return new Uint8Array(0);
      const FR = new FileReaderSync();
      return new Uint8Array(FR.readAsArrayBuffer(node.file.slice(pos, end)));
    }
    return new Uint8Array(0);
  };
  const nodeWrite = (node, pos, bytes) => {
    if (!node.data) throw fault('this file is read-only');
    const end = pos + bytes.length;
    if (end > node.data.length) { const nd = new Uint8Array(Math.max(end, node.data.length * 2, 4096)); nd.set(node.data.subarray(0, node.size)); node.data = nd; }
    node.data.set(bytes, pos);
    if (end > node.size) node.size = end;
    node.dirty = true;
  };
  const hRead = (h, n) => {
    if (h.std === 'out' || h.std === 'err' || !h.r) { h.err = true; return new Uint8Array(0); }
    let pre = null;
    if (h.unget !== undefined) { pre = h.unget; h.unget = undefined; n--; }
    const b = nodeRead(h.node, h.pos, Math.max(n, 0)); h.pos += b.length;
    if (b.length < n) h.eof = true;
    if (pre !== null) { const r = new Uint8Array(b.length + 1); r[0] = pre; r.set(b, 1); return r; }
    return b;
  };
  const hWrite = (h, bytes) => {
    if (h.std === 'out') return writeStd(bytes, false);
    if (h.std === 'err') return writeStd(bytes, true);
    if (!h.w) { h.err = true; return; }
    if (h.append) h.pos = h.node.size;
    nodeWrite(h.node, h.pos, bytes); h.pos += bytes.length;
  };
  const fopen = (pp, mp) => {
    const path = norm(cstr(pp, 'fopen')), mode = latin(mp, 'fopen');
    let node = files.get(path);
    const md = mode.replace(/[bt]/g, '');
    if (!['r', 'w', 'a', 'r+', 'w+', 'a+'].includes(md)) throw fault('fopen: unknown mode "' + mode + '" (use "r", "w", "a", "rb", "wb"...)');
    if (path.endsWith('/') || path === '/') return 0;
    if (md[0] === 'r' && !node) return 0;
    if (md[0] === 'w') { node = { data: new Uint8Array(1024), size: 0, dirty: true }; files.set(path, node); }
    if (md[0] === 'a' && !node) { node = { data: new Uint8Array(1024), size: 0, dirty: true }; files.set(path, node); }
    const h = { path, node, pos: 0, r: md[0] === 'r' || md.includes('+'), w: md[0] !== 'r' || md.includes('+'), append: md[0] === 'a', eof: false, err: false };
    const fp = newHandle();
    handles.set(fp, h);
    return fp;
  };
  const shellSplit = (cmd) => {
    const args = []; let cur = '', i = 0, q = null, has = false;
    while (i < cmd.length) {
      const c = cmd[i];
      if (q) { if (c === q) { q = null; i++; continue; } if (c === '\\' && q === '"' && i + 1 < cmd.length) { cur += cmd[i + 1]; i += 2; continue; } cur += c; i++; continue; }
      if (c === "'" || c === '"') { q = c; has = true; i++; continue; }
      if (c === '\\' && i + 1 < cmd.length) { cur += cmd[i + 1]; i += 2; has = true; continue; }
      if (c === ' ' || c === '\t' || c === '\n') { if (cur || has) { args.push(cur); cur = ''; has = false; } i++; continue; }
      if (c === '|' || c === ';' || c === '&' || c === '`' || c === '$' || c === '<' || c === '>') {
        if (c === '>' || c === '<') { args.push({ redirect: c, rest: cmd.slice(i) }); return args; }
        throw fault('popen: the emulator can only run a single curl command (found "' + c + '" in the command)');
      }
      cur += c; i++; has = true;
    }
    if (q) throw fault('popen: a quote in the command is never closed');
    if (cur || has) args.push(cur);
    return args;
  };
  const popen = (cp, mp) => {
    const cmd = cstr(cp, 'popen');
    const args = shellSplit(cmd).filter(a => typeof a === 'string');
    if (!args.length || args[0] !== 'curl') throw fault('popen: the emulator can only run "curl" commands (you asked for "' + (args[0] || '') + '"). On a real computer popen can run any program.');
    let url = null, fail = false; const headers = {};
    for (let i = 1; i < args.length; i++) {
      const a = args[i];
      if (a === '-m' || a === '--max-time' || a === '--connect-timeout' || a === '--retry') { i++; continue; }
      if (a === '-A' || a === '--user-agent') { headers['User-Agent'] = args[++i]; continue; }
      if (a === '-H' || a === '--header') { const h = args[++i] || ''; const k = h.indexOf(':'); if (k > 0) headers[h.slice(0, k).trim()] = h.slice(k + 1).trim(); continue; }
      if (a === '-o' || a === '--output' || a === '-d' || a === '--data') throw fault('popen: curl ' + a + ' is not supported in the emulator - read the page from the pipe instead');
      if (a.startsWith('-')) { if (a.includes('f') && !a.startsWith('--')) fail = true; if (a === '--fail') fail = true; continue; }
      url = a;
    }
    if (!url) throw fault('popen: curl needs a URL');
    const res = env.web ? env.web(url, headers) : { status: 0, body: new Uint8Array(0) };
    let body = res.body, code = 0;
    if (res.status === 0) { body = new Uint8Array(0); code = 6; }
    else if (res.status >= 400 && fail) { body = new Uint8Array(0); code = 22; }
    const h = { path: 'pipe:' + url, node: { data: body, size: body.length }, pos: 0, r: true, w: false, pipe: true, code };
    const fp = newHandle();
    handles.set(fp, h);
    return fp;
  };
  // ---- scanf family
  const scanImpl = (src, fp, ap, getRest) => {
    let s = 0, p = ix(fp, 1, curName, 'the format string'), count = 0;
    const Sx = src;
    const isSp = (c) => c === 32 || (c >= 9 && c <= 13);
    const nextPtr = () => ap.i32();
    const put = (ptr, bytes) => { const i = ixw(ptr, bytes.length, curName, 'a %s/%c destination'); u8.set(bytes, i); };
    for (;;) {
      const c = u8[p];
      if (c === 0 || c === undefined) break;
      if (isSp(c)) { while (isSp(u8[p])) p++; while (s < Sx.length && isSp(Sx[s])) s++; continue; }
      if (c !== 37) { if (Sx[s] !== c) break; s++; p++; continue; }
      p++;
      if (u8[p] === 37) { if (Sx[s] !== 37) break; s++; p++; continue; }
      let skip = false; if (u8[p] === 42) { skip = true; p++; }
      let width = 0; while (u8[p] >= 48 && u8[p] <= 57) width = width * 10 + (u8[p++] - 48);
      let len = ''; while (u8[p] && 'hlLzj'.includes(String.fromCharCode(u8[p]))) len += String.fromCharCode(u8[p++]);
      const conv = String.fromCharCode(u8[p++]);
      if (conv !== 'c' && conv !== '[' && conv !== 'n') while (s < Sx.length && isSp(Sx[s])) s++;
      const maxw = width || Infinity;
      if (conv === 'n') { if (!skip) wr32(nextPtr(), s); continue; }
      if (s >= Sx.length) { if (count === 0) count = -1; break; }
      if ('diuxXo'.includes(conv)) {
        let j = s; if ((Sx[j] === 45 || Sx[j] === 43) && j - s < maxw) j++;
        const base = conv === 'x' || conv === 'X' ? 16 : conv === 'o' ? 8 : 10;
        if (base === 16 && Sx[j] === 48 && (Sx[j + 1] | 32) === 120) j += 2;
        const st = j;
        while (j < Sx.length && j - s < maxw) { const d = Sx[j] | 32; const v = d >= 48 && d <= 57 ? d - 48 : d >= 97 && d <= 122 ? d - 87 : 99; if (v >= base) break; j++; }
        if (j === st) break;
        const txt = String.fromCharCode(...Sx.subarray(s, j));
        const v = base === 10 ? BigInt(txt.replace('+', '')) : BigInt((txt.startsWith('-') ? '-' : '') + (base === 16 ? '0x' : '0o') + txt.replace(/^[+-]?(0x|0X)?/, ''));
        s = j;
        if (!skip) {
          const ptr = nextPtr();
          if (len === 'll' || len === 'j') { const i = ixw(ptr, 8, curName, 'a %lld destination'); dv.setBigInt64(i, BigInt.asIntN(64, v), true); }
          else if (len === 'h') dv.setInt16(ixw(ptr, 2, curName), Number(BigInt.asIntN(16, v)), true);
          else if (len === 'hh') dv.setInt8(ixw(ptr, 1, curName), Number(BigInt.asIntN(8, v)));
          else dv.setInt32(ixw(ptr, 4, curName, 'a %d destination'), Number(BigInt.asIntN(32, v)), true);
          count++;
        }
        continue;
      }
      if ('feEgGa'.includes(conv)) {
        const txt = String.fromCharCode(...Sx.subarray(s, Math.min(Sx.length, s + (width || 400))));
        const mm = /^[+-]?(inf(inity)?|nan|(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?)/i.exec(txt);
        if (!mm) break;
        s += mm[0].length;
        const v = parseFloat(mm[0].replace(/^([+-]?)inf(inity)?$/i, '$1Infinity'));
        if (!skip) { const ptr = nextPtr(); if (len === 'l' || len === 'L') dv.setFloat64(ixw(ptr, 8, curName, 'a %lf destination'), v, true); else dv.setFloat32(ixw(ptr, 4, curName, 'a %f destination'), v, true); count++; }
        continue;
      }
      if (conv === 's') {
        const st = s; while (s < Sx.length && !isSp(Sx[s]) && s - st < maxw) s++;
        if (!skip) { const ptr = nextPtr(); put(ptr, Sx.subarray(st, s)); put(ptr + s - st, [0]); count++; }
        continue;
      }
      if (conv === 'c') {
        const n = width || 1; if (s + n > Sx.length) break;
        if (!skip) { const ptr = nextPtr(); put(ptr, Sx.subarray(s, s + n)); count++; }
        s += n; continue;
      }
      if (conv === '[') {
        let neg = false; if (u8[p] === 94) { neg = true; p++; }
        const set = new Set(); if (u8[p] === 93) { set.add(93); p++; }
        while (u8[p] && u8[p] !== 93) { if (u8[p + 1] === 45 && u8[p + 2] && u8[p + 2] !== 93) { for (let k = u8[p]; k <= u8[p + 2]; k++) set.add(k); p += 3; } else set.add(u8[p++]); }
        p++;
        const st = s; while (s < Sx.length && (set.has(Sx[s]) !== neg) && s - st < maxw) s++;
        if (s === st) break;
        if (!skip) { const ptr = nextPtr(); put(ptr, Sx.subarray(st, s)); put(ptr + s - st, [0]); count++; }
        continue;
      }
      break;
    }
    if (getRest) getRest(s);
    return count;
  };
  // ---- strtol / strtod
  const strtoNum = (sp, endp, base, wide, unsigned) => {
    const Sx = cbytes(sp, curName); let i = 0;
    while (i < Sx.length && (Sx[i] === 32 || (Sx[i] >= 9 && Sx[i] <= 13))) i++;
    let neg = false; if (Sx[i] === 45 || Sx[i] === 43) { neg = Sx[i] === 45; i++; }
    if ((base === 0 || base === 16) && Sx[i] === 48 && (Sx[i + 1] | 32) === 120) { base = 16; i += 2; }
    else if (base === 0 && Sx[i] === 48) base = 8;
    else if (base === 0) base = 10;
    const st = i; let v = 0n;
    while (i < Sx.length) { const d = Sx[i] | 32; const x = d >= 48 && d <= 57 ? d - 48 : d >= 97 && d <= 122 ? d - 87 : 99; if (x >= base) break; v = v * BigInt(base) + BigInt(x); i++; }
    if (i === st) i = 0;
    if (endp) wr32(endp, (sp + i) | 0);
    if (neg) v = -v;
    const bits = wide ? 64 : 32;
    if (unsigned) { const max = (1n << BigInt(bits)) - 1n; if (v > max) v = max; return BigInt.asUintN(bits, v); }
    const max = (1n << BigInt(bits - 1)) - 1n, min = -(1n << BigInt(bits - 1));
    if (v > max) v = max; if (v < min) v = min;
    return v;
  };
  const strtodImpl = (sp, endp) => {
    const Sx = latin(sp, curName);
    const mm = /^[ \t\n\r\v\f]*([+-]?(inf(inity)?|nan|(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?))/i.exec(Sx);
    if (!mm) { if (endp) wr32(endp, sp); return 0; }
    if (endp) wr32(endp, (sp + mm[0].length) | 0);
    return parseFloat(mm[1].replace(/inf(inity)?/i, 'Infinity'));
  };
  const strcmpImpl = (a, b, n, fold) => {
    let i = ix(a, 1, curName, 'the first string'), j = ix(b, 1, curName, 'the second string');
    for (let k = 0; k < n; k++) {
      let x = u8[i + k], y = u8[j + k];
      if (x === undefined || y === undefined) throw fault(curName + '(): a string never ends');
      if (fold) { if (x >= 65 && x <= 90) x += 32; if (y >= 65 && y <= 90) y += 32; }
      if (x !== y) return x - y;
      if (x === 0) return 0;
    }
    return 0;
  };
  const span = (a, n, who, what) => ix(a, n, who || curName, what);
  const copy = (d, s, n, who) => { n >>>= 0; if (!n) return; const di = ixw(d, n, who, 'the destination'), si = span(s, n, who, 'the source'); u8.copyWithin(di, si, si + n); };
  // ---- qsort / bsearch (same algorithms as the course's C library)
  const qsortImpl = (base, n, size, cmp) => {
    n >>>= 0; size >>>= 0;
    if (n > 1) { ixw(base, n * size, 'qsort', 'the array'); }
    const call = (a, b) => m.callFunction(cmp, [a, b]);
    const swap = (a, b) => { if (a === b) return; const i = a - B, j = b - B; for (let k = 0; k < size; k++) { const t = u8[i + k]; u8[i + k] = u8[j + k]; u8[j + k] = t; } };
    const rec = (a, n) => {
      while (n > 10) {
        swap(a, a + Math.floor(n / 2) * size);
        let i = 0, j = n;
        for (;;) {
          do i++; while (i < n && call(a + i * size, a) < 0);
          do j--; while (call(a + j * size, a) > 0);
          if (i >= j) break;
          swap(a + i * size, a + j * size);
        }
        swap(a, a + j * size);
        const left = j, right = n - j - 1;
        if (left < right) { rec(a, left); a += (j + 1) * size; n = right; }
        else { rec(a + (j + 1) * size, right); n = left; }
      }
      for (let i = 1; i < n; i++) for (let j = i; j > 0 && call(a + (j - 1) * size, a + j * size) > 0; j--) swap(a + (j - 1) * size, a + j * size);
    };
    if (!m.isCode(cmp)) throw fault('qsort(): the comparison function ' + hex(cmp) + ' is not code (pass the address of a function, like ldr r3, =my_compare)');
    rec(base >>> 0, n);
  };
  let strtokSave = 0;
  const isspace = (c) => c === 32 || c === 9 || c === 10 || c === 13 || c === 11 || c === 12;
  const isdigit = (c) => c >= 48 && c <= 57, isalpha = (c) => (c >= 97 && c <= 122) || (c >= 65 && c <= 90);
  const isupper = (c) => c >= 65 && c <= 90, islower = (c) => c >= 97 && c <= 122;
  const isalnum = (c) => isalpha(c) || isdigit(c);
  const spanOf = (s, a, inSet) => { const set = new Set(cbytes(a)); const i0 = ix(s, 1, curName); let i = i0; while (u8[i] && set.has(u8[i]) === inSet) i++; return i - i0; };
  let randState = 1;
  const envStrs = new Map();
  const M = Math, fr = Math.fround;
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const atexitFns = [];
  const roundAway = (x) => (x < 0 ? -M.round(-x) : M.round(x));
  const F = {
    printf: (f, ap) => { const b = format(f, ap); writeStd(b, false); return b.length; },
    vprintf: (f, ap) => { const b = format(f, new VAP(ap)); writeStd(b, false); return b.length; },
    fprintf: (fh, f, ap) => { const h = H(fh, 'fprintf'); const b = format(f, ap); hWrite(h, b); return b.length; },
    dprintf: (fd, f, ap) => { const b = format(f, ap); if (fd === 1 || fd === 2) writeStd(b, fd === 2); return b.length; },
    vfprintf: (fh, f, ap) => { const h = H(fh, 'vfprintf'); const b = format(f, new VAP(ap)); hWrite(h, b); return b.length; },
    sprintf: (d, f, ap) => toMem(d, 0x7fffffff, format(f, ap)),
    vsprintf: (d, f, ap) => toMem(d, 0x7fffffff, format(f, new VAP(ap))),
    snprintf: (d, n, f, ap) => toMem(d, n >>> 0, format(f, ap)),
    vsnprintf: (d, n, f, ap) => toMem(d, n >>> 0, format(f, new VAP(ap))),
    sscanf: (s, f, ap) => scanImpl(cbytes(s, 'sscanf').slice(), f, ap),
    scanf: (f, ap) => { const h = handles.get(FB); const all = nodeRead(h.node, h.pos, 1 << 30); return scanImpl(all, f, ap, (k) => { h.pos += k; }); },
    fscanf: (fh, f, ap) => { const h = H(fh, 'fscanf'); const all = nodeRead(h.node, h.pos, 1 << 30); return scanImpl(all, f, ap, (k) => { h.pos += k; }); },
    puts: (s) => { writeStd(cbytes(s, 'puts'), false); writeStd([10], false); return 1; },
    putchar: (c) => { writeStd([c & 255], false); return c & 255; },
    fputs: (s, fh) => { const h = H(fh, 'fputs'); hWrite(h, cbytes(s, 'fputs')); return 1; },
    fputc: (c, fh) => { hWrite(H(fh, 'fputc'), [c & 255]); return c & 255; },
    putc: (c, fh) => { hWrite(H(fh, 'putc'), [c & 255]); return c & 255; },
    getchar: () => { const b = hRead(handles.get(FB), 1); return b.length ? b[0] : -1; },
    fgetc: (fh) => { const b = hRead(H(fh, 'fgetc'), 1); return b.length ? b[0] : -1; },
    getc: (fh) => { const b = hRead(H(fh, 'getc'), 1); return b.length ? b[0] : -1; },
    ungetc: (c, fh) => { const h = H(fh, 'ungetc'); if (c === -1) return -1; h.unget = c & 255; h.eof = false; return c; },
    fgets: (d, n, fh) => {
      const h = H(fh, 'fgets'); if (n <= 0) return 0;
      const di = ixw(d, n, 'fgets', 'the buffer');
      let k = 0;
      while (k < n - 1) { const b = hRead(h, 1); if (!b.length) break; u8[di + k++] = b[0]; if (b[0] === 10) break; }
      if (k === 0) return 0;
      u8[di + k] = 0; return d;
    },
    fopen, popen,
    fclose: (fh) => { const h = H(fh, 'fclose'); if (h.std) return 0; if (h.pipe) throw fault('use pclose() (not fclose) for something opened with popen()'); handles.delete(fh >>> 0); freeHandles.push(fh >>> 0); return 0; },
    pclose: (fh) => { const h = H(fh, 'pclose'); if (!h.pipe) throw fault('pclose() is only for things opened with popen()'); handles.delete(fh >>> 0); freeHandles.push(fh >>> 0); return h.code << 8; },
    fread: (p, size, n, fh) => { const h = H(fh, 'fread'); const want = (size >>> 0) * (n >>> 0); if (!want) return 0; const di = ixw(p, want, 'fread', 'the buffer'); const b = hRead(h, want); u8.set(b, di); return Math.floor(b.length / size); },
    fwrite: (p, size, n, fh) => { const h = H(fh, 'fwrite'); const k = (size >>> 0) * (n >>> 0); const si = span(p, k, 'fwrite', 'the data'); hWrite(h, u8.slice(si, si + k)); return n; },
    fseek: (fh, off, wh) => { const h = H(fh, 'fseek'); if (h.std || h.pipe) return -1; const base = wh === 0 ? 0 : wh === 1 ? h.pos : h.node.size; const np = base + off; if (np < 0) return -1; h.pos = np; h.eof = false; h.unget = undefined; return 0; },
    ftell: (fh) => { const h = H(fh, 'ftell'); return h.std ? -1 : h.pos; },
    rewind: (fh) => { const h = H(fh, 'rewind'); h.pos = 0; h.eof = false; h.err = false; },
    feof: (fh) => (H(fh, 'feof').eof ? 1 : 0),
    ferror: (fh) => (H(fh, 'ferror').err ? 1 : 0),
    clearerr: (fh) => { const h = H(fh, 'clearerr'); h.eof = false; h.err = false; },
    fflush: () => { flush(); return 0; },
    remove: (pp) => (files.delete(norm(cstr(pp, 'remove'))) ? 0 : -1),
    rename: (a, b) => { const A = norm(cstr(a, 'rename')), Bn = norm(cstr(b, 'rename')); const n = files.get(A); if (!n) return -1; files.delete(A); files.set(Bn, n); n.dirty = true; return 0; },
    perror: (s) => { writeStd(enc.encode((s ? cstr(s) + ': ' : '') + 'error\n'), true); },
    malloc: (n) => malloc(n),
    __live_blocks: () => liveBlocks,
    __heap_check: () => heapCheck(),
    calloc: (a, b) => { const n = (a >>> 0) * (b >>> 0); if (n > 0x40000000) return 0; const p = malloc(n); if (p) u8.fill(0, p - B, p - B + n); return p; },
    realloc: (p, n) => {
      if (!p) return malloc(n);
      if (n === 0) { free(p); return 0; }
      const old = blockOK(p, 'realloc');
      const np = malloc(n); if (!np) return 0;
      u8.copyWithin(np - B, (p >>> 0) - B, (p >>> 0) - B + Math.min(old, n >>> 0)); free(p); return np;
    },
    free: (p) => free(p),
    exit: (c) => { throw new ExitSignal(c); }, _exit: (c) => { throw new ExitSignal(c); },
    abort: () => { throw fault('abort() was called'); },
    atexit: (fn) => { atexitFns.push(fn); return 0; },
    abs: (x) => (x < 0 ? -x : x) | 0, labs: (x) => (x < 0 ? -x : x) | 0, llabs: (x) => (x < 0n ? -x : x),
    atoi: (s) => Number(strtoNum(s, 0, 10, false, false)), atol: (s) => Number(strtoNum(s, 0, 10, false, false)),
    atoll: (s) => strtoNum(s, 0, 10, true, false), atof: (s) => strtodImpl(s, 0),
    strtol: (s, e, b) => Number(strtoNum(s, e, b, false, false)), strtoul: (s, e, b) => Number(BigInt.asIntN(32, strtoNum(s, e, b, false, true))),
    strtoll: (s, e, b) => strtoNum(s, e, b, true, false), strtoull: (s, e, b) => BigInt.asIntN(64, strtoNum(s, e, b, true, true)),
    strtod: (s, e) => strtodImpl(s, e), strtof: (s, e) => fr(strtodImpl(s, e)),
    rand: () => { randState = (Math.imul(randState, 1103515245) + 12345) >>> 0; return (randState >>> 1) & 0x7fffffff; },
    srand: (s) => { randState = s >>> 0; },
    getenv: (n) => { const k = cstr(n, 'getenv'); const v = (env.vars || {})[k]; if (v === undefined) return 0; if (!envStrs.has(k)) envStrs.set(k, allocStr(v)); return envStrs.get(k); },
    system: (c) => (c ? -1 : 0),
    qsort: qsortImpl,
    bsearch: (key, base, n, size, cmp) => { let lo = 0, hi = n >>> 0; while (lo < hi) { const mid = (lo + hi) >>> 1; const c = m.callFunction(cmp, [key, base + mid * size]); if (c === 0) return base + mid * size; if (c < 0) hi = mid; else lo = mid + 1; } return 0; },
    memcmp: (a, b, n) => { n >>>= 0; const i = span(a, n, 'memcmp'), j = span(b, n, 'memcmp'); for (let k = 0; k < n; k++) { const d = u8[i + k] - u8[j + k]; if (d) return d; } return 0; },
    memchr: (s, c, n) => { n >>>= 0; c &= 255; const i = span(s, n, 'memchr'); for (let k = 0; k < n; k++) if (u8[i + k] === c) return s + k; return 0; },
    memcpy: (d, s, n) => { copy(d, s, n, 'memcpy'); return d; },
    memmove: (d, s, n) => { copy(d, s, n, 'memmove'); return d; },
    memset: (d, c, n) => { n >>>= 0; if (n) { const i = ixw(d, n, 'memset', 'the destination'); u8.fill(c & 255, i, i + n); } return d; },
    strlen: (s) => { if (!s) throw fault('strlen(NULL): the string pointer is NULL (0)'); return cstrLen(s, 'strlen'); },
    strnlen: (s, n) => { const i0 = ix(s, 1, 'strnlen'); let i = 0; while (i < (n >>> 0) && u8[i0 + i]) i++; return i; },
    strcpy: (d, s) => { const n = cstrLen(s, 'strcpy'); copy(d, s, n + 1, 'strcpy'); return d; },
    stpcpy: (d, s) => { const n = cstrLen(s, 'stpcpy'); copy(d, s, n + 1, 'stpcpy'); return d + n; },
    strncpy: (d, s, n) => { n >>>= 0; const di = ixw(d, n, 'strncpy', 'the destination'), si = ix(s, 1, 'strncpy'); let i = 0; for (; i < n && u8[si + i]; i++) u8[di + i] = u8[si + i]; for (; i < n; i++) u8[di + i] = 0; return d; },
    strcat: (d, s) => { const a = cstrLen(d, 'strcat'), n = cstrLen(s, 'strcat'); copy(d + a, s, n + 1, 'strcat'); return d; },
    strncat: (d, s, n) => { const a = cstrLen(d, 'strncat'); const si = ix(s, 1, 'strncat'); let k = 0; while (k < (n >>> 0) && u8[si + k]) k++; const di = ixw(d + a, k + 1, 'strncat'); u8.copyWithin(di, si, si + k); u8[di + k] = 0; return d; },
    strcmp: (a, b) => { if (!a || !b) throw fault('strcmp was given a NULL string'); return strcmpImpl(a, b, Infinity, false); },
    strncmp: (a, b, n) => strcmpImpl(a, b, n >>> 0, false),
    strcasecmp: (a, b) => strcmpImpl(a, b, Infinity, true), strncasecmp: (a, b, n) => strcmpImpl(a, b, n >>> 0, true),
    strchr: (s, c) => { c &= 255; const i0 = ix(s, 1, 'strchr'); for (let i = i0; i < u8.length; i++) { if (u8[i] === c) return B + i; if (!u8[i]) return 0; } throw fault('strchr(): the string never ends'); },
    strrchr: (s, c) => { c &= 255; const i0 = ix(s, 1, 'strrchr'); let r = 0; for (let i = i0; i < u8.length; i++) { if (u8[i] === c) r = B + i; if (!u8[i]) return r; } throw fault('strrchr(): the string never ends'); },
    strstr: (h, n) => {
      const nl = cstrLen(n, 'strstr'); if (!nl) return h;
      const hl = cstrLen(h, 'strstr'); const hi = h - B, ni = n - B;
      outer: for (let i = 0; i + nl <= hl; i++) { for (let j = 0; j < nl; j++) if (u8[hi + i + j] !== u8[ni + j]) continue outer; return h + i; }
      return 0;
    },
    strdup: (s) => { const n = cstrLen(s, 'strdup'); const p = malloc(n + 1); if (!p) return 0; u8.copyWithin(p - B, s - B, s - B + n + 1); return p; },
    strndup: (s, n) => { const si = ix(s, 1, 'strndup'); let k = 0; while (k < (n >>> 0) && u8[si + k]) k++; const p = malloc(k + 1); if (!p) return 0; u8.copyWithin(p - B, si, si + k); u8[p - B + k] = 0; return p; },
    strspn: (s, a) => spanOf(s, a, true),
    strcspn: (s, r) => spanOf(s, r, false),
    strpbrk: (s, a) => { const set = new Set(cbytes(a)); for (let i = ix(s, 1, 'strpbrk'); u8[i]; i++) if (set.has(u8[i])) return B + i; return 0; },
    strerror: () => { if (!envStrs.has('#err')) envStrs.set('#err', allocStr('error')); return envStrs.get('#err'); },
    strtok: (s, d) => {
      if (!s) s = strtokSave;
      if (!s) return 0;
      s += spanOf(s, d, true);
      if (!u8[s - B]) { strtokSave = 0; return 0; }
      const e = s + spanOf(s, d, false);
      if (u8[e - B]) { u8[ixw(e, 1, 'strtok', 'the string (strtok changes the string, so it must not be a constant)')] = 0; strtokSave = e + 1; } else strtokSave = 0;
      return s;
    },
    strtok_r: (s, d, save) => {
      if (!s) s = rd32(save);
      if (!s) return 0;
      s += spanOf(s, d, true);
      if (!u8[s - B]) { wr32(save, 0); return 0; }
      const e = s + spanOf(s, d, false);
      if (u8[e - B]) { u8[ixw(e, 1, 'strtok_r')] = 0; wr32(save, e + 1); } else wr32(save, 0);
      return s;
    },
    isalpha: (c) => +isalpha(c), isdigit: (c) => +isdigit(c), isalnum: (c) => +isalnum(c), isspace: (c) => +isspace(c),
    isupper: (c) => +isupper(c), islower: (c) => +islower(c), isxdigit: (c) => +(isdigit(c) || (c >= 97 && c <= 102) || (c >= 65 && c <= 70)),
    ispunct: (c) => +(c > 32 && c < 127 && !isalnum(c)), isprint: (c) => +(c >= 32 && c < 127), isgraph: (c) => +(c > 32 && c < 127),
    iscntrl: (c) => +((c >= 0 && c < 32) || c === 127), tolower: (c) => (isupper(c) ? c + 32 : c), toupper: (c) => (islower(c) ? c - 32 : c),
    time: (t) => { const v = Math.floor(Date.now() / 1000); if (t) wr32(t, v); return v; },
    clock: () => Math.floor(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0) * 1000),
    sleep: () => 0, usleep: () => 0,
    __assert_fail: (e, file, line) => { flush(); throw fault('assert failed: ' + cstr(e)); },
    exp: M.exp, log: M.log, log2: M.log2, log10: M.log10, sin: M.sin, cos: M.cos, tan: M.tan, asin: M.asin, acos: M.acos, atan: M.atan,
    sinh: M.sinh, cosh: M.cosh, tanh: M.tanh, sqrt: M.sqrt, fabs: M.abs, floor: M.floor, ceil: M.ceil, round: roundAway, trunc: M.trunc,
    cbrt: M.cbrt, erf: erfImpl, exp2: (x) => M.pow(2, x), expm1: M.expm1, log1p: M.log1p,
    pow: M.pow, atan2: M.atan2, fmod: (a, b) => a % b, hypot: M.hypot, fmin: (a, b) => (a !== a ? b : b !== b ? a : M.min(a, b)), fmax: (a, b) => (a !== a ? b : b !== b ? a : M.max(a, b)),
    copysign: (a, b) => ((b < 0 || (b === 0 && 1 / b < 0)) ? -M.abs(a) : M.abs(a)),
    ldexp: (x, e) => x * M.pow(2, e), ldexpf: (x, e) => fr(x * M.pow(2, e)),
    lround: (x) => roundAway(x) | 0, lroundf: (x) => roundAway(x) | 0,
    __aeabi_idiv: (a, b) => (b === 0 ? 0 : (a / b) | 0), __aeabi_uidiv: (a, b) => (b === 0 ? 0 : ((a >>> 0) / (b >>> 0)) | 0),
    __aeabi_idivmod: (a, b) => { if (b === 0) return [0, a]; const q = (a / b) | 0; return [q, (a - Math.imul(q, b)) | 0]; },
    __aeabi_uidivmod: (a, b) => { if (b === 0) return [0, a]; const q = ((a >>> 0) / (b >>> 0)) >>> 0; return [q | 0, ((a >>> 0) - q * (b >>> 0)) | 0]; },
    __aeabi_ldivmod: (a, b) => { if (b === 0n) return [0, 0, Number(a & 0xFFFFFFFFn) | 0, Number((a >> 32n) & 0xFFFFFFFFn) | 0]; const q = BigInt.asIntN(64, a / b), r = BigInt.asIntN(64, a % b); return [Number(q & 0xFFFFFFFFn) | 0, Number((q >> 32n) & 0xFFFFFFFFn) | 0, Number(r & 0xFFFFFFFFn) | 0, Number((r >> 32n) & 0xFFFFFFFFn) | 0]; },
    __aeabi_uldivmod: (a, b) => { a = BigInt.asUintN(64, a); b = BigInt.asUintN(64, b); if (b === 0n) return [0, 0, Number(a & 0xFFFFFFFFn) | 0, Number(a >> 32n) | 0]; const q = a / b, r = a % b; return [Number(q & 0xFFFFFFFFn) | 0, Number(q >> 32n) | 0, Number(r & 0xFFFFFFFFn) | 0, Number(r >> 32n) | 0]; },
    __aeabi_memcpy: (d, s, n) => copy(d, s, n, 'memcpy'), __aeabi_memcpy4: (d, s, n) => copy(d, s, n, 'memcpy'), __aeabi_memcpy8: (d, s, n) => copy(d, s, n, 'memcpy'),
    __aeabi_memmove: (d, s, n) => copy(d, s, n, 'memmove'), __aeabi_memmove4: (d, s, n) => copy(d, s, n, 'memmove'), __aeabi_memmove8: (d, s, n) => copy(d, s, n, 'memmove'),
    __aeabi_memset: (d, n, c) => { n >>>= 0; if (n) { const i = ixw(d, n, 'memset'); u8.fill(c & 255, i, i + n); } },
    __aeabi_memclr: (d, n) => { n >>>= 0; if (n) { const i = ixw(d, n, 'memset'); u8.fill(0, i, i + n); } },
    __aeabi_f2lz: (x) => (x !== x ? 0n : x >= 9.2233720368547758e18 ? 0x7FFFFFFFFFFFFFFFn : x <= -9.2233720368547758e18 ? -0x8000000000000000n : BigInt(Math.trunc(x))),
    __aeabi_f2ulz: (x) => (x !== x || x <= 0 ? 0n : x >= 1.8446744073709552e19 ? -1n : BigInt.asIntN(64, BigInt(Math.trunc(x)))),
    __aeabi_l2f: (x) => fr(Number(BigInt.asIntN(64, x))), __aeabi_ul2f: (x) => fr(Number(BigInt.asUintN(64, x))),
    __aeabi_l2d: (x) => Number(BigInt.asIntN(64, x)), __aeabi_ul2d: (x) => Number(BigInt.asUintN(64, x)),
    __aeabi_lmul: (a, b) => BigInt.asIntN(64, a * b),
    __aeabi_llsl: (a, n) => BigInt.asIntN(64, a << BigInt(n & 63)), __aeabi_llsr: (a, n) => BigInt.asIntN(64, BigInt.asUintN(64, a) >> BigInt(n & 63)), __aeabi_lasr: (a, n) => a >> BigInt(n & 63),
  };
  F.bcmp = F.memcmp;
  F.__aeabi_d2lz = F.__aeabi_f2lz; F.__aeabi_d2ulz = F.__aeabi_f2ulz;
  F.__aeabi_memset4 = F.__aeabi_memset8 = F.__aeabi_memset; F.__aeabi_memclr4 = F.__aeabi_memclr8 = F.__aeabi_memclr;
  F.frexp = (x, ep) => { if (x === 0 || !isFinite(x)) { wr32(ep, 0); return x; } let e = Math.ceil(Math.log2(Math.abs(x))); let f = x / Math.pow(2, e); if (Math.abs(f) >= 1) { f /= 2; e++; } if (Math.abs(f) < 0.5) { f *= 2; e--; } wr32(ep, e); return f; };
  F.frexpf = (x, ep) => fr(F.frexp(x, ep));
  F.modf = (x, ip) => { const t = Math.trunc(x); const i = ixw(ip, 8, 'modf'); dv.setFloat64(i, t, true); return x - t; };
  F.modff = (x, ip) => { const t = Math.trunc(x); const i = ixw(ip, 4, 'modff'); dv.setFloat32(i, t, true); return fr(x - t); };
  for (const n of 'exp log log2 log10 sin cos tan asin acos atan sinh cosh tanh sqrt fabs floor ceil round trunc cbrt erf exp2 expm1 log1p'.split(' ')) { const f = F[n]; F[n + 'f'] = (x) => fr(f(x)); }
  for (const n of 'pow atan2 fmod hypot fmin fmax copysign'.split(' ')) { const f = F[n]; F[n + 'f'] = (a, b) => fr(f(a, b)); }
  // ---- calling convention glue: one specialised "thunk" per function (reads the arguments, calls, clobbers, stores the result)
  const CLOB = 0xDEADBEEF | 0;
  const stk = (o) => dv.getInt32(ix(((R[13] >>> 0) + o) >>> 0, 4, curName, 'an argument on the stack'), true);
  const big = (lo, hi) => (BigInt(hi) << 32n) | BigInt(lo >>> 0);
  const makeThunk = (name) => {
    const fn = F[name];
    if (!fn) return null;
    const sig = parseSig(name);
    let ncrn = 0, nsaa = 0, sUsed = 0, vfpDone = false;
    const rd = [];
    const core32 = () => { if (ncrn < 4) { const k = ncrn++; return () => R[k]; } const o = nsaa; nsaa += 4; return () => stk(o); };
    const core64 = () => {
      ncrn = (ncrn + 1) & ~1;
      if (ncrn + 2 <= 4) { const k = ncrn; ncrn += 2; return [() => R[k], () => R[k + 1]]; }
      ncrn = 4; nsaa = (nsaa + 7) & ~7; const o = nsaa; nsaa += 8; return [() => stk(o), () => stk(o + 4)];
    };
    for (const t of sig.args) {
      if (t === 'i') rd.push(core32());
      else if (t === 'l') { const [a, b] = core64(); rd.push(() => big(a(), b())); }
      else if (t === 'f') {
        if (sig.base) { const a = core32(); rd.push(() => { SI[0] = a(); return SF[0]; }); continue; }
        let k = -1; if (!vfpDone) for (let i = 0; i < 16; i++) if (!(sUsed & (1 << i))) { k = i; break; }
        if (k >= 0) { sUsed |= 1 << k; rd.push(() => VF[k]); } else { vfpDone = true; const o = nsaa; nsaa += 4; rd.push(() => { SI[0] = stk(o); return SF[0]; }); }
      } else if (t === 'd') {
        if (sig.base) { const [a, b] = core64(); rd.push(() => { SI[0] = a(); SI[1] = b(); return SD[0]; }); continue; }
        let k = -1; if (!vfpDone) for (let i = 0; i < 8; i++) if (!(sUsed & (3 << (2 * i)))) { k = i; break; }
        if (k >= 0) { sUsed |= 3 << (2 * k); rd.push(() => VD[k]); } else { vfpDone = true; nsaa = (nsaa + 7) & ~7; const o = nsaa; nsaa += 8; rd.push(() => { SI[0] = stk(o); SI[1] = stk(o + 4); return SD[0]; }); }
      }
    }
    if (sig.variadic) {
      const off = ncrn * 4 + nsaa;
      rd.push(() => {
        if ((R[13] & 7) !== 0) throw fault(name + '() was called with the stack pointer at ' + hex(R[13]) + ', which is not a multiple of 8. The ARM calling rules (AAPCS) need sp to be a multiple of 8 when you call a function: push an even number of registers (for example push {r4, lr} instead of push {lr}).');
        return new VA(off);
      });
    }
    const n = rd.length, a0 = rd[0], a1 = rd[1], a2 = rd[2], a3 = rd[3], a4 = rd[4];
    const ret = sig.ret, base = sig.base;
    return (pc) => {
      curPc = pc; curName = name;
      let res;
      switch (n) {
        case 0: res = fn(); break;
        case 1: res = fn(a0()); break;
        case 2: res = fn(a0(), a1()); break;
        case 3: res = fn(a0(), a1(), a2()); break;
        case 4: res = fn(a0(), a1(), a2(), a3()); break;
        case 5: res = fn(a0(), a1(), a2(), a3(), a4()); break;
        default: res = fn.apply(null, rd.map(f => f()));
      }
      // clobber the registers a call may change (so programs that wrongly keep values in them fail like on real hardware)
      R[1] = CLOB; R[2] = CLOB; R[3] = CLOB; R[12] = CLOB;
      VI[1] = CLOB; VI[2] = CLOB; VI[3] = CLOB; VI[4] = CLOB; VI[5] = CLOB; VI[6] = CLOB; VI[7] = CLOB; VI[8] = CLOB;
      VI[9] = CLOB; VI[10] = CLOB; VI[11] = CLOB; VI[12] = CLOB; VI[13] = CLOB; VI[14] = CLOB; VI[15] = CLOB;
      switch (ret) {
        case 'i': R[0] = res | 0; VI[0] = CLOB; break;
        case 'v': R[0] = CLOB; VI[0] = CLOB; break;
        case 'l': { const v = BigInt.asUintN(64, BigInt(res)); R[0] = Number(v & 0xFFFFFFFFn) | 0; R[1] = Number(v >> 32n) | 0; VI[0] = CLOB; break; }
        case 'f': if (base) { SF[0] = res; R[0] = SI[0]; VI[0] = CLOB; } else { VF[0] = res; R[0] = CLOB; } break;
        case 'd': if (base) { SD[0] = res; R[0] = SI[0]; R[1] = SI[1]; VI[0] = CLOB; VI[1] = CLOB; } else { VD[0] = res; R[0] = CLOB; } break;
        case 'q': R[0] = res[0] | 0; R[1] = res[1] | 0; if (res.length > 2) { R[2] = res[2] | 0; R[3] = res[3] | 0; } break;
      }
    };
  };
  const call = (name, fn, pc) => { const t = makeThunk(name); t(pc); };
  // raw Linux system calls (svc #0)
  const sysWrite = (fd, buf, n, pc) => {
    curPc = pc; curName = 'write (svc)';
    n >>>= 0;
    const i = ix(buf, n, 'write (svc #0)', 'the buffer in r1');
    if (fd === 1 || fd === 2) { writeStd(u8.slice(i, i + n), fd === 2); return n; }
    return -9;
  };
  const sysRead = (fd, buf, n, pc) => {
    curPc = pc; curName = 'read (svc)';
    if (fd !== 0) return -9;
    const h = handles.get(FB); const b = hRead(h, n >>> 0); u8.set(b, ixw(buf, b.length, 'read (svc #0)', 'the buffer in r1')); return b.length;
  };
  // program start: argv strings on the heap
  const setupArgs = (argv) => {
    const argvPtr = malloc(4 * (argv.length + 1)); liveBlocks--; liveBytes -= 4 * (argv.length + 1);
    argv.forEach((a, k) => { const p = allocStr(a); dv.setUint32(argvPtr - B + 4 * k, p, true); });
    dv.setUint32(argvPtr - B + 4 * argv.length, 0, true);
    liveBlocks = 0; liveBytes = 0;
    return argvPtr;
  };
  const lib = { funcs: F, call, makeThunk, refresh, flush, sysWrite, sysRead, setupArgs, heapCheck, files, atexitFns,
    stats: () => ({ blocks: liveBlocks, bytes: liveBytes, peak: peakBytes }), malloc, free, cstr };
  return lib;
};

// ---------------- run a whole program ----------------
// units: [{name, text, hidden, rename}] or pre-assembled [{name, obj, hidden}]
K.buildProgram = function (units, opts) {
  opts = opts || {};
  const objs = [];
  const errors = [];
  units.forEach((u, i) => {
    const obj = u.obj || K.assemble({ name: u.name, text: u.text, rename: u.rename });
    if (obj.errors.length) for (const e of obj.errors) errors.push({ unit: i, line: e.line, msg: e.msg });
    objs.push({ obj, name: u.name, hidden: !!u.hidden });
  });
  if (errors.length) return { ok: false, stage: 'assemble', errors, units: units.map(u => ({ name: u.name, hidden: !!u.hidden })) };
  const prog = K.link(objs, { libcFuncs: K.LIBC_FUNCS, entry: opts.entry || 'main' });
  if (!prog.ok) return { ok: false, stage: 'link', errors: prog.errors, units: prog.units };
  return { ok: true, prog };
};

// A program that runs one instruction at a time, for the step debugger.
K.debugSession = function (prog, env) {
  env = env || {};
  const m = new K.Machine(prog, { singleStep: true, checkABI: env.checkABI !== false });
  const lib = m.lib = K.makeLibc(m, env);
  const S = m.S, R = S.R, L = prog.layout;
  const argv = env.argv || ['program'];
  const argvPtr = lib.setupArgs(argv);
  R[0] = argv.length; R[1] = argvPtr; R[13] = L.stackHi; R[14] = LAYOUT.MAGIC_EXIT;
  const sess = { m, prog, lib, pc: prog.entry | 0, done: false, exitCode: null, fault: null, steps: 0 };
  const finish = () => { sess.done = true; try { lib.flush(); } catch (e) { /* ignore */ } };
  sess.step = function () {
    if (sess.done) return false;
    try {
      sess.pc = m.stepOnce(sess.pc);
      sess.steps++;
      if (sess.pc === (LAYOUT.MAGIC_EXIT | 0)) { sess.exitCode = R[0]; finish(); }
    } catch (e) {
      if (e instanceof K.ExitSignal) sess.exitCode = e.code;
      else if (e instanceof K.CFault) {
        const w = m.where(e.pc);
        sess.fault = { msg: e.message, pc: e.pc, unit: w.unit, line: w.line, func: w.func, abi: !!e.abi };
        sess.exitCode = -1;
      } else throw e;
      finish();
    }
    return !sess.done;
  };
  sess.depth = () => m.frames.length;
  sess.stack = () => m.frames.slice().reverse().map(f => { const fn = K.funcAt(prog, f.target); return { func: fn ? fn.name : K.hex(f.target), ret: f.ret >>> 0 }; });
  return sess;
};

K.runProgram = function (prog, env) {
  env = env || {};
  const m = new K.Machine(prog, { maxSteps: env.maxSteps, deadline: env.deadline, checkABI: env.checkABI, singleStep: env.singleStep });
  const lib = m.lib = K.makeLibc(m, env);
  const S = m.S, R = S.R;
  const L = prog.layout;
  const argv = env.argv || ['program'];
  const argvPtr = lib.setupArgs(argv);
  R[0] = argv.length; R[1] = argvPtr; R[13] = L.stackHi; R[14] = LAYOUT.MAGIC_EXIT;
  let exitCode = 0, fault = null;
  const t0 = Date.now();
  try {
    m.run(prog.entry);
    exitCode = R[0];
  } catch (e) {
    if (e instanceof K.ExitSignal) exitCode = e.code;
    else if (e instanceof K.CFault) {
      const w = m.where(e.pc);
      fault = { msg: e.message, pc: e.pc, unit: w.unit, line: w.line, func: w.func, abi: !!e.abi, timeout: !!e.timeout, stack: m.frames.slice(-12).reverse().map(f => { const fn = K.funcAt(prog, f.target); return fn ? fn.name : K.hex(f.target); }) };
      exitCode = -1;
    } else throw e;
  }
  try { lib.flush(); } catch (e) { /* ignore */ }
  return { exitCode, fault, ms: Date.now() - t0, steps: S.steps, leaks: lib.stats(), files: lib.files, machine: m, compiled: m.compiled };
};
})(typeof globalThis !== 'undefined' ? globalThis : this);

