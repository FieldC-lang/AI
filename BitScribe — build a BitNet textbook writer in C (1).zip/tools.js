// BitScribe tools: the Machine (C playground), the Writer (textbook writer) and My code (project + export).
(function () {
'use strict';
const BS = window.BS;
const { $, $$, esc, h, toast, modal, fmtTime } = BS;
BS.views = BS.views || {};
const S = () => BS.S();

// ---------------- a tiny IndexedDB store for books (optional; the app works without it) ----------------
const Store = (() => {
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((res) => {
      try {
        const r = indexedDB.open('bitscribe-books', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('files');
        r.onsuccess = () => res(r.result);
        r.onerror = () => res(null);
      } catch (e) { res(null); }
    });
    return dbp;
  }
  async function op(mode, fn) {
    const db = await open();
    if (!db) return null;
    return new Promise((res) => {
      try { const tx = db.transaction('files', mode); const st = tx.objectStore('files'); const r = fn(st); tx.oncomplete = () => res(r && r.result); tx.onerror = () => res(null); } catch (e) { res(null); }
    });
  }
  return {
    put: (k, v) => op('readwrite', st => st.put(v, k)),
    get: (k) => op('readonly', st => st.get(k)),
    del: (k) => op('readwrite', st => st.delete(k)),
  };
})();

// ---------------- Machine ----------------
const TEMPLATES = {
  hello: { label: 'Hello, world', mine: false, src: '#include <stdio.h>\n\nint main(void) {\n    printf("Hello from the BitScribe machine!\\n");\n    for (int i = 1; i <= 5; i++) printf("%d squared is %d\\n", i, i * i);\n    return 0;\n}\n' },
  generate: { label: 'Generate text with my BitNet', mine: true, src: '// Uses YOUR engine: engine_load and generate from the course.\nint main(void) {\n    static Engine e;\n    if (!engine_load(&e, "models/tiny.bnet", "models/tiny.tok", 256)) {\n        printf("could not load the model\\n");\n        return 1;\n    }\n    e.sampler.temperature = 0.8f;\n    Str out;\n    str_init(&out);\n    generate(&e, "Book: Volcanoes\\nChapter: Eruptions\\nSection: What happens in an eruption\\n<|text|>\\n", 150, &out, 1);\n    printf("\\n\\n[%lld tokens]\\n", e.total_tokens);\n    return 0;\n}\n' },
  tokens: { label: 'Tokenizer explorer', mine: true, src: '// Uses YOUR tokenizer: load_tokenizer, encode and token_text.\nint main(void) {\n    static Tokenizer t;\n    if (!load_tokenizer("models/tiny.tok", &t)) { printf("no tokenizer\\n"); return 1; }\n    const char* text = "BitNet stores every weight in 1.58 bits.";\n    int ids[64];\n    int n = encode(&t, text, ids, 64, 1);\n    printf("%d tokens:\\n", n);\n    for (int i = 0; i < n; i++) {\n        int len;\n        const char* p = token_text(&t, ids[i], &len);\n        printf("%5d  \\"%.*s\\"\\n", ids[i], len, p);\n    }\n    return 0;\n}\n' },
  diagrams: { label: 'Draw diagrams into a PDF', mine: true, src: '// Uses YOUR layout, diagram and PDF code.\nint main(void) {\n    static Settings s;\n    settings_defaults(&s);\n    static Pdf pdf;\n    pdf_begin(&pdf);\n    static Layout L;\n    if (!layout_init(&L, &s, &pdf, NULL, NULL, 0, "My diagrams")) { printf("fonts missing\\n"); return 1; }\n    layout_chapter(&L, 1, "Diagrams drawn by my code");\n    layout_diagram(&L, "[DIAGRAM cycle: Evaporation | Condensation | Precipitation | Collection ; The water cycle]");\n    layout_diagram(&L, "[DIAGRAM plot: y=x*sin(x) | x=-10..10 ; A wiggly graph]");\n    layout_diagram(&L, "[DIAGRAM tree: Rocks > Igneous, Sedimentary, Metamorphic ; Three kinds of rock]");\n    layout_finish_page(&L);\n    const char* fonts[6] = {L.fonts[0].name, L.fonts[1].name, L.fonts[2].name, L.fonts[3].name, L.fonts[4].name, L.fonts[5].name};\n    pdf_finish(&pdf, "My diagrams", fonts);\n    pdf_save(&pdf, "diagrams.pdf");\n    printf("Saved diagrams.pdf with %d page(s)\\n", pdf.n_pages);\n    return 0;\n}\n' },
};
const machineRunner = new BS.Runner('machine');
BS.views.machine = function (view) {
  const st = S();
  if (!st.machine.src) st.machine.src = TEMPLATES.hello.src;
  view.innerHTML = `
    <h1>The Machine</h1>
    <p class="sub">A C computer inside this app: your code is compiled to WebAssembly and run here. Tick <b>Use my BitScribe code</b> to call the functions you wrote in the lessons.</p>
    <div class="card editor-card">
      <div class="editor-bar">
        <select id="tpl" style="width:auto"><option value="">Examples…</option>${Object.entries(TEMPLATES).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('')}</select>
        <label class="switch" style="margin:0"><input type="checkbox" id="mine" ${st.machine.mine ? 'checked' : ''}> Use my BitScribe code</label>
        <span class="grow"></span>
        <button class="btn primary" id="mrun">▶ Run</button>
      </div>
      <div id="med"></div>
      <div class="results">
        <div class="row" style="margin-bottom:8px"><label class="grow">Arguments <input type="text" id="margs" placeholder="for example: --topic Bees" value="${esc(st.machine.args || '')}"></label></div>
        <div class="console" id="mout">Output appears here.</div>
        <div id="mfiles" class="filelist"></div>
      </div>
    </div>`;
  const ed = BS.makeEditor($('#med', view), st.machine.src, { onChange: (v) => { st.machine.src = v; BS.save({ local: true }); }, onRun: () => run(), allowPaste: true });
  $('#tpl', view).onchange = (e) => { const t = TEMPLATES[e.target.value]; if (!t) return; ed.set(t.src); st.machine.src = t.src; $('#mine', view).checked = t.mine; st.machine.mine = t.mine; BS.save({ local: true }); e.target.value = ''; };
  $('#mine', view).onchange = (e) => { st.machine.mine = e.target.checked; BS.save({ local: true }); };
  $('#margs', view).onchange = (e) => { st.machine.args = e.target.value; BS.save({ local: true }); };
  const out = $('#mout', view), runBtn = $('#mrun', view), filesBox = $('#mfiles', view);
  let running = false;
  async function run() {
    if (running) { machineRunner.stop(); return; }
    running = true; runBtn.textContent = '■ Stop'; runBtn.classList.replace('primary', 'danger');
    out.innerHTML = ''; filesBox.innerHTML = '';
    let chunks = [], note = '';
    if ($('#mine', view).checked) {
      const p = BS.programChunks({ fill: true, renameMain: true });
      chunks = p.chunks;
      if (p.missing.length) note = `(${p.missing.length} lesson(s) not done yet: the course's code fills in for those parts)\n`;
    }
    chunks.push({ name: 'your code', code: ed.get() });
    const args = ($('#margs', view).value.match(/"[^"]*"|\S+/g) || []).map(a => a.replace(/^"|"$/g, ''));
    if (note) out.appendChild(document.createTextNode(note));
    const t0 = Date.now();
    const res = await machineRunner.run({ chunks, argv: ['program', ...args], returnFiles: true }, {
      onOut: (t, e) => {
        if (t) out.appendChild(document.createTextNode(t));
        if (e) { const s = document.createElement('span'); s.className = 'e'; s.textContent = e; out.appendChild(s); }
        if (out.childNodes.length > 4000) out.removeChild(out.firstChild);
        out.scrollTop = out.scrollHeight;
      },
    });
    running = false; runBtn.textContent = '▶ Run'; runBtn.classList.replace('danger', 'primary');
    const tail = document.createElement('span');
    tail.className = res.fault || (res.compile && !res.compile.ok) ? 'e' : '';
    if (res.stopped) tail.textContent = '\n[stopped]';
    else if (res.compile && !res.compile.ok) { const e = res.compile.error; tail.textContent = `Compile error${e.file === 'your code' ? ' on line ' + e.line : ' in ' + e.file}: ${e.msg}${e.file === 'your code' && e.src ? '\n    ' + e.src : ''}`; if (e.file === 'your code') ed.mark(e.line); }
    else if (res.fault) { const line = (res.fault.lineId >>> 20) === chunks.length ? res.fault.lineId & 0xfffff : 0; tail.textContent = `\n[crashed: ${res.fault.msg}${line ? ' — line ' + line : ''}${res.stack && res.stack.length ? ' — in ' + res.stack.slice(0, 3).join(' ← ') : ''}]`; if (line) ed.mark(line); }
    else tail.textContent = `\n[finished with exit code ${res.exitCode} in ${fmtTime((Date.now() - t0) / 1000)}]`;
    out.appendChild(tail);
    out.scrollTop = out.scrollHeight;
    showFiles(filesBox, res.files || []);
  }
  runBtn.onclick = run;
  BS.onLeave = () => { if (running) machineRunner.stop(); };
};
function showFiles(box, files) {
  box.innerHTML = '';
  for (const [path, data] of files) {
    if (/\.state$/.test(path)) continue;
    const name = path.replace(/^\//, '');
    const isPdf = /\.pdf$/i.test(name);
    const row = h(`<div class="f"><span class="ic">${isPdf ? '📕' : '📄'}</span><b class="grow">${esc(name)}</b><span class="muted">${(data.length / 1024).toFixed(1)} KB</span>${isPdf ? '<button class="btn small blue" data-a="view">View</button>' : '<button class="btn small" data-a="text">Show</button>'}<button class="btn small" data-a="save">Download</button></div>`);
    const v = $('[data-a=view]', row); if (v) v.onclick = () => BS.openPdf(data, name);
    const t = $('[data-a=text]', row); if (t) t.onclick = () => modal(`<h3>${esc(name)}</h3><pre class="console" style="max-height:60vh">${esc(new TextDecoder().decode(data.slice(0, 200000)))}</pre>`);
    $('[data-a=save]', row).onclick = () => BS.saveFile(name.split('/').pop().replace(/\.(state)$/, '.txt'), data);
    box.appendChild(row);
  }
}
BS.showFiles = showFiles;

// ---------------- Writer ----------------
const writerRunner = new BS.Runner('writer');
let job = null;   // the running (or last) writing job, kept while you switch tabs
function settingsText(w, native) {
  const one = (s) => String(s == null ? '' : s).replace(/[\r\n]+/g, ' ').trim();
  const lines = [
    '# BitScribe settings: one "key = value" per line. Lines starting with # are comments.',
    'topic = ' + one(w.topic), 'title = ' + one(w.title), 'audience = ' + one(w.audience), 'author = ' + one(w.author || 'BitScribe'),
    'model = models/tiny.bnet', 'tokenizer = models/tiny.tok', 'out = book', 'font = ' + (w.font === 'sans' ? 'sans' : 'serif'),
    'user_agent = BitScribe/1.0 (student textbook project' + (native ? '; add your email here' : '') + ')',
    'wiki = ' + (native ? 'en.wikipedia.org' : 'offline.bitscribe'),
    'pages = ' + w.pages, 'volumes = ' + w.volumes, 'chapters = ' + w.chapters, 'sections = ' + w.sections, 'tokens_per_hit = ' + w.tokens_per_hit,
    'web = ' + (w.web ? 1 : 0), 'web_sources = ' + w.web_sources, 'diagrams = ' + (w.diagrams ? 1 : 0), 'diagram_every = ' + w.diagram_every,
    'exercises = ' + (w.exercises ? 1 : 0), 'key_ideas = ' + (w.key_ideas ? 1 : 0), 'toc = ' + (w.toc ? 1 : 0), 'index = ' + (w.index ? 1 : 0), 'resume = 1',
    'temperature = ' + w.temperature, 'top_p = ' + w.top_p, 'top_k = ' + w.top_k, 'repeat_penalty = ' + w.repeat_penalty, 'seed = ' + w.seed,
    'font_size = ' + w.font_size, 'line_spacing = ' + w.line_spacing, 'margin_mm = ' + w.margin_mm,
  ];
  return lines.join('\n') + '\n';
}
BS.settingsText = settingsText;
function userPages(text) {
  // "My sources": blocks separated by a line with --- ; the first line of a block is its title
  return String(text || '').split(/^\s*---\s*$/m).map(b => b.trim()).filter(Boolean).map(b => {
    const nl = b.indexOf('\n');
    return { title: (nl < 0 ? b : b.slice(0, nl)).replace(/^#+\s*/, '').trim().slice(0, 90), text: nl < 0 ? '' : b.slice(nl + 1).trim() };
  }).filter(p => p.title && p.text.length > 40);
}
function estimate(w) {
  const tokens = w.pages * w.volumes * 450 * 1.4;
  const speed = S().writerSpeed || 140;      // forward passes per second in this browser (measured after a run)
  return tokens * 2.6 / speed;               // prompts are re-read on every hit, so ~2.6 forward passes per new token
}
BS.views.writer = function (view) {
  const st = S(), w = st.writer;
  const coding = BS.LESSONS.filter(BS.isCoding);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  view.innerHTML = `
    <div class="hero"><h1>The Writer</h1><div class="sub">One prompt in, a finished textbook out: your BitNet program researches the topic, plans volumes and chapters, writes every section in many short model “hits”, draws diagrams, and lays out PDFs with contents and an index.</div></div>
    <div class="card" id="prog-status" style="margin-bottom:14px">${missing.length === 0 ? `<b>✅ Your program: all ${BS.TOTAL_PARTS()} parts written by you.</b> The Writer runs exactly your code.` : `<b>Your program: ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts written by you.</b> <span class="sub">Until you finish the course, the Writer can run as a <b>demo</b> in which the course's own code fills in the ${missing.length} lesson(s) you have not done yet.</span>`}</div>
    <div class="grid2">
      <div class="card">
        <h3>Your book</h3>
        <label class="field"><span>Topic — the one prompt</span><input type="text" class="big-input" data-k="topic" maxlength="90" placeholder="for example: Volcanoes"></label>
        <label class="field"><span>Title (empty = the topic)</span><input type="text" data-k="title" maxlength="90"></label>
        <div class="grid2"><label class="field"><span>Written for</span><input type="text" data-k="audience" maxlength="90"></label><label class="field"><span>Author line</span><input type="text" data-k="author" maxlength="90" placeholder="BitScribe"></label></div>
        <label class="field"><span>Pages per volume: <b id="v-pages"></b></span><div class="range-row"><input type="range" min="1" max="600" data-k="pages" data-num="1"><input type="number" min="1" max="600" data-k="pages" data-num="1"></div></label>
        <label class="field"><span>Volumes: <b id="v-vols"></b></span><div class="range-row"><input type="range" min="1" max="10" data-k="volumes" data-num="1"><input type="number" min="1" max="10" data-k="volumes" data-num="1"></div></label>
        <p class="muted" id="est"></p>
      </div>
      <div class="card">
        <h3>What goes in</h3>
        <label class="switch"><input type="checkbox" data-k="web"> Research the topic in the encyclopedia first</label>
        <label class="field"><span>Articles to read</span><input type="number" min="0" max="8" data-k="web_sources" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="diagrams"> Diagrams and pictures</label>
        <label class="field"><span>Automatic diagram every … sections</span><input type="number" min="1" max="20" data-k="diagram_every" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="exercises"> Exercises after each chapter</label>
        <label class="switch"><input type="checkbox" data-k="key_ideas"> “Key idea” boxes</label>
        <label class="switch"><input type="checkbox" data-k="toc"> Contents pages</label>
        <label class="switch"><input type="checkbox" data-k="index"> Index</label>
      </div>
    </div>
    <details class="card" style="margin-top:14px"><summary style="cursor:pointer;font-weight:800">More settings: model, layout and your own sources</summary>
      <div class="grid3" style="margin-top:10px">
        <label class="field"><span>Chapters per volume (0 = auto)</span><input type="number" min="0" max="80" data-k="chapters" data-num="1"></label>
        <label class="field"><span>Sections per chapter (0 = auto)</span><input type="number" min="0" max="16" data-k="sections" data-num="1"></label>
        <label class="field"><span>Most tokens per hit</span><input type="number" min="32" max="4000" data-k="tokens_per_hit" data-num="1"></label>
        <label class="field"><span>Temperature</span><input type="number" min="0" max="2" step="0.05" data-k="temperature" data-num="1"></label>
        <label class="field"><span>Top-p</span><input type="number" min="0.05" max="1" step="0.05" data-k="top_p" data-num="1"></label>
        <label class="field"><span>Top-k (0 = off)</span><input type="number" min="0" max="1000" data-k="top_k" data-num="1"></label>
        <label class="field"><span>Repeat penalty</span><input type="number" min="1" max="2" step="0.05" data-k="repeat_penalty" data-num="1"></label>
        <label class="field"><span>Random seed</span><input type="number" data-k="seed" data-num="1"></label>
        <label class="field"><span>Book font</span><select data-k="font"><option value="serif">Times (serif)</option><option value="sans">Helvetica (sans-serif)</option></select></label>
        <label class="field"><span>Font size (pt)</span><input type="number" min="7" max="16" step="0.5" data-k="font_size" data-num="1"></label>
        <label class="field"><span>Line spacing</span><input type="number" min="1" max="2.5" step="0.05" data-k="line_spacing" data-num="1"></label>
        <label class="field"><span>Margins (mm)</span><input type="number" min="8" max="40" data-k="margin_mm" data-num="1"></label>
      </div>
      <label class="field"><span>My own sources (optional). Paste notes or articles you are allowed to use: first line = title, then the text. Separate sources with a line containing only ---</span><textarea data-k="sources" rows="6" placeholder="Photosynthesis notes&#10;Plants make glucose from carbon dioxide and water using light energy..."></textarea></label>
      <p class="muted">The browser cannot reach the internet, so the emulator's “web” is a built-in encyclopedia of ${BS.ASSETS.articles.length} articles plus your own sources. On a real computer your exported program reads Wikipedia.</p>
    </details>
    <div class="row" style="margin:16px 0"><button class="btn primary" id="go" style="font-size:16px;padding:14px 22px">✍️ Write my textbook</button><button class="btn" id="stop" hidden>■ Stop</button><button class="btn" id="resume" hidden>Continue writing</button><span class="grow"></span><button class="btn small" id="dl-settings">Download settings.txt</button></div>
    <div id="job"></div>`;
  // bind the form
  $$('[data-k]', view).forEach(inp => {
    const k = inp.dataset.k;
    if (inp.type === 'checkbox') inp.checked = !!w[k]; else inp.value = w[k];
    const ev = inp.type === 'range' || inp.tagName === 'TEXTAREA' || inp.type === 'text' ? 'input' : 'change';
    inp.addEventListener(ev, () => {
      let v = inp.type === 'checkbox' ? (inp.checked ? 1 : 0) : inp.value;
      if (inp.dataset.num) { v = Number(v); if (!isFinite(v)) return; const mn = inp.min !== '' ? Number(inp.min) : -Infinity, mx = inp.max !== '' ? Number(inp.max) : Infinity; v = Math.min(mx, Math.max(mn, v)); }
      w[k] = v;
      $$(`[data-k="${k}"]`, view).forEach(o => { if (o !== inp && o.type !== 'checkbox') o.value = v; });
      BS.save();
      refresh();
    });
  });
  function refresh() {
    $('#v-pages', view).textContent = w.pages;
    $('#v-vols', view).textContent = w.volumes;
    const words = Math.round(w.pages * w.volumes * 450);
    $('#est', view).textContent = `About ${words.toLocaleString()} words in ${w.volumes * w.pages} pages. Estimated writing time in this browser with the small model: ${fmtTime(estimate(w))}${w.pages * w.volumes > 200 ? ' — big books are best written on a computer with the exported program' : ''}.`;
  }
  refresh();
  $('#dl-settings', view).onclick = () => BS.saveFile('settings.txt', settingsText(w, true));
  const go = $('#go', view), stop = $('#stop', view), resume = $('#resume', view), jobBox = $('#job', view);
  go.onclick = () => start(false);
  resume.onclick = () => start(true);
  stop.onclick = () => { if (job && job.running) { writerRunner.stop(); } };
  async function start(cont) {
    if (job && job.running) return;
    if (!w.topic || !String(w.topic).trim()) { toast('Type a topic first.'); return; }
    const miss = BS.LESSONS.filter(BS.isCoding).filter(L => !(S().done[L.id] && S().code[L.id]));
    if (miss.length) {
      const ok = await modal(`<h3>Run a demo?</h3><p>You have written ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts. For the other ${miss.length} lesson(s) the course's own code will be used, hidden from you. Your written parts are used as they are.</p><p class="muted">When you finish the course, the Writer runs 100% your code.</p>`, [{ label: 'Cancel', value: false }, { label: 'Run the demo', value: true, cls: 'primary' }]);
      if (!ok) return;
    }
    const prev = cont && job ? job.files : new Map();
    job = { running: true, t0: Date.now(), tWrite: 0, log: [], plan: [], status: 'Starting…', frac: 0, tokens: 0, files: new Map(), results: [], cont, prevFiles: prev, done: null, error: null };
    if (!cont) await Store.del('lastbook');
    built = null;
    renderJob();
    go.disabled = true; stop.hidden = false; resume.hidden = true;
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(true); } catch (e) {}
    const { chunks } = BS.programChunks({ fill: true });
    const files = [['/settings.txt', settingsText(w, false)]];
    if (cont) for (const [p, d] of prev) if (/\.(md|state)$/.test(p)) files.push([p, d]);
    const sources = userPages(w.sources);
    let buf = '';
    const res = await writerRunner.run({ chunks, argv: ['bitscribe'], files, userPages: sources, snapshot: '_vol\\d+\\.(md|state|pdf)$', returnFiles: '\\.(pdf|md)$', maxOut: 200e6 }, {
      onCompiled: (m) => { if (!m.ok) { job.error = m.error; } else job.status = 'Researching and planning…'; renderJob(); },
      onOut: (t) => {
        buf += t;
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) { handleLine(buf.slice(0, nl)); buf = buf.slice(nl + 1); }
        renderJobSoon();
      },
      onFiles: (fs) => { for (const [p, d] of fs) job.files.set(p, d); renderJobSoon(); },
    });
    if (buf) handleLine(buf);
    job.running = false;
    for (const [p, d] of (res.files || [])) job.files.set(p, d);
    if (res.stopped) job.status = 'Stopped. Press “Continue writing” to carry on from the last finished chapter.';
    else if (res.fault) job.error = { msg: res.fault.msg + (res.stack && res.stack.length ? ' (in ' + res.stack.slice(0, 3).join(' ← ') + ')' : '') };
    else if (res.exitCode && !job.error) job.error = { msg: (res.err || 'the program stopped with exit code ' + res.exitCode).trim() };
    if (!res.stopped && !job.error) {
      job.status = 'Finished!';
      const secs = (Date.now() - (job.tWrite || job.t0)) / 1000;
      if (job.tokens > 50 && secs > 5) { S().writerSpeed = Math.round(job.tokens * 2.6 / secs); BS.save({ local: true }); }
      BS.sound('complete'); BS.confetti();
    }
    try { await Store.put('lastbook', { files: [...job.files.entries()], results: job.results, topic: w.topic, t: Date.now() }); } catch (e) {}
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(false); } catch (e) {}
    go.disabled = false; stop.hidden = true; resume.hidden = !(res.stopped || job.error) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  }
  function handleLine(line) {
    if (!line.startsWith('@@')) { if (line.trim()) job.log.push(line); return; }
    const sp = line.indexOf(' ');
    const kind = line.slice(2, sp < 0 ? undefined : sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    if (kind === 'status') {
      job.status = rest;
      if (!job.tWrite) job.tWrite = Date.now();
      const m = /volume (\d+)\/(\d+), chapter (\d+)\/(\d+), section (\d+)\/(\d+)/.exec(rest);
      if (m) { const [V, NV, C, NC, K, NK] = m.slice(1).map(Number); job.frac = ((V - 1) + ((C - 1) + (K - 1) / NK) / NC) / NV; }
    } else if (kind === 'progress') { const m = /tokens (\d+)/.exec(rest); if (m) job.tokens += +m[1]; }
    else if (kind === 'plan') job.plan.push(rest);
    else if (kind === 'log') job.log.push(rest);
    else if (kind === 'file') { const m = /^(\S+)\s+(\d+)/.exec(rest); if (m) job.results.push({ path: '/' + m[1].replace(/^\//, ''), pages: +m[2] }); job.log.push('finished ' + rest.replace(/^\//, '') + ' pages'); }
    else if (kind === 'done') job.log.push(rest);
    if (job.log.length > 300) job.log.splice(0, job.log.length - 300);
  }
  let renderTimer = null, built = null, shownResults = -1;
  function renderJobSoon() { if (!renderTimer) renderTimer = setTimeout(() => { renderTimer = null; renderJob(); }, 400); }
  function buildJob() {
    jobBox.innerHTML = `<div class="card">
      <div class="jerr"></div>
      <div class="row"><b class="grow jstatus"></b><span class="muted jtime"></span></div>
      <div class="bar" style="margin:10px 0"><i class="jbar"></i></div>
      <div class="jfiles"></div>
      <details class="jprev-d"><summary class="muted" style="cursor:pointer">Latest text from the model</summary><div class="preview-text jprev"></div></details>
      <details class="jplan-d"><summary class="muted jplan-s" style="cursor:pointer">The plan</summary><div class="log jplan"></div></details>
      <details><summary class="muted" style="cursor:pointer">Log</summary><div class="log jlog"></div></details>
    </div>`;
    built = { box: jobBox.firstElementChild };
    for (const k of ['jerr', 'jstatus', 'jtime', 'jbar', 'jfiles', 'jprev', 'jprev-d', 'jplan', 'jplan-d', 'jplan-s', 'jlog']) built[k] = $('.' + k, jobBox);
    if (job.running) built['jprev-d'].open = true;
    shownResults = -1;
  }
  function renderJob() {
    if (!job || !document.body.contains(jobBox)) return;
    if (!built || !jobBox.contains(built.box)) buildJob();
    const B = built;
    const elapsed = (Date.now() - job.t0) / 1000;
    let eta = '';
    if (job.running && job.frac > 0.02 && job.tWrite) { const we = (Date.now() - job.tWrite) / 1000; eta = ' · about ' + fmtTime(we * (1 - job.frac) / job.frac) + ' left'; }
    B.jerr.innerHTML = job.error ? `<div class="res err"><h4>The program stopped with an error</h4>${esc(job.error.msg)}${job.error.file ? `<div class="muted">${esc(job.error.file)}, line ${job.error.line}</div>` : ''}</div>` : '';
    B.jstatus.textContent = job.status;
    B.jtime.textContent = (job.done && !job.running && !job.tokens ? '' : fmtTime(elapsed) + eta + ' · ' + job.tokens.toLocaleString() + ' tokens');
    B.jbar.style.width = (job.running ? Math.max(2, 100 * job.frac) : job.error ? 100 * job.frac : 100).toFixed(1) + '%';
    const pdfs = job.results.filter(r => job.files.has(r.path));
    if (pdfs.length !== shownResults) {
      shownResults = pdfs.length;
      B.jfiles.innerHTML = pdfs.length ? `<h3>Your book</h3><div class="filelist">${pdfs.map((r, i) => `<div class="f"><span class="ic">📕</span><b class="grow">${esc(r.path.slice(1))}</b><span class="muted">${r.pages} pages</span><button class="btn small blue" data-v="${i}">View</button><button class="btn small" data-d="${i}">Download PDF</button><button class="btn small" data-m="${i}">Text (.md)</button></div>`).join('')}</div>` : '';
      $$('[data-v]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.v]; b.onclick = () => BS.openPdf(job.files.get(r.path), r.path.slice(1)); });
      $$('[data-d]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.d]; b.onclick = () => BS.saveFile(r.path.slice(1), job.files.get(r.path)); });
      $$('[data-m]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.m]; const mdp = r.path.replace(/\.pdf$/, '.md'); b.onclick = () => { const d = job.files.get(mdp); if (d) BS.saveFile(mdp.slice(1), d); else toast('The text file is not available.'); }; });
    }
    const md = [...job.files.entries()].filter(([p]) => /\.md$/.test(p)).sort((a, b) => a[0] < b[0] ? -1 : 1).pop();
    const preview = md ? new TextDecoder().decode(md[1].slice(Math.max(0, md[1].length - 2500))) : '';
    B['jprev-d'].hidden = !preview;
    if (B.jprev.textContent !== preview) { B.jprev.textContent = preview; B.jprev.scrollTop = 1e9; }
    B['jplan-d'].hidden = !job.plan.length;
    B['jplan-s'].textContent = 'The plan (' + job.plan.length + ' chapters)';
    const planText = job.plan.join('\n');
    if (B.jplan.textContent !== planText) B.jplan.textContent = planText;
    const logText = job.log.slice(-150).join('\n');
    if (B.jlog.textContent !== logText) { B.jlog.textContent = logText; B.jlog.scrollTop = 1e9; }
  }
  if (job) {
    if (job.running) { go.disabled = true; stop.hidden = false; }
    else resume.hidden = !(job.error || /Stopped/.test(job.status)) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  } else {
    Store.get('lastbook').then(last => {
      if (!last || job || !document.body.contains(jobBox)) return;
      job = { running: false, t0: last.t, tWrite: last.t, log: [], plan: [], status: 'Your last book (' + (last.topic || '') + ')', frac: 1, tokens: 0, files: new Map(last.files || []), results: last.results || [], done: true, error: null };
      resume.hidden = !(job.results.length === 0 && [...job.files.keys()].some(p => /\.state$/.test(p)));
      renderJob();
    });
  }
  const tick = setInterval(() => { if (!document.body.contains(jobBox)) { clearInterval(tick); return; } if (job && job.running) renderJob(); }, 1000);
};

// ---------------- My code: the project ----------------
BS.views.project = function (view) {
  const st = S();
  const coding = BS.LESSONS.filter(BS.isCoding);
  const mine = coding.filter(L => st.done[L.id] && st.code[L.id]);
  view.innerHTML = `
    <h1>My code</h1>
    <div class="card">
      <div class="row"><div class="grow"><b>${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts</b> of BitScribe are written by you (${mine.length} of ${coding.length} coding lessons).</div></div>
      <div class="bar" style="margin:10px 0"><i style="width:${(100 * BS.partsWritten() / BS.TOTAL_PARTS()).toFixed(1)}%"></i></div>
      <div class="row">
        <button class="btn" id="chk">Check that it compiles</button>
        <button class="btn" id="alltests">Run every test with my code</button>
        <button class="btn blue" id="export">Export project (.zip)</button>
      </div>
      <div id="pres" style="margin-top:10px"></div>
    </div>
    <div class="card" style="margin-top:14px" id="units"></div>`;
  const unitsBox = $('#units', view);
  for (const u of BS.UNITS) {
    const ls = u.lessons.filter(BS.isCoding);
    if (!ls.length) continue;
    const row = h(`<div class="unit-row"><div class="row"><span class="pill" style="background:${esc(u.color)};color:#fff">${esc(u.title)}</span><span class="muted">${ls.filter(L => st.done[L.id] && st.code[L.id]).length}/${ls.length}</span></div></div>`);
    for (const L of ls) {
      const ok = st.done[L.id] && st.code[L.id];
      const r = h(`<div class="lesson-row"><span>${ok ? '✅' : '⬜'}</span><span class="lt" style="font-weight:800">${esc(L.title)}</span>${L.items.map(i => `<span class="pill ${ok ? 'green' : ''}">${esc(i)}</span>`).join('')}</div>`);
      r.onclick = () => {
        if (!ok) { location.hash = 'lesson-' + L.id; return; }
        modal(`<h3>${esc(L.title)}</h3><div class="code-view">${BS.hlC(st.code[L.id].src)}</div><p class="muted">To change this code, open the lesson again: it is tested before it is saved.</p>`, [{ label: 'Close', value: 0 }, { label: 'Open the lesson', value: 1, cls: 'primary' }]).then(v => { if (v) location.hash = 'lesson-' + L.id; });
      };
      row.appendChild(r);
    }
    unitsBox.appendChild(row);
  }
  const pres = $('#pres', view);
  $('#chk', view).onclick = async () => {
    const { chunks, missing } = BS.programChunks({});
    if (missing.length) { pres.innerHTML = `<div class="res info"><h4>${missing.length} lesson(s) still to do</h4>The program needs every part before it can be built on its own: ${missing.slice(0, 6).map(L => esc(L.title)).join(', ')}${missing.length > 6 ? '…' : ''}.</div>`; return; }
    pres.innerHTML = '<div class="res info">Compiling your whole program…</div>';
    const res = await BS.testRunner.run({ chunks, compileOnly: true });
    if (res.compile && res.compile.ok) { pres.innerHTML = `<div class="res ok"><h4>✅ Your whole program compiles</h4>${chunks.length} lessons of your own code, in ${Math.round(res.compile.ms)} ms.</div>`; BS.sound('pass'); }
    else { const e = res.compile && res.compile.error; pres.innerHTML = `<div class="res err"><h4>Compile error</h4>${e ? `<b>${esc(e.file)}, line ${e.line}:</b> ${esc(e.msg)}${e.src ? `<pre>${esc(e.src)}</pre>` : ''}` : ''}</div>`; }
  };
  $('#alltests', view).onclick = async () => {
    const todo = coding.filter(L => st.done[L.id] && st.code[L.id]);
    if (!todo.length) { pres.innerHTML = '<div class="res info">Finish a coding lesson first.</div>'; return; }
    let stopped = false, passed = 0;
    const failed = [];
    pres.innerHTML = '<div class="res info"><div class="row"><b id="atp" class="grow">Starting…</b><button class="btn small" id="atstop">Stop</button></div><div class="bar" style="margin-top:8px"><i id="atbar"></i></div></div><div id="atfail"></div>';
    $('#atstop', pres).onclick = () => { stopped = true; BS.testRunner.stop(); };
    for (let i = 0; i < todo.length && !stopped; i++) {
      const L = todo[i];
      $('#atp', pres).textContent = `Testing ${i + 1} of ${todo.length}: ${L.title}`;
      $('#atbar', pres).style.width = (100 * i / todo.length) + '%';
      const chunks = BS.lessonChunks(L, st.code[L.id].src, true);
      const res = await BS.testRunner.run({ chunks, argv: ['test'] });
      if (res.stopped) break;
      const r = BS.interpret(L, res, chunks);
      if (r.pass) passed++;
      else { failed.push(L); $('#atfail', pres).insertAdjacentHTML('beforeend', `<div class="res err"><b>${esc(L.title)}</b>: ${esc(r.compileError ? r.compileError.msg + ' (' + r.compileError.file + ', line ' + r.compileError.line + ')' : r.fault ? r.fault.msg : (r.fails[0] || 'failed'))}</div>`); }
    }
    $('#atbar', pres).style.width = '100%';
    $('#atp', pres).textContent = stopped ? `Stopped: ${passed} passed, ${failed.length} failed so far.` : `${passed} of ${todo.length} lessons pass with your own code for every earlier part.${failed.length ? ' A lesson can fail here when an earlier function of yours behaves a little differently from the course\'s.' : ''}`;
    if (!stopped && !failed.length) BS.sound('complete');
  };
  $('#export', view).onclick = () => exportZip(pres);
};

// ---------------- export the project as a .zip for a real computer ----------------
async function exportZip(box) {
  const st = S(), A = BS.ASSETS;
  const coding = BS.LESSONS.filter(BS.isCoding);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  let c = `/*\n * bitscribe.c - a BitNet b1.58 language model and textbook writer, in C99.\n * Written function by function in the BitScribe course. Exported ${BS.today()}.\n *\n * Build:  make      (or: gcc -std=c99 -O3 -march=native -fopenmp -o bitscribe bitscribe.c -lm)\n * Run:    ./bitscribe --topic "Black holes" --pages 600 --volumes 10\n */\n\n`;
  for (const L of coding) {
    c += `// ===== ${L.unitObj.title}: ${L.title} =====\n`;
    if (st.done[L.id] && st.code[L.id]) c += st.code[L.id].src.replace(/\s+$/, '') + '\n\n';
    else c += `/* MISSING - write ${L.items.join(', ')} in the lesson "${L.title}". The program will not build until every part is written. */\n\n`;
  }
  const model = BS.modelBytes();
  const files = [
    { name: 'bitscribe/bitscribe.c', data: c },
    { name: 'bitscribe/Makefile', data: A.makefile },
    { name: 'bitscribe/README.md', data: A.readme + (missing.length ? `\n\n## Not finished yet\n\n${missing.length} lesson(s) are still missing (marked MISSING in bitscribe.c). Finish them in the app, then export again.\n` : '') },
    { name: 'bitscribe/settings.txt', data: settingsText(st.writer, true) },
    { name: 'bitscribe/convert.py', data: A.convertPy, exec: true },
    { name: 'bitscribe/models/tiny.bnet', data: model.bnet },
    { name: 'bitscribe/models/tiny.tok', data: model.tok },
    { name: 'bitscribe/models/README.txt', data: A.modelCard },
    { name: 'bitscribe/fonts/readme.txt', data: A.afmReadme },
    { name: 'bitscribe/fonts/NOTE.txt', data: A.fontsNote },
  ];
  for (const [n, t] of Object.entries(BS.afmTexts())) files.push({ name: 'bitscribe/fonts/' + n + '.afm', data: t });
  const blob = ZipWriter.make(files);
  if (box) box.innerHTML = `<div class="res ok"><h4>Project ready (${(blob.size / 1048576).toFixed(1)} MB)</h4>${missing.length ? `${missing.length} lesson(s) are still missing, so the exported program will not build yet.` : 'Unzip it on a Linux, macOS or Windows (WSL) computer and run <code>make</code>.'}</div>`;
  await BS.saveFile('bitscribe-project.zip', blob);
}
BS.exportZip = exportZip;
})();
