(function(G){
// ===== BitScribe C compiler: errors, lexer, preprocessor =====
class CError extends Error {
  constructor(msg, tok) { super(msg); this.tok = tok || null; }
}
function cerr(tok, msg) { throw new CError(msg, tok); }

const PUNCTS = ['...', '<<=', '>>=', '->', '++', '--', '<<', '>>', '<=', '>=', '==', '!=', '&&', '||',
  '*=', '/=', '%=', '+=', '-=', '&=', '^=', '|=', '##', '[', ']', '(', ')', '{', '}', '.', '&', '*', '+',
  '-', '~', '!', '/', '%', '<', '>', '^', '|', '?', ':', ';', '=', ',', '#'];
const P3 = new Set(PUNCTS.filter(p => p.length === 3));
const P2 = new Set(PUNCTS.filter(p => p.length === 2));
const P1 = new Set(PUNCTS.filter(p => p.length === 1));

function isIdStart(c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c === '_'; }
function isIdChar(c) { return isIdStart(c) || (c >= '0' && c <= '9'); }
function isDigitC(c) { return c >= '0' && c <= '9'; }

// Split a source chunk into logical lines: comments removed, backslash-newlines joined.
// Each logical line keeps the physical line number of every character.
function logicalLines(src) {
  const out = [];
  let cur = '', ln = [], line = 1, i = 0;
  const n = src.length;
  const push = () => { out.push({ s: cur, ln }); cur = ''; ln = []; };
  while (i < n) {
    const c = src[i];
    if (c === '\\' && (src[i + 1] === '\n' || (src[i + 1] === '\r' && src[i + 2] === '\n'))) {
      i += src[i + 1] === '\r' ? 3 : 2; line++; continue;
    }
    if (c === '/' && src[i + 1] === '/') {
      while (i < n && src[i] !== '\n') {
        if (src[i] === '\\' && src[i + 1] === '\n') { i += 2; line++; continue; }
        i++;
      }
      continue;
    }
    if (c === '/' && src[i + 1] === '*') {
      const startLine = line; i += 2;
      while (i < n && !(src[i] === '*' && src[i + 1] === '/')) { if (src[i] === '\n') line++; i++; }
      if (i >= n) throw new CError('a /* comment */ was never closed (it started on line ' + startLine + ')', { l: startLine });
      i += 2; cur += ' '; ln.push(line); continue;
    }
    if (c === '"' || c === "'") {
      const q = c; cur += c; ln.push(line); i++;
      while (i < n && src[i] !== q) {
        if (src[i] === '\n') break;
        if (src[i] === '\\' && i + 1 < n) {
          if (src[i + 1] === '\n') { i += 2; line++; continue; }
          cur += src[i] + src[i + 1]; ln.push(line, line); i += 2; continue;
        }
        cur += src[i]; ln.push(line); i++;
      }
      if (src[i] === q) { cur += q; ln.push(line); i++; }
      continue;
    }
    if (c === '\n') { push(); line++; i++; continue; }
    if (c === '\r') { i++; continue; }
    cur += c; ln.push(line); i++;
  }
  push();
  return out;
}

function utf8(str) { return new TextEncoder().encode(str); }

function readEscape(s, i, tok) {
  // s[i] is the char after backslash. returns [byteValue, newIndex]
  const c = s[i];
  switch (c) {
    case 'n': return [10, i + 1]; case 't': return [9, i + 1]; case 'r': return [13, i + 1];
    case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': {
      let v = 0, j = i;
      while (j < s.length && j < i + 3 && s[j] >= '0' && s[j] <= '7') { v = v * 8 + (s.charCodeAt(j) - 48); j++; }
      return [v & 255, j];
    }
    case 'x': {
      let v = 0, j = i + 1;
      while (j < s.length && /[0-9a-fA-F]/.test(s[j])) { v = v * 16 + parseInt(s[j], 16); j++; }
      if (j === i + 1) cerr(tok, 'a \\x escape needs hex digits after it');
      return [v & 255, j];
    }
    case '\\': return [92, i + 1]; case "'": return [39, i + 1]; case '"': return [34, i + 1];
    case '?': return [63, i + 1]; case 'a': return [7, i + 1]; case 'b': return [8, i + 1];
    case 'f': return [12, i + 1]; case 'v': return [11, i + 1]; case 'e': return [27, i + 1];
    default: cerr(tok, 'unknown escape sequence \\' + c);
  }
}

function parseNumber(raw, tok) {
  let s = raw;
  const isHex = /^0[xX]/.test(s);
  const isFloat = isHex ? /[pP]/.test(s) : /[.eE]/.test(s);
  if (isFloat) {
    let fl = 'double';
    if (/[fF]$/.test(s)) { fl = 'float'; s = s.slice(0, -1); }
    else if (/[lL]$/.test(s)) { s = s.slice(0, -1); }
    let v;
    if (isHex) {
      const m = /^0[xX]([0-9a-fA-F]*)(?:\.([0-9a-fA-F]*))?[pP]([+-]?\d+)$/.exec(s);
      if (!m) cerr(tok, 'bad hex float ' + raw);
      const ip = m[1] ? parseInt(m[1], 16) : 0;
      const fp = m[2] ? parseInt(m[2], 16) / Math.pow(16, m[2].length) : 0;
      v = (ip + fp) * Math.pow(2, parseInt(m[3], 10));
    } else {
      if (!/^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) cerr(tok, 'this number is not written correctly: ' + raw);
      v = parseFloat(s);
    }
    return { t: 'num', float: fl, v };
  }
  const m = /^(0[xX][0-9a-fA-F]+|0[0-7]*|[1-9][0-9]*)([uUlL]*)$/.exec(s);
  if (!m) cerr(tok, 'this number is not written correctly: ' + raw + (/^0\d/.test(s) ? ' (a number starting with 0 is octal, so it can only use digits 0-7)' : ''));
  const digits = m[1], suf = m[2].toLowerCase();
  let v;
  if (/^0[xX]/.test(digits)) v = BigInt(digits);
  else if (digits.length > 1 && digits[0] === '0') v = BigInt('0o' + digits.slice(1));
  else v = BigInt(digits);
  const u = suf.includes('u'), ll = suf.includes('ll'), dec = !/^0/.test(digits) || digits === '0';
  let ty;
  const fitsI32 = v <= 0x7fffffffn, fitsU32 = v <= 0xffffffffn, fitsI64 = v <= 0x7fffffffffffffffn;
  if (v > 0xffffffffffffffffn) cerr(tok, 'number too large: ' + raw);
  if (ll) ty = (u || (!dec && !fitsI64) || !fitsI64) ? 'ullong' : 'llong';
  else if (u) ty = fitsU32 ? 'uint' : 'ullong';
  else if (dec) ty = fitsI32 ? (suf.includes('l') ? 'long' : 'int') : (fitsI64 ? 'llong' : 'ullong');
  else ty = fitsI32 ? 'int' : fitsU32 ? 'uint' : fitsI64 ? 'llong' : 'ullong';
  return { t: 'num', ity: ty, v };
}

function tokenizeLine(s, lns, fileIdx, startIdx) {
  const toks = [];
  let i = startIdx || 0, sp = true;
  const n = s.length;
  while (i < n) {
    const c = s[i];
    if (c === ' ' || c === '\t' || c === '\f' || c === '\v') { i++; sp = true; continue; }
    const tok = { f: fileIdx, l: lns[i] || lns[lns.length - 1] || 1, c: i, sp };
    sp = false;
    if (isIdStart(c)) {
      let j = i + 1; while (j < n && isIdChar(s[j])) j++;
      tok.t = 'id'; tok.v = s.slice(i, j); i = j; toks.push(tok); continue;
    }
    if (isDigitC(c) || (c === '.' && isDigitC(s[i + 1]))) {
      let j = i + 1;
      while (j < n) {
        const d = s[j];
        if ((d === '+' || d === '-') && /[eEpP]/.test(s[j - 1]) && !/^0[xX]/.test(s.slice(i, j)) ) { j++; continue; }
        if ((d === '+' || d === '-') && /[pP]/.test(s[j - 1])) { j++; continue; }
        if (isIdChar(d) || d === '.') { j++; continue; }
        break;
      }
      const raw = s.slice(i, j);
      Object.assign(tok, parseNumber(raw, tok)); tok.raw = raw; i = j; toks.push(tok); continue;
    }
    if (c === '"') {
      const bytes = []; let j = i + 1;
      while (j < n && s[j] !== '"') {
        if (s[j] === '\\') { const [b, k] = readEscape(s, j + 1, tok); bytes.push(b); j = k; continue; }
        const cp = s.codePointAt(j);
        if (cp < 128) { bytes.push(cp); j++; }
        else { const ch = String.fromCodePoint(cp); for (const b of utf8(ch)) bytes.push(b); j += ch.length; }
      }
      if (j >= n) cerr(tok, 'this "string" is missing its closing quote "');
      tok.t = 'str'; tok.bytes = bytes; tok.raw = s.slice(i, j + 1); i = j + 1; toks.push(tok); continue;
    }
    if (c === "'") {
      let j = i + 1, v;
      if (s[j] === '\\') { const r = readEscape(s, j + 1, tok); v = r[0]; j = r[1]; }
      else { const cp = s.codePointAt(j); if (cp > 127) cerr(tok, "a character in '' must be a plain ASCII character"); v = cp; j++; }
      if (s[j] !== "'") cerr(tok, "a character constant like 'a' must hold exactly one character and end with '");
      tok.t = 'num'; tok.ity = 'int'; tok.v = BigInt(v > 127 ? v - 256 : v); tok.raw = s.slice(i, j + 1); tok.isChar = true;
      i = j + 1; toks.push(tok); continue;
    }
    const t3 = s.substr(i, 3), t2 = s.substr(i, 2);
    if (P3.has(t3)) { tok.t = 'p'; tok.v = t3; i += 3; toks.push(tok); continue; }
    if (P2.has(t2)) { tok.t = 'p'; tok.v = t2; i += 2; toks.push(tok); continue; }
    if (P1.has(c)) { tok.t = 'p'; tok.v = c; i += 1; toks.push(tok); continue; }
    cerr(tok, 'unexpected character ' + JSON.stringify(c) + ' (C code can only use plain ASCII outside "strings")');
  }
  return toks;
}

function tokText(t) {
  if (t.t === 'id' || t.t === 'p') return t.v;
  return t.raw !== undefined ? t.raw : String(t.v);
}

const KNOWN_HEADERS = new Set(['stdio.h', 'stdlib.h', 'string.h', 'math.h', 'stdint.h', 'stdbool.h', 'ctype.h',
  'stddef.h', 'time.h', 'assert.h', 'limits.h', 'float.h', 'stdarg.h', 'errno.h', 'unistd.h', 'inttypes.h', 'strings.h', 'omp.h', 'iso646.h']);

function preprocess(chunks, opts) {
  const macros = new Map();
  const out = [];
  const warnings = opts.warnings || [];
  const defineObj = (name, text) => {
    const toks = text ? tokenizeLine(text, [0], -1) : [];
    macros.set(name, { fn: false, params: [], body: toks });
  };
  defineObj('__STDC__', '1'); defineObj('__STDC_VERSION__', '199901L'); defineObj('__BITSCRIBE__', '1');
  defineObj('__wasm32__', '1'); defineObj('__ILP32__', '1');
  for (const [k, v] of Object.entries(opts.defines || {})) defineObj(k, v);

  for (let fi = 0; fi < chunks.length; fi++) {
    const lines = logicalLines(chunks[fi].code);
    const cond = [];
    let pending = [];
    const active = () => cond.every(c => c.active);
    const flush = () => { if (pending.length) { for (const t of expandTokens(pending, macros, fi)) out.push(t); pending = []; } };
    for (const L of lines) {
      const s = L.s;
      let k = 0; while (k < s.length && (s[k] === ' ' || s[k] === '\t')) k++;
      if (s[k] === '#') {
        flush();
        const toks = tokenizeLine(s, L.ln, fi, k + 1);
        const dtok = toks[0] || { f: fi, l: L.ln[k] };
        const d = toks.length ? toks[0].v : '';
        const rest = toks.slice(1);
        if (d === 'ifdef' || d === 'ifndef') {
          const on = rest.length && macros.has(rest[0].v);
          const v = d === 'ifdef' ? on : !on;
          cond.push({ active: v, taken: v });
          continue;
        }
        if (d === 'if') {
          const v = active() ? !!evalPPExpr(rest, macros, fi, dtok) : false;
          cond.push({ active: v, taken: v });
          continue;
        }
        if (d === 'elif') {
          const c = cond[cond.length - 1]; if (!c) cerr(dtok, '#elif without #if');
          if (c.taken) c.active = false;
          else { const outer = cond.slice(0, -1).every(x => x.active); const v = outer && !!evalPPExpr(rest, macros, fi, dtok); c.active = v; c.taken = v; }
          continue;
        }
        if (d === 'else') { const c = cond[cond.length - 1]; if (!c) cerr(dtok, '#else without #if'); c.active = !c.taken; c.taken = true; continue; }
        if (d === 'endif') { if (!cond.length) cerr(dtok, '#endif without #if'); cond.pop(); continue; }
        if (!active()) continue;
        if (d === '' ) continue;
        if (d === 'define') {
          const nt = rest[0];
          if (!nt || nt.t !== 'id') cerr(dtok, '#define needs a name');
          const afterName = nt.c + nt.v.length;
          if (s[afterName] === '(') {
            const params = []; let i = 2, variadic = false;
            // rest[1] is '('
            while (i < rest.length && !(rest[i].t === 'p' && rest[i].v === ')')) {
              const t = rest[i];
              if (t.t === 'id') params.push(t.v);
              else if (t.t === 'p' && t.v === '...') { variadic = true; }
              else if (!(t.t === 'p' && t.v === ',')) cerr(t, 'bad macro parameter list');
              i++;
            }
            macros.set(nt.v, { fn: true, params, variadic, body: rest.slice(i + 1) });
          } else {
            macros.set(nt.v, { fn: false, params: [], body: rest.slice(1) });
          }
          continue;
        }
        if (d === 'undef') { if (rest[0]) macros.delete(rest[0].v); continue; }
        if (d === 'include') {
          const m = /#\s*include\s*([<"])([^>"]+)[>"]/.exec(s);
          if (!m) cerr(dtok, 'bad #include line');
          if (m[1] === '<') {
            if (!KNOWN_HEADERS.has(m[2])) cerr(dtok, 'the emulator does not have <' + m[2] + '>. It has: ' + [...KNOWN_HEADERS].slice(0, 14).join(' '));
          } else warnings.push({ tok: dtok, msg: '#include "' + m[2] + '" ignored - the emulator already joins all of your project code into one file' });
          continue;
        }
        if (d === 'error') cerr(dtok, '#error ' + rest.map(tokText).join(' '));
        if (d === 'warning') { warnings.push({ tok: dtok, msg: rest.map(tokText).join(' ') }); continue; }
        if (d === 'pragma' || d === 'line' || d === 'ident') continue;
        cerr(dtok, 'unknown preprocessor directive #' + d);
      } else if (active()) {
        const toks = tokenizeLine(s, L.ln, fi, 0);
        for (const t of toks) pending.push(t);
      }
    }
    flush();
    if (cond.length) cerr({ f: fi, l: lines.length }, 'an #if/#ifdef was never closed with #endif');
  }
  out.push({ t: 'eof', f: chunks.length - 1, l: 999999, v: '' });
  return { tokens: out, macros };
}

function expandTokens(input, macros, fi) {
  const out = [];
  const stack = [];
  for (let i = input.length - 1; i >= 0; i--) stack.push(input[i]);
  while (stack.length) {
    const t = stack.pop();
    if (t.t !== 'id') { out.push(t); continue; }
    if (t.v === '__LINE__') { out.push({ ...t, t: 'num', ity: 'int', v: BigInt(t.l), raw: String(t.l) }); continue; }
    if (t.v === '__FILE__') { out.push({ ...t, t: 'str', bytes: [...utf8('code')], raw: '"code"' }); continue; }
    const m = macros.get(t.v);
    if (!m || (t.hide && t.hide.has(t.v))) { out.push(t); continue; }
    const hide = new Set(t.hide || []); hide.add(t.v);
    if (!m.fn) {
      const rep = pasteAll(m.body.map(b => ({ ...b, l: t.l, f: t.f, c: t.c })), t).map(b => ({ ...b, hide: b.hide ? new Set([...b.hide, ...hide]) : hide }));
      for (let i = rep.length - 1; i >= 0; i--) stack.push(rep[i]);
      continue;
    }
    const nx = stack[stack.length - 1];
    if (!nx || nx.t !== 'p' || nx.v !== '(') { out.push(t); continue; }
    stack.pop();
    const args = []; let cur = [], depth = 0;
    for (;;) {
      if (!stack.length) cerr(t, 'macro ' + t.v + '( ... is missing its closing )');
      const a = stack.pop();
      if (a.t === 'p' && a.v === '(') depth++;
      else if (a.t === 'p' && a.v === ')') { if (depth === 0) break; depth--; }
      else if (a.t === 'p' && a.v === ',' && depth === 0 && !(m.variadic && args.length >= m.params.length)) { args.push(cur); cur = []; continue; }
      cur.push(a);
    }
    args.push(cur);
    if (m.params.length === 0 && !m.variadic && args.length === 1 && args[0].length === 0) args.length = 0;
    if (!m.variadic && args.length !== m.params.length) cerr(t, 'macro ' + t.v + ' expects ' + m.params.length + ' argument(s) but got ' + args.length);
    const body = [];
    const argOf = (name) => {
      if (name === '__VA_ARGS__' && m.variadic) return args[m.params.length] || [];
      const idx = m.params.indexOf(name);
      return idx >= 0 ? (args[idx] || []) : null;
    };
    const B = m.body;
    for (let i = 0; i < B.length; i++) {
      const b = B[i];
      if (b.t === 'p' && b.v === '#' && B[i + 1] && B[i + 1].t === 'id' && argOf(B[i + 1].v)) {
        const a = argOf(B[i + 1].v);
        const text = a.map((x, j) => (j && x.sp ? ' ' : '') + tokText(x)).join('');
        body.push({ t: 'str', bytes: [...utf8(text)], raw: JSON.stringify(text), f: t.f, l: t.l, c: t.c });
        i++; continue;
      }
      if (b.t === 'id' && argOf(b.v)) {
        const a = argOf(b.v);
        const nearPaste = (B[i + 1] && B[i + 1].t === 'p' && B[i + 1].v === '##') || (B[i - 1] && B[i - 1].t === 'p' && B[i - 1].v === '##');
        const sub = nearPaste ? a : expandTokens(a, macros, fi);
        for (const x of sub) body.push({ ...x, l: t.l, f: t.f });
        if (!sub.length && nearPaste) body.push({ t: 'placemarker', f: t.f, l: t.l });
        continue;
      }
      body.push({ ...b, l: t.l, f: t.f, c: t.c });
    }
    const pasted = pasteAll(body, t).filter(x => x.t !== 'placemarker').map(b => ({ ...b, hide: b.hide ? new Set([...b.hide, ...hide]) : hide }));
    for (let i = pasted.length - 1; i >= 0; i--) stack.push(pasted[i]);
  }
  return out;
}

function pasteAll(toks, at) {
  if (!toks.some(x => x.t === 'p' && x.v === '##')) return toks;
  const res = [];
  for (let i = 0; i < toks.length; i++) {
    const x = toks[i];
    if (x.t === 'p' && x.v === '##') {
      const left = res.pop(); const right = toks[++i];
      if (!left || !right) cerr(at, '## needs something on both sides');
      const lt = left.t === 'placemarker' ? '' : tokText(left), rt = right.t === 'placemarker' ? '' : tokText(right);
      const text = lt + rt;
      if (!text) { res.push({ t: 'placemarker', f: at.f, l: at.l }); continue; }
      const nt = tokenizeLine(text, [at.l], at.f);
      if (nt.length !== 1) cerr(at, 'pasting "' + lt + '" and "' + rt + '" does not make a single token');
      res.push({ ...nt[0], l: at.l, f: at.f });
    } else res.push(x);
  }
  return res;
}

function evalPPExpr(toks, macros, fi, at) {
  // handle defined
  const t1 = [];
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    if (t.t === 'id' && t.v === 'defined') {
      let name;
      if (toks[i + 1] && toks[i + 1].v === '(') { name = toks[i + 2] && toks[i + 2].v; i += 3; }
      else { name = toks[i + 1] && toks[i + 1].v; i += 1; }
      t1.push({ t: 'num', ity: 'int', v: macros.has(name) ? 1n : 0n, f: t.f, l: t.l });
    } else t1.push(t);
  }
  const ex = expandTokens(t1, macros, fi).map(t => (t.t === 'id' ? { t: 'num', ity: 'int', v: 0n, f: t.f, l: t.l } : t));
  let p = 0;
  const peek = () => ex[p] || { t: 'eof', v: '' };
  const num = (x) => (typeof x === 'bigint' ? x : BigInt(Math.trunc(x)));
  function prim() {
    const t = ex[p++];
    if (!t) cerr(at, 'incomplete #if expression');
    if (t.t === 'num') return t.float ? BigInt(Math.trunc(t.v)) : t.v;
    if (t.t === 'p' && t.v === '(') { const v = cond(); if (!ex[p] || ex[p].v !== ')') cerr(at, 'missing ) in #if'); p++; return v; }
    if (t.t === 'p' && t.v === '!') return prim() ? 0n : 1n;
    if (t.t === 'p' && t.v === '-') return -prim();
    if (t.t === 'p' && t.v === '+') return prim();
    if (t.t === 'p' && t.v === '~') return ~prim();
    cerr(at, 'cannot understand this #if expression');
  }
  const PREC = { '*': 10, '/': 10, '%': 10, '+': 9, '-': 9, '<<': 8, '>>': 8, '<': 7, '>': 7, '<=': 7, '>=': 7, '==': 6, '!=': 6, '&': 5, '^': 4, '|': 3, '&&': 2, '||': 1 };
  function bin(minp) {
    let l = prim();
    for (;;) {
      const t = peek(); const pr = t.t === 'p' ? PREC[t.v] : undefined;
      if (pr === undefined || pr < minp) return l;
      p++; const r = bin(pr + 1);
      switch (t.v) {
        case '*': l = l * r; break; case '/': l = r === 0n ? 0n : l / r; break; case '%': l = r === 0n ? 0n : l % r; break;
        case '+': l = l + r; break; case '-': l = l - r; break; case '<<': l = l << r; break; case '>>': l = l >> r; break;
        case '<': l = l < r ? 1n : 0n; break; case '>': l = l > r ? 1n : 0n; break; case '<=': l = l <= r ? 1n : 0n; break;
        case '>=': l = l >= r ? 1n : 0n; break; case '==': l = l === r ? 1n : 0n; break; case '!=': l = l !== r ? 1n : 0n; break;
        case '&': l = l & r; break; case '^': l = l ^ r; break; case '|': l = l | r; break;
        case '&&': l = (l && r) ? 1n : 0n; break; case '||': l = (l || r) ? 1n : 0n; break;
      }
    }
  }
  function cond() {
    const c = bin(1);
    if (peek().v === '?') { p++; const a = cond(); if (peek().v !== ':') cerr(at, 'missing : in #if'); p++; const b = cond(); return c ? a : b; }
    return c;
  }
  const v = cond();
  return num(v) !== 0n;
}
// ===== BitScribe C compiler: types + parser (builds a typed AST) =====
function mkInt(size, unsigned, name) { return { k: 'int', size, align: size, unsigned, name }; }
const TY = {
  void: { k: 'void', size: 1, align: 1, name: 'void' },
  bool: { k: 'int', size: 1, align: 1, unsigned: true, bool: true, name: '_Bool' },
  char: mkInt(1, false, 'char'), schar: mkInt(1, false, 'signed char'), uchar: mkInt(1, true, 'unsigned char'),
  short: mkInt(2, false, 'short'), ushort: mkInt(2, true, 'unsigned short'),
  int: mkInt(4, false, 'int'), uint: mkInt(4, true, 'unsigned int'),
  long: mkInt(4, false, 'long'), ulong: mkInt(4, true, 'unsigned long'),
  llong: mkInt(8, false, 'long long'), ullong: mkInt(8, true, 'unsigned long long'),
  float: { k: 'float', size: 4, align: 4, name: 'float' }, double: { k: 'float', size: 8, align: 8, name: 'double' },
};
TY.char.isChar = true;
function ptrTo(t) { return { k: 'ptr', to: t, size: 4, align: 4 }; }
function arrOf(t, n) { return { k: 'array', of: t, len: n, size: n == null ? 0 : t.size * n, align: t.align }; }
function funcTy(ret, params, variadic, unspecified) { return { k: 'func', ret, params, variadic, unspecified, size: 1, align: 1 }; }
const isInt = t => t.k === 'int';
const isFlt = t => t.k === 'float';
const isArith = t => t.k === 'int' || t.k === 'float';
const isPtr = t => t.k === 'ptr';
const isScalar = t => isArith(t) || isPtr(t);
const isAgg = t => t.k === 'struct' || t.k === 'array';
function wty(t) {
  if (t.k === 'int') return t.size === 8 ? 'i64' : 'i32';
  if (t.k === 'float') return t.size === 4 ? 'f32' : 'f64';
  if (t.k === 'void') return null;
  return 'i32';
}
function typeStr(t) {
  if (!t) return '?';
  switch (t.k) {
    case 'int': case 'float': case 'void': return t.name;
    case 'ptr': return t.to.k === 'func' ? typeStr(t.to.ret) + ' (*)(' + t.to.params.map(typeStr).join(', ') + ')' : typeStr(t.to) + '*';
    case 'array': return typeStr(t.of) + '[' + (t.len == null ? '' : t.len) + ']';
    case 'struct': return (t.union ? 'union ' : 'struct ') + (t.tag || '(anonymous)');
    case 'func': return typeStr(t.ret) + '(' + t.params.map(typeStr).join(', ') + (t.variadic ? ', ...' : '') + ')';
  }
  return '?';
}
function sameType(a, b) {
  if (a === b) return true;
  if (a.k !== b.k) return false;
  switch (a.k) {
    case 'int': return a.size === b.size && !!a.unsigned === !!b.unsigned && !!a.bool === !!b.bool;
    case 'float': case 'void': return a.size === b.size;
    case 'ptr': return sameType(a.to, b.to) || a.to.k === 'void' || b.to.k === 'void';
    case 'array': return sameType(a.of, b.of) && (a.len == null || b.len == null || a.len === b.len);
    case 'struct': return a === b;
    case 'func':
      if (!sameType(a.ret, b.ret)) return false;
      if (a.unspecified || b.unspecified) return true;
      if (a.params.length !== b.params.length || !!a.variadic !== !!b.variadic) return false;
      return a.params.every((p, i) => sameType(p, b.params[i]));
  }
  return false;
}
function strictPtrMatch(a, b) { // for pointer warnings: exact pointee match ignoring signedness of char
  if (a.k === "void" || b.k === "void") return true;
  if (a.k !== b.k) return false;
  if (a.k === 'int') return a.size === b.size;
  if (a.k === 'ptr') return a.to.k === 'void' || b.to.k === 'void' || strictPtrMatch(a.to, b.to);
  return sameType(a, b);
}
function promote(t) { return (t.k === 'int' && t.size < 4) ? TY.int : t; }
function usualArith(a, b) {
  if (isFlt(a) || isFlt(b)) {
    if ((isFlt(a) && a.size === 8) || (isFlt(b) && b.size === 8)) return TY.double;
    return TY.float;
  }
  a = promote(a); b = promote(b);
  if (a.size === 8 || b.size === 8) {
    const u = (a.size === 8 && a.unsigned) || (b.size === 8 && b.unsigned);
    return u ? TY.ullong : TY.llong;
  }
  return (a.unsigned || b.unsigned) ? TY.uint : TY.int;
}
function wrapInt(v, t) { // v BigInt -> value wrapped to type t (BigInt)
  if (t.bool) return v !== 0n ? 1n : 0n;
  const bits = BigInt(t.size * 8);
  return t.unsigned ? BigInt.asUintN(Number(bits), v) : BigInt.asIntN(Number(bits), v);
}

const TYPE_KW = new Set(['void', 'char', 'short', 'int', 'long', 'float', 'double', 'signed', 'unsigned', '_Bool',
  'struct', 'union', 'enum', 'const', 'volatile', 'restrict', '__restrict', 'typedef', 'static', 'extern', 'auto',
  'register', 'inline', '__inline', '_Noreturn', '__attribute__']);
const KEYWORDS = new Set([...TYPE_KW, 'if', 'else', 'while', 'do', 'for', 'switch', 'case', 'default', 'break',
  'continue', 'return', 'goto', 'sizeof', 'va_arg', '_Static_assert']);

class Parser {
  constructor(tokens, chunks, opts) {
    this.toks = tokens; this.p = 0; this.chunks = chunks; this.opts = opts;
    this.scopes = [new Map()]; this.tags = [new Map()];
    this.funcs = new Map(); this.globals = []; this.strings = []; this.warnings = opts.warnings || [];
    this.fn = null; this.loop = 0; this.sw = 0; this.uid = 0; this.staticLocals = [];
  }
  // ---- token helpers
  peek(k = 0) { return this.toks[this.p + k]; }
  next() { return this.toks[this.p++]; }
  is(v, k = 0) { const t = this.toks[this.p + k]; return t && (t.t === 'p' || t.t === 'id') && t.v === v; }
  accept(v) { if (this.is(v)) { return this.toks[this.p++]; } return null; }
  expect(v, what) {
    const t = this.peek();
    if (!this.is(v)) {
      let msg = "expected '" + v + "'" + (what ? ' ' + what : '') + ' but found ' + this.desc(t);
      if (v === ';') {
        const prev = this.toks[this.p - 1];
        if (prev && t && t.l > prev.l) { msg = "missing ';' at the end of this line"; cerr(prev, msg); }
      }
      cerr(t, msg);
    }
    return this.next();
  }
  desc(t) { if (!t || t.t === 'eof') return 'the end of the code'; if (t.t === 'str') return 'a string'; if (t.t === 'num') return "'" + (t.raw || t.v) + "'"; return "'" + t.v + "'"; }
  warn(tok, msg) { this.warnings.push({ tok, msg }); }
  // ---- scopes
  push() { this.scopes.push(new Map()); this.tags.push(new Map()); }
  pop() { this.scopes.pop(); this.tags.pop(); }
  lookup(name) { for (let i = this.scopes.length - 1; i >= 0; i--) { const s = this.scopes[i].get(name); if (s) return s; } return null; }
  lookupTag(name) { for (let i = this.tags.length - 1; i >= 0; i--) { const s = this.tags[i].get(name); if (s) return s; } return null; }
  declare(sym, tok) {
    const sc = this.scopes[this.scopes.length - 1];
    const old = sc.get(sym.name);
    if (old) {
      if (old.kind === 'func' && sym.kind === 'func') return old;
      if (old.kind === 'global' && sym.kind === 'global' && (old.extern || sym.extern)) { if (!sym.extern) { old.extern = false; } return old; }
      if (old.kind === 'typedef' && sym.kind === 'typedef' && sameType(old.ty, sym.ty)) return old;
      cerr(tok, "'" + sym.name + "' is already declared in this scope" + (old.tok ? ' (first on line ' + old.tok.l + ')' : ''));
    }
    sc.set(sym.name, sym); sym.tok = sym.tok || tok; return sym;
  }
  isTypedefName(t) { if (!t || t.t !== 'id') return false; const s = this.lookup(t.v); return !!(s && s.kind === 'typedef'); }
  isTypeStart(k = 0) {
    const t = this.peek(k);
    if (!t || t.t !== 'id') return false;
    if (TYPE_KW.has(t.v)) return true;
    return this.isTypedefName(t);
  }
  // ---- declaration specifiers
  skipAttribute() {
    while (this.is('__attribute__')) {
      this.next(); this.expect('('); let d = 1;
      while (d > 0) { const t = this.next(); if (t.t === 'eof') break; if (t.v === '(') d++; else if (t.v === ')') d--; }
    }
  }
  parseDeclSpec(allowStorage = true) {
    const start = this.peek();
    let storage = null, inline = false, isConst = false;
    const c = { void: 0, char: 0, short: 0, int: 0, long: 0, float: 0, double: 0, signed: 0, unsigned: 0, bool: 0 };
    let named = null, sty = null, any = false;
    for (;;) {
      const t = this.peek();
      if (!t || t.t !== 'id') break;
      const v = t.v;
      if (v === '__attribute__') { this.skipAttribute(); continue; }
      if (v === 'typedef' || v === 'static' || v === 'extern' || v === 'auto' || v === 'register') {
        if (!allowStorage && v !== 'register') cerr(t, "'" + v + "' is not allowed here");
        if (v === 'typedef' || v === 'static' || v === 'extern') { if (storage && storage !== v) cerr(t, 'too many storage words (' + storage + ', ' + v + ')'); storage = v; }
        this.next(); continue;
      }
      if (v === 'inline' || v === '__inline' || v === '_Noreturn') { inline = true; this.next(); continue; }
      if (v === 'const') { isConst = true; this.next(); continue; }
      if (v === 'volatile' || v === 'restrict' || v === '__restrict') { this.next(); continue; }
      if (v in c && v !== 'bool') { c[v]++; any = true; this.next(); continue; }
      if (v === '_Bool') { c.bool++; any = true; this.next(); continue; }
      if (v === 'struct' || v === 'union') { if (any || named || sty) cerr(t, 'too many types in one declaration'); this.next(); sty = this.parseStructSpec(v === 'union', t); continue; }
      if (v === 'enum') { if (any || named || sty) cerr(t, 'too many types in one declaration'); this.next(); sty = this.parseEnumSpec(t); continue; }
      if (!any && !named && !sty && this.isTypedefName(t)) { named = this.lookup(v).ty; this.next(); continue; }
      break;
    }
    let ty;
    if (sty) ty = sty;
    else if (named) ty = named;
    else if (!any) { if (storage || inline || isConst) ty = TY.int; else cerr(start, 'expected a type here, like int or float, but found ' + this.desc(start)); }
    else {
      if (c.void) ty = TY.void;
      else if (c.bool) ty = TY.bool;
      else if (c.float) ty = TY.float;
      else if (c.double) ty = TY.double;
      else if (c.char) ty = c.unsigned ? TY.uchar : (c.signed ? TY.schar : TY.char);
      else if (c.short) ty = c.unsigned ? TY.ushort : TY.short;
      else if (c.long >= 2) ty = c.unsigned ? TY.ullong : TY.llong;
      else if (c.long === 1) ty = c.unsigned ? TY.ulong : TY.long;
      else ty = c.unsigned ? TY.uint : TY.int;
    }
    return { ty, storage, inline, isConst, tok: start };
  }
  parseStructSpec(isUnion, kwTok) {
    let tag = null;
    if (this.peek().t === 'id' && !this.is('{')) { tag = this.next().v; }
    let st = null;
    if (this.is('{')) {
      if (tag) {
        const cur = this.tags[this.tags.length - 1].get(tag);
        if (cur && cur.complete) cerr(kwTok, (isUnion ? 'union ' : 'struct ') + tag + ' is defined twice');
        st = cur || { k: 'struct', tag, union: isUnion, fields: [], size: 0, align: 1, complete: false };
        this.tags[this.tags.length - 1].set(tag, st);
      } else st = { k: 'struct', tag: null, union: isUnion, fields: [], size: 0, align: 1, complete: false };
      this.next();
      const fields = [];
      while (!this.accept('}')) {
        if (this.peek().t === 'eof') cerr(kwTok, 'struct is missing its closing }');
        const spec = this.parseDeclSpec(false);
        if (this.accept(';')) {
          if (spec.ty.k === 'struct' && !spec.ty.tag) { fields.push({ name: null, ty: spec.ty, anon: true }); continue; }
          continue;
        }
        for (;;) {
          const d = this.parseDeclarator(spec.ty, false);
          if (this.is(':')) cerr(this.peek(), 'bit-fields (name : width) are not supported by the emulator');
          if (d.ty.k === 'func') cerr(d.tok, 'a struct cannot contain a function (use a function pointer instead)');
          if (d.ty.k === 'struct' && !d.ty.complete) cerr(d.tok, typeStr(d.ty) + ' is not fully defined yet, so it cannot be inside another struct (use a pointer)');
          if (fields.some(f => f.name === d.name)) cerr(d.tok, "struct already has a member called '" + d.name + "'");
          fields.push({ name: d.name, ty: d.ty, tok: d.tok });
          if (!this.accept(',')) break;
        }
        this.expect(';', 'after a struct member');
      }
      // layout
      let off = 0, align = 1, size = 0;
      const flat = [];
      for (const f of fields) {
        const a = f.ty.align;
        if (isUnion) { f.offset = 0; size = Math.max(size, f.ty.size); }
        else { off = (off + a - 1) & ~(a - 1); f.offset = off; off += f.ty.size; }
        align = Math.max(align, a);
        if (f.anon) { for (const g of f.ty.fields) flat.push({ name: g.name, ty: g.ty, offset: f.offset + g.offset }); }
        else flat.push(f);
      }
      if (!isUnion) size = off;
      size = (size + align - 1) & ~(align - 1);
      st.fields = flat; st.size = size || 0; st.align = align; st.complete = true;
      return st;
    }
    if (!tag) cerr(kwTok, 'struct needs a name or a { body }');
    st = this.lookupTag(tag);
    if (!st) {
      st = { k: 'struct', tag, union: isUnion, fields: [], size: 0, align: 1, complete: false };
      this.tags[this.tags.length - 1].set(tag, st);
    }
    return st;
  }
  parseEnumSpec(kwTok) {
    let tag = null;
    if (this.peek().t === 'id' && !this.is('{')) tag = this.next().v;
    if (this.accept('{')) {
      let val = 0n;
      while (!this.accept('}')) {
        const nt = this.next();
        if (nt.t !== 'id') cerr(nt, 'expected a name inside enum { }');
        if (this.accept('=')) val = BigInt(this.constInt(this.parseCond(), nt));
        this.declare({ kind: 'enumconst', name: nt.v, ty: TY.int, value: BigInt.asIntN(32, val) }, nt);
        val += 1n;
        if (!this.accept(',')) { this.expect('}', 'to close the enum'); break; }
      }
      if (tag) this.tags[this.tags.length - 1].set('enum ' + tag, true);
    }
    return TY.int;
  }
  // ---- declarators
  parseDeclarator(base, abstract) {
    // returns {name, ty, tok, params}
    const tok = this.peek();
    let nptr = 0;
    for (;;) {
      if (this.accept('*')) { nptr++; continue; }
      if (this.is('const') || this.is('volatile') || this.is('restrict') || this.is('__restrict')) { this.next(); continue; }
      if (this.is('__attribute__')) { this.skipAttribute(); continue; }
      break;
    }
    let inner = null, name = null, nameTok = tok;
    if (this.is('(') && (this.is('*', 1) || this.is('(', 1) || this.is('^', 1) || (this.peek(1).t === 'id' && !this.isTypeStart(1)))) {
      this.next(); inner = this.parseDeclarator(null, abstract); this.expect(')');
    } else if (this.peek().t === 'id' && !KEYWORDS.has(this.peek().v) && !(abstract && this.isTypedefName(this.peek()))) {
      nameTok = this.next(); name = nameTok.v;
    } else if (!abstract) {
      cerr(this.peek(), 'expected a name here but found ' + this.desc(this.peek()));
    }
    const suffixes = [];
    for (;;) {
      if (this.accept('[')) {
        if (this.accept(']')) { suffixes.push({ k: 'arr', len: null }); continue; }
        while (this.is('static') || this.is('const')) this.next();
        const e = this.parseAssign();
        const n = this.constInt(e, this.peek(), 'the size of an array must be a constant number (the emulator does not support variable-length arrays - use malloc)');
        if (n < 0) cerr(nameTok, 'array size cannot be negative');
        this.expect(']'); suffixes.push({ k: 'arr', len: Number(n) }); continue;
      }
      if (this.is('(')) { this.next(); suffixes.push(this.parseParams()); continue; }
      break;
    }
    const apply = (t) => {
      for (let i = 0; i < nptr; i++) t = ptrTo(t);
      for (let i = suffixes.length - 1; i >= 0; i--) {
        const s = suffixes[i];
        if (s.k === 'arr') {
          if (t.k === 'func') cerr(nameTok, 'you cannot make an array of functions');
          if (t.k === 'void') cerr(nameTok, 'you cannot make an array of void');
          t = arrOf(t, s.len);
        } else {
          if (t.k === 'array') cerr(nameTok, 'a function cannot return an array (return a pointer instead)');
          if (t.k === 'func') cerr(nameTok, 'a function cannot return a function');
          t = funcTy(t, s.params.map(p => p.ty), s.variadic, s.unspecified);
          t.pnames = s.params.map(p => p.name); t.ptoks = s.params.map(p => p.tok);
        }
      }
      return t;
    };
    if (inner) {
      const innerApply = inner.apply;
      const full = (b) => innerApply(apply(b));
      if (base === null) return { name: inner.name, tok: inner.tok, apply: full };
      const ty = full(base);
      return { name: inner.name, tok: inner.tok, ty };
    }
    if (base === null) return { name, tok: nameTok, apply };
    return { name, tok: nameTok, ty: apply(base) };
  }
  parseParams() {
    // after '('
    const params = []; let variadic = false, unspecified = false;
    if (this.accept(')')) return { k: 'fn', params, variadic, unspecified: true };
    if (this.is('void') && this.is(')', 1)) { this.next(); this.next(); return { k: 'fn', params, variadic: false }; }
    for (;;) {
      if (this.accept('...')) { variadic = true; this.expect(')'); break; }
      const spec = this.parseDeclSpec(false);
      const d = this.parseDeclarator(spec.ty, true);
      let t = d.ty;
      if (t.k === 'array') t = ptrTo(t.of);
      else if (t.k === 'func') t = ptrTo(t);
      if (t.k === 'void') cerr(d.tok, 'a parameter cannot have type void');
      params.push({ name: d.name, ty: t, tok: d.tok });
      if (this.accept(',')) continue;
      this.expect(')', 'to close the parameter list');
      break;
    }
    return { k: 'fn', params, variadic, unspecified };
  }
  parseTypeName() {
    const spec = this.parseDeclSpec(false);
    const d = this.parseDeclarator(spec.ty, true);
    return d.ty;
  }
  // ---- translation unit
  parseUnit() {
    while (this.peek().t !== 'eof') this.parseExternal();
  }
  parseExternal() {
    if (this.accept(';')) return;
    if (this.is('_Static_assert')) { this.parseStaticAssert(); return; }
    const spec = this.parseDeclSpec(true);
    if (this.accept(';')) return;
    let first = true;
    for (;;) {
      const d = this.parseDeclarator(spec.ty, false);
      const file = d.tok.f;
      if (spec.storage === 'typedef') {
        this.declare({ kind: 'typedef', name: d.name, ty: d.ty }, d.tok);
      } else if (d.ty.k === 'func') {
        let sym = this.lookup(d.name);
        if (sym && sym.kind !== 'func') cerr(d.tok, "'" + d.name + "' is already used as a variable name");
        if (sym && !sameType(sym.ty, d.ty) && !(sym.ty.unspecified || d.ty.unspecified)) {
          const sig = (t, nm) => typeStr(t.ret) + ' ' + nm + '(' + t.params.map((p, i) => typeStr(p) + (t.pnames && t.pnames[i] ? ' ' + t.pnames[i] : '')).join(', ') + (t.variadic ? ', ...' : '') + ')';
          if (this.chunks[file] && this.chunks[file].expectProto) cerr(sym.tok, "your function '" + d.name + "' must look exactly like this:  " + sig(d.ty, d.name) + "   - yours is:  " + sig(sym.ty, d.name));
          if (sym.expected) cerr(d.tok, "your function '" + d.name + "' must look exactly like this:  " + sym.expected + "   - yours is:  " + sig(d.ty, d.name));
          cerr(d.tok, "conflicting types for '" + d.name + "': here it is " + sig(d.ty, d.name) + ', but earlier it was ' + sig(sym.ty, d.name));
        }
        if (!sym) {
          sym = { kind: 'func', name: d.name, ty: d.ty, defined: false, file, tok: d.tok, chunk: this.chunks[file] };
          this.scopes[0].set(d.name, sym); this.funcs.set(d.name, sym);
        } else if (d.ty.unspecified === false && sym.ty.unspecified) { sym.ty = d.ty; }
        if (this.chunks[file] && this.chunks[file].expectProto) sym.expected = typeStr(d.ty.ret) + ' ' + d.name + '(' + d.ty.params.map((p, i) => typeStr(p) + (d.ty.pnames && d.ty.pnames[i] ? ' ' + d.ty.pnames[i] : '')).join(', ') + ')';
        if (spec.storage === 'static') sym.isStatic = true;
        if (first && this.is('{')) {
          if (sym.defined) {
            if (sym.weak) { sym.weak = false; }
            else if (this.chunks[file].weak) { this.skipBody(); return; }
            else cerr(d.tok, "the function '" + d.name + "' is written twice" + (sym.tok ? ' (the first one is in ' + this.chunkName(sym.tok.f) + ' line ' + sym.tok.l + ')' : ''));
          }
          sym.ty = d.ty; sym.tok = d.tok; sym.file = file;
          sym.weak = !!this.chunks[file].weak;
          this.parseFunctionBody(sym, d);
          return;
        }
      } else {
        if (d.ty.k === 'void') cerr(d.tok, 'a variable cannot have type void');
        const isExtern = spec.storage === 'extern';
        let sym = this.scopes[0].get(d.name);
        if (sym && sym.kind !== 'global') cerr(d.tok, "'" + d.name + "' is already declared as something else");
        if (!sym) {
          sym = { kind: 'global', name: d.name, ty: d.ty, extern: isExtern, file, id: this.uid++ };
          this.scopes[0].set(d.name, sym); sym.tok = d.tok; this.globals.push(sym);
        } else if (!isExtern) {
          if (sym.defined && this.is('=')) cerr(d.tok, "the global variable '" + d.name + "' is defined twice");
          sym.extern = false; if (sym.ty.k === 'array' && sym.ty.len == null) sym.ty = d.ty;
        }
        if (this.accept('=')) {
          sym.init = this.parseInitializer(sym.ty, d.tok); sym.defined = true;
          if (sym.ty.k === 'array' && sym.ty.len == null) sym.ty = sym.init.ty;
        }
        if (!isExtern) sym.defined = true;
      }
      first = false;
      if (this.accept(',')) continue;
      this.expect(';', 'after the declaration');
      return;
    }
  }
  chunkName(f) { return (this.chunks[f] && this.chunks[f].name) || 'code'; }
  skipBody() { let d = 0; do { const t = this.next(); if (t.v === '{') d++; else if (t.v === '}') d--; if (t.t === 'eof') break; } while (d > 0); }
  parseStaticAssert() {
    const t = this.next(); this.expect('(');
    const v = this.constInt(this.parseAssign(), t);
    let msg = 'static assertion failed';
    if (this.accept(',')) { const s = this.next(); if (s.t === 'str') msg = new TextDecoder().decode(new Uint8Array(s.bytes)); }
    this.expect(')'); this.expect(';');
    if (!v) cerr(t, msg);
  }
  parseFunctionBody(sym, d) {
    const fty = d.ty;
    const fn = { sym, name: d.name, ty: fty, params: [], locals: [], tok: d.tok, hasVaStart: false, calls: new Set(), addrFns: new Set(), file: d.tok.f };
    this.fn = fn; sym.fn = fn; sym.defined = true;
    this.push();
    const pn = fty.pnames || [];
    if (fty.unspecified) fty.params = [];
    fty.params.forEach((pt, i) => {
      if (!pn[i]) cerr(fty.ptoks ? fty.ptoks[i] : d.tok, 'parameter ' + (i + 1) + " of '" + d.name + "' needs a name");
      const ps = { kind: 'local', name: pn[i], ty: pt, param: i, id: this.uid++, addrTaken: false };
      this.declare(ps, fty.ptoks[i]); fn.params.push(ps); fn.locals.push(ps);
    });
    fn.body = this.parseCompound(true);
    this.pop();
    this.fn = null;
  }
  // ---- statements
  parseCompound(noScope) {
    const t = this.expect('{');
    if (!noScope) this.push();
    const items = [];
    while (!this.accept('}')) {
      if (this.peek().t === 'eof') cerr(t, 'this { was never closed with }');
      items.push(this.parseStmt());
    }
    if (!noScope) this.pop();
    return { k: 'block', items, tok: t };
  }
  isDeclStart() {
    if (!this.isTypeStart()) return false;
    // typedef name followed by ':' is a label; followed by '=' etc. is an expression? (only if shadowed var)
    return true;
  }
  parseStmt() {
    const t = this.peek();
    if (t.t === 'id') {
      switch (t.v) {
        case 'if': {
          this.next(); this.expect('(', "after 'if'"); const c = this.toCond(this.parseExpr(), t); this.expect(')', 'to close the if condition');
          const th = this.parseStmt(); let el = null;
          if (this.accept('else')) el = this.parseStmt();
          return { k: 'if', c, t: th, f: el, tok: t };
        }
        case 'while': {
          this.next(); this.expect('(', "after 'while'"); const c = this.toCond(this.parseExpr(), t); this.expect(')', 'to close the while condition');
          this.loop++; const body = this.parseStmt(); this.loop--;
          return { k: 'while', c, body, tok: t };
        }
        case 'do': {
          this.next(); this.loop++; const body = this.parseStmt(); this.loop--;
          this.expect('while', "after the do { } body"); this.expect('('); const c = this.toCond(this.parseExpr(), t); this.expect(')'); this.expect(';', 'after do { } while ( )');
          return { k: 'do', c, body, tok: t };
        }
        case 'for': {
          this.next(); this.expect('(', "after 'for'"); this.push();
          let init = null;
          if (this.accept(';')) init = null;
          else if (this.isDeclStart()) init = this.parseDeclStmt();
          else { init = { k: 'expr', e: this.parseExpr(), tok: this.peek() }; this.expect(';', 'after the first part of the for loop'); }
          let c = null; if (!this.is(';')) c = this.toCond(this.parseExpr(), t); this.expect(';', 'after the condition of the for loop');
          let inc = null; if (!this.is(')')) inc = this.parseExpr(); this.expect(')', 'to close the for ( ; ; )');
          this.loop++; const body = this.parseStmt(); this.loop--;
          this.pop();
          return { k: 'for', init, c, inc, body, tok: t };
        }
        case 'switch': {
          this.next(); this.expect('('); let e = this.rv(this.parseExpr());
          if (!isInt(e.ty)) cerr(t, 'switch needs a whole number (int or char), not ' + typeStr(e.ty));
          e = this.conv(e, promote(e.ty)); this.expect(')');
          this.sw++; const body = this.parseStmt(); this.sw--;
          return { k: 'switch', e, body, tok: t };
        }
        case 'case': {
          this.next(); if (!this.sw) cerr(t, "'case' can only be used inside a switch");
          const v = this.constInt(this.parseCond(), t, 'a case value must be a constant'); this.expect(':', 'after the case value');
          return { k: 'case', v: BigInt(v), tok: t };
        }
        case 'default': {
          this.next(); if (!this.sw) cerr(t, "'default' can only be used inside a switch"); this.expect(':');
          return { k: 'default', tok: t };
        }
        case 'break': this.next(); if (!this.loop && !this.sw) cerr(t, "'break' can only be used inside a loop or switch"); this.expect(';', "after 'break'"); return { k: 'break', tok: t };
        case 'continue': this.next(); if (!this.loop) cerr(t, "'continue' can only be used inside a loop"); this.expect(';', "after 'continue'"); return { k: 'continue', tok: t };
        case 'return': {
          this.next(); const rt = this.fn.ty.ret; let e = null;
          if (!this.is(';')) {
            e = this.rv(this.parseExpr());
            if (rt.k === 'void') { if (e.ty.k !== 'void') cerr(t, "'" + this.fn.name + "' returns void, so 'return' cannot give back a value"); }
            else e = this.assignConv(e, rt, t, 'return value');
          } else if (rt.k !== 'void') cerr(t, "'" + this.fn.name + "' must return a value of type " + typeStr(rt));
          this.expect(';', 'after the return statement');
          return { k: 'return', e, tok: t };
        }
        case 'goto': cerr(t, "'goto' is not supported by the emulator - use loops, break and continue instead");
        case '_Static_assert': this.parseStaticAssert(); return { k: 'empty' };
      }
      if (this.isDeclStart() && !(this.is(':', 1))) return this.parseDeclStmt();
      if (this.is(':', 1) && t.t === 'id') cerr(t, 'labels (name:) are not supported by the emulator');
    }
    if (this.is('{')) return this.parseCompound(false);
    if (this.accept(';')) return { k: 'empty' };
    const e = this.parseExpr();
    this.expect(';', 'at the end of this statement');
    return { k: 'expr', e, tok: t };
  }
  parseDeclStmt() {
    const spec = this.parseDeclSpec(true);
    const decls = [];
    if (this.accept(';')) return { k: 'block', items: [], noscope: true };
    for (;;) {
      const d = this.parseDeclarator(spec.ty, false);
      if (spec.storage === 'typedef') { this.declare({ kind: 'typedef', name: d.name, ty: d.ty }, d.tok); }
      else if (d.ty.k === 'func') {
        let sym = this.lookup(d.name);
        if (!sym || sym.kind !== 'func') { sym = this.funcs.get(d.name) || { kind: 'func', name: d.name, ty: d.ty, defined: false, file: d.tok.f, tok: d.tok }; this.funcs.set(d.name, sym); if (!this.scopes[0].has(d.name)) this.scopes[0].set(d.name, sym); }
        this.declare(sym, d.tok);
      } else {
        if (d.ty.k === 'void') cerr(d.tok, 'a variable cannot have type void');
        if (spec.storage === 'extern') {
          const g = this.scopes[0].get(d.name);
          if (!g) cerr(d.tok, 'extern variable ' + d.name + ' is not defined globally');
          this.declare(g, d.tok);
        } else if (spec.storage === 'static') {
          const sym = { kind: 'global', name: d.name, ty: d.ty, file: d.tok.f, id: this.uid++, staticLocal: true, defined: true, tok: d.tok };
          this.declare(sym, d.tok); this.globals.push(sym);
          if (this.accept('=')) { sym.init = this.parseInitializer(sym.ty, d.tok); if (sym.ty.k === 'array' && sym.ty.len == null) sym.ty = sym.init.ty; }
        } else {
          const sym = { kind: 'local', name: d.name, ty: d.ty, id: this.uid++, addrTaken: false };
          let init = null;
          // declare before parsing initializer (C scope rule)
          this.declare(sym, d.tok);
          if (this.accept('=')) {
            init = this.parseInitializer(sym.ty, d.tok);
            if (sym.ty.k === 'array' && sym.ty.len == null) sym.ty = init.ty;
          }
          if (sym.ty.k === 'array' && sym.ty.len == null) cerr(d.tok, "the array '" + d.name + "' needs a size, like " + d.name + '[10]');
          if (sym.ty.k === 'struct' && !sym.ty.complete) cerr(d.tok, typeStr(sym.ty) + ' is not fully defined, so you cannot make a variable of it');
          this.fn.locals.push(sym);
          decls.push({ sym, init, tok: d.tok });
        }
      }
      if (this.accept(',')) continue;
      this.expect(';', 'after the declaration');
      break;
    }
    return { k: 'decl', decls };
  }
  // ---- initializers: produce {ty, entries:[{off, ty, e}|{off, bytes}]}
  parseInitializer(ty, tok) {
    const entries = [];
    let fty = ty;
    if (ty.k === 'array' && ty.len == null) {
      // determine length
      const res = this.initAgg(ty, 0, entries, tok, true);
      fty = arrOf(ty.of, res);
    } else if (isAgg(ty)) {
      this.initAgg(ty, 0, entries, tok, false);
    } else {
      if (this.accept('{')) { const e = this.parseAssign(); entries.push({ off: 0, ty, e: this.assignConv(this.rv(e), ty, tok, 'initial value') }); this.accept(','); this.expect('}'); }
      else { const e = this.parseAssign(); entries.push({ off: 0, ty, e: this.assignConv(this.rv(e), ty, tok, 'initial value') }); }
    }
    return { ty: fty, entries };
  }
  initAgg(ty, base, entries, tok, open) {
    // returns number of elements (for arrays with unknown length)
    if (ty.k === 'array' && (ty.of === TY.char || ty.of === TY.uchar || ty.of === TY.schar) && (this.peek().t === 'str' || (this.is('{') && this.peek(1).t === 'str' && this.is('}', 2)))) {
      const braced = !!this.accept('{');
      const bytes = this.readStringBytes();
      if (braced) this.expect('}');
      if (ty.len != null && bytes.length - 1 > ty.len) cerr(tok, 'the string is too long for ' + typeStr(ty) + ' (it needs ' + bytes.length + ' bytes including the 0 at the end)');
      const nb = ty.len != null ? bytes.slice(0, ty.len) : bytes;
      entries.push({ off: base, bytes: nb });
      return bytes.length;
    }
    if (!this.is('{')) {
      if (ty.k === 'struct') {
        const e = this.rv(this.parseAssign());
        if (e.ty.k === 'struct' && e.ty === ty) { entries.push({ off: base, ty, e }); return 1; }
        cerr(tok, 'a struct must be initialised with { ... } or another struct of the same type');
      }
      cerr(tok, 'an array must be initialised with { ... }');
    }
    this.next();
    const r = this.initList(ty, base, entries, tok);
    this.accept(',');
    this.expect('}', 'to close the { initialiser list }');
    return r;
  }
  initList(ty, base, entries, tok) {
    if (ty.k === 'array') {
      let idx = 0, max = 0;
      const es = ty.of.size;
      while (!this.is('}')) {
        if (this.accept('[')) { idx = Number(this.constInt(this.parseCond(), tok)); this.expect(']'); this.expect('='); }
        if (ty.len != null && idx >= ty.len) cerr(this.peek(), 'too many values for ' + typeStr(ty));
        this.initElem(ty.of, base + idx * es, entries, tok);
        idx++; max = Math.max(max, idx);
        if (!this.accept(',')) break;
      }
      return max;
    }
    if (ty.k === 'struct') {
      let fi = 0;
      while (!this.is('}')) {
        if (this.accept('.')) {
          const nt = this.next(); fi = ty.fields.findIndex(f => f.name === nt.v);
          if (fi < 0) cerr(nt, typeStr(ty) + " has no member called '" + nt.v + "'");
          this.expect('=');
        }
        if (fi >= ty.fields.length) cerr(this.peek(), 'too many values for ' + typeStr(ty));
        const f = ty.fields[fi];
        this.initElem(f.ty, base + f.offset, entries, tok);
        fi++;
        if (ty.union) fi = ty.fields.length;
        if (!this.accept(',')) break;
      }
      return 1;
    }
    cerr(tok, 'cannot initialise this');
  }
  initElem(ty, off, entries, tok) {
    if (isAgg(ty)) {
      if (this.is('{') || (ty.k === 'array' && this.peek().t === 'str')) { this.initAgg(ty, off, entries, tok, false); return; }
      if (ty.k === 'struct') {
        // struct value or brace elision
        const save = this.p;
        const e = this.rv(this.parseAssign());
        if (e.ty === ty) { entries.push({ off, ty, e }); return; }
        this.p = save;
      }
      // brace elision: fill sub-elements from the current list
      this.initElided(ty, off, entries, tok);
      return;
    }
    const e = this.rv(this.parseAssign());
    entries.push({ off, ty, e: this.assignConv(e, ty, tok, 'initial value') });
  }
  initElided(ty, off, entries, tok) {
    if (ty.k === 'array') {
      for (let i = 0; i < ty.len; i++) {
        if (this.is('}')) return;
        this.initElem(ty.of, off + i * ty.of.size, entries, tok);
        if (i < ty.len - 1) { if (this.is('}')) return; if (!this.accept(',')) return; }
      }
      return;
    }
    for (let i = 0; i < ty.fields.length; i++) {
      if (this.is('}')) return;
      this.initElem(ty.fields[i].ty, off + ty.fields[i].offset, entries, tok);
      if (i < ty.fields.length - 1) { if (this.is('}')) return; if (!this.accept(',')) return; }
    }
  }
  readStringBytes() {
    const bytes = [];
    while (this.peek().t === 'str') { for (const b of this.next().bytes) bytes.push(b); }
    bytes.push(0);
    return bytes;
  }
  // ---- expressions
  parseExpr() {
    let e = this.parseAssign();
    while (this.is(',')) { const t = this.next(); const b = this.parseAssign(); e = { k: 'comma', a: e, b: this.rv(b), ty: this.rv(b).ty, tok: t }; }
    return e;
  }
  parseAssign() {
    const lhs = this.parseCond();
    const t = this.peek();
    if (t.t === 'p' && ['=', '+=', '-=', '*=', '/=', '%=', '<<=', '>>=', '&=', '^=', '|='].includes(t.v)) {
      this.next();
      const rhs = this.rv(this.parseAssign());
      return this.mkAssign(t.v, lhs, rhs, t);
    }
    return lhs;
  }
  mkAssign(op, a, b, t) {
    if (!this.isLvalue(a)) cerr(t, 'the left side of ' + op + ' must be a variable or memory location you can change');
    if (a.ty.k === 'array') cerr(t, 'you cannot assign to a whole array - copy it element by element or use memcpy');
    if (op === '=') {
      if (a.ty.k === 'struct') {
        if (b.ty !== a.ty) cerr(t, 'cannot assign ' + typeStr(b.ty) + ' to ' + typeStr(a.ty));
        return { k: 'assign', op, a, b, ty: a.ty, tok: t };
      }
      return { k: 'assign', op, a, b: this.assignConv(b, a.ty, t, 'value'), ty: a.ty, tok: t };
    }
    const bop = op.slice(0, -1);
    if (isPtr(a.ty) && (bop === '+' || bop === '-')) {
      if (!isInt(b.ty)) cerr(t, 'you can only add a whole number to a pointer');
      return { k: 'assign', op, a, b: this.conv(b, TY.int), ty: a.ty, ct: a.ty, ptrStep: this.elemSize(a.ty.to, t), tok: t };
    }
    if (!isArith(a.ty) || !isArith(b.ty)) cerr(t, op + ' needs numbers on both sides');
    if (['%', '<<', '>>', '&', '^', '|'].includes(bop) && (!isInt(a.ty) || !isInt(b.ty))) cerr(t, op + ' only works on whole numbers (not float/double)');
    let ct = (bop === '<<' || bop === '>>') ? promote(a.ty) : usualArith(a.ty, b.ty);
    const bb = (bop === '<<' || bop === '>>') ? this.conv(b, promote(b.ty)) : this.conv(b, ct);
    return { k: 'assign', op, a, b: bb, ty: a.ty, ct, tok: t };
  }
  elemSize(t, tok) {
    if (t.k === 'void') return 1;
    if (t.k === 'func') cerr(tok, 'you cannot do arithmetic on a function pointer');
    if (t.k === 'struct' && !t.complete) cerr(tok, typeStr(t) + ' is not fully defined, so pointer arithmetic on it is impossible');
    return t.size;
  }
  parseCond() {
    const c = this.parseBin(1);
    if (this.is('?')) {
      const t = this.next();
      const a = this.rv(this.parseExpr());
      this.expect(':', 'in the ? : expression');
      const b = this.rv(this.parseCond());
      const cc = this.toCond(c, t);
      let ty;
      if (isArith(a.ty) && isArith(b.ty)) ty = usualArith(a.ty, b.ty);
      else if (a.ty.k === 'void' && b.ty.k === 'void') ty = TY.void;
      else if (isPtr(a.ty) && isPtr(b.ty)) ty = a.ty.to.k === 'void' ? b.ty : a.ty;
      else if (isPtr(a.ty) && this.isNullConst(b)) ty = a.ty;
      else if (isPtr(b.ty) && this.isNullConst(a)) ty = b.ty;
      else if (a.ty.k === 'struct' && a.ty === b.ty) ty = a.ty;
      else cerr(t, 'the two sides of ? : have types that do not match (' + typeStr(a.ty) + ' and ' + typeStr(b.ty) + ')');
      return { k: 'cond', c: cc, a: this.conv(a, ty), b: this.conv(b, ty), ty, tok: t };
    }
    return c;
  }
  parseBin(minp) {
    const PREC = { '||': 1, '&&': 2, '|': 3, '^': 4, '&': 5, '==': 6, '!=': 6, '<': 7, '>': 7, '<=': 7, '>=': 7, '<<': 8, '>>': 8, '+': 9, '-': 9, '*': 10, '/': 10, '%': 10 };
    let l = this.parseUnary();
    for (;;) {
      const t = this.peek();
      const pr = t.t === 'p' ? PREC[t.v] : undefined;
      if (pr === undefined || pr < minp) return l;
      this.next();
      const r = this.parseBin(pr + 1);
      l = this.mkBin(t.v, l, r, t);
    }
  }
  isNullConst(e) {
    while (e.k === 'cast' && (isInt(e.ty) || (isPtr(e.ty) && e.ty.to.k === 'void'))) e = e.a;
    return e.k === 'num' && isInt(e.ty) && e.v === 0n;
  }
  mkBin(op, a, b, t) {
    a = this.rv(a); b = this.rv(b);
    const A = a.ty, B = b.ty;
    if (op === '&&' || op === '||') {
      return { k: 'logic', op, a: this.toCond(a, t), b: this.toCond(b, t), ty: TY.int, tok: t };
    }
    if (op === '+' || op === '-') {
      if (isPtr(A) && isInt(B)) return { k: 'padd', a, b: this.conv(b, promote(B).size === 8 ? TY.llong : TY.int), sign: op === '+' ? 1 : -1, step: this.elemSize(A.to, t), ty: A, tok: t };
      if (op === '+' && isInt(A) && isPtr(B)) return { k: 'padd', a: b, b: this.conv(a, TY.int), sign: 1, step: this.elemSize(B.to, t), ty: B, tok: t };
      if (op === '-' && isPtr(A) && isPtr(B)) {
        if (!strictPtrMatch(A.to, B.to)) this.warn(t, 'subtracting pointers of different types (' + typeStr(A) + ' - ' + typeStr(B) + ')');
        return { k: 'pdiff', a, b, step: this.elemSize(A.to, t), ty: TY.int, tok: t };
      }
    }
    if (['<', '>', '<=', '>=', '==', '!='].includes(op)) {
      if (isPtr(A) || isPtr(B)) {
        if (isPtr(A) && isPtr(B)) { if (!strictPtrMatch(A.to, B.to)) this.warn(t, 'comparing pointers of different types (' + typeStr(A) + ' and ' + typeStr(B) + ')'); }
        else if (isPtr(A) && this.isNullConst(b)) b = this.conv(b, A);
        else if (isPtr(B) && this.isNullConst(a)) a = this.conv(a, B);
        else if (isPtr(A) && isInt(B)) { this.warn(t, 'comparing a pointer with a number'); b = this.conv(b, A); }
        else if (isPtr(B) && isInt(A)) { this.warn(t, 'comparing a pointer with a number'); a = this.conv(a, B); }
        else cerr(t, 'cannot compare ' + typeStr(A) + ' with ' + typeStr(B));
        return { k: 'cmp', op, a, b, ct: TY.uint, ty: TY.int, tok: t };
      }
      if (!isArith(A) || !isArith(B)) cerr(t, 'cannot compare ' + typeStr(A) + ' with ' + typeStr(B) + (A.k === 'struct' ? ' (compare the members one by one)' : ''));
      const ct = usualArith(A, B);
      if (isInt(A) && isInt(B) && ct.unsigned && (!A.unsigned || !B.unsigned)) {
        const s = !A.unsigned ? a : b;
        if (!(s.k === 'num' && s.v >= 0n)) this.warn(t, 'comparing a signed and an unsigned number - a negative value would look huge');
      }
      return { k: 'cmp', op, a: this.conv(a, ct), b: this.conv(b, ct), ct, ty: TY.int, tok: t };
    }
    if (!isArith(A) || !isArith(B)) {
      if (A.k === 'struct' || B.k === 'struct') cerr(t, "'" + op + "' cannot be used on a whole struct");
      cerr(t, "'" + op + "' needs numbers on both sides, but got " + typeStr(A) + ' and ' + typeStr(B));
    }
    if (['%', '<<', '>>', '&', '|', '^'].includes(op) && (!isInt(A) || !isInt(B))) cerr(t, "'" + op + "' only works on whole numbers, not float or double" + (op === '%' ? ' (use fmodf for floats)' : ''));
    if (op === '<<' || op === '>>') {
      const ct = promote(A);
      return { k: 'bin', op, a: this.conv(a, ct), b: this.conv(b, promote(B)), ty: ct, ct, tok: t };
    }
    const ct = usualArith(A, B);
    const r = { k: 'bin', op, a: this.conv(a, ct), b: this.conv(b, ct), ty: ct, ct, tok: t };
    if ((op === '/' || op === '%') && isInt(ct) && b.k === 'num' && b.v === 0n) cerr(t, 'dividing by zero');
    return this.fold(r);
  }
  fold(e) {
    if (e.a && e.b && e.a.k === 'num' && e.b.k === 'num' && isInt(e.ty)) {
      try { const v = this.constEval(e); return { k: 'num', v, ty: e.ty, tok: e.tok }; } catch (x) { return e; }
    }
    return e;
  }
  parseUnary() {
    const t = this.peek();
    if (t.t === 'p') {
      switch (t.v) {
        case '++': case '--': {
          this.next(); const a = this.parseUnary();
          return this.mkIncDec(a, t.v === '++' ? 1 : -1, false, t);
        }
        case '-': case '+': {
          this.next(); const a = this.rv(this.parseCast());
          if (!isArith(a.ty)) cerr(t, "'" + t.v + "' needs a number");
          const ty = promote(a.ty);
          if (t.v === '+') return this.conv(a, ty);
          if (a.k === 'num') { return { k: 'num', v: isInt(ty) ? wrapInt(-BigInt(a.v), ty) : -a.v, ty, tok: t }; }
          return { k: 'neg', a: this.conv(a, ty), ty, tok: t };
        }
        case '!': { this.next(); const a = this.rv(this.parseCast()); return { k: 'not', a: this.toCond(a, t), ty: TY.int, tok: t }; }
        case '~': {
          this.next(); const a = this.rv(this.parseCast());
          if (!isInt(a.ty)) cerr(t, "'~' only works on whole numbers");
          const ty = promote(a.ty);
          if (a.k === 'num') return { k: 'num', v: wrapInt(~BigInt(a.v), ty), ty, tok: t };
          return { k: 'bnot', a: this.conv(a, ty), ty, tok: t };
        }
        case '*': {
          this.next(); const a = this.rv(this.parseCast());
          return this.mkDeref(a, t);
        }
        case '&': {
          this.next(); const a = this.parseCast();
          return this.mkAddr(a, t);
        }
        case '(': {
          if (this.isTypeStart(1)) return this.parseCast();
          break;
        }
      }
    } else if (t.t === 'id' && t.v === 'sizeof') {
      this.next();
      let ty;
      if (this.is('(') && this.isTypeStart(1)) { this.next(); ty = this.parseTypeName(); this.expect(')'); }
      else { const e = this.parseUnary(); ty = e.ty; }
      if (ty.k === 'func') cerr(t, 'sizeof cannot be used on a function');
      if (ty.k === 'struct' && !ty.complete) cerr(t, 'sizeof ' + typeStr(ty) + ': the struct is not fully defined yet');
      return { k: 'num', v: BigInt(ty.size), ty: TY.uint, tok: t };
    } else if (t.t === 'id' && t.v === 'va_arg') {
      this.next(); this.expect('(');
      const ap = this.parseAssign(); this.expect(',');
      const ty = this.parseTypeName(); this.expect(')');
      if (!this.isLvalue(ap)) cerr(t, 'va_arg needs a va_list variable');
      return { k: 'vaarg', ap, ty, tok: t };
    }
    return this.parsePostfix();
  }
  parseCast() {
    if (this.is('(') && this.isTypeStart(1)) {
      const t = this.next();
      const ty = this.parseTypeName();
      this.expect(')', 'to close the (type) cast');
      if (this.is('{')) cerr(t, 'compound literals like (type){...} are not supported by the emulator');
      const a = this.rv(this.parseCast());
      return this.mkCast(a, ty, t);
    }
    return this.parseUnary();
  }
  mkCast(a, ty, t) {
    if (ty.k === 'void') return { k: 'cast', a, ty, tok: t };
    if (ty.k === 'struct' || ty.k === 'array') cerr(t, 'you cannot cast to ' + typeStr(ty));
    if (a.ty.k === 'struct') cerr(t, 'you cannot cast a struct to ' + typeStr(ty));
    if (a.ty.k === 'void') cerr(t, 'a void value cannot be cast');
    if (isPtr(ty) && isFlt(a.ty)) cerr(t, 'you cannot cast a float/double to a pointer');
    if (isFlt(ty) && isPtr(a.ty)) cerr(t, 'you cannot cast a pointer to float/double');
    if (a.k === 'num' && isArith(ty)) {
      return { k: 'num', v: this.convConst(a.v, a.ty, ty), ty, tok: t };
    }
    return { k: 'cast', a, ty, tok: t };
  }
  convConst(v, from, to) {
    if (isInt(to)) {
      if (isFlt(from)) { if (!isFinite(v)) return 0n; return wrapInt(BigInt(Math.trunc(v)), to); }
      return wrapInt(BigInt(v), to);
    }
    if (isFlt(to)) {
      const x = isFlt(from) ? v : Number(v);
      return to.size === 4 ? Math.fround(x) : x;
    }
    return v;
  }
  mkDeref(a, t) {
    if (!isPtr(a.ty)) cerr(t, "'*' needs a pointer, but this is " + typeStr(a.ty) + (isInt(a.ty) ? ' (a number, not an address)' : ''));
    const to = a.ty.to;
    if (to.k === 'void') cerr(t, 'you cannot use * on a void* - cast it to a real pointer type first, like (float*)p');
    if (to.k === 'struct' && !to.complete) cerr(t, typeStr(to) + ' is not fully defined');
    return { k: 'deref', a, ty: to, tok: t };
  }
  mkAddr(a, t) {
    if (a.k === 'id' && a.sym.kind === 'func') { this.noteFnAddr(a.sym); return { k: 'faddr', a, ty: ptrTo(a.sym.ty), tok: t }; }
    if (a.k === 'deref' && a.ty.k === 'func') return a.a;
    if (!this.isLvalue(a) && !(a.k === 'id' && a.ty.k === 'array') && !(a.k === 'member') && !(a.k === 'deref')) cerr(t, "'&' needs a variable (you can only take the address of something stored in memory)");
    this.markAddr(a);
    return { k: 'addr', a, ty: ptrTo(a.ty), tok: t };
  }
  markAddr(a) {
    while (a.k === 'member' && !a.arrow) a = a.a;
    if (a.k === 'id' && a.sym.kind === 'local') a.sym.addrTaken = true;
  }
  noteFnAddr(sym) { if (this.fn) this.fn.addrFns.add(sym.name); else (this.globalFnAddrs || (this.globalFnAddrs = new Set())).add(sym.name); sym.addrTaken = true; }
  mkIncDec(a, delta, post, t) {
    if (!this.isLvalue(a)) cerr(t, (delta > 0 ? '++' : '--') + ' needs a variable you can change');
    if (!isScalar(a.ty)) cerr(t, (delta > 0 ? '++' : '--') + ' needs a number or pointer');
    return { k: 'incdec', a, delta, post, step: isPtr(a.ty) ? this.elemSize(a.ty.to, t) : 1, ty: a.ty, tok: t };
  }
  isLvalue(e) {
    if (e.k === 'id') return e.sym.kind === 'local' || e.sym.kind === 'global';
    if (e.k === 'deref') return true;
    if (e.k === 'member') return e.arrow || this.isLvalue(e.a) || e.a.k === 'call';
    return false;
  }
  parsePostfix() {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      if (t.t !== 'p') break;
      if (t.v === '[') {
        this.next(); const i = this.parseExpr(); this.expect(']', 'to close the [index]');
        const A = this.rv(e), I = this.rv(i);
        if (!(isPtr(A.ty) || isPtr(I.ty))) cerr(t, '[ ] needs an array or pointer on the left, but this is ' + typeStr(e.ty));
        if (!(isInt(A.ty) || isInt(I.ty))) cerr(t, 'the index inside [ ] must be a whole number, not ' + typeStr(I.ty));
        e = this.mkDeref(this.mkBin('+', A, I, t), t); e.index = true; continue;
      }
      if (t.v === '(') { this.next(); e = this.parseCall(e, t); continue; }
      if (t.v === '.' || t.v === '->') {
        this.next(); const nt = this.next();
        if (nt.t !== 'id') cerr(nt, 'expected a member name after ' + t.v);
        let base = e, st;
        if (t.v === '->') {
          base = this.rv(e);
          if (!isPtr(base.ty) || base.ty.to.k !== 'struct') cerr(t, "'->' needs a pointer to a struct, but this is " + typeStr(base.ty) + (base.ty.k === 'struct' ? " (use '.' for a struct that is not a pointer)" : ''));
          st = base.ty.to;
        } else {
          if (e.ty.k !== 'struct') cerr(t, "'.' needs a struct, but this is " + typeStr(e.ty) + (isPtr(e.ty) && e.ty.to.k === 'struct' ? " (it is a pointer - use '->' instead)" : ''));
          st = e.ty;
        }
        if (!st.complete) cerr(t, typeStr(st) + ' is not fully defined');
        const f = st.fields.find(x => x.name === nt.v);
        if (!f) cerr(nt, typeStr(st) + " has no member called '" + nt.v + "'. Its members are: " + st.fields.map(x => x.name).join(', '));
        e = { k: 'member', a: base, arrow: t.v === '->', field: f, ty: f.ty, tok: nt };
        continue;
      }
      if (t.v === '++' || t.v === '--') { this.next(); e = this.mkIncDec(e, t.v === '++' ? 1 : -1, true, t); continue; }
      break;
    }
    return e;
  }
  parseCall(fe, t) {
    const args = [];
    if (!this.accept(')')) {
      for (;;) { args.push(this.rv(this.parseAssign())); if (this.accept(',')) continue; this.expect(')', 'to close the function call'); break; }
    }
    let fty, direct = null;
    if (fe.k === 'id' && fe.sym.kind === 'func') { direct = fe.sym; fty = fe.sym.ty; }
    else {
      const f = this.rv(fe);
      if (isPtr(f.ty) && f.ty.to.k === 'func') fty = f.ty.to;
      else cerr(t, 'this is not a function, so it cannot be called with ( )');
      fe = f;
    }
    const name = direct ? "'" + direct.name + "'" : 'this function pointer';
    if (!fty.unspecified) {
      const np = fty.params.length;
      if (args.length < np || (!fty.variadic && args.length > np)) {
        cerr(t, name + ' takes ' + np + ' argument' + (np === 1 ? '' : 's') + (fty.variadic ? ' or more' : '') + ' but you gave it ' + args.length + (direct && direct.fn ? '' : '') + '. It looks like: ' + typeStr(fty.ret) + ' ' + (direct ? direct.name : '(*f)') + '(' + fty.params.map((p, i) => typeStr(p) + (fty.pnames && fty.pnames[i] ? ' ' + fty.pnames[i] : '')).join(', ') + (fty.variadic ? ', ...' : '') + ')');
      }
    }
    const cargs = args.map((a, i) => {
      if (!fty.unspecified && i < fty.params.length) return this.assignConv(a, fty.params[i], t, 'argument ' + (i + 1) + ' of ' + name);
      // variadic: default promotions
      if (a.ty.k === 'struct') cerr(t, 'you cannot pass a struct to a ... function');
      if (isFlt(a.ty) && a.ty.size === 4) return this.conv(a, TY.double);
      if (isInt(a.ty) && a.ty.size < 4) return this.conv(a, TY.int);
      return a;
    });
    if (direct) {
      if (this.fn) this.fn.calls.add(direct.name); else (this.globalCalls || (this.globalCalls = new Set())).add(direct.name);
      if (direct.name === 'va_start' || direct.name === 'va_end' || direct.name === 'va_copy') { /* builtin */ }
      this.checkFormat(direct, cargs, t);
    }
    return { k: 'call', f: direct ? null : fe, sym: direct, fty, args: cargs, ty: fty.ret, tok: t };
  }
  checkFormat(sym, args, t) {
    const fmtIdx = { printf: 0, fprintf: 1, sprintf: 1, snprintf: 2, scanf: -1 }[sym.name];
    if (fmtIdx === undefined || fmtIdx < 0) return;
    const f = args[fmtIdx];
    let s = f; while (s && s.k === 'cast') s = s.a;
    if (!s || s.k !== 'decay' || s.a.k !== 'str') return;
    const fmt = new TextDecoder().decode(new Uint8Array(s.a.bytes.slice(0, -1)));
    const re = /%[-+ #0]*(\*|\d+)?(?:\.(\*|\d+))?(hh|h|ll|l|z|t|j|L)?([a-zA-Z%])/g;
    let m, ai = fmtIdx + 1;
    while ((m = re.exec(fmt))) {
      const conv = m[4];
      if (conv === '%') continue;
      if (m[1] === '*') ai++;
      if (m[2] === '*') ai++;
      const a = args[ai++];
      if (!a) { this.warn(t, sym.name + ': the format "' + fmt.slice(0, 40) + '" has more % codes than values'); return; }
      const ty = a.ty;
      const bad = (exp) => this.warn(t, sym.name + ': %' + (m[3] || '') + conv + ' expects ' + exp + ' but value ' + (ai - fmtIdx - 1) + ' is ' + typeStr(ty));
      if ('diouxXc'.includes(conv)) { if (!isInt(ty)) bad(conv === 'c' ? 'a char/int' : 'a whole number'); else if ((m[3] === 'll') !== (ty.size === 8)) bad(m[3] === 'll' ? 'a long long' : 'an int (use %lld for long long)'); }
      else if ('feEgGaA'.includes(conv)) { if (!isFlt(ty)) bad('a float or double'); }
      else if (conv === 's') { if (!(isPtr(ty) && isInt(ty.to) && ty.to.size === 1)) bad('a string (char*)'); }
      else if (conv === 'p') { if (!isPtr(ty)) bad('a pointer'); }
    }
    if (ai < args.length) this.warn(t, sym.name + ': you gave more values than the format has % codes');
  }
  parsePrimary() {
    const t = this.next();
    if (t.t === 'num') {
      if (t.float) return { k: 'num', v: t.float === 'float' ? Math.fround(t.v) : t.v, ty: t.float === 'float' ? TY.float : TY.double, tok: t };
      return { k: 'num', v: t.v, ty: TY[t.ity], tok: t };
    }
    if (t.t === 'str') {
      const bytes = [...t.bytes];
      while (this.peek().t === 'str') for (const b of this.next().bytes) bytes.push(b);
      bytes.push(0);
      const s = { k: 'str', bytes, ty: arrOf(TY.char, bytes.length), tok: t, id: this.strings.length };
      this.strings.push(s);
      return s;
    }
    if (t.t === 'id') {
      if (KEYWORDS.has(t.v)) cerr(t, "'" + t.v + "' is a C keyword and cannot be used here");
      const sym = this.lookup(t.v);
      if (!sym) {
        if (this.is('(')) cerr(t, "the function '" + t.v + "' does not exist yet - check the spelling, or write it first (functions must be declared before they are used)");
        cerr(t, "'" + t.v + "' is not declared - check the spelling, or declare it first (for example: int " + t.v + ' = 0;)');
      }
      if (sym.kind === 'typedef') cerr(t, "'" + t.v + "' is a type name, not a value");
      if (sym.kind === 'enumconst') return { k: 'num', v: sym.value, ty: TY.int, tok: t };
      if (sym.kind === 'func' && !this.is('(')) this.noteFnAddr(sym);
      return { k: 'id', sym, ty: sym.ty, tok: t };
    }
    if (t.t === 'p' && t.v === '(') {
      const e = this.parseExpr();
      this.expect(')', 'to close the ( bracket');
      return e;
    }
    cerr(t, 'expected a value here but found ' + this.desc(t));
  }
  // ---- conversions
  rv(e) {
    if (e.ty.k === 'array') return { k: 'decay', a: e, ty: ptrTo(e.ty.of), tok: e.tok };
    if (e.ty.k === 'func') { if (e.k === 'id') this.noteFnAddr(e.sym); return { k: 'faddr', a: e, ty: ptrTo(e.ty), tok: e.tok }; }
    return e;
  }
  conv(e, ty) {
    if (e.ty === ty || (sameType(e.ty, ty) && e.ty.k !== 'ptr' && e.ty.k !== 'int')) return e;
    if (e.ty.k === 'int' && ty.k === 'int' && e.ty.size === ty.size && !!e.ty.unsigned === !!ty.unsigned && !!e.ty.bool === !!ty.bool) return e;
    if (e.ty.k === 'ptr' && ty.k === 'ptr') return { k: 'cast', a: e, ty, tok: e.tok };
    if (e.k === 'num' && isArith(ty) && isArith(e.ty)) return { k: 'num', v: this.convConst(e.v, e.ty, ty), ty, tok: e.tok };
    return { k: 'cast', a: e, ty, tok: e.tok };
  }
  toCond(e, t) {
    e = this.rv(e);
    if (!isScalar(e.ty)) cerr(t, 'a condition must be a number or pointer, not ' + typeStr(e.ty));
    return e;
  }
  assignConv(e, ty, t, what) {
    const A = e.ty;
    if (ty.k === 'struct') { if (A !== ty) cerr(t, what + ': expected ' + typeStr(ty) + ' but got ' + typeStr(A)); return e; }
    if (isArith(ty) && isArith(A)) return this.conv(e, ty);
    if (isPtr(ty)) {
      if (isPtr(A)) {
        if (!strictPtrMatch(ty.to, A.to) && !(ty.to.k === 'func' && A.to.k === 'func' && sameType(ty.to, A.to))) this.warn(t, what + ': expected ' + typeStr(ty) + ' but got ' + typeStr(A));
        return this.conv(e, ty);
      }
      if (this.isNullConst(e)) return this.conv(e, ty);
      if (isInt(A)) { this.warn(t, what + ': using a number as a pointer (' + typeStr(A) + ' to ' + typeStr(ty) + ')'); return this.conv(e, ty); }
    }
    if (isInt(ty) && isPtr(A)) { if (ty.bool) return this.conv(e, ty); this.warn(t, what + ': using a pointer as a number'); return this.conv(e, ty); }
    if (A.k === 'void') cerr(t, what + ': this has no value (it is void)');
    cerr(t, what + ': expected ' + typeStr(ty) + ' but got ' + typeStr(A));
  }
  // ---- constants
  constInt(e, tok, msg) {
    try {
      const v = this.constEval(this.rv(e));
      if (typeof v !== 'bigint') { if (typeof v === 'number') return BigInt(Math.trunc(v)); throw 0; }
      return v;
    } catch (x) { if (x instanceof CError) throw x; cerr(tok, msg || 'this must be a constant number'); }
  }
  constEval(e) {
    switch (e.k) {
      case 'num': return e.v;
      case 'cast': {
        const v = this.constEval(e.a);
        if (isPtr(e.ty)) { if (typeof v === 'bigint') return v; throw 0; }
        return this.convConst(v, e.a.ty, e.ty);
      }
      case 'neg': { const v = this.constEval(e.a); return isInt(e.ty) ? wrapInt(-v, e.ty) : -v; }
      case 'bnot': return wrapInt(~this.constEval(e.a), e.ty);
      case 'not': { const v = this.constEval(e.a); return (v === 0n || v === 0) ? 1n : 0n; }
      case 'logic': { const a = this.constEval(e.a); const at = !(a === 0n || a === 0); if (e.op === '&&') { if (!at) return 0n; const b = this.constEval(e.b); return (b === 0n || b === 0) ? 0n : 1n; } if (at) return 1n; const b = this.constEval(e.b); return (b === 0n || b === 0) ? 0n : 1n; }
      case 'cond': { const c = this.constEval(e.c); return (c === 0n || c === 0) ? this.constEval(e.b) : this.constEval(e.a); }
      case 'cmp': {
        const a = this.constEval(e.a), b = this.constEval(e.b);
        let r;
        switch (e.op) { case '<': r = a < b; break; case '>': r = a > b; break; case '<=': r = a <= b; break; case '>=': r = a >= b; break; case '==': r = a == b; break; default: r = a != b; }
        return r ? 1n : 0n;
      }
      case 'bin': {
        const a = this.constEval(e.a), b = this.constEval(e.b), t = e.ty;
        if (isFlt(t)) {
          let r;
          switch (e.op) { case '+': r = a + b; break; case '-': r = a - b; break; case '*': r = a * b; break; case '/': r = a / b; break; default: throw 0; }
          return t.size === 4 ? Math.fround(r) : r;
        }
        let r;
        switch (e.op) {
          case '+': r = a + b; break; case '-': r = a - b; break; case '*': r = a * b; break;
          case '/': if (b === 0n) throw 0; r = a / b; break; case '%': if (b === 0n) throw 0; r = a % b; break;
          case '<<': r = a << (b & 63n); break; case '>>': r = a >> (b & 63n); break;
          case '&': r = a & b; break; case '|': r = a | b; break; case '^': r = a ^ b; break;
          default: throw 0;
        }
        return wrapInt(r, t);
      }
      case 'comma': throw 0;
    }
    throw 0;
  }
}
// ===== BitScribe C compiler: WebAssembly code generator =====
const WT = { i32: 0x7f, i64: 0x7e, f32: 0x7d, f64: 0x7c };
function uleb(n, out) { n = n >>> 0; do { let b = n & 0x7f; n >>>= 7; if (n) b |= 0x80; out.push(b); } while (n); }
function sleb(n, out) { n |= 0; for (;;) { const b = n & 0x7f; n >>= 7; if ((n === 0 && (b & 0x40) === 0) || (n === -1 && (b & 0x40) !== 0)) { out.push(b); return; } out.push(b | 0x80); } }
function sleb64(n, out) { n = BigInt.asIntN(64, n); for (;;) { const b = Number(n & 0x7fn); n >>= 7n; if ((n === 0n && (b & 0x40) === 0) || (n === -1n && (b & 0x40) !== 0)) { out.push(b); return; } out.push(b | 0x80); } }
function bytesOfStr(s, out) { const b = new TextEncoder().encode(s); uleb(b.length, out); for (const x of b) out.push(x); }
const F32B = new Float32Array(1), F64B = new Float64Array(1);
const OPS = {
  add: { i32: 0x6a, i64: 0x7c, f32: 0x92, f64: 0xa0 }, sub: { i32: 0x6b, i64: 0x7d, f32: 0x93, f64: 0xa1 },
  mul: { i32: 0x6c, i64: 0x7e, f32: 0x94, f64: 0xa2 }, div_s: { i32: 0x6d, i64: 0x7f, f32: 0x95, f64: 0xa3 },
  div_u: { i32: 0x6e, i64: 0x80, f32: 0x95, f64: 0xa3 }, rem_s: { i32: 0x6f, i64: 0x81 }, rem_u: { i32: 0x70, i64: 0x82 },
  and: { i32: 0x71, i64: 0x83 }, or: { i32: 0x72, i64: 0x84 }, xor: { i32: 0x73, i64: 0x85 },
  shl: { i32: 0x74, i64: 0x86 }, shr_s: { i32: 0x75, i64: 0x87 }, shr_u: { i32: 0x76, i64: 0x88 },
  eq: { i32: 0x46, i64: 0x51, f32: 0x5b, f64: 0x61 }, ne: { i32: 0x47, i64: 0x52, f32: 0x5c, f64: 0x62 },
  lt_s: { i32: 0x48, i64: 0x53, f32: 0x5d, f64: 0x63 }, lt_u: { i32: 0x49, i64: 0x54, f32: 0x5d, f64: 0x63 },
  gt_s: { i32: 0x4a, i64: 0x55, f32: 0x5e, f64: 0x64 }, gt_u: { i32: 0x4b, i64: 0x56, f32: 0x5e, f64: 0x64 },
  le_s: { i32: 0x4c, i64: 0x57, f32: 0x5f, f64: 0x65 }, le_u: { i32: 0x4d, i64: 0x58, f32: 0x5f, f64: 0x65 },
  ge_s: { i32: 0x4e, i64: 0x59, f32: 0x60, f64: 0x66 }, ge_u: { i32: 0x4f, i64: 0x5a, f32: 0x60, f64: 0x66 },
};
const INLINE_BUILTINS = new Set(['memcpy', 'memmove', 'memset', 'sqrtf', 'sqrt', 'fabsf', 'fabs', 'floorf', 'floor',
  'ceilf', 'ceil', 'truncf', 'trunc', 'roundf', 'round', 'fminf', 'fmaxf', 'fmin', 'fmax', 'copysignf', 'copysign', '__va_ptr', 'abs']);
const DATA_BASE = 1024;

class FnB {
  constructor() { this.c = []; this.localTypes = []; this.ctl = []; }
  op(...b) { for (const x of b) this.c.push(x); }
  u(n) { uleb(n, this.c); }
  i32(v) { this.c.push(0x41); sleb(v | 0, this.c); }
  i64(v) { this.c.push(0x42); sleb64(BigInt(v), this.c); }
  f32(v) { this.c.push(0x43); F32B[0] = v; for (const b of new Uint8Array(F32B.buffer)) this.c.push(b); }
  f64(v) { this.c.push(0x44); F64B[0] = v; for (const b of new Uint8Array(F64B.buffer)) this.c.push(b); }
  lget(i) { this.c.push(0x20); uleb(i, this.c); }
  lset(i) { this.c.push(0x21); uleb(i, this.c); }
  ltee(i) { this.c.push(0x22); uleb(i, this.c); }
  gget(i) { this.c.push(0x23); uleb(i, this.c); }
  gset(i) { this.c.push(0x24); uleb(i, this.c); }
  call(i) { this.c.push(0x10); uleb(i, this.c); }
  mem(op, align, off) { this.c.push(op); uleb(align, this.c); uleb(off >>> 0, this.c); }
  open(kind, bt, info) { this.c.push(kind === 'block' ? 0x02 : kind === 'loop' ? 0x03 : 0x04); this.c.push(bt === undefined ? 0x40 : bt); this.ctl.push(info || {}); }
  els() { this.c.push(0x05); }
  end() { this.c.push(0x0b); this.ctl.pop(); }
  br(depth) { this.c.push(0x0c); uleb(depth, this.c); }
  brif(depth) { this.c.push(0x0d); uleb(depth, this.c); }
}

class Gen {
  constructor(parser, opts, builtinNames) {
    this.P = parser; this.opts = opts; this.safe = opts.safe !== false; this.builtinNames = builtinNames;
    this.types = []; this.typeMap = new Map();
    this.imports = []; this.importIdx = new Map();
    this.fnIdx = new Map(); this.bodies = [];
    this.table = [null]; this.tableIdx = new Map();
    this.data = []; this.dataEnd = DATA_BASE; this.globalAddr = new Map(); this.strAddr = new Map(); this.pendingGlobals = [];
    this.G_SP = 0; this.G_LINE = 1; this.G_LIMIT = 2; this.G_HEAP = 3;
    this.lineFiles = [];
  }
  typeIndex(params, results) {
    const key = params.join(',') + '>' + results.join(',');
    let i = this.typeMap.get(key);
    if (i === undefined) { i = this.types.length; this.types.push({ params, results }); this.typeMap.set(key, i); }
    return i;
  }
  sigOf(fty) {
    const params = [];
    if (fty.ret.k === 'struct') params.push('i32');
    for (const p of fty.params) params.push(p.k === 'struct' ? 'i32' : wty(p));
    if (fty.variadic) params.push('i32');
    const r = fty.ret.k === 'void' ? [] : [fty.ret.k === 'struct' ? 'i32' : wty(fty.ret)];
    return { params, results: r };
  }
  // ---------- whole program
  build() {
    const P = this.P;
    const roots = [];
    for (const n of (this.opts.roots || ['main'])) if (P.funcs.has(n)) roots.push(n);
    if (!roots.length) cerr(null, 'there is no main() function to start the program');
    const reach = new Set(); const q = [...roots];
    for (const s of [P.globalCalls, P.globalFnAddrs]) if (s) for (const n of s) q.push(n);
    while (q.length) {
      const n = q.pop(); if (reach.has(n)) continue; reach.add(n);
      const sym = P.funcs.get(n); if (!sym || !sym.fn) continue;
      for (const c of sym.fn.calls) q.push(c);
      for (const c of sym.fn.addrFns) q.push(c);
    }
    this.reach = reach;
    // imports: always-needed helpers
    const helper = (name, params, results) => { this.importIdx.set(name, this.imports.length); this.imports.push({ name, type: this.typeIndex(params, results) }); };
    helper('__nullfault', ['i32'], []); helper('__stackoverflow', ['i32'], []); helper('__noreturn', ['i32'], []);
    const defined = [];
    for (const n of reach) {
      const sym = P.funcs.get(n);
      if (!sym) continue;
      if (sym.fn) { defined.push(sym); continue; }
      if (INLINE_BUILTINS.has(n)) continue;
      if (this.builtinNames.has(n)) {
        const sig = this.sigOf(sym.ty);
        this.importIdx.set(n, this.imports.length);
        this.imports.push({ name: n, type: this.typeIndex(sig.params, sig.results) });
        continue;
      }
      const where = this.usedWhere(n);
      cerr(sym.tok, "the function '" + n + "' is used" + where + ' but it is never written. Write the whole function ' + typeStr(sym.ty.ret) + ' ' + n + '(...) { ... }');
    }
    const nImp = this.imports.length;
    defined.forEach((s, i) => this.fnIdx.set(s.name, nImp + i));
    this.defined = defined;
    // helper wasm functions (round)
    this.extraFns = [];
    for (const sym of defined) this.bodies.push(this.genFunction(sym));
    // start function
    const mainName = this.opts.entry || 'main';
    const msym = P.funcs.get(mainName);
    if (!msym || !msym.fn) cerr(null, 'there is no ' + mainName + '() function to start the program');
    this.startBody = this.genStart(msym);
    // pending globals
    while (this.pendingGlobals.length) this.initGlobal(this.pendingGlobals.shift());
    return this.emitModule();
  }
  usedWhere(n) {
    for (const s of this.P.funcs.values()) if (s.fn && s.fn.calls.has(n) && this.reach.has(s.name)) return " in '" + s.name + "'";
    return '';
  }
  funcIndex(sym) {
    if (this.fnIdx.has(sym.name)) return this.fnIdx.get(sym.name);
    if (this.importIdx.has(sym.name)) return this.importIdx.get(sym.name);
    cerr(sym.tok, "internal: function '" + sym.name + "' not available");
  }
  tableSlot(sym) {
    let i = this.tableIdx.get(sym.name);
    if (i === undefined) {
      if (!this.fnIdx.has(sym.name)) {
        if (this.importIdx.has(sym.name)) { /* ok */ }
        else cerr(sym.tok, "the function '" + sym.name + "' is used as a pointer but never written");
      }
      i = this.table.length; this.table.push(sym); this.tableIdx.set(sym.name, i);
    }
    return i;
  }
  alloc(size, align) {
    this.dataEnd = (this.dataEnd + align - 1) & ~(align - 1);
    const a = this.dataEnd; this.dataEnd += Math.max(size, 1); return a;
  }
  addrOfGlobal(sym) {
    let a = this.globalAddr.get(sym.id);
    if (a === undefined) {
      if (sym.extern && !sym.defined) cerr(sym.tok, "the global variable '" + sym.name + "' is declared extern but never defined");
      a = this.alloc(sym.ty.size, Math.max(sym.ty.align, 4)); this.globalAddr.set(sym.id, a); this.pendingGlobals.push(sym);
    }
    return a;
  }
  addrOfString(s) {
    let a = this.strAddr.get(s);
    if (a === undefined) { a = this.alloc(s.bytes.length, 1); this.strAddr.set(s, a); this.data.push({ off: a, bytes: s.bytes }); }
    return a;
  }
  initGlobal(sym) {
    if (!sym.init) return;
    const base = this.globalAddr.get(sym.id);
    const buf = new Uint8Array(sym.ty.size); const dv = new DataView(buf.buffer);
    for (const en of sym.init.entries) {
      if (en.bytes) { buf.set(en.bytes.slice(0, sym.ty.size - en.off), en.off); continue; }
      if (en.ty.k === 'struct') cerr(sym.tok, 'a global struct must be initialised with constant values in { }');
      const v = this.staticValue(en.e, sym);
      const t = en.ty, o = en.off;
      if (t.k === 'float') { if (t.size === 4) dv.setFloat32(o, Number(v), true); else dv.setFloat64(o, Number(v), true); }
      else if (t.size === 8) dv.setBigInt64(o, BigInt.asIntN(64, BigInt(v)), true);
      else if (t.size === 4) dv.setInt32(o, Number(BigInt.asIntN(32, BigInt(v))), true);
      else if (t.size === 2) dv.setInt16(o, Number(BigInt.asIntN(16, BigInt(v))), true);
      else buf[o] = Number(BigInt.asUintN(8, BigInt(v)));
    }
    this.data.push({ off: base, bytes: buf });
  }
  staticValue(e, sym) {
    // constant numbers or addresses
    const addr = this.staticAddr(e);
    if (addr !== null) return BigInt(addr);
    try {
      const v = this.P.constEval(e);
      return v;
    } catch (x) {
      cerr(e.tok || sym.tok, "the starting value of the global '" + sym.name + "' must be a constant (a number, a string, or the address of something global)");
    }
  }
  staticAddr(e) {
    switch (e.k) {
      case 'cast': return isPtr(e.ty) || (isInt(e.ty) && e.ty.size === 4) ? this.staticAddr(e.a) : null;
      case 'decay': return this.staticLval(e.a);
      case 'addr': return this.staticLval(e.a);
      case 'faddr': return e.a.k === 'id' ? this.tableSlot(e.a.sym) : null;
      case 'padd': { const b = this.staticAddr(e.a); if (b === null) return null; let k; try { k = Number(this.P.constEval(e.b)); } catch (x) { return null; } return b + e.sign * k * e.step; }
    }
    return null;
  }
  staticLval(e) {
    switch (e.k) {
      case 'id': return e.sym.kind === 'global' ? this.addrOfGlobal(e.sym) : null;
      case 'str': return this.addrOfString(e);
      case 'member': if (e.arrow) { const b = this.staticAddr(e.a); return b === null ? null : b + e.field.offset; } { const b = this.staticLval(e.a); return b === null ? null : b + e.field.offset; }
      case 'deref': return this.staticAddr(e.a);
    }
    return null;
  }
  lineId(tok) { if (!tok) return 0; return ((tok.f & 2047) << 20) | Math.min(tok.l, 0xfffff); }
  // ---------- functions
  genFunction(sym) {
    const fn = sym.fn, fty = sym.ty;
    const b = this.b = new FnB(); this.cur = fn;
    this.frame = 0; this.tpool = { i32: [], i64: [], f32: [], f64: [] }; this.tlive = []; this.framePatches = [];
    const sig = this.sigOf(fty);
    let pi = 0;
    this.retPtr = fty.ret.k === 'struct' ? pi++ : -1;
    const nC = fty.params.length;
    const firstC = pi; pi += nC;
    this.vaPtr = fty.variadic ? pi++ : -1;
    this.nParams = pi;
    b.localTypes = [];
    const newLocal = (t) => { const i = this.nParams + b.localTypes.length; b.localTypes.push(t); return i; };
    this.newLocal = newLocal;
    this.fp = -1;
    // assign storage
    const memLocals = [];
    for (const s of fn.locals) {
      const inMem = s.addrTaken || isAgg(s.ty);
      if (s.param !== undefined) {
        s.widx = firstC + s.param;
        if (inMem) { s.mem = true; memLocals.push(s); } else s.mem = false;
      } else {
        if (inMem) { s.mem = true; memLocals.push(s); }
        else { s.mem = false; s.widx = newLocal(wty(s.ty)); }
      }
    }
    for (const s of memLocals) { const a = Math.max(s.ty.align, 4); this.frame = (this.frame + a - 1) & ~(a - 1); s.off = this.frame; this.frame += Math.max(s.ty.size, 1); }
    this.fp = newLocal('i32');
    this.chk = newLocal('i32');
    this.lastLine = -1;
    // body
    const body = new FnB(); body.localTypes = b.localTypes; this.b = body;
    // copy params into memory slots
    for (const s of memLocals) {
      if (s.param === undefined) continue;
      if (s.ty.k === 'struct') { body.lget(this.fp); if (s.off) { body.i32(s.off); body.op(0x6a); } body.lget(s.widx); body.i32(s.ty.size); body.op(0xfc, 10, 0, 0); }
      else { body.lget(this.fp); body.lget(s.widx); this.emitStore(s.ty, s.off); }
    }
    this.genStmt(fn.body);
    // fallthrough end
    if (fty.ret.k !== 'void') {
      if (sym.name === 'main' || sym.name === '__user_main') { body.i32(0); this.emitRet(); }
      else { body.i32(this.lineId(fn.body.endTok || fn.tok)); body.call(this.importIdx.get('__noreturn')); body.op(0x00); }
    } else this.emitRet();
    // prologue
    const pro = new FnB();
    const F = (this.frame + 15) & ~15;
    this.frameSize = F;
    if (F > 0) {
      pro.gget(this.G_SP); pro.i32(F); pro.op(0x6b); pro.ltee(this.fp); pro.gset(this.G_SP);
      if (this.safe || true) { pro.lget(this.fp); pro.gget(this.G_LIMIT); pro.op(0x49); pro.open('if'); pro.i32(this.lineId(fn.tok)); pro.call(this.importIdx.get('__stackoverflow')); pro.end(); }
    }
    // patch: epilogue placeholders. We generated returns referencing frame via emitRet which uses this.frameSizeRef
    const code = pro.c.concat(this.patchFrame(body.c, F));
    return { typeIdx: this.typeIndex(sig.params, sig.results), locals: b.localTypes, code, name: sym.name };
  }
  patchFrame(code, F) {
    const P = this.framePatches || [];
    if (!P.length) return code;
    const out = []; let last = 0;
    for (const p of P) {
      for (let i = last; i < p.start; i++) out.push(code[i]);
      if (F > 0) {
        for (let i = p.start; i < p.cpos; i++) out.push(code[i]);
        out.push(0x41); sleb(F, out);
        for (let i = p.cpos + 6; i < p.end; i++) out.push(code[i]);
      }
      last = p.end;
    }
    for (let i = last; i < code.length; i++) out.push(code[i]);
    this.framePatches = [];
    return out;
  }
  emitRet() {
    const b = this.b;
    const start = b.c.length;
    b.lget(this.fp);
    const cpos = b.c.length;
    b.op(0x41, 0x80, 0x80, 0x80, 0x80, 0x00);
    b.op(0x6a); b.gset(this.G_SP);
    this.framePatches.push({ start, cpos, end: b.c.length });
    b.op(0x0f);
  }
  frameMayExist() { return true; }
  genStart(msym) {
    const b = this.b = new FnB(); this.cur = null;
    const fty = msym.ty;
    if (fty.params.length >= 2) { b.lget(0); b.lget(1); }
    else if (fty.params.length === 1) { b.lget(0); }
    b.call(this.fnIdx.get(msym.name));
    if (fty.ret.k === 'void') b.i32(0);
    else if (wty(fty.ret) === 'i64') b.op(0xa7);
    else if (wty(fty.ret) !== 'i32') cerr(msym.tok, 'main must return int');
    return { typeIdx: this.typeIndex(['i32', 'i32'], ['i32']), locals: [], code: b.c, name: '__start' };
  }
  // ---------- temps
  temp(t) { const pool = this.tpool[t]; const i = pool.length ? pool.pop() : this.newLocal(t); this.tlive.push([t, i]); return i; }
  releaseTemps() { for (const [t, i] of this.tlive) this.tpool[t].push(i); this.tlive = []; }
  // ---------- statements
  setLine(tok) {
    if (!tok) return;
    const id = this.lineId(tok);
    if (id === this.lastLine) return;
    this.lastLine = id;
    this.b.i32(id); this.b.gset(this.G_LINE);
  }
  genStmt(s) {
    const b = this.b;
    this.releaseTemps();
    switch (s.k) {
      case 'block': {
        // check case labels
        for (const it of s.items) this.genStmt(it);
        return;
      }
      case 'empty': return;
      case 'decl':
        for (const d of s.decls) {
          if (!d.init) continue;
          this.setLine(d.tok); this.lastLine = -1;
          this.genInit(d.sym, d.init);
        }
        return;
      case 'expr': this.setLine(s.tok); this.gen(s.e, false); return;
      case 'if':
        this.setLine(s.tok); this.genCond(s.c);
        b.open('if'); this.lastLine = -1; this.genStmt(s.t);
        if (s.f) { b.els(); this.lastLine = -1; this.genStmt(s.f); }
        b.end(); this.lastLine = -1; return;
      case 'while':
        b.open('block', 0x40, { brk: true }); b.open('loop', 0x40, { cont: true });
        this.lastLine = -1; this.setLine(s.tok); this.genCond(s.c); b.op(0x45); b.brif(1);
        this.genStmt(s.body); b.br(0); b.end(); b.end(); this.lastLine = -1; return;
      case 'do':
        b.open('block', 0x40, { brk: true }); b.open('loop'); b.open('block', 0x40, { cont: true });
        this.lastLine = -1; this.genStmt(s.body); b.end();
        this.lastLine = -1; this.setLine(s.tok); this.genCond(s.c); b.brif(0); b.end(); b.end(); this.lastLine = -1; return;
      case 'for':
        if (s.init) this.genStmt(s.init);
        b.open('block', 0x40, { brk: true }); b.open('loop');
        this.lastLine = -1;
        if (s.c) { this.setLine(s.tok); this.genCond(s.c); b.op(0x45); b.brif(1); }
        b.open('block', 0x40, { cont: true }); this.genStmt(s.body); b.end();
        this.lastLine = -1;
        if (s.inc) { this.setLine(s.tok); this.gen(s.inc, false); }
        b.br(0); b.end(); b.end(); this.lastLine = -1; return;
      case 'switch': return this.genSwitch(s);
      case 'case': case 'default': cerr(s.tok, "the emulator only supports 'case' labels directly inside the switch { } block, not inside an inner block");
      case 'break': case 'continue': {
        const key = s.k === 'break' ? 'brk' : 'cont';
        for (let i = b.ctl.length - 1; i >= 0; i--) if (b.ctl[i][key]) { b.br(b.ctl.length - 1 - i); return; }
        cerr(s.tok, s.k + ' is not inside a loop');
      }
      case 'return': {
        this.setLine(s.tok);
        const rt = this.cur.ty.ret;
        if (s.e) {
          if (rt.k === 'struct') {
            b.lget(this.retPtr); this.genAddrValue(s.e); b.i32(rt.size); b.op(0xfc, 10, 0, 0);
            b.lget(this.retPtr);
          } else if (rt.k === 'void') this.gen(s.e, false);
          else this.gen(s.e, true);
        }
        this.emitRet();
        return;
      }
    }
    cerr(s.tok, 'internal: unknown statement ' + s.k);
  }
  genSwitch(s) {
    const b = this.b;
    this.setLine(s.tok);
    const wt = wty(s.e.ty);
    const sel = this.temp(wt);
    this.gen(s.e, true); b.lset(sel);
    const items = s.body.k === 'block' ? s.body.items : [s.body];
    const segs = [{ vals: [], def: false, stmts: [] }];
    for (const it of items) {
      if (it.k === 'case' || it.k === 'default') {
        let seg = segs[segs.length - 1];
        if (seg.stmts.length) { seg = { vals: [], def: false, stmts: [] }; segs.push(seg); }
        if (it.k === 'case') { if (segs.some(g => g.vals.some(v => v === it.v))) cerr(it.tok, 'case ' + it.v + ' appears twice'); seg.vals.push(it.v); }
        else { if (segs.some(g => g.def)) cerr(it.tok, 'default appears twice'); seg.def = true; }
      } else segs[segs.length - 1].stmts.push(it);
    }
    const n = segs.length;
    b.open('block', 0x40, { brk: true });
    for (let i = n - 1; i >= 0; i--) b.open('block');
    for (let i = 0; i < n; i++) for (const v of segs[i].vals) {
      b.lget(sel); if (wt === 'i64') { b.i64(v); b.op(0x51); } else { b.i32(Number(BigInt.asIntN(32, v))); b.op(0x46); } b.brif(i);
    }
    const di = segs.findIndex(g => g.def);
    b.br(di >= 0 ? di : n);
    for (let i = 0; i < n; i++) { b.end(); this.lastLine = -1; for (const st of segs[i].stmts) this.genStmt(st); }
    b.end(); this.lastLine = -1;
  }
  genInit(sym, init) {
    const b = this.b;
    if (!sym.mem) {
      const en = init.entries[0];
      if (en) { this.gen(en.e, true); b.lset(sym.widx); }
      return;
    }
    const ty = sym.ty;
    const whole = init.entries.length === 1 && init.entries[0].off === 0 && init.entries[0].ty === ty && !init.entries[0].bytes;
    if (isAgg(ty) && !whole) {
      b.lget(this.fp); if (sym.off) { b.i32(sym.off); b.op(0x6a); } b.i32(0); b.i32(ty.size); b.op(0xfc, 11, 0);
    }
    for (const en of init.entries) {
      if (en.bytes) {
        const tmp = { bytes: en.bytes };
        const a = this.addrOfString(tmp);
        b.lget(this.fp); b.i32(sym.off + en.off); b.op(0x6a); b.i32(a); b.i32(en.bytes.length); b.op(0xfc, 10, 0, 0);
        continue;
      }
      if (en.ty.k === 'struct') {
        b.lget(this.fp); b.i32(sym.off + en.off); b.op(0x6a); this.genAddrValue(en.e); b.i32(en.ty.size); b.op(0xfc, 10, 0, 0);
        continue;
      }
      b.lget(this.fp); this.gen(en.e, true); this.emitStore(en.ty, sym.off + en.off);
    }
  }
  // ---------- expressions
  emitLoad(ty, off) {
    const b = this.b;
    if (ty.k === 'int') {
      if (ty.size === 1) return b.mem(ty.unsigned ? 0x2d : 0x2c, 0, off);
      if (ty.size === 2) return b.mem(ty.unsigned ? 0x2f : 0x2e, 1, off);
      if (ty.size === 4) return b.mem(0x28, 2, off);
      return b.mem(0x29, 3, off);
    }
    if (ty.k === 'float') return ty.size === 4 ? b.mem(0x2a, 2, off) : b.mem(0x2b, 3, off);
    if (ty.k === 'ptr') return b.mem(0x28, 2, off);
    cerr(null, 'internal: load of ' + typeStr(ty));
  }
  emitStore(ty, off) {
    const b = this.b;
    if (ty.k === 'int') {
      if (ty.size === 1) return b.mem(0x3a, 0, off);
      if (ty.size === 2) return b.mem(0x3b, 1, off);
      if (ty.size === 4) return b.mem(0x36, 2, off);
      return b.mem(0x37, 3, off);
    }
    if (ty.k === 'float') return ty.size === 4 ? b.mem(0x38, 2, off) : b.mem(0x39, 3, off);
    if (ty.k === 'ptr') return b.mem(0x36, 2, off);
    cerr(null, 'internal: store of ' + typeStr(ty));
  }
  nullCheck(tok) {
    if (!this.safe) return;
    const b = this.b;
    b.ltee(this.chk); b.i32(1024); b.op(0x49); b.open('if'); b.i32(this.lineId(tok)); b.call(this.importIdx.get('__nullfault')); b.end(); b.lget(this.chk);
  }
  // pushes base address, returns constant offset
  genAddr(e) {
    const b = this.b;
    switch (e.k) {
      case 'id': {
        const s = e.sym;
        if (s.kind === 'global') { b.i32(this.addrOfGlobal(s)); return 0; }
        if (s.kind === 'local') { if (!s.mem) cerr(e.tok, "internal: '" + s.name + "' is not in memory"); b.lget(this.fp); return s.off; }
        cerr(e.tok, 'cannot take the address of this');
      }
      case 'str': b.i32(this.addrOfString(e)); return 0;
      case 'deref': {
        const a = e.a;
        if (a.k === 'padd' && a.b.k === 'num') {
          const k = Number(BigInt.asIntN(32, BigInt(a.b.v))) * a.sign * a.step;
          if (k >= 0 && k < 0x40000000) { this.gen(a.a, true); this.nullCheck(e.tok); return k; }
        }
        this.gen(a, true); this.nullCheck(e.tok); return 0;
      }
      case 'member': {
        if (e.arrow) { this.gen(e.a, true); this.nullCheck(e.tok); return e.field.offset; }
        return this.genAddr(e.a) + e.field.offset;
      }
      case 'call': case 'cond': case 'comma': case 'assign': this.gen(e, true); return 0;
      case 'cast': return this.genAddr(e.a);
    }
    cerr(e.tok, 'this does not have an address');
  }
  genAddrValue(e) { const off = this.genAddr(e); if (off) { this.b.i32(off); this.b.op(0x6a); } }
  genCond(e) {
    const b = this.b;
    const t = wty(e.ty);
    if (e.k === 'cmp' || e.k === 'logic' || e.k === 'not') { this.gen(e, true); return; }
    this.gen(e, true);
    if (t === 'i64') { b.i64(0); b.op(0x52); }
    else if (t === 'f32') { b.f32(0); b.op(0x5c); }
    else if (t === 'f64') { b.f64(0); b.op(0x62); }
  }
  genBool(e) { // 0/1 i32
    const b = this.b;
    if (e.k === 'cmp' || e.k === 'logic' || e.k === 'not') { this.gen(e, true); return; }
    this.genCond(e);
    if (wty(e.ty) === 'i32') { b.i32(0); b.op(0x47); }
  }
  cvt(from, to) {
    const b = this.b;
    if (to.k === 'void') { if (from.k !== 'void') b.op(0x1a); return; }
    const fw = wty(from), tw = wty(to);
    if (to.k === 'int' && to.bool) {
      if (from.k === 'int' && from.bool) return;
      if (fw === 'i32') { b.i32(0); b.op(0x47); } else if (fw === 'i64') { b.i64(0); b.op(0x52); }
      else if (fw === 'f32') { b.f32(0); b.op(0x5c); } else { b.f64(0); b.op(0x62); }
      return;
    }
    // to wasm type first
    if (fw !== tw) {
      const u = from.k === 'ptr' || (from.k === 'int' && from.unsigned);
      const tu = to.k === 'int' && to.unsigned;
      const key = fw + '>' + tw;
      switch (key) {
        case 'i64>i32': b.op(0xa7); break;
        case 'i32>i64': b.op(u ? 0xad : 0xac); break;
        case 'f32>i32': b.op(0xfc, tu ? 1 : 0); break;
        case 'f64>i32': b.op(0xfc, tu ? 3 : 2); break;
        case 'f32>i64': b.op(0xfc, tu ? 5 : 4); break;
        case 'f64>i64': b.op(0xfc, tu ? 7 : 6); break;
        case 'i32>f32': b.op(u ? 0xb3 : 0xb2); break;
        case 'i64>f32': b.op(u ? 0xb5 : 0xb4); break;
        case 'i32>f64': b.op(u ? 0xb8 : 0xb7); break;
        case 'i64>f64': b.op(u ? 0xba : 0xb9); break;
        case 'f64>f32': b.op(0xb6); break;
        case 'f32>f64': b.op(0xbb); break;
        default: cerr(null, 'internal: conversion ' + key);
      }
    }
    if (to.k === 'int' && to.size < 4) {
      // narrow
      if (from.k === 'int' && from.size <= to.size && !!from.unsigned === !!to.unsigned && !from.bool) return;
      if (from.k === 'int' && from.bool) return;
      if (to.size === 1) { if (to.unsigned) { b.i32(255); b.op(0x71); } else b.op(0xc0); }
      else { if (to.unsigned) { b.i32(65535); b.op(0x71); } else b.op(0xc1); }
    }
  }
  narrow(ty) {
    const b = this.b;
    if (ty.k !== 'int') return;
    if (ty.bool) { b.i32(0); b.op(0x47); return; }
    if (ty.size === 1) { if (ty.unsigned) { b.i32(255); b.op(0x71); } else b.op(0xc0); }
    else if (ty.size === 2) { if (ty.unsigned) { b.i32(65535); b.op(0x71); } else b.op(0xc1); }
  }
  constOf(ty, v) {
    const b = this.b, t = wty(ty);
    if (t === 'i32') b.i32(Number(BigInt.asIntN(32, BigInt(v))));
    else if (t === 'i64') b.i64(BigInt(v));
    else if (t === 'f32') b.f32(Number(v));
    else b.f64(Number(v));
  }
  arith(op, ct) {
    const b = this.b, t = wty(ct), u = ct.k === 'int' && ct.unsigned, f = ct.k === 'float';
    const name = { '+': 'add', '-': 'sub', '*': 'mul', '/': u ? 'div_u' : 'div_s', '%': u ? 'rem_u' : 'rem_s', '&': 'and', '|': 'or', '^': 'xor', '<<': 'shl', '>>': u ? 'shr_u' : 'shr_s' }[op];
    if (f && !['add', 'sub', 'mul', 'div_s', 'div_u'].includes(name)) cerr(null, 'internal: float op ' + op);
    b.op(OPS[name][t]);
  }
  gen(e, want = true) {
    const b = this.b;
    switch (e.k) {
      case 'num': if (want) this.constOf(e.ty, e.v); return;
      case 'str': if (want) b.i32(this.addrOfString(e)); return;
      case 'id': {
        const s = e.sym;
        if (s.kind === 'func') { if (want) b.i32(this.tableSlot(s)); return; }
        if (!want) return;
        if (s.kind === 'local' && !s.mem) { b.lget(s.widx); return; }
        if (isAgg(s.ty)) { this.genAddrValue(e); return; }
        const off = this.genAddr(e); this.emitLoad(s.ty, off); return;
      }
      case 'decay': if (want) this.genAddrValue(e.a); else this.gen(e.a, false); return;
      case 'faddr': {
        if (e.a.k === 'id') { if (want) b.i32(this.tableSlot(e.a.sym)); return; }
        if (e.a.k === 'deref') { this.gen(e.a.a, want); return; }
        this.gen(e.a, want); return;
      }
      case 'addr': {
        if (e.a.k === 'id' && e.a.sym.kind === 'func') { if (want) b.i32(this.tableSlot(e.a.sym)); return; }
        this.genAddrValue(e.a); if (!want) b.op(0x1a); return;
      }
      case 'deref': case 'member': {
        if (isAgg(e.ty)) { this.genAddrValue(e); if (!want) b.op(0x1a); return; }
        const off = this.genAddr(e); this.emitLoad(e.ty, off); if (!want) b.op(0x1a); return;
      }
      case 'padd': {
        this.gen(e.a, true);
        if (e.b.k === 'num') {
          const k = Number(BigInt.asIntN(32, BigInt(e.b.v) * BigInt(e.step)));
          if (k !== 0) { b.i32(k); b.op(e.sign > 0 ? 0x6a : 0x6b); }
        } else {
          this.gen(e.b, true); if (wty(e.b.ty) === 'i64') b.op(0xa7);
          if (e.step !== 1) {
            const sh = Math.log2(e.step);
            if (Number.isInteger(sh)) { b.i32(sh); b.op(0x74); } else { b.i32(e.step); b.op(0x6c); }
          }
          b.op(e.sign > 0 ? 0x6a : 0x6b);
        }
        if (!want) b.op(0x1a); return;
      }
      case 'pdiff': {
        this.gen(e.a, true); this.gen(e.b, true); b.op(0x6b);
        if (e.step !== 1) { b.i32(e.step); b.op(0x6d); }
        if (!want) b.op(0x1a); return;
      }
      case 'bin': {
        this.gen(e.a, true); this.gen(e.b, true);
        if ((e.op === '<<' || e.op === '>>')) { const bt = wty(e.b.ty), at = wty(e.ty); if (bt !== at) { if (at === 'i64') b.op(0xad); else b.op(0xa7); } }
        this.arith(e.op, e.ct);
        if (!want) b.op(0x1a); return;
      }
      case 'cmp': {
        this.gen(e.a, true); this.gen(e.b, true);
        const t = wty(e.ct), u = e.ct.k === 'ptr' || (e.ct.k === 'int' && e.ct.unsigned);
        const nm = { '==': 'eq', '!=': 'ne', '<': u ? 'lt_u' : 'lt_s', '>': u ? 'gt_u' : 'gt_s', '<=': u ? 'le_u' : 'le_s', '>=': u ? 'ge_u' : 'ge_s' }[e.op];
        b.op(OPS[nm][t]);
        if (!want) b.op(0x1a); return;
      }
      case 'logic': {
        this.genCond(e.a);
        if (e.op === '&&') { b.open('if', 0x7f); this.genBool(e.b); b.els(); b.i32(0); b.end(); }
        else { b.open('if', 0x7f); b.i32(1); b.els(); this.genBool(e.b); b.end(); }
        if (!want) b.op(0x1a); return;
      }
      case 'not': this.genCond(e.a); b.op(0x45); if (!want) b.op(0x1a); return;
      case 'neg': {
        const t = wty(e.ty);
        if (t === 'i32') { b.i32(0); this.gen(e.a, true); b.op(0x6b); }
        else if (t === 'i64') { b.i64(0); this.gen(e.a, true); b.op(0x7d); }
        else { this.gen(e.a, true); b.op(t === 'f32' ? 0x8c : 0x9a); }
        if (!want) b.op(0x1a); return;
      }
      case 'bnot': {
        this.gen(e.a, true);
        if (wty(e.ty) === 'i64') { b.i64(-1); b.op(0x85); } else { b.i32(-1); b.op(0x73); }
        if (!want) b.op(0x1a); return;
      }
      case 'cond': {
        this.genCond(e.c);
        const t = e.ty.k === 'void' ? null : (isAgg(e.ty) ? 'i32' : wty(e.ty));
        if (!want || !t) { b.open('if'); this.gen(e.a, false); b.els(); this.gen(e.b, false); b.end(); if (want && t) cerr(e.tok, 'internal'); return; }
        b.open('if', WT[t]);
        if (isAgg(e.ty)) { this.genAddrValue(e.a); b.els(); this.genAddrValue(e.b); }
        else { this.gen(e.a, true); b.els(); this.gen(e.b, true); }
        b.end(); return;
      }
      case 'comma': this.gen(e.a, false); this.gen(e.b, want); return;
      case 'cast': {
        if (e.ty.k === 'void') { this.gen(e.a, false); return; }
        if (!want) { this.gen(e.a, false); return; }
        if (isAgg(e.a.ty)) cerr(e.tok, 'cannot convert ' + typeStr(e.a.ty));
        this.gen(e.a, true); this.cvt(e.a.ty, e.ty); return;
      }
      case 'assign': return this.genAssign(e, want);
      case 'incdec': return this.genIncDec(e, want);
      case 'call': return this.genCall(e, want);
      case 'vaarg': {
        // ap: local or memory lvalue holding pointer
        const ap = e.ap;
        const tmp = this.temp('i32');
        this.gen(ap, true); b.ltee(tmp);
        b.i32(8); b.op(0x6a);
        this.storeTo(ap, () => {});
        b.lget(tmp);
        const t = e.ty;
        if (t.k === 'float' && t.size === 4) { b.mem(0x2b, 3, 0); b.op(0xb6); }
        else if (t.k === 'struct') cerr(e.tok, 'va_arg cannot read a struct');
        else this.emitLoad(t, 0);
        if (!want) b.op(0x1a); return;
      }
    }
    cerr(e.tok, 'internal: cannot generate ' + e.k);
  }
  storeTo(lv, _) {
    // value on stack -> store into lvalue lv (simple: id local or memory)
    const b = this.b;
    if (lv.k === 'id' && lv.sym.kind === 'local' && !lv.sym.mem) { b.lset(lv.sym.widx); return; }
    const t = this.temp(wty(lv.ty)); b.lset(t);
    const off = this.genAddr(lv); b.lget(t); this.emitStore(lv.ty, off);
  }
  genAssign(e, want) {
    const b = this.b, a = e.a, ty = a.ty;
    const isLocal = a.k === 'id' && a.sym.kind === 'local' && !a.sym.mem;
    if (e.op === '=') {
      if (ty.k === 'struct') {
        const d = this.temp('i32');
        this.genAddrValue(a); b.ltee(d); this.genAddrValue(e.b); b.i32(ty.size); b.op(0xfc, 10, 0, 0);
        if (want) b.lget(d);
        return;
      }
      if (isLocal) { this.gen(e.b, true); if (want) b.ltee(a.sym.widx); else b.lset(a.sym.widx); return; }
      const off = this.genAddr(a);
      this.gen(e.b, true);
      let tv = -1; if (want) { tv = this.temp(wty(ty)); b.ltee(tv); }
      this.emitStore(ty, off);
      if (want) b.lget(tv);
      return;
    }
    const bop = e.op.slice(0, -1);
    const combine = () => {
      if (e.ptrStep !== undefined) {
        this.gen(e.b, true);
        if (e.ptrStep !== 1) { b.i32(e.ptrStep); b.op(0x6c); }
        b.op(bop === '+' ? 0x6a : 0x6b);
        return;
      }
      this.cvt(ty, e.ct);
      this.gen(e.b, true);
      if (bop === '<<' || bop === '>>') { const bt = wty(e.b.ty), at = wty(e.ct); if (bt !== at) { if (at === 'i64') b.op(0xad); else b.op(0xa7); } }
      this.arith(bop, e.ct);
      this.cvt(e.ct, ty);
    };
    if (isLocal) {
      b.lget(a.sym.widx); combine();
      if (want) b.ltee(a.sym.widx); else b.lset(a.sym.widx);
      return;
    }
    const ta = this.temp('i32');
    const off = this.genAddr(a); b.ltee(ta); b.lget(ta);
    this.emitLoad(ty, off);
    combine();
    let tv = -1; if (want) { tv = this.temp(wty(ty)); b.ltee(tv); }
    this.emitStore(ty, off);
    if (want) b.lget(tv);
  }
  genIncDec(e, want) {
    const b = this.b, a = e.a, ty = a.ty, t = wty(ty);
    const isLocal = a.k === 'id' && a.sym.kind === 'local' && !a.sym.mem;
    const addDelta = () => {
      if (ty.k === 'ptr') { b.i32(e.step); b.op(e.delta > 0 ? 0x6a : 0x6b); }
      else if (t === 'i32') { b.i32(1); b.op(e.delta > 0 ? 0x6a : 0x6b); this.narrow(ty); }
      else if (t === 'i64') { b.i64(1); b.op(e.delta > 0 ? 0x7c : 0x7d); }
      else if (t === 'f32') { b.f32(1); b.op(e.delta > 0 ? 0x92 : 0x93); }
      else { b.f64(1); b.op(e.delta > 0 ? 0xa0 : 0xa1); }
    };
    if (isLocal) {
      const w = a.sym.widx;
      if (e.post && want) { b.lget(w); b.lget(w); addDelta(); b.lset(w); return; }
      b.lget(w); addDelta(); if (want) b.ltee(w); else b.lset(w); return;
    }
    const ta = this.temp('i32');
    const off = this.genAddr(a); b.ltee(ta); b.lget(ta);
    this.emitLoad(ty, off);
    let tv = -1;
    if (want && e.post) { tv = this.temp(t); b.ltee(tv); }
    addDelta();
    if (want && !e.post) { tv = this.temp(t); b.ltee(tv); }
    this.emitStore(ty, off);
    if (want) b.lget(tv);
  }
  genCall(e, want) {
    const b = this.b;
    const sym = e.sym, fty = e.fty;
    if (sym && !sym.fn && INLINE_BUILTINS.has(sym.name)) return this.genInlineBuiltin(e, want);
    let retTmp = -1;
    if (fty.ret.k === 'struct') {
      const a = Math.max(fty.ret.align, 4); this.frame = (this.frame + a - 1) & ~(a - 1);
      retTmp = this.frame; this.frame += fty.ret.size;
      b.lget(this.fp); b.i32(retTmp); b.op(0x6a);
    }
    const np = fty.unspecified ? e.args.length : fty.params.length;
    for (let i = 0; i < np && i < e.args.length; i++) {
      const a = e.args[i];
      if (a.ty.k === 'struct') this.genAddrValue(a); else this.gen(a, true);
    }
    const extra = fty.variadic ? e.args.slice(np) : [];
    let area = 0;
    if (fty.variadic) {
      area = Math.max(8, extra.length * 8);
      b.gget(this.G_SP); b.i32(area); b.op(0x6b); b.gset(this.G_SP);
      extra.forEach((a, i) => {
        b.gget(this.G_SP); this.gen(a, true);
        const t = wty(a.ty);
        if (t === 'i64') b.mem(0x37, 3, i * 8); else if (t === 'f64') b.mem(0x39, 3, i * 8); else if (t === 'f32') { b.op(0xbb); b.mem(0x39, 3, i * 8); } else b.mem(0x36, 2, i * 8);
      });
      b.gget(this.G_SP);
    }
    if (sym) {
      b.call(this.funcIndex(sym));
    } else {
      this.gen(e.f, true);
      const sig = this.sigOf(fty);
      b.op(0x11); b.u(this.typeIndex(sig.params, sig.results)); b.op(0x00);
    }
    if (fty.variadic) { b.gget(this.G_SP); b.i32(area); b.op(0x6a); b.gset(this.G_SP); }
    if (!want && fty.ret.k !== 'void') b.op(0x1a);
    else if (want && fty.ret.k === 'void') cerr(e.tok, 'this function returns void, so it has no value to use');
  }
  genInlineBuiltin(e, want) {
    const b = this.b, n = e.sym.name, A = e.args;
    const g = (i) => this.gen(A[i], true);
    switch (n) {
      case 'memcpy': case 'memmove': {
        const d = this.temp('i32');
        g(0); b.ltee(d); g(1); g(2); b.op(0xfc, 10, 0, 0); if (want) b.lget(d); return;
      }
      case 'memset': {
        const d = this.temp('i32');
        g(0); b.ltee(d); g(1); g(2); b.op(0xfc, 11, 0); if (want) b.lget(d); return;
      }
      case '__va_ptr': if (this.vaPtr < 0) cerr(e.tok, 'va_start can only be used inside a function with ... parameters'); if (want) b.lget(this.vaPtr); return;
      case 'abs': {
        const t = this.temp('i32'); g(0); b.lset(t); b.i32(0); b.lget(t); b.op(0x6b); b.lget(t); b.i32(0); b.op(0x48); b.op(0x1b); if (!want) b.op(0x1a); return;
      }
    }
    const f32 = n.endsWith('f') && !['sqrt', 'fabs', 'floor', 'ceil', 'trunc', 'round', 'fmin', 'fmax', 'copysign'].includes(n);
    const base = f32 ? n.slice(0, -1) : n;
    const unary = { sqrt: [0x91, 0x9f], fabs: [0x8b, 0x99], floor: [0x8e, 0x9c], ceil: [0x8d, 0x9b], trunc: [0x8f, 0x9d] };
    if (unary[base]) { g(0); b.op(unary[base][f32 ? 0 : 1]); if (!want) b.op(0x1a); return; }
    const binary = { fmin: [0x96, 0xa4], fmax: [0x97, 0xa5], copysign: [0x98, 0xa6] };
    if (binary[base]) { g(0); g(1); b.op(binary[base][f32 ? 0 : 1]); if (!want) b.op(0x1a); return; }
    if (base === 'round') {
      // t = trunc(x); if |x-t| >= 0.5 then t + copysign(1,x) else t
      const W = f32 ? 'f32' : 'f64';
      const x = this.temp(W), t = this.temp(W);
      g(0); b.ltee(x); b.op(f32 ? 0x8f : 0x9d); b.ltee(t);
      if (f32) b.f32(1); else b.f64(1);
      b.lget(x); b.op(f32 ? 0x98 : 0xa6);
      b.op(f32 ? 0x92 : 0xa0);
      b.lget(t);
      b.lget(x); b.lget(t); b.op(f32 ? 0x93 : 0xa1); b.op(f32 ? 0x8b : 0x99);
      if (f32) b.f32(0.5); else b.f64(0.5);
      b.op(f32 ? 0x60 : 0x66);
      b.op(0x1b);
      if (!want) b.op(0x1a); return;
    }
    cerr(e.tok, 'internal builtin ' + n);
  }
  // ---------- module
  emitModule() {
    const out = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];
    const section = (id, fill) => { const body = []; fill(body); out.push(id); uleb(body.length, out); for (const x of body) out.push(x); };
    // finalize memory layout
    const stackSize = this.opts.stackSize || (4 << 20);
    const dataEnd = (this.dataEnd + 15) & ~15;
    const stackBase = dataEnd, stackTop = dataEnd + stackSize;
    const heapBase = stackTop;
    const pages = Math.ceil((heapBase + (this.opts.initialHeap || (8 << 20))) / 65536);
    const startIdx = this.imports.length + this.defined.length;
    const allFns = this.bodies.concat([this.startBody]);
    section(1, (s) => {
      uleb(this.types.length, s);
      for (const t of this.types) { s.push(0x60); uleb(t.params.length, s); for (const p of t.params) s.push(WT[p]); uleb(t.results.length, s); for (const r of t.results) s.push(WT[r]); }
    });
    section(2, (s) => {
      uleb(this.imports.length, s);
      for (const im of this.imports) { bytesOfStr('env', s); bytesOfStr(im.name, s); s.push(0x00); uleb(im.type, s); }
    });
    section(3, (s) => { uleb(allFns.length, s); for (const f of allFns) uleb(f.typeIdx, s); });
    section(4, (s) => { uleb(1, s); s.push(0x70, 0x00); uleb(this.table.length, s); });
    section(5, (s) => { uleb(1, s); s.push(0x01); uleb(pages, s); uleb(65536, s); });
    section(6, (s) => {
      const glob = [['i32', stackTop, true], ['i32', 0, true], ['i32', stackBase + 256, false], ['i32', heapBase, false]];
      uleb(glob.length, s);
      for (const [t, v, mut] of glob) { s.push(WT[t], mut ? 1 : 0, 0x41); sleb(v, s); s.push(0x0b); }
    });
    section(7, (s) => {
      const ex = [['memory', 2, 0], ['__start', 0, startIdx], ['__line', 3, this.G_LINE], ['__sp', 3, this.G_SP], ['__heap_base', 3, this.G_HEAP], ['__table', 1, 0]];
      uleb(ex.length, s);
      for (const [n, k, i] of ex) { bytesOfStr(n, s); s.push(k); uleb(i, s); }
    });
    if (this.table.length > 1) section(9, (s) => {
      uleb(1, s); s.push(0x00, 0x41); sleb(1, s); s.push(0x0b);
      uleb(this.table.length - 1, s);
      for (let i = 1; i < this.table.length; i++) uleb(this.funcIndex(this.table[i]), s);
    });
    section(10, (s) => {
      uleb(allFns.length, s);
      for (const f of allFns) {
        const body = [];
        // compress locals
        const runs = [];
        for (const t of f.locals) { if (runs.length && runs[runs.length - 1][1] === t) runs[runs.length - 1][0]++; else runs.push([1, t]); }
        uleb(runs.length, body);
        for (const [n, t] of runs) { uleb(n, body); body.push(WT[t]); }
        for (const x of f.code) body.push(x);
        body.push(0x0b);
        uleb(body.length, s); for (const x of body) s.push(x);
      }
    });
    section(11, (s) => {
      uleb(this.data.length, s);
      for (const d of this.data) { s.push(0x00, 0x41); sleb(d.off, s); s.push(0x0b); uleb(d.bytes.length, s); for (const x of d.bytes) s.push(x); }
    });
    // name section
    const names = [];
    this.imports.forEach((im, i) => names.push([i, im.name]));
    allFns.forEach((f, i) => names.push([this.imports.length + i, f.name]));
    section(0, (s) => {
      bytesOfStr('name', s);
      const sub = []; uleb(names.length, sub); for (const [i, n] of names) { uleb(i, sub); bytesOfStr(n, sub); }
      s.push(1); uleb(sub.length, s); for (const x of sub) s.push(x);
    });
    return { wasm: new Uint8Array(out), heapBase, stackBase, stackTop, dataEnd, pages, fnNames: names.map(x => x[1]) };
  }
}
// ===== BitScribe C compiler: prelude + compile() =====
const PRELUDE_C = `
typedef unsigned int size_t; typedef int ssize_t; typedef int ptrdiff_t; typedef int intptr_t; typedef unsigned int uintptr_t;
typedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t; typedef long long int64_t; typedef unsigned long long uint64_t;
typedef long long intmax_t; typedef unsigned long long uintmax_t;
typedef struct __FILE FILE; typedef char* va_list; typedef long time_t; typedef long clock_t; typedef int wchar_t;
#define NULL ((void*)0)
#define EOF (-1)
#define bool _Bool
#define true 1
#define false 0
#define CHAR_BIT 8
#define SCHAR_MIN (-128)
#define SCHAR_MAX 127
#define UCHAR_MAX 255
#define CHAR_MIN (-128)
#define CHAR_MAX 127
#define SHRT_MIN (-32768)
#define SHRT_MAX 32767
#define USHRT_MAX 65535
#define INT_MIN (-2147483647-1)
#define INT_MAX 2147483647
#define UINT_MAX 4294967295U
#define LONG_MIN (-2147483647L-1)
#define LONG_MAX 2147483647L
#define ULONG_MAX 4294967295UL
#define LLONG_MAX 9223372036854775807LL
#define LLONG_MIN (-9223372036854775807LL-1)
#define ULLONG_MAX 18446744073709551615ULL
#define INT8_MIN (-128)
#define INT8_MAX 127
#define UINT8_MAX 255
#define INT16_MIN (-32768)
#define INT16_MAX 32767
#define UINT16_MAX 65535
#define INT32_MIN (-2147483647-1)
#define INT32_MAX 2147483647
#define UINT32_MAX 4294967295U
#define INT64_MAX 9223372036854775807LL
#define INT64_MIN (-9223372036854775807LL-1)
#define UINT64_MAX 18446744073709551615ULL
#define SIZE_MAX 4294967295U
#define FLT_MAX 3.40282347e+38F
#define FLT_MIN 1.17549435e-38F
#define FLT_EPSILON 1.19209290e-7F
#define DBL_MAX 1.7976931348623157e+308
#define DBL_MIN 2.2250738585072014e-308
#define DBL_EPSILON 2.2204460492503131e-16
#define RAND_MAX 2147483647
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define CLOCKS_PER_SEC 1000000L
#define M_PI 3.14159265358979323846
#define M_E 2.7182818284590452354
#define M_SQRT2 1.41421356237309504880
#define M_LN2 0.69314718055994530942
#define M_LN10 2.30258509299404568402
#define INFINITY 1e39f
#define HUGE_VAL 1e309
#define HUGE_VALF 1e39f
#define NAN (0.0f/0.0f)
#define isnan(x) ((x) != (x))
#define isinf(x) ((x) == INFINITY || (x) == -INFINITY)
#define isfinite(x) (!isnan(x) && !isinf(x))
#define assert(e) ((e) ? (void)0 : __assert_fail(#e, __LINE__))
#define va_start(ap, last) ((ap) = (va_list)__va_ptr())
#define va_end(ap) ((void)0)
#define va_copy(d, s) ((d) = (s))
#define stdin ((FILE*)8)
#define stdout ((FILE*)16)
#define stderr ((FILE*)24)
#define BUFSIZ 8192
#define FILENAME_MAX 4096
#define PRId64 "lld"
#define PRIu64 "llu"
#define PRIx64 "llx"
#define PRId32 "d"
#define PRIu32 "u"
int printf(const char* fmt, ...); int fprintf(FILE* f, const char* fmt, ...); int sprintf(char* buf, const char* fmt, ...);
int snprintf(char* buf, size_t n, const char* fmt, ...); int vprintf(const char* fmt, va_list ap);
int vfprintf(FILE* f, const char* fmt, va_list ap); int vsprintf(char* buf, const char* fmt, va_list ap);
int vsnprintf(char* buf, size_t n, const char* fmt, va_list ap);
int sscanf(const char* s, const char* fmt, ...); int scanf(const char* fmt, ...); int fscanf(FILE* f, const char* fmt, ...);
int puts(const char* s); int putchar(int c); int fputs(const char* s, FILE* f); int fputc(int c, FILE* f); int putc(int c, FILE* f);
int getchar(void); int fgetc(FILE* f); int getc(FILE* f); int ungetc(int c, FILE* f); char* fgets(char* buf, int n, FILE* f);
FILE* fopen(const char* path, const char* mode); int fclose(FILE* f);
size_t fread(void* p, size_t size, size_t n, FILE* f); size_t fwrite(const void* p, size_t size, size_t n, FILE* f);
int fseek(FILE* f, long off, int whence); long ftell(FILE* f); void rewind(FILE* f); int feof(FILE* f); int ferror(FILE* f);
void clearerr(FILE* f); int fflush(FILE* f); int remove(const char* path); int rename(const char* a, const char* b);
FILE* popen(const char* cmd, const char* mode); int pclose(FILE* f); void perror(const char* s);
void* malloc(size_t n); void* calloc(size_t n, size_t size); void* realloc(void* p, size_t n); void free(void* p);
void exit(int code); void abort(void); int abs(int x); long labs(long x); long long llabs(long long x);
int atoi(const char* s); long atol(const char* s); long long atoll(const char* s); double atof(const char* s);
long strtol(const char* s, char** end, int base); unsigned long strtoul(const char* s, char** end, int base);
long long strtoll(const char* s, char** end, int base); unsigned long long strtoull(const char* s, char** end, int base);
double strtod(const char* s, char** end); float strtof(const char* s, char** end);
int rand(void); void srand(unsigned int seed); char* getenv(const char* name); int system(const char* cmd);
void qsort(void* base, size_t n, size_t size, int (*cmp)(const void*, const void*));
void* bsearch(const void* key, const void* base, size_t n, size_t size, int (*cmp)(const void*, const void*));
void* memcpy(void* d, const void* s, size_t n); void* memmove(void* d, const void* s, size_t n); void* memset(void* d, int c, size_t n);
int memcmp(const void* a, const void* b, size_t n); void* memchr(const void* s, int c, size_t n);
size_t strlen(const char* s); size_t strnlen(const char* s, size_t n); char* strcpy(char* d, const char* s);
char* strncpy(char* d, const char* s, size_t n); char* strcat(char* d, const char* s); char* strncat(char* d, const char* s, size_t n);
int strcmp(const char* a, const char* b); int strncmp(const char* a, const char* b, size_t n);
int strcasecmp(const char* a, const char* b); int strncasecmp(const char* a, const char* b, size_t n);
char* strchr(const char* s, int c); char* strrchr(const char* s, int c); char* strstr(const char* h, const char* n);
char* strdup(const char* s); char* strndup(const char* s, size_t n); size_t strspn(const char* s, const char* a);
size_t strcspn(const char* s, const char* r); char* strpbrk(const char* s, const char* a); char* strtok(char* s, const char* d);
char* strerror(int e);
float sqrtf(float x); double sqrt(double x); float fabsf(float x); double fabs(double x); float floorf(float x); double floor(double x);
float ceilf(float x); double ceil(double x); float truncf(float x); double trunc(double x); float roundf(float x); double round(double x);
float fminf(float a, float b); float fmaxf(float a, float b); double fmin(double a, double b); double fmax(double a, double b);
float copysignf(float a, float b); double copysign(double a, double b);
float expf(float x); double exp(double x); float exp2f(float x); double exp2(double x); float logf(float x); double log(double x);
float log2f(float x); double log2(double x); float log10f(float x); double log10(double x); float powf(float a, float b); double pow(double a, double b);
float sinf(float x); double sin(double x); float cosf(float x); double cos(double x); float tanf(float x); double tan(double x);
float asinf(float x); double asin(double x); float acosf(float x); double acos(double x); float atanf(float x); double atan(double x);
float atan2f(float y, float x); double atan2(double y, double x); float sinhf(float x); double sinh(double x);
float coshf(float x); double cosh(double x); float tanhf(float x); double tanh(double x); float fmodf(float a, float b); double fmod(double a, double b);
float hypotf(float a, float b); double hypot(double a, double b); float cbrtf(float x); double cbrt(double x);
double ldexp(double x, int e); float ldexpf(float x, int e); double erf(double x); float erff(float x); long lround(double x); long lroundf(float x);
time_t time(time_t* t); clock_t clock(void); unsigned int sleep(unsigned int s); int usleep(unsigned int us);
void __assert_fail(const char* expr, int line); void* __va_ptr(void); int __live_blocks(void); int __heap_check(void);
int isdigit(int c) { return c >= '0' && c <= '9'; }
int isalpha(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
int isalnum(int c) { return isalpha(c) || isdigit(c); }
int isspace(int c) { return c == ' ' || c == '\\t' || c == '\\n' || c == '\\r' || c == '\\v' || c == '\\f'; }
int isupper(int c) { return c >= 'A' && c <= 'Z'; }
int islower(int c) { return c >= 'a' && c <= 'z'; }
int isxdigit(int c) { return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
int ispunct(int c) { return c > 32 && c < 127 && !isalnum(c); }
int isprint(int c) { return c >= 32 && c < 127; }
int isgraph(int c) { return c > 32 && c < 127; }
int iscntrl(int c) { return (c >= 0 && c < 32) || c == 127; }
int tolower(int c) { return isupper(c) ? c + 32 : c; }
int toupper(int c) { return islower(c) ? c - 32 : c; }
static void __qs_swap(char* a, char* b, size_t n) { while (n--) { char t = *a; *a++ = *b; *b++ = t; } }
void qsort(void* base, size_t n, size_t size, int (*cmp)(const void*, const void*)) {
  char* a = (char*)base;
  while (n > 10) {
    __qs_swap(a, a + (n / 2) * size, size);
    size_t i = 0, j = n;
    for (;;) {
      do i++; while (i < n && cmp(a + i * size, a) < 0);
      do j--; while (cmp(a + j * size, a) > 0);
      if (i >= j) break;
      __qs_swap(a + i * size, a + j * size, size);
    }
    __qs_swap(a, a + j * size, size);
    size_t left = j, right = n - j - 1;
    if (left < right) { qsort(a, left, size, cmp); a += (j + 1) * size; n = right; }
    else { qsort(a + (j + 1) * size, right, size, cmp); n = left; }
  }
  for (size_t i = 1; i < n; i++)
    for (size_t j = i; j > 0 && cmp(a + (j - 1) * size, a + j * size) > 0; j--)
      __qs_swap(a + (j - 1) * size, a + j * size, size);
}
void* bsearch(const void* key, const void* base, size_t n, size_t size, int (*cmp)(const void*, const void*)) {
  const char* a = (const char*)base; size_t lo = 0, hi = n;
  while (lo < hi) { size_t mid = (lo + hi) / 2; int c = cmp(key, a + mid * size); if (c == 0) return (void*)(a + mid * size); if (c < 0) hi = mid; else lo = mid + 1; }
  return NULL;
}
static char* __strtok_save;
char* strtok(char* s, const char* delim) {
  if (!s) s = __strtok_save;
  if (!s) return NULL;
  s += strspn(s, delim);
  if (!*s) { __strtok_save = NULL; return NULL; }
  char* e = s + strcspn(s, delim);
  if (*e) { *e = 0; __strtok_save = e + 1; } else __strtok_save = NULL;
  return s;
}
`;

function compileC(userChunks, opts = {}) {
  const chunks = [{ name: 'C library', code: PRELUDE_C, weak: true, sys: true }].concat(userChunks);
  const warnings = [];
  const t0 = (typeof performance !== 'undefined' ? performance : Date).now();
  try {
    const { tokens } = preprocess(chunks, { warnings, defines: opts.defines });
    for (const t of tokens) if (t.t === 'id' && t.v === 'main' && chunks[t.f] && chunks[t.f].renameMain) t.v = '__user_main';
    const P = new Parser(tokens, chunks, { warnings });
    P.parseUnit();
    const builtins = opts.builtins || (typeof RT_BUILTINS !== 'undefined' ? RT_BUILTINS : new Set());
    const G = new Gen(P, opts, builtins);
    const res = G.build();
    return { ok: true, ...res, warnings: warnings.map(w => fmtDiag(w.tok, w.msg, chunks, 'warning')).filter(w => !w.sys), chunks: chunks.map(c => ({ name: c.name, sys: !!c.sys, hidden: !!c.hidden })), ms: (typeof performance !== 'undefined' ? performance : Date).now() - t0 };
  } catch (e) {
    if (e instanceof CError) return { ok: false, error: fmtDiag(e.tok, e.message, chunks, 'error'), warnings: warnings.map(w => fmtDiag(w.tok, w.msg, chunks, 'warning')).filter(w => !w.sys), chunks: chunks.map(c => ({ name: c.name, sys: !!c.sys, hidden: !!c.hidden })) };
    throw e;
  }
}

function fmtDiag(tok, msg, chunks, kind) {
  const f = tok && tok.f >= 0 ? tok.f : -1;
  const ch = f >= 0 ? chunks[f] : null;
  const line = tok ? tok.l : 0;
  let src = '';
  if (ch && line) { const L = ch.code.split('\n'); src = L[line - 1] || ''; }
  return { kind, msg, file: ch ? ch.name : '', chunk: f, line, col: tok && tok.c !== undefined ? tok.c : -1, src, sys: !!(ch && ch.sys), hidden: !!(ch && ch.hidden) };
}
// ===== BitScribe runtime: the C library, virtual files, virtual web (curl), and the program runner =====
const RT_BUILTINS = new Set(('printf fprintf sprintf snprintf vprintf vfprintf vsprintf vsnprintf sscanf scanf fscanf puts putchar fputs fputc putc ' +
  'getchar fgetc getc ungetc fgets fopen fclose fread fwrite fseek ftell rewind feof ferror clearerr fflush remove rename popen pclose perror ' +
  'malloc calloc realloc free exit abort labs llabs atoi atol atoll atof strtol strtoul strtoll strtoull strtod strtof rand srand getenv system ' +
  'memcmp memchr strlen strnlen strcpy strncpy strcat strncat strcmp strncmp strcasecmp strncasecmp strchr strrchr strstr strdup strndup ' +
  'strspn strcspn strpbrk strerror expf exp exp2f exp2 logf log log2f log2 log10f log10 powf pow sinf sin cosf cos tanf tan asinf asin acosf acos ' +
  'atanf atan atan2f atan2 sinhf sinh coshf cosh tanhf tanh fmodf fmod hypotf hypot cbrtf cbrt ldexp ldexpf erf erff lround lroundf time clock sleep usleep __assert_fail __live_blocks __heap_check').split(/\s+/));

class ExitSignal { constructor(code) { this.code = code; } }
class CFault extends Error { constructor(msg, lineId) { super(msg); this.lineId = lineId; } }

// ---------------- number formatting (exact, like glibc) ----------------
const _f64 = new Float64Array(1), _u32 = new Uint32Array(_f64.buffer);
function decompose(v) { // v >= 0 finite -> [mant BigInt, exp]
  _f64[0] = v;
  const lo = _u32[0], hi = _u32[1];
  const e = (hi >>> 20) & 0x7ff;
  let mant = (BigInt(hi & 0xfffff) << 32n) | BigInt(lo);
  if (e === 0) return [mant, -1074];
  return [mant | (1n << 52n), e - 1075];
}
function ratOf(v) { const [m, e] = decompose(v); return e >= 0 ? [m << BigInt(e), 1n] : [m, 1n << BigInt(-e)]; }
function roundDiv(n, d) { let q = n / d; const r = n % d; const t = 2n * r; if (t > d || (t === d && (q & 1n) === 1n)) q += 1n; return q; }
function fmtFixed(v, prec) {
  const [n, d] = ratOf(v);
  const q = roundDiv(n * (10n ** BigInt(prec)), d);
  let s = q.toString();
  if (prec > 0) { s = s.padStart(prec + 1, '0'); s = s.slice(0, s.length - prec) + '.' + s.slice(s.length - prec); }
  return s;
}
function fmtExp(v, prec) { // returns [digits string "d.ddd", exp]
  if (v === 0) return [prec > 0 ? '0.' + '0'.repeat(prec) : '0', 0];
  const [n, d] = ratOf(v);
  let X = Math.floor(Math.log10(v));
  const pow10 = (k) => 10n ** BigInt(Math.abs(k));
  const ge = (k) => k >= 0 ? n >= d * pow10(k) : n * pow10(k) >= d; // v >= 10^k
  while (!ge(X)) X--;
  while (ge(X + 1)) X++;
  const sh = prec - X;
  let q = sh >= 0 ? roundDiv(n * pow10(sh), d) : roundDiv(n, d * pow10(sh));
  if (q >= 10n ** BigInt(prec + 1)) { X++; const sh2 = prec - X; q = sh2 >= 0 ? roundDiv(n * pow10(sh2), d) : roundDiv(n, d * pow10(sh2)); }
  const s = q.toString();
  return [prec > 0 ? s[0] + '.' + s.slice(1) : s, X];
}
function expStr(X, upper) { return (upper ? 'E' : 'e') + (X < 0 ? '-' : '+') + String(Math.abs(X)).padStart(2, '0'); }
function fmtFloat(v, conv, prec, flags) {
  const upper = conv === conv.toUpperCase();
  const neg = v < 0 || (v === 0 && 1 / v < 0);
  let a = Math.abs(v), body;
  if (!isFinite(a)) body = isNaN(a) ? 'nan' : 'inf';
  else {
    const c = conv.toLowerCase();
    if (prec < 0) prec = 6;
    if (c === 'f') body = fmtFixed(a, prec);
    else if (c === 'e') { const [m, X] = fmtExp(a, prec); body = m + expStr(X, false); }
    else if (c === 'g' || c === 'a') {
      let P = prec === 0 ? 1 : prec;
      const X = a === 0 ? 0 : fmtExp(a, P - 1)[1];
      if (P > X && X >= -4) body = fmtFixed(a, P - 1 - X); else { const [m, X2] = fmtExp(a, P - 1); body = m + expStr(X2, false); }
      if (!flags.includes('#')) {
        let [mm, ee] = body.split('e');
        if (mm.includes('.')) { mm = mm.replace(/0+$/, ''); if (mm.endsWith('.')) mm = mm.slice(0, -1); }
        body = ee !== undefined ? mm + 'e' + ee : mm;
      }
    }
    if (flags.includes('#') && !body.includes('.') && c !== 'g') body = body.replace(/^(\d+)/, '$1.');
  }
  if (upper) body = body.toUpperCase();
  const sign = neg ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : '';
  return [sign, body];
}

// ---------------- the runner ----------------
function runC(comp, env) {
  // env: {argv, files: Map(path -> {data:Uint8Array,size}|{file:File,size}), onOut(text,isErr), web(url, headers) -> {status, body:Uint8Array}, safe, vars, stdin}
  const enc = new TextEncoder();
  const decOut = new TextDecoder('utf-8'), decErr = new TextDecoder('utf-8');
  const files = env.files || new Map();
  let memory = null, u8 = null, dv = null, buf = null;
  const refresh = () => { if (buf !== memory.buffer) { buf = memory.buffer; u8 = new Uint8Array(buf); dv = new DataView(buf); } };
  const safe = env.safe !== false;
  // ---- stdout buffering
  let outBytes = [], errBytes = [], lastFlush = Date.now(), totalOut = 0;
  const maxOut = env.maxOut || 50e6;
  const flush = () => {
    if (outBytes.length) { const t = decOut.decode(new Uint8Array(outBytes), { stream: true }); outBytes = []; env.onOut && env.onOut(t, false); }
    if (errBytes.length) { const t = decErr.decode(new Uint8Array(errBytes), { stream: true }); errBytes = []; env.onOut && env.onOut(t, true); }
    lastFlush = Date.now();
  };
  const writeStd = (bytes, isErr) => {
    totalOut += bytes.length;
    if (totalOut > maxOut) throw new CFault('your program printed more than ' + (maxOut / 1e6) + ' MB of text - is a loop printing forever?', 0);
    const arr = isErr ? errBytes : outBytes;
    for (let i = 0; i < bytes.length; i++) arr.push(bytes[i]);
    if (arr.length > 16384 || Date.now() - lastFlush > 40 || isErr) flush();
  };
  // ---- heap
  let heapTop = 0, heapStart = 0;
  const freeLists = new Map();
  let liveBlocks = 0, liveBytes = 0, peakBytes = 0;
  const MAGIC = 0xA110C8ED, FREED = 0xF4EEF4EE;
  const RED = safe ? 8 : 0;
  const ensure = (end) => {
    if (end <= buf.byteLength) return true;
    const need = Math.ceil((end - buf.byteLength) / 65536);
    const grow = Math.max(need, Math.min(16384, Math.ceil(buf.byteLength / 65536 / 2)));
    try { memory.grow(grow); } catch (e) { try { memory.grow(need); } catch (e2) { return false; } }
    refresh(); return true;
  };
  const malloc = (n) => {
    n = n >>> 0;
    const usz = (Math.max(n, 1) + 7) & ~7;
    const bsz = usz + RED;
    let p = 0;
    const fl = freeLists.get(bsz);
    if (fl && fl.length) p = fl.pop();
    else {
      const base = heapTop;
      if (!ensure(base + 8 + bsz)) return 0;
      p = base + 8; heapTop = base + 8 + bsz;
    }
    dv.setUint32(p - 8, n, true); dv.setUint32(p - 4, MAGIC, true);
    if (safe) { u8.fill(0xCD, p, p + usz); u8.fill(0xFD, p + usz, p + bsz); if (usz > n) u8.fill(0xFD, p + n, p + usz); }
    liveBlocks++; liveBytes += n; if (liveBytes > peakBytes) peakBytes = liveBytes;
    return p;
  };
  const blockOK = (p, who) => {
    if (p < heapStart || p >= heapTop || (p & 7)) throw new CFault(who + '() was given a pointer that malloc never gave out (address ' + hex(p) + ')', 0);
    const m = dv.getUint32(p - 4, true);
    if (m === FREED) throw new CFault(who + '() was called on memory that was already freed (double free)', 0);
    if (m !== MAGIC) throw new CFault(who + '() was given a pointer that is not the start of a malloc block (address ' + hex(p) + ')', 0);
    const n = dv.getUint32(p - 8, true);
    if (safe) {
      const usz = (Math.max(n, 1) + 7) & ~7;
      for (let i = p + n; i < p + usz + RED; i++) if (u8[i] !== 0xFD) throw new CFault('heap overflow: your program wrote past the end of a malloc block of ' + n + ' bytes (found at ' + who + '). Check your loop limits and array sizes.', 0);
    }
    return n;
  };
  const free = (p) => {
    if (!p) return;
    const n = blockOK(p, 'free');
    const usz = (Math.max(n, 1) + 7) & ~7;
    dv.setUint32(p - 4, FREED, true);
    const bsz = usz + RED;
    let fl = freeLists.get(bsz); if (!fl) { fl = []; freeLists.set(bsz, fl); } fl.push(p);
    liveBlocks--; liveBytes -= n;
  };
  const hex = (v) => '0x' + (v >>> 0).toString(16).padStart(8, '0');
  // walks every heap block and checks the red zones after live blocks (finds writes past the end of malloc'd arrays)
  const heapCheck = () => {
    if (!safe) return 0;
    let p = heapStart + 8;
    while (p < heapTop) {
      const n = dv.getUint32(p - 8, true), m = dv.getUint32(p - 4, true);
      if (m !== MAGIC && m !== FREED) throw new CFault('heap overflow: your program wrote past the end of a malloc block and damaged the next block. Check your loop limits and array sizes.', 0);
      const usz = (Math.max(n, 1) + 7) & ~7;
      if (m === MAGIC) for (let i = p + n; i < p + usz + RED; i++) if (u8[i] !== 0xFD) throw new CFault('heap overflow: your program wrote past the end of an array of ' + n + ' bytes made with malloc. Check your loop limits (< or <=?) and array sizes.', 0);
      p += usz + RED + 8;
    }
    return 1;
  };
  // ---- strings
  const cstrLen = (p) => { let e = p; while (u8[e] !== 0) { e++; if (e >= u8.length) throw new CFault('a string never ends (no 0 byte at the end)', 0); } return e - p; };
  const cbytes = (p) => u8.subarray(p, p + cstrLen(p));
  const cstr = (p) => { if (!p) throw new CFault('a NULL pointer was used as a string', 0); return new TextDecoder().decode(cbytes(p)); };
  const latin = (p) => { const b = cbytes(p); let s = ''; for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return s; };
  const putStr = (p, str, max) => { const b = enc.encode(str); const n = Math.min(b.length, max === undefined ? b.length : max - 1); u8.set(b.subarray(0, n), p); u8[p + n] = 0; return b.length; };
  const allocStr = (str) => { const b = enc.encode(str); const p = malloc(b.length + 1); u8.set(b, p); u8[p + b.length] = 0; liveBlocks--; liveBytes -= b.length + 1; return p; };
  // ---- printf
  const format = (fp, ap) => {
    const out = [];
    let p = fp;
    const nextI32 = () => { const v = dv.getInt32(ap, true); ap += 8; return v; };
    const nextI64 = () => { const v = dv.getBigInt64(ap, true); ap += 8; return v; };
    const nextF64 = () => { const v = dv.getFloat64(ap, true); ap += 8; return v; };
    const pushS = (s) => { for (let i = 0; i < s.length; i++) out.push(s.charCodeAt(i) & 255); };
    const pad = (sign, body, flags, width, numeric) => {
      let len = sign.length + body.length;
      if (width > len) {
        if (flags.includes('-')) { pushS(sign); pushS(body); pushS(' '.repeat(width - len)); return; }
        if (flags.includes('0') && numeric) { pushS(sign); pushS('0'.repeat(width - len)); pushS(body); return; }
        pushS(' '.repeat(width - len)); pushS(sign); pushS(body); return;
      }
      pushS(sign); pushS(body);
    };
    for (;;) {
      const c = u8[p++];
      if (c === 0) break;
      if (c !== 37) { out.push(c); continue; }
      let flags = '';
      while ('-+ #0'.includes(String.fromCharCode(u8[p])) && u8[p]) flags += String.fromCharCode(u8[p++]);
      let width = 0, prec = -1;
      if (u8[p] === 42) { p++; width = nextI32(); if (width < 0) { flags += '-'; width = -width; } }
      else while (u8[p] >= 48 && u8[p] <= 57) width = width * 10 + (u8[p++] - 48);
      if (u8[p] === 46) { p++; prec = 0; if (u8[p] === 42) { p++; prec = nextI32(); } else while (u8[p] >= 48 && u8[p] <= 57) prec = prec * 10 + (u8[p++] - 48); }
      let len = '';
      while ('hlLzjt'.includes(String.fromCharCode(u8[p])) && u8[p]) len += String.fromCharCode(u8[p++]);
      const conv = String.fromCharCode(u8[p++]);
      const wide = len === 'll' || len === 'j' || len === 'L';
      switch (conv) {
        case 'd': case 'i': {
          let v = wide ? nextI64() : BigInt(nextI32());
          if (len === 'h') v = BigInt.asIntN(16, v); if (len === 'hh') v = BigInt.asIntN(8, v);
          const neg = v < 0n; let s = (neg ? -v : v).toString();
          if (prec >= 0) { s = s.padStart(prec, '0'); if (prec === 0 && v === 0n) s = ''; }
          pad(neg ? '-' : flags.includes('+') ? '+' : flags.includes(' ') ? ' ' : '', s, prec >= 0 ? flags.replace('0', '') : flags, width, true);
          break;
        }
        case 'u': case 'x': case 'X': case 'o': {
          let v = wide ? BigInt.asUintN(64, nextI64()) : BigInt(nextI32() >>> 0);
          if (len === 'h') v = BigInt.asUintN(16, v); if (len === 'hh') v = BigInt.asUintN(8, v);
          let s = v.toString(conv === 'u' ? 10 : conv === 'o' ? 8 : 16);
          if (conv === 'X') s = s.toUpperCase();
          if (prec >= 0) { s = s.padStart(prec, '0'); if (prec === 0 && v === 0n) s = ''; }
          let pre = '';
          if (flags.includes('#') && v !== 0n) pre = conv === 'x' ? '0x' : conv === 'X' ? '0X' : conv === 'o' ? '0' : '';
          pad(pre, s, prec >= 0 ? flags.replace('0', '') : flags, width, true);
          break;
        }
        case 'c': pad('', String.fromCharCode(nextI32() & 255), flags, width, false); break;
        case 's': {
          const sp = nextI32();
          let bytes;
          if (!sp) bytes = [...enc.encode('(null)')];
          else { let e = sp; while (u8[e] !== 0 && (prec < 0 || e - sp < prec)) e++; bytes = u8.subarray(sp, e); }
          const n = bytes.length;
          if (width > n && !flags.includes('-')) pushS(' '.repeat(width - n));
          for (let i = 0; i < n; i++) out.push(bytes[i]);
          if (width > n && flags.includes('-')) pushS(' '.repeat(width - n));
          break;
        }
        case 'f': case 'F': case 'e': case 'E': case 'g': case 'G': case 'a': case 'A': {
          const v = nextF64(); const [sign, body] = fmtFloat(v, conv, prec, flags);
          pad(sign, body, isFinite(v) ? flags : flags.replace('0', ''), width, true); break;
        }
        case 'p': { const v = nextI32() >>> 0; pad('', v ? '0x' + v.toString(16) : '(nil)', flags, width, false); break; }
        case '%': out.push(37); break;
        case 'n': { const ptr = nextI32(); dv.setInt32(ptr, out.length, true); break; }
        default: pushS('%' + flags + len + conv);
      }
    }
    return out;
  };
  const toMem = (dst, n, bytes) => { // snprintf semantics
    if (n > 0) { const k = Math.min(bytes.length, n - 1); for (let i = 0; i < k; i++) u8[dst + i] = bytes[i]; u8[dst + k] = 0; }
    return bytes.length;
  };
  // ---- files
  const norm = (path) => {
    let s = path.replace(/\\/g, '/');
    if (!s.startsWith('/')) s = '/' + s;
    const parts = [];
    for (const x of s.split('/')) { if (!x || x === '.') continue; if (x === '..') parts.pop(); else parts.push(x); }
    return '/' + parts.join('/');
  };
  const handles = new Map();
  handles.set(8, { std: 'in', pos: 0, node: { data: env.stdin || new Uint8Array(0), size: (env.stdin || []).length }, r: true });
  handles.set(16, { std: 'out', w: true });
  handles.set(24, { std: 'err', w: true });
  const H = (f, who) => {
    const h = handles.get(f);
    if (!h) throw new CFault(who + '() was given a FILE* that is not open' + (f === 0 ? ' (it is NULL - did fopen fail? always check if fopen returned NULL)' : ''), 0);
    return h;
  };
  const nodeRead = (node, pos, n) => {
    if (node.data) return node.data.subarray(pos, Math.min(node.size, pos + n));
    if (node.file) {
      const end = Math.min(node.size, pos + n);
      if (end <= pos) return new Uint8Array(0);
      const R = new FileReaderSync();
      return new Uint8Array(R.readAsArrayBuffer(node.file.slice(pos, end)));
    }
    return new Uint8Array(0);
  };
  const nodeWrite = (node, pos, bytes) => {
    if (!node.data) throw new CFault('this file is read-only', 0);
    const end = pos + bytes.length;
    if (end > node.data.length) { const nd = new Uint8Array(Math.max(end, node.data.length * 2, 4096)); nd.set(node.data.subarray(0, node.size)); node.data = nd; }
    node.data.set(bytes, pos);
    if (end > node.size) node.size = end;
    node.dirty = true;
  };
  const hRead = (h, n) => {
    if (h.std === 'out' || h.std === 'err' || !h.r) { h.err = true; return new Uint8Array(0); }
    let pre = null;
    if (h.unget !== undefined) { pre = h.unget; h.unget = undefined; n--; }
    const b = nodeRead(h.node, h.pos, Math.max(n, 0)); h.pos += b.length;
    if (b.length < n) h.eof = true;
    if (pre !== null) { const r = new Uint8Array(b.length + 1); r[0] = pre; r.set(b, 1); return r; }
    return b;
  };
  const hWrite = (h, bytes) => {
    if (h.std === 'out') return writeStd(bytes, false);
    if (h.std === 'err') return writeStd(bytes, true);
    if (!h.w) { h.err = true; return; }
    if (h.append) h.pos = h.node.size;
    nodeWrite(h.node, h.pos, bytes); h.pos += bytes.length;
  };
  const fopen = (pp, mp) => {
    const path = norm(cstr(pp)), mode = latin(mp);
    let node = files.get(path);
    const m = mode.replace(/[bt]/g, '');
    if (!['r', 'w', 'a', 'r+', 'w+', 'a+'].includes(m)) throw new CFault('fopen: unknown mode "' + mode + '" (use "r", "w", "a", "rb", "wb"...)', 0);
    if (path.endsWith('/') || path === '/') return 0;
    if (m[0] === 'r' && !node) return 0;
    if (m[0] === 'w') { node = { data: new Uint8Array(1024), size: 0, dirty: true }; files.set(path, node); }
    if (m[0] === 'a' && !node) { node = { data: new Uint8Array(1024), size: 0, dirty: true }; files.set(path, node); }
    const h = { path, node, pos: 0, r: m[0] === 'r' || m.includes('+'), w: m[0] !== 'r' || m.includes('+'), append: m[0] === 'a', eof: false, err: false };
    const fp = malloc(16); liveBlocks--; liveBytes -= 16;
    handles.set(fp, h);
    return fp;
  };
  // ---- the virtual web: popen("curl ...")
  const shellSplit = (cmd) => {
    const args = []; let cur = '', i = 0, q = null, has = false;
    while (i < cmd.length) {
      const c = cmd[i];
      if (q) { if (c === q) { q = null; i++; continue; } if (c === '\\' && q === '"' && i + 1 < cmd.length) { cur += cmd[i + 1]; i += 2; continue; } cur += c; i++; continue; }
      if (c === "'" || c === '"') { q = c; has = true; i++; continue; }
      if (c === '\\' && i + 1 < cmd.length) { cur += cmd[i + 1]; i += 2; has = true; continue; }
      if (c === ' ' || c === '\t' || c === '\n') { if (cur || has) { args.push(cur); cur = ''; has = false; } i++; continue; }
      if (c === '|' || c === ';' || c === '&' || c === '`' || c === '$' || c === '<' || c === '>') {
        if ((c === '>' || c === '<') ) { args.push({ redirect: c, rest: cmd.slice(i) }); return args; }
        throw new CFault('popen: the emulator can only run a single curl command (found "' + c + '" in the command)', 0);
      }
      cur += c; i++; has = true;
    }
    if (q) throw new CFault('popen: a quote in the command is never closed', 0);
    if (cur || has) args.push(cur);
    return args;
  };
  const popen = (cp, mp) => {
    const cmd = cstr(cp);
    const args = shellSplit(cmd).filter(a => typeof a === 'string');
    if (!args.length || args[0] !== 'curl') throw new CFault('popen: the emulator can only run "curl" commands (you asked for "' + (args[0] || '') + '"). On a real computer popen can run any program.', 0);
    let url = null, fail = false; const headers = {};
    for (let i = 1; i < args.length; i++) {
      const a = args[i];
      if (a === '-m' || a === '--max-time' || a === '--connect-timeout' || a === '--retry') { i++; continue; }
      if (a === '-A' || a === '--user-agent') { headers['User-Agent'] = args[++i]; continue; }
      if (a === '-H' || a === '--header') { const h = args[++i] || ''; const k = h.indexOf(':'); if (k > 0) headers[h.slice(0, k).trim()] = h.slice(k + 1).trim(); continue; }
      if (a === '-o' || a === '--output' || a === '-d' || a === '--data') throw new CFault('popen: curl ' + a + ' is not supported in the emulator - read the page from the pipe instead', 0);
      if (a.startsWith('-')) { if (a.includes('f') && !a.startsWith('--')) fail = true; if (a === '--fail') fail = true; continue; }
      url = a;
    }
    if (!url) throw new CFault('popen: curl needs a URL', 0);
    const res = env.web ? env.web(url, headers) : { status: 0, body: new Uint8Array(0) };
    let body = res.body, code = 0;
    if (res.status === 0) { body = new Uint8Array(0); code = 6; }
    else if (res.status >= 400 && fail) { body = new Uint8Array(0); code = 22; }
    const node = { data: body, size: body.length };
    const h = { path: 'pipe:' + url, node, pos: 0, r: true, w: false, pipe: true, code };
    const fp = malloc(16); liveBlocks--; liveBytes -= 16;
    handles.set(fp, h);
    return fp;
  };
  // ---- sscanf (common subset)
  const scanImpl = (src, fp, ap, getRest) => {
    let s = 0, p = fp, count = 0;
    const S = src; // Uint8Array
    const isSp = (c) => c === 32 || (c >= 9 && c <= 13);
    const nextPtr = () => { const v = dv.getInt32(ap, true); ap += 8; return v; };
    for (;;) {
      const c = u8[p];
      if (c === 0) break;
      if (isSp(c)) { while (isSp(u8[p])) p++; while (s < S.length && isSp(S[s])) s++; continue; }
      if (c !== 37) { if (S[s] !== c) break; s++; p++; continue; }
      p++;
      if (u8[p] === 37) { if (S[s] !== 37) break; s++; p++; continue; }
      let skip = false; if (u8[p] === 42) { skip = true; p++; }
      let width = 0; while (u8[p] >= 48 && u8[p] <= 57) width = width * 10 + (u8[p++] - 48);
      let len = ''; while ('hlLzj'.includes(String.fromCharCode(u8[p])) && u8[p]) len += String.fromCharCode(u8[p++]);
      const conv = String.fromCharCode(u8[p++]);
      if (conv !== 'c' && conv !== '[' && conv !== 'n') while (s < S.length && isSp(S[s])) s++;
      const maxw = width || Infinity;
      if (conv === 'n') { if (!skip) dv.setInt32(nextPtr(), s, true); continue; }
      if (s >= S.length) { if (count === 0) count = -1; break; }
      if ('diuxXo'.includes(conv)) {
        let j = s; if ((S[j] === 45 || S[j] === 43) && j - s < maxw) j++;
        const base = conv === 'x' || conv === 'X' ? 16 : conv === 'o' ? 8 : 10;
        if (base === 16 && S[j] === 48 && (S[j + 1] | 32) === 120) j += 2;
        const st = j;
        while (j < S.length && j - s < maxw) { const d = S[j] | 32; const v = d >= 48 && d <= 57 ? d - 48 : d >= 97 && d <= 122 ? d - 87 : 99; if (v >= base) break; j++; }
        if (j === st) break;
        const txt = String.fromCharCode(...S.subarray(s, j));
        let v = base === 10 ? BigInt(txt.replace('+', '')) : BigInt((txt.startsWith('-') ? '-' : '') + (base === 16 ? '0x' : '0o') + txt.replace(/^[+-]?(0x|0X)?/, '')) ;
        s = j;
        if (!skip) { const ptr = nextPtr(); if (len === 'll' || len === 'j') dv.setBigInt64(ptr, BigInt.asIntN(64, v), true); else if (len === 'h') dv.setInt16(ptr, Number(BigInt.asIntN(16, v)), true); else if (len === 'hh') dv.setInt8(ptr, Number(BigInt.asIntN(8, v))); else dv.setInt32(ptr, Number(BigInt.asIntN(32, v)), true); count++; }
        continue;
      }
      if ('feEgGa'.includes(conv)) {
        const txt = String.fromCharCode(...S.subarray(s, Math.min(S.length, s + (width || 400))));
        const m = /^[+-]?(inf(inity)?|nan|(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?)/i.exec(txt);
        if (!m) break;
        s += m[0].length;
        const v = parseFloat(m[0].replace(/^([+-]?)inf(inity)?$/i, '$1Infinity'));
        if (!skip) { const ptr = nextPtr(); if (len === 'l' || len === 'L') dv.setFloat64(ptr, v, true); else dv.setFloat32(ptr, v, true); count++; }
        continue;
      }
      if (conv === 's') {
        const st = s; while (s < S.length && !isSp(S[s]) && s - st < maxw) s++;
        if (!skip) { const ptr = nextPtr(); u8.set(S.subarray(st, s), ptr); u8[ptr + s - st] = 0; count++; }
        continue;
      }
      if (conv === 'c') {
        const n = width || 1; if (s + n > S.length) break;
        if (!skip) { const ptr = nextPtr(); u8.set(S.subarray(s, s + n), ptr); count++; }
        s += n; continue;
      }
      if (conv === '[') {
        let neg = false; if (u8[p] === 94) { neg = true; p++; }
        const set = new Set(); if (u8[p] === 93) { set.add(93); p++; }
        while (u8[p] && u8[p] !== 93) { if (u8[p + 1] === 45 && u8[p + 2] && u8[p + 2] !== 93) { for (let k = u8[p]; k <= u8[p + 2]; k++) set.add(k); p += 3; } else set.add(u8[p++]); }
        p++;
        const st = s; while (s < S.length && (set.has(S[s]) !== neg) && s - st < maxw) s++;
        if (s === st) break;
        if (!skip) { const ptr = nextPtr(); u8.set(S.subarray(st, s), ptr); u8[ptr + s - st] = 0; count++; }
        continue;
      }
      break;
    }
    if (getRest) getRest(s);
    return count;
  };
  // ---- strtol / strtod
  const strtoNum = (sp, endp, base, wide, unsigned) => {
    const S = cbytes(sp); let i = 0;
    while (i < S.length && (S[i] === 32 || (S[i] >= 9 && S[i] <= 13))) i++;
    let neg = false; if (S[i] === 45 || S[i] === 43) { neg = S[i] === 45; i++; }
    if ((base === 0 || base === 16) && S[i] === 48 && (S[i + 1] | 32) === 120) { base = 16; i += 2; }
    else if (base === 0 && S[i] === 48) base = 8;
    else if (base === 0) base = 10;
    const st = i; let v = 0n;
    while (i < S.length) { const d = S[i] | 32; const x = d >= 48 && d <= 57 ? d - 48 : d >= 97 && d <= 122 ? d - 87 : 99; if (x >= base) break; v = v * BigInt(base) + BigInt(x); i++; }
    if (i === st) i = 0;
    if (endp) dv.setUint32(endp, sp + i, true);
    if (neg) v = -v;
    const bits = wide ? 64 : 32;
    if (unsigned) { const max = (1n << BigInt(bits)) - 1n; if (v > max) v = max; return BigInt.asUintN(bits, v); }
    const max = (1n << BigInt(bits - 1)) - 1n, min = -(1n << BigInt(bits - 1));
    if (v > max) v = max; if (v < min) v = min;
    return v;
  };
  const strtodImpl = (sp, endp) => {
    const S = latin(sp);
    const m = /^[ \t\n\r\v\f]*([+-]?(inf(inity)?|nan|(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?))/i.exec(S);
    if (!m) { if (endp) dv.setUint32(endp, sp, true); return 0; }
    if (endp) dv.setUint32(endp, sp + m[0].length, true);
    return parseFloat(m[1].replace(/inf(inity)?/i, 'Infinity'));
  };
  let randState = 1;
  const strcmpImpl = (a, b, n, fold) => {
    for (let i = 0; i < n; i++) {
      let x = u8[a + i], y = u8[b + i];
      if (fold) { if (x >= 65 && x <= 90) x += 32; if (y >= 65 && y <= 90) y += 32; }
      if (x !== y) return x - y;
      if (x === 0) return 0;
    }
    return 0;
  };
  const envStrs = new Map();
  const M = Math, fr = Math.fround;
  const lib = {
    __nullfault: (l) => { throw new CFault('NULL pointer! Your program tried to use memory through a pointer that is NULL (or almost NULL). Check that malloc/fopen worked and that your pointers point somewhere.', l); },
    __stackoverflow: (l) => { throw new CFault('stack overflow: too much recursion, or a local array that is too big (use malloc for big arrays)', l); },
    __noreturn: (l) => { throw new CFault('this function reached its end without a return statement, but it promised to return a value', l); },
    __assert_fail: (e, l) => { flush(); throw new CFault('assert failed: ' + cstr(e), 0, l); },
    printf: (f, ap) => { const b = format(f, ap); writeStd(b, false); return b.length; },
    vprintf: (f, ap) => { const b = format(f, ap); writeStd(b, false); return b.length; },
    fprintf: (fh, f, ap) => { const b = format(f, ap); hWrite(H(fh, 'fprintf'), b); return b.length; },
    vfprintf: (fh, f, ap) => { const b = format(f, ap); hWrite(H(fh, 'vfprintf'), b); return b.length; },
    sprintf: (d, f, ap) => toMem(d, 0x7fffffff, format(f, ap)),
    vsprintf: (d, f, ap) => toMem(d, 0x7fffffff, format(f, ap)),
    snprintf: (d, n, f, ap) => toMem(d, n >>> 0, format(f, ap)),
    vsnprintf: (d, n, f, ap) => toMem(d, n >>> 0, format(f, ap)),
    sscanf: (s, f, ap) => scanImpl(cbytes(s).slice(), f, ap),
    scanf: (f, ap) => { const h = handles.get(8); const all = nodeRead(h.node, h.pos, 1 << 30); return scanImpl(all, f, ap, (k) => { h.pos += k; }); },
    fscanf: (fh, f, ap) => { const h = H(fh, 'fscanf'); const all = nodeRead(h.node, h.pos, 1 << 30); return scanImpl(all, f, ap, (k) => { h.pos += k; }); },
    puts: (s) => { writeStd(cbytes(s), false); writeStd([10], false); return 1; },
    putchar: (c) => { writeStd([c & 255], false); return c & 255; },
    fputs: (s, fh) => { hWrite(H(fh, 'fputs'), cbytes(s)); return 1; },
    fputc: (c, fh) => { hWrite(H(fh, 'fputc'), [c & 255]); return c & 255; },
    putc: (c, fh) => { hWrite(H(fh, 'putc'), [c & 255]); return c & 255; },
    getchar: () => { const b = hRead(handles.get(8), 1); return b.length ? b[0] : -1; },
    fgetc: (fh) => { const b = hRead(H(fh, 'fgetc'), 1); return b.length ? b[0] : -1; },
    getc: (fh) => { const b = hRead(H(fh, 'getc'), 1); return b.length ? b[0] : -1; },
    ungetc: (c, fh) => { const h = H(fh, 'ungetc'); if (c === -1) return -1; h.unget = c & 255; h.eof = false; return c; },
    fgets: (d, n, fh) => {
      const h = H(fh, 'fgets'); if (n <= 0) return 0;
      let k = 0;
      while (k < n - 1) { const b = hRead(h, 1); if (!b.length) break; u8[d + k++] = b[0]; if (b[0] === 10) break; }
      if (k === 0) return 0;
      u8[d + k] = 0; return d;
    },
    fopen, popen,
    fclose: (fh) => { const h = H(fh, 'fclose'); if (h.std) return 0; if (h.pipe) throw new CFault('use pclose() (not fclose) for something opened with popen()', 0); handles.delete(fh); return 0; },
    pclose: (fh) => { const h = H(fh, 'pclose'); if (!h.pipe) throw new CFault('pclose() is only for things opened with popen()', 0); handles.delete(fh); return h.code << 8; },
    fread: (p, size, n, fh) => { const h = H(fh, 'fread'); const want = (size >>> 0) * (n >>> 0); if (!want) return 0; const b = hRead(h, want); u8.set(b, p); return Math.floor(b.length / size); },
    fwrite: (p, size, n, fh) => { const h = H(fh, 'fwrite'); const k = (size >>> 0) * (n >>> 0); hWrite(h, u8.slice(p, p + k)); return n; },
    fseek: (fh, off, wh) => { const h = H(fh, 'fseek'); if (h.std || h.pipe) return -1; const base = wh === 0 ? 0 : wh === 1 ? h.pos : h.node.size; const np = base + off; if (np < 0) return -1; h.pos = np; h.eof = false; h.unget = undefined; return 0; },
    ftell: (fh) => { const h = H(fh, 'ftell'); return h.std ? -1 : h.pos; },
    rewind: (fh) => { const h = H(fh, 'rewind'); h.pos = 0; h.eof = false; h.err = false; },
    feof: (fh) => (H(fh, 'feof').eof ? 1 : 0),
    ferror: (fh) => (H(fh, 'ferror').err ? 1 : 0),
    clearerr: (fh) => { const h = H(fh, 'clearerr'); h.eof = false; h.err = false; },
    fflush: (fh) => { flush(); return 0; },
    remove: (pp) => (files.delete(norm(cstr(pp))) ? 0 : -1),
    rename: (a, b) => { const A = norm(cstr(a)), B = norm(cstr(b)); const n = files.get(A); if (!n) return -1; files.delete(A); files.set(B, n); n.dirty = true; return 0; },
    perror: (s) => { writeStd(enc.encode((s ? cstr(s) + ': ' : '') + 'error\n'), true); },
    malloc: (n) => malloc(n),
    __live_blocks: () => liveBlocks,
    __heap_check: () => heapCheck(),
    calloc: (a, b) => { const n = (a >>> 0) * (b >>> 0); if (n > 0x7fffffff) return 0; const p = malloc(n); if (p) u8.fill(0, p, p + n); return p; },
    realloc: (p, n) => {
      if (!p) return malloc(n);
      if (n === 0) { free(p); return 0; }
      const old = blockOK(p, 'realloc');
      const np = malloc(n); if (!np) return 0;
      u8.copyWithin(np, p, p + Math.min(old, n >>> 0)); free(p); return np;
    },
    free: (p) => free(p),
    exit: (c) => { throw new ExitSignal(c); },
    abort: () => { throw new CFault('abort() was called', 0); },
    labs: (x) => Math.abs(x) | 0, llabs: (x) => (x < 0n ? -x : x),
    atoi: (s) => Number(strtoNum(s, 0, 10, false, false)), atol: (s) => Number(strtoNum(s, 0, 10, false, false)),
    atoll: (s) => strtoNum(s, 0, 10, true, false), atof: (s) => strtodImpl(s, 0),
    strtol: (s, e, b) => Number(strtoNum(s, e, b, false, false)), strtoul: (s, e, b) => Number(BigInt.asIntN(32, strtoNum(s, e, b, false, true))),
    strtoll: (s, e, b) => strtoNum(s, e, b, true, false), strtoull: (s, e, b) => BigInt.asIntN(64, strtoNum(s, e, b, true, true)),
    strtod: (s, e) => strtodImpl(s, e), strtof: (s, e) => fr(strtodImpl(s, e)),
    rand: () => { randState = (Math.imul(randState, 1103515245) + 12345) >>> 0; return (randState >>> 1) & 0x7fffffff; },
    srand: (s) => { randState = s >>> 0; },
    getenv: (n) => { const k = cstr(n); const v = (env.vars || {})[k]; if (v === undefined) return 0; if (!envStrs.has(k)) envStrs.set(k, allocStr(v)); return envStrs.get(k); },
    system: (c) => (c ? -1 : 0),
    memcmp: (a, b, n) => { for (let i = 0; i < n; i++) { const d = u8[a + i] - u8[b + i]; if (d) return d; } return 0; },
    memchr: (s, c, n) => { c &= 255; for (let i = 0; i < n; i++) if (u8[s + i] === c) return s + i; return 0; },
    strlen: (s) => { if (!s) throw new CFault('strlen(NULL): the string pointer is NULL', 0); return cstrLen(s); },
    strnlen: (s, n) => { let i = 0; while (i < n && u8[s + i]) i++; return i; },
    strcpy: (d, s) => { const n = cstrLen(s); u8.copyWithin(d, s, s + n + 1); return d; },
    strncpy: (d, s, n) => { let i = 0; for (; i < n && u8[s + i]; i++) u8[d + i] = u8[s + i]; for (; i < n; i++) u8[d + i] = 0; return d; },
    strcat: (d, s) => { const a = cstrLen(d), n = cstrLen(s); u8.copyWithin(d + a, s, s + n + 1); return d; },
    strncat: (d, s, n) => { const a = cstrLen(d); let i = 0; for (; i < n && u8[s + i]; i++) u8[d + a + i] = u8[s + i]; u8[d + a + i] = 0; return d; },
    strcmp: (a, b) => { if (!a || !b) throw new CFault('strcmp was given a NULL string', 0); return strcmpImpl(a, b, Infinity, false); },
    strncmp: (a, b, n) => strcmpImpl(a, b, n >>> 0, false),
    strcasecmp: (a, b) => strcmpImpl(a, b, Infinity, true), strncasecmp: (a, b, n) => strcmpImpl(a, b, n >>> 0, true),
    strchr: (s, c) => { c &= 255; for (let i = s; ; i++) { if (u8[i] === c) return i; if (!u8[i]) return 0; } },
    strrchr: (s, c) => { c &= 255; let r = 0; for (let i = s; ; i++) { if (u8[i] === c) r = i; if (!u8[i]) return r; } },
    strstr: (h, n) => {
      const nl = cstrLen(n); if (!nl) return h;
      const hl = cstrLen(h);
      outer: for (let i = 0; i + nl <= hl; i++) { for (let j = 0; j < nl; j++) if (u8[h + i + j] !== u8[n + j]) continue outer; return h + i; }
      return 0;
    },
    strdup: (s) => { const n = cstrLen(s); const p = malloc(n + 1); if (!p) return 0; u8.copyWithin(p, s, s + n + 1); return p; },
    strndup: (s, n) => { let k = 0; while (k < n && u8[s + k]) k++; const p = malloc(k + 1); if (!p) return 0; u8.copyWithin(p, s, s + k); u8[p + k] = 0; return p; },
    strspn: (s, a) => { const set = new Set(cbytes(a)); let i = 0; while (u8[s + i] && set.has(u8[s + i])) i++; return i; },
    strcspn: (s, r) => { const set = new Set(cbytes(r)); let i = 0; while (u8[s + i] && !set.has(u8[s + i])) i++; return i; },
    strpbrk: (s, a) => { const set = new Set(cbytes(a)); for (let i = s; u8[i]; i++) if (set.has(u8[i])) return i; return 0; },
    strerror: (e) => { if (!envStrs.has('#err')) envStrs.set('#err', allocStr('error')); return envStrs.get('#err'); },
    expf: (x) => fr(M.exp(x)), exp: M.exp, exp2f: (x) => fr(M.pow(2, x)), exp2: (x) => M.pow(2, x),
    logf: (x) => fr(M.log(x)), log: M.log, log2f: (x) => fr(M.log2(x)), log2: M.log2, log10f: (x) => fr(M.log10(x)), log10: M.log10,
    powf: (a, b) => fr(M.pow(a, b)), pow: M.pow, sinf: (x) => fr(M.sin(x)), sin: M.sin, cosf: (x) => fr(M.cos(x)), cos: M.cos,
    tanf: (x) => fr(M.tan(x)), tan: M.tan, asinf: (x) => fr(M.asin(x)), asin: M.asin, acosf: (x) => fr(M.acos(x)), acos: M.acos,
    atanf: (x) => fr(M.atan(x)), atan: M.atan, atan2f: (y, x) => fr(M.atan2(y, x)), atan2: M.atan2,
    sinhf: (x) => fr(M.sinh(x)), sinh: M.sinh, coshf: (x) => fr(M.cosh(x)), cosh: M.cosh, tanhf: (x) => fr(M.tanh(x)), tanh: M.tanh,
    fmodf: (a, b) => fr(a % b), fmod: (a, b) => a % b, hypotf: (a, b) => fr(M.hypot(a, b)), hypot: M.hypot, cbrtf: (x) => fr(M.cbrt(x)), cbrt: M.cbrt,
    ldexp: (x, e) => x * M.pow(2, e), ldexpf: (x, e) => fr(x * M.pow(2, e)),
    erf: (x) => erfImpl(x), erff: (x) => fr(erfImpl(x)),
    lround: (x) => (x < 0 ? -M.round(-x) : M.round(x)) | 0, lroundf: (x) => (x < 0 ? -M.round(-x) : M.round(x)) | 0,
    time: (t) => { const v = Math.floor(Date.now() / 1000); if (t) dv.setInt32(t, v, true); return v; },
    clock: () => Math.floor(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0) * 1000),
    sleep: () => 0, usleep: () => 0,
  };
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  // ---- instantiate
  const imports = { env: {} };
  const mod = comp.module || new WebAssembly.Module(comp.wasm);
  for (const im of WebAssembly.Module.imports(mod)) {
    const f = lib[im.name];
    if (!f) throw new Error('runtime is missing ' + im.name);
    imports.env[im.name] = f;
  }
  const inst = new WebAssembly.Instance(mod, imports);
  memory = inst.exports.memory; refresh();
  heapStart = heapTop = (inst.exports.__heap_base.value + 15) & ~15;
  // argv
  const argv = env.argv || ['program'];
  const argvPtr = malloc(4 * (argv.length + 1)); liveBlocks--;
  argv.forEach((a, i) => { const p = allocStr(a); dv.setUint32(argvPtr + 4 * i, p, true); });
  dv.setUint32(argvPtr + 4 * argv.length, 0, true);
  liveBlocks = 0; liveBytes = 0; const baseLive = 0;
  let exitCode = 0, fault = null;
  const tStart = Date.now();
  try {
    exitCode = inst.exports.__start(argv.length, argvPtr);
  } catch (e) {
    if (e instanceof ExitSignal) exitCode = e.code;
    else {
      let line = 0;
      try { line = inst.exports.__line.value; } catch (x) {}
      fault = describeFault(e, line);
      exitCode = -1;
    }
  }
  try { flush(); } catch (e) {}
  const stack = fault && fault.raw && fault.raw.stack ? parseWasmStack(fault.raw.stack) : [];
  return { exitCode, fault, stack, ms: Date.now() - tStart, leaks: { blocks: liveBlocks - baseLive, bytes: liveBytes }, peakBytes, files, memPages: buf.byteLength / 65536 };
}

function describeFault(e, line) {
  if (e instanceof CFault) return { msg: e.message, lineId: e.lineId || line, raw: e };
  const m = String(e && e.message || e);
  let msg;
  if (/out of bounds/i.test(m) && /memory/i.test(m)) msg = 'your program read or wrote memory that does not exist (out of bounds). Check array indexes, loop limits and pointer maths.';
  else if (/divi.*zero|by zero/i.test(m)) msg = 'division by zero: a whole number was divided by 0';
  else if (/integer overflow/i.test(m)) msg = 'integer overflow in a division (INT_MIN / -1)';
  else if (/call stack|too much recursion|stack overflow/i.test(m)) msg = 'stack overflow: a function called itself too many times (infinite recursion?)';
  else if (/signature|null function|indirect call|uninitialized element|table index/i.test(m)) msg = 'a function pointer was called, but it is NULL or points to a function of a different type';
  else if (/unreachable/i.test(m)) msg = 'the program reached code that should never run';
  else msg = 'the program crashed: ' + m;
  return { msg, lineId: line, raw: e };
}
function parseWasmStack(st) {
  const names = [];
  for (const ln of String(st).split('\n')) {
    const m = /at ([A-Za-z_][A-Za-z0-9_]*) \(wasm/.exec(ln) || /^([A-Za-z_][A-Za-z0-9_]*)@.*wasm/.exec(ln);
    if (m && !m[1].startsWith('__') && m[1] !== 'Object') names.push(m[1]);
  }
  return names;
}
function erfImpl(x) { // Abramowitz-Stegun 7.1.26 refined with series for small x
  const s = x < 0 ? -1 : 1; x = Math.abs(x);
  if (x < 0.5) { let sum = x, term = x, n = 0; for (n = 1; n < 30; n++) { term *= -x * x / n; sum += term / (2 * n + 1); } return s * 2 / Math.sqrt(Math.PI) * sum; }
  const t = 1 / (1 + 0.5 * x);
  const y = 1 - t * Math.exp(-x * x - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
  return s * y;
}
G.BSCC={compileC, runC, RT_BUILTINS, CError, CFault, ExitSignal};
if (typeof module !== 'undefined') module.exports = G.BSCC;
})(typeof self !== 'undefined' ? self : globalThis);
