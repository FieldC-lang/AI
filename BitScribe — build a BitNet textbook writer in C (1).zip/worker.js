// BitScribe emulator worker: compiles C with the built-in compiler (bscc.js) and runs it as WebAssembly.
if (typeof BSCC === 'undefined') importScripts('bscc.js', 'minweb.js');
let baseFiles = new Map();
let articles = [];
let web = null;

function snapshotFiles(files, filter, onlyDirty) {
  const out = [];
  for (const [path, node] of files) {
    if (baseFiles.has(path) && !node.dirty) continue;
    if (filter && !filter.test(path)) continue;
    if (onlyDirty && !node.dirty) continue;
    if (!node.data) continue;
    out.push([path, node.data.slice(0, node.size)]);
  }
  return out;
}

self.onmessage = (ev) => {
  const m = ev.data;
  if (m.type === 'init') {
    baseFiles = new Map(m.base);
    articles = m.articles || [];
    web = makeOfflineWeb(articles, []);
    self.postMessage({ type: 'ready' });
    return;
  }
  if (m.type !== 'run') return;
  const id = m.id;
  const t0 = performance.now();
  const comp = BSCC.compileC(m.chunks, { safe: m.safe !== false });
  self.postMessage({ type: 'compiled', id, ok: comp.ok, error: comp.error || null, warnings: comp.warnings || [], ms: performance.now() - t0 });
  if (!comp.ok) { self.postMessage({ type: 'done', id, compiled: false }); return; }
  if (m.compileOnly) { self.postMessage({ type: 'done', id, compiled: true }); return; }
  const files = new Map();
  for (const [p, d] of baseFiles) files.set(p, { data: d, size: d.length });
  for (const [p, d] of (m.files || [])) {
    const data = typeof d === 'string' ? new TextEncoder().encode(d) : d;
    files.set(p, { data, size: data.length, dirty: true });
  }
  const runWeb = m.userPages && m.userPages.length ? makeOfflineWeb(articles.concat(m.userPages), []) : web;
  let buf = '', ebuf = '', last = performance.now();
  const snapRe = m.snapshot ? new RegExp(m.snapshot) : null;
  const flush = () => {
    if (buf || ebuf) self.postMessage({ type: 'out', id, text: buf, err: ebuf });
    buf = ''; ebuf = ''; last = performance.now();
  };
  const onOut = (text, isErr) => {
    if (isErr) ebuf += text; else buf += text;
    if (snapRe && !isErr && /@@(status|file|done)/.test(text)) {
      flush();
      const snap = snapshotFiles(files, snapRe, false);
      if (snap.length) self.postMessage({ type: 'files', id, files: snap });
      return;
    }
    if (buf.length + ebuf.length > 8192 || performance.now() - last > 120) flush();
  };
  let res;
  try {
    res = BSCC.runC(comp, { files, web: runWeb, argv: m.argv || ['program'], onOut, maxOut: m.maxOut || 20e6, stdin: m.stdin ? new TextEncoder().encode(m.stdin) : undefined });
  } catch (e) {
    flush();
    self.postMessage({ type: 'done', id, compiled: true, exitCode: -1, fault: { msg: 'the emulator stopped: ' + (e && e.message || e) }, stack: [], files: [] });
    return;
  }
  flush();
  const outFiles = m.returnFiles ? snapshotFiles(files, m.returnFiles === true ? null : new RegExp(m.returnFiles), false) : [];
  self.postMessage({
    type: 'done', id, compiled: true, exitCode: res.exitCode,
    fault: res.fault ? { msg: res.fault.msg, lineId: res.fault.lineId || 0 } : null,
    stack: res.stack || [], ms: res.ms, leaks: res.leaks, peakBytes: res.peakBytes, files: outFiles,
  });
};
