/* Units 4-6. Truths are computed by the emulator at run time; tools/check.cjs verifies every step. */
(function (root) {
var U = root.UNITS = root.UNITS || [];
var ENGINE = root.ENGINE || require('./engine.js');
var asm = root.LESSON_TOOLS.asm, swap = root.LESSON_TOOLS.swap;

// A program that runs one layer of the model on a list of 8 inputs.
function layerRun(x, offset, name) {
  return asm(`
.data
x: .word ${x}
.bss
out: .space 32
.text
    bl load_model
    ldr r0, =x
    ldr r1, =layer_ptr
    ldr r1, [r1${offset ? ', #' + offset : ''}]${' '.repeat(offset ? (offset > 9 ? 4 : 5) : 9)}@ layer ${name}
    ldr r2, =out
    bl bitlinear`);
}
var SQUASH_LOOP = asm(`
.data
x: .word 64, -200, 16, 100
.bss
xq: .space 16
.text
    ldr r4, =x
    ldr r11, =xq
    mov r7, #200          @ the biggest size in x
    mov r1, #127
    mov r2, #0
squash:
    ldr r3, [r4, r2, lsl #2]
    [[1]] r3, r3, r1
    [[2]] r3, r3, r7
    str r3, [r11, r2, lsl #2]
    add r2, r2, #1
    cmp r2, #4
    blt squash`);

U.push({ id: 'u4', title: 'BitLinear', blurb: 'The layer the whole model is built from.', lessons: [
{ id: 'l10', title: 'Squash the inputs', blurb: 'Every input is squeezed into the range -127 to 127.', steps: [
  { t: 'learn', title: 'Find the biggest input',
    text: 'The weights are tiny. BitNet also keeps the **inputs** of each layer small: it squeezes them into the range -127 to 127, which fits in 8 bits.\n\nThe first step is to find the biggest input, ignoring the sign. `movgt r7, r3` keeps a new value only when it beats the best so far.',
    code: asm(`
.data
x: .word 64, -200, 16, 100
.text
    ldr r4, =x
    mov r7, #0            @ biggest so far
    mov r2, #0
top:
    ldr r3, [r4, r2, lsl #2]
    cmp r3, #0
    rsblt r3, r3, #0      @ ignore the sign
    cmp r3, r7
    movgt r7, r3
    add r2, r2, #1
    cmp r2, #4
    blt top`) },
  { t: 'predict', title: 'Scale one input',
    text: 'The biggest size was 200. Each input is multiplied by 127 and divided by 200, so the biggest lands exactly on 127 or -127. `sdiv` divides whole numbers and drops any fraction.',
    code: asm(`
    mov r3, #100
    mov r1, #127
    mul r3, r3, r1
    mov r7, #200
    sdiv r3, r3, r7`),
    ask: 'What does the input 100 become?', options: ['63', '64', '127', '50'], verify: 'reg:r3',
    why: '100 x 127 = 12,700, and 12,700 / 200 = 63.5. The fraction is dropped, leaving 63. That small loss is the price of keeping the numbers small.' },
  { t: 'experiment', title: 'Which comes first?',
    text: 'Version A multiplies, then divides. Version B divides, then multiplies. Run both and compare `r3`.',
    variants: [
      { label: 'Multiply first', code: asm(`
    mov r3, #100
    mov r1, #127
    mov r7, #200
    mul r3, r3, r1
    sdiv r3, r3, r7`) },
      { label: 'Divide first', code: asm(`
    mov r3, #100
    mov r1, #127
    mov r7, #200
    sdiv r3, r3, r7
    mul r3, r3, r1`) } ],
    verify: 'reg:r3',
    ask: 'Why does dividing first give 0?',
    options: ['Whole-number division drops the fraction, so 100 / 200 is already 0', '`sdiv` cannot divide by 200', '`mul` only works on small numbers', 'The register is too small for the answer'], answer: 0,
    why: 'Registers hold whole numbers only. 100 / 200 is 0.5, which becomes 0, and 0 times anything is 0. Multiplying first keeps the detail until the last moment. The whole program follows this rule.' },
  { t: 'fill', title: 'The squash loop',
    text: 'Fill in the two instructions that turn each input into a number from -127 to 127. The result goes into `xq`.',
    code: SQUASH_LOOP,
    chips: ['mul', 'sdiv', 'add', 'sub'], answer: ['mul', 'sdiv'], checks: ['mem:xq'],
    why: 'Multiply by 127, then divide by the biggest size. -200 becomes exactly -127, and the others keep their proportions.' },
  { t: 'inspect', title: 'What squashing costs',
    text: 'Run the finished loop and read the clock.',
    code: SQUASH_LOOP.replace('[[1]]', 'mul').replace('[[2]]', 'sdiv'),
    ask: 'How many ticks did it take to squash four inputs?', options: ['33', '12', '28', '40'], verify: 'clock', unit: 'ticks',
    why: 'Five instructions to set up, then seven per input. Squashing is cheap next to what comes next: the weights.' }
] },
{ id: 'l11', title: 'One whole layer', blurb: 'Squash, add or subtract or skip, then scale back.', unlock: ['bitlinear'], steps: [
  { t: 'learn', title: 'BitLinear in four steps',
    text: '`bitlinear` is the layer the whole model is made of. It takes 8 inputs and makes 8 outputs:\n\n1. find the biggest input\n2. squash the inputs into -127..127\n3. for each output, add, subtract or skip each input, as that output\'s weights say\n4. undo the squash and apply the layer\'s scale\n\nThis runs layer v, whose weights simply pass inputs 0, 1 and 2 along. Compare `x`, `xq` and `out` in the Memory panel.',
    pre: 'thru:bitlinear', show: ['xq'],
    code: layerRun('64, -200, 16, 100, 0, 0, 0, 0', 8, 'v') },
  { t: 'inspect', title: 'Look inside',
    text: 'Run it, then find `xq` in the Memory panel. It holds the inputs after squashing.',
    pre: 'thru:bitlinear', show: ['xq'],
    code: layerRun('64, -200, 16, 100, 0, 0, 0, 0', 8, 'v'),
    ask: 'What did the input -200 become in `xq`?', options: ['-127', '-200', '-128', '127'], verify: 'mem:xq[1]',
    why: '-200 was the biggest in size, so it lands on -127. After step 4 it comes out as -200 again. The 64 comes out as 62: squashing to 8 bits loses a little detail, and the model is trained to cope with that.' },
  { t: 'predict', title: 'The scale byte',
    text: 'Layer q starts with the scale byte 16. Scales are counted in eighths, so 16 means "times 2". Its first output adds input 0 and skips the rest. The only input is 64.',
    pre: 'thru:bitlinear', show: ['xq'],
    code: layerRun('64, 0, 0, 0, 0, 0, 0, 0', 0, 'q'),
    ask: 'What is `out[0]`?', options: ['128', '64', '16', '127'], verify: 'mem:out[0]',
    why: 'The weights can only say add, subtract or skip. The scale byte lets a whole layer be louder or quieter. Here it doubles 64 to 128. One byte of scale per layer is all the extra precision BitNet keeps.' },
  { t: 'inspect', title: 'Where does the time go?',
    text: 'Run the layer to the end. A new panel shows how many ticks were spent inside each function.',
    pre: 'thru:bitlinear',
    code: layerRun('64, -200, 16, 100, 0, 0, 0, 0', 8, 'v'),
    ask: 'Which function used the most ticks?', options: ['bitlinear', 'weight_at', 'load_model', '(top level)'], verify: 'hot',
    why: 'The inner loop of `bitlinear` runs 64 times, once per weight, and each trip also calls `weight_at`. Together they are nearly all of the cost. Finding, squashing and scaling are small change.' },
  { t: 'inspect', title: 'The cost of one layer',
    text: 'Run it once more and read the clock.',
    pre: 'thru:bitlinear',
    code: layerRun('64, -200, 16, 100, 0, 0, 0, 0', 8, 'v'),
    ask: 'How many ticks did the whole program take?', options: ['1559', '64', '448', '12289'], verify: 'clock', unit: 'ticks',
    why: 'Each of the 64 weights costs 20 ticks: 11 in the loop and 9 inside `weight_at`. That is 1,280 of the total. The model runs seven of these layers for every word, so nearly all of its time is spent right here.' }
] } ] });

U.push({ id: 'u5', title: 'Words into numbers', blurb: 'Text becomes word numbers, and word numbers become lists.', lessons: [
{ id: 'l12', title: 'The tokenizer', blurb: 'Matching typed letters against the words the model knows.', unlock: ['words', 'find_word', 'encode'], steps: [
  { t: 'learn', title: 'Words are bytes too',
    text: 'A model cannot read. Text has to be turned into word numbers first: `red` is 0, `blue` is 1, `end` is 2. That job is called **tokenizing**.\n\nLetters are stored as numbers, one byte each. `.asciz "red"` stores the three letters and then a 0 to mark the end. The table `words` holds the address of each word. This loads the first letter of word 1.',
    pre: 'thru:words', show: ['word_red', 'word_blue', 'word_end', 'words'],
    code: asm(`
    ldr r0, =words
    ldr r1, [r0, #4]      @ address of word 1
    ldrb r2, [r1]         @ its first letter`) },
  { t: 'predict', title: 'Look a word up',
    text: '`find_word` gets the address of some letters in `r0` and how many there are in `r1`. It compares them with each known word, letter by letter, and returns the word number.',
    pre: 'thru:find_word',
    code: asm(`
.data
text: .ascii "blue"
.text
    ldr r0, =text
    mov r1, #4
    bl find_word`),
    ask: 'What comes back in `r0`?', options: ['1', '0', '2', '4'], verify: 'reg:r0',
    why: '`red` fails at the first letter. `blue` matches all four letters, so its number, 1, is returned.' },
  { t: 'predict', title: 'Half a word',
    text: 'Now the text is only the two letters `re`. Both letters match the start of `red`.',
    pre: 'thru:find_word',
    code: asm(`
.data
text: .ascii "re"
.text
    ldr r0, =text
    mov r1, #2
    bl find_word`),
    ask: 'What comes back in `r0`?', options: ['-1', '0', '2', '1'], verify: 'reg:r0',
    why: 'After the letters match, the function checks that the known word **ends** there too, by looking for its 0 byte. `red` still has a `d` left, so it is not a match. -1 means "not a word I know".' },
  { t: 'inspect', title: 'A whole line',
    text: '`encode` walks along a line of text, splits it at the spaces, and looks each word up. The numbers go into `tokens`. This line contains a word the model does not know.',
    pre: 'thru:encode', show: ['tokens'],
    code: asm(`
.data
text: .ascii "red green blue\\n"
.text
    ldr r0, =text
    mov r1, #15           @ length of the text
    bl encode`),
    ask: 'How many words did `encode` find? (It returns the count in `r0`.)', options: ['2', '3', '15', '0'], verify: 'reg:r0',
    why: '`green` is not in the vocabulary, so it is left out. `tokens` now starts 0, 1: red, blue. The real BitNet tokenizer never has this problem because it knows 128,256 word pieces and can spell any word from them.' },
  { t: 'fill', title: 'Finish find_word',
    text: 'Fill in the check that makes sure the known word ends where the typed word ends.',
    pre: 'upto:find_word',
    code: swap(ENGINE.parts.find_word, [['cmp r6, #0\n    moveq r0, r2', 'cmp r6, #[[1]]\n    [[2]] r0, r2']]),
    chips: ['0', '32', 'moveq', 'movne', '1'], answer: ['0', 'moveq'],
    tests: [
      { name: 'find_word("blue")', post: '.data\ntext: .ascii "blue"\n.text\n_start:\n    ldr r0, =text\n    mov r1, #4\n    bl find_word' },
      { name: 'find_word("re")', post: '.data\ntext: .ascii "re"\n.text\n_start:\n    ldr r0, =text\n    mov r1, #2\n    bl find_word' },
      { name: 'find_word("end")', post: '.data\ntext: .ascii "end"\n.text\n_start:\n    ldr r0, =text\n    mov r1, #3\n    bl find_word' } ],
    why: 'Every stored word ends with a 0 byte. If the next byte of the known word is 0, both words ended together, and the word number in `r2` is the answer.' }
] },
{ id: 'l13', title: 'Embedding and RMS norm', blurb: 'A word becomes 8 numbers, kept at a steady size.', unlock: ['isqrt', 'rmsnorm'], steps: [
  { t: 'learn', title: 'A row of numbers for each word',
    text: 'Inside the model a word is a list of 8 numbers called its **embedding**. The word table in the file has one row per word, so turning a word number into its list is just "go to that row and copy it".\n\nRegisters cannot hold fractions, so this program counts in 64ths: **64 stands for 1.0**. `lsl #6` multiplies by 64.',
    pre: 'thru:load_model',
    code: asm(`
.bss
x: .space 32
.text
    bl load_model
    mov r0, #1             @ word 1 is "blue"
    ldr r1, =embed_ptr
    ldr r1, [r1]
    add r1, r1, r0, lsl #3 @ its row: 8 bytes per word
    ldr r4, =x
    mov r2, #0
copy:
    ldrsb r3, [r1, r2]
    lsl r3, r3, #6         @ 1 becomes 64, our "1.0"
    str r3, [r4, r2, lsl #2]
    add r2, r2, #1
    cmp r2, #8
    blt copy`) },
  { t: 'predict', title: 'Counting in 64ths',
    text: 'If 64 stands for 1.0, then 32 stands for 0.5. This adds half of `r0` to itself.',
    code: asm(`
    mov r0, #64           @ 1.0
    add r0, r0, r0, lsr #1`),
    ask: 'What number stands for 1.5?', options: ['96', '65', '128', '66'], verify: 'reg:r0',
    why: '64 + 32 = 96. This is called **fixed point**. The real BitNet uses true fractions for these in-between values; whole numbers are used here so that every instruction stays simple.' },
  { t: 'predict', title: 'A square root from whole numbers',
    text: '`isqrt` finds the biggest whole number whose square still fits in `r0`. It starts with a guess that is far too big and keeps averaging the guess with "number / guess" until it stops shrinking.',
    pre: 'thru:isqrt',
    code: asm(`
    mov r0, #1000
    bl isqrt`),
    ask: 'What comes back in `r0`?', options: ['31', '32', '500', '100'], verify: 'reg:r0',
    why: '31 x 31 = 961 fits. 32 x 32 = 1,024 does not. The guesses went 1000, 500, 251, 127, 67, 40, 32, 31. Each guess lands much closer than the one before.' },
  { t: 'predict', title: 'Keeping numbers a steady size',
    text: 'As lists pass through layers they can grow or shrink. `rmsnorm` measures the **typical size** of a list (square everything, average, square root) and rescales the list so that its typical size is 64. Here every input is 128.',
    pre: 'thru:rmsnorm',
    code: asm(`
.data
x: .word 128, 128, 128, 128, 128, 128, 128, 128
.bss
out: .space 32
.text
    ldr r0, =x
    ldr r1, =out
    bl rmsnorm`),
    ask: 'What is `out[0]`?', options: ['64', '128', '1', '8'], verify: 'mem:out[0]',
    why: 'The typical size was 128, so everything is halved to bring it to 64. If the inputs had all been 10, they would have been stretched up to 64 instead. The model runs this before every block so the numbers never drift.' },
  { t: 'inspect', title: 'One loud number',
    text: 'This is the embedding of `red`: a single 64 and seven zeros. Run `rmsnorm` on it and look at `out`.',
    pre: 'thru:rmsnorm',
    code: asm(`
.data
x: .word 64, 0, 0, 0, 0, 0, 0, 0
.bss
out: .space 32
.text
    ldr r0, =x
    ldr r1, =out
    bl rmsnorm`),
    ask: 'What is `out[0]`?', options: ['186', '64', '8', '512'], verify: 'mem:out[0]',
    why: 'Seven of the eight numbers are 0, so the typical size of the list is small: about 22. To bring that up to 64, the one loud number has to grow to 186.' },
  { t: 'fill', title: 'Build rmsnorm',
    text: 'Fill in the two slides. One divides the sum of squares by 8 to get the average. The other multiplies each input by 64 before the divide.',
    pre: 'upto:rmsnorm',
    code: swap(ENGINE.parts.rmsnorm, [['lsr r0, r0, #3         @ mean = sum / 8', 'lsr r0, r0, #[[1]]     @ mean = sum / 8'], ['lsl r3, r3, #6         @ times 64', 'lsl r3, r3, #[[2]]     @ times 64']]),
    chips: ['3', '6', '8', '2', '1'], answer: ['3', '6'],
    tests: [
      { name: 'eight inputs of 128', checks: ['mem:out'], post: '.data\nx: .word 128, 128, 128, 128, 128, 128, 128, 128\n.bss\nout: .space 32\n.text\n_start:\n    ldr r0, =x\n    ldr r1, =out\n    bl rmsnorm' },
      { name: 'a mixed list', checks: ['mem:out'], post: '.data\nx: .word 64, -32, 16, 8, 0, 0, 0, 100\n.bss\nout: .space 32\n.text\n_start:\n    ldr r0, =x\n    ldr r1, =out\n    bl rmsnorm' } ],
    why: 'Sliding right by 3 divides by 8, the number of inputs. Sliding left by 6 multiplies by 64, the number that stands for 1.0.' }
] } ] });

U.push({ id: 'u6', title: 'Attention', blurb: 'How one word looks back at the words before it.', lessons: [
{ id: 'l14', title: 'Scores into shares', blurb: 'Softmax, done with a small lookup table.', unlock: ['softmax'], steps: [
  { t: 'learn', title: 'From scores to shares',
    text: 'Soon each earlier word will get a **score** for how useful it is. `softmax` turns scores into **shares** that add up to about 256: the best score takes most, and the others get a little.\n\nA share shrinks by a fixed factor for every point below the top score. Working that out needs a curve, so the program keeps 32 ready-made values in `exp_table` and just looks one up.',
    pre: 'thru:softmax', show: ['exp_table'],
    code: asm(`
.data
s: .word 20, 8
.bss
p: .space 8
.text
    ldr r0, =s
    mov r1, #2            @ two scores
    ldr r2, =p
    bl softmax`) },
  { t: 'predict', title: 'Equal scores',
    text: 'Now both scores are the same.',
    pre: 'thru:softmax',
    code: asm(`
.data
s: .word 5, 5
.bss
p: .space 8
.text
    ldr r0, =s
    mov r1, #2
    ldr r2, =p
    bl softmax`),
    ask: 'What does `p` hold afterwards?', options: ['128, 128', '256, 0', '5, 5', '255, 255'], verify: 'mem:p',
    why: 'Equal scores get equal shares, and the shares add up to 256. So each gets 128, which is one half.' },
  { t: 'predict', title: 'Only the gap matters',
    text: 'The first program had the scores 20 and 8 and gave the shares 243 and 12. These scores are 100 higher, but the gap between them is still 12.',
    pre: 'thru:softmax',
    code: asm(`
.data
s: .word 120, 108
.bss
p: .space 8
.text
    ldr r0, =s
    mov r1, #2
    ldr r2, =p
    bl softmax`),
    ask: 'What does `p` hold afterwards?', options: ['243, 12', '134, 121', '256, 0', '128, 128'], verify: 'mem:p',
    why: '`softmax` first finds the top score and then looks only at how far each score is below it. That distance is the position in the table. Same gaps, same shares.' },
  { t: 'inspect', title: 'Three scores',
    text: 'The middle score is the highest. Run it and look at `p`.',
    pre: 'thru:softmax',
    code: asm(`
.data
s: .word 8, 20, 8
.bss
p: .space 12
.text
    ldr r0, =s
    mov r1, #3
    ldr r2, =p
    bl softmax`),
    ask: 'What share does the middle score get?', options: ['232', '20', '85', '256'], verify: 'mem:p[1]',
    why: 'The two low scores get 11 each and the winner takes the rest. 11 + 232 + 11 is 254, not quite 256, because whole-number division drops fractions.' },
  { t: 'fill', title: 'Build softmax',
    text: 'Fill in the size of the table and the slide that makes shares count out of 256.',
    pre: 'upto:softmax',
    code: swap(ENGINE.parts.softmax, [['cmp r5, #32', 'cmp r5, #[[1]]'], ['lsl r5, r5, #8         @ times 256', 'lsl r5, r5, #[[2]]']]),
    chips: ['32', '8', '6', '16', '4'], answer: ['32', '8'],
    tests: [
      { name: 'scores 20, 8', checks: ['mem:p'], post: '.data\ns: .word 20, 8\n.bss\np: .space 8\n.text\n_start:\n    ldr r0, =s\n    mov r1, #2\n    ldr r2, =p\n    bl softmax' },
      { name: 'scores 40, 20, 28', checks: ['mem:p'], post: '.data\ns: .word 40, 20, 28\n.bss\np: .space 12\n.text\n_start:\n    ldr r0, =s\n    mov r1, #3\n    ldr r2, =p\n    bl softmax' } ],
    why: 'The table has 32 entries. A score 32 or more below the top gets no share at all, and the program must not read past the end of the table. Sliding left by 8 multiplies by 256 before the divide.' }
] },
{ id: 'l15', title: 'Position by rotation', blurb: 'How the model knows which word came first.', unlock: ['rotate'], steps: [
  { t: 'learn', title: 'Turning a pair of numbers',
    text: 'So far nothing tells the model **where** a word sits in the sentence. BitNet marks position by treating two numbers as a point on paper and **turning** it around the centre. Later words are turned further.\n\nTurning needs the cosine and sine of the angle. The table `turn` holds them for eight angles, 45 degrees apart, times 256. `turn_pair` turns the pair (64, 0) by one step.',
    pre: 'thru:rotate', show: ['turn'],
    code: asm(`
.data
v: .word 64, 0
.text
    ldr r0, =v
    mov r1, #1            @ one step of 45 degrees
    bl turn_pair`) },
  { t: 'predict', title: 'A quarter turn',
    text: 'Two steps is 90 degrees. Picture the point (64, 0) on paper and turn it a quarter of the way round.',
    pre: 'thru:rotate',
    code: asm(`
.data
v: .word 64, 0
.text
    ldr r0, =v
    mov r1, #2            @ two steps: 90 degrees
    bl turn_pair`),
    ask: 'What does `v` hold afterwards?', options: ['0, 64', '64, 0', '-64, 0', '45, 45'], verify: 'mem:v',
    why: 'A quarter turn moves a point on the first axis onto the second. The length stays 64: turning changes direction, never size.' },
  { t: 'inspect', title: 'Stamping a whole list',
    text: '`rotate` stamps a position onto a list of 8 numbers. It turns the first pair two steps per position and the second pair one step per position, and leaves the rest alone. This is position 1.',
    pre: 'thru:rotate',
    code: asm(`
.data
v: .word 64, 0, 64, 0, 7, 7, 7, 7
.text
    ldr r0, =v
    mov r1, #1            @ position 1
    bl rotate`),
    ask: 'What is `v[2]`, the start of the second pair?', options: ['45', '0', '64', '7'], verify: 'mem:v[2]',
    why: 'The first pair made a quarter turn to (0, 64). The second pair turns at half that speed, so it made an eighth of a turn to (45, 45). Two speeds let the model tell near from far.' },
  { t: 'predict', title: 'Round the clock',
    text: 'The table has only eight angles, so the program uses `and r1, r1, #7` to wrap the step number round. This asks for position 8.',
    pre: 'thru:rotate',
    code: asm(`
.data
v: .word 64, 0, 64, 0
.text
    ldr r0, =v
    mov r1, #8            @ position 8
    bl rotate`),
    ask: 'What does `v` hold afterwards?', options: ['64, 0, 64, 0', '0, 64, 45, 45', '-64, 0, -64, 0', '0, 0, 0, 0'], verify: 'mem:v',
    why: 'Eight steps of 45 degrees is a full circle, so position 8 looks exactly like position 0. That is why this tiny model stops at 8 words. The real BitNet uses many pairs turning at many speeds and can tell 4,096 positions apart.' },
  { t: 'fill', title: 'Build turn_pair',
    text: 'The new first number is `a x cos - b x sin`. The new second number is `a x sin + b x cos`. `mla` multiplies and adds; `mls` multiplies and subtracts.',
    pre: 'upto:rotate',
    code: swap(ENGINE.parts.rotate, [['mls r1, r5, r3, r1     @ minus b * sin', '[[1]] r1, r5, r3, r1     @ minus b * sin'], ['mla r1, r5, r2, r1     @ plus b * cos', '[[2]] r1, r5, r2, r1     @ plus b * cos'], ['asr r1, r1, #8\n    str r1, [r0, #4]', 'asr r1, r1, #[[3]]\n    str r1, [r0, #4]']]),
    chips: ['mls', 'mla', '8', '6', '4'], answer: ['mls', 'mla', '8'],
    tests: [
      { name: '(64, 0) turned one step', checks: ['mem:v'], post: '.data\nv: .word 64, 0\n.text\n_start:\n    ldr r0, =v\n    mov r1, #1\n    bl turn_pair' },
      { name: '(30, -50) turned three steps', checks: ['mem:v'], post: '.data\nv: .word 30, -50\n.text\n_start:\n    ldr r0, =v\n    mov r1, #3\n    bl turn_pair' } ],
    why: 'The table values are 256 times too big, so each result is slid right by 8 to bring it back. `asr` is the slide that keeps negative numbers negative.' }
] },
{ id: 'l16', title: 'Attention and its cache', blurb: 'Query, key, value: the heart of a language model.', unlock: ['dot', 'attention'], steps: [
  { t: 'learn', title: 'How well do two lists match?',
    text: 'A **dot product** multiplies two lists slot by slot and adds everything up. If the lists point the same way the result is big. Attention uses it to score how well two words match.\n\n`ldr r12, [r0], #4` loads from the address in `r0` and **then** moves `r0` forward by 4, ready for the next number.',
    pre: 'thru:dot',
    code: asm(`
.data
a: .word 1, 2, 3, 0, 0, 0, 0, 0
b: .word 4, 5, 6, 0, 0, 0, 0, 0
.text
    ldr r0, =a
    ldr r1, =b
    bl dot`) },
  { t: 'predict', title: 'Load, then step forward',
    text: 'Each `ldr` here loads a word and then moves `r0` on by 4 bytes.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    ldr r1, [r0], #4
    ldr r2, [r0], #4`),
    ask: 'What is loaded into `r2`?', options: ['6', '5', '7', '4'], verify: 'reg:r2',
    why: 'The first load takes 5 and moves `r0` to the second word. The second load takes 6. No position register and no slide are needed, which is why `dot` is so short.' },
  { t: 'learn', title: 'One word looks back',
    text: 'For each word, `attention` uses three layers:\n\n- **q** makes a query: what am I looking for?\n- **k** makes a key: what do I offer?\n- **v** makes a value: what do I hand over?\n\nThe query is scored against the key of every word so far with `dot`. `softmax` turns the scores into shares, and the values are blended by share. Here `red` goes in at position 0 and `blue` at position 1. Look at `scores` and `probs` afterwards.',
    pre: 'thru:attention', show: ['scores', 'probs'],
    code: asm(`
.data
red:  .word 186, 0, 0, 0, 0, 0, 0, 0
blue: .word 0, 186, 0, 0, 0, 0, 0, 0
.bss
out: .space 32
.text
    bl load_model
    ldr r0, =red
    mov r1, #0            @ position 0
    ldr r2, =out
    bl attention
    ldr r0, =blue
    mov r1, #1            @ position 1
    ldr r2, =out
    bl attention`) },
  { t: 'inspect', title: 'Who gets the attention?',
    text: 'Run the same program. After the second call, `probs` holds the shares that position 1 gave to each word: first the share for position 0, then the share for itself.',
    pre: 'thru:attention', show: ['scores', 'probs'],
    code: asm(`
.data
red:  .word 186, 0, 0, 0, 0, 0, 0, 0
blue: .word 0, 186, 0, 0, 0, 0, 0, 0
.bss
out: .space 32
.text
    bl load_model
    ldr r0, =red
    mov r1, #0
    ldr r2, =out
    bl attention
    ldr r0, =blue
    mov r1, #1
    ldr r2, =out
    bl attention`),
    ask: 'Out of 256, what share went to position 0?', options: ['243', '12', '128', '0'], verify: 'mem:probs[0]',
    why: 'The weights in q and k were chosen so that, after `rotate` has stamped the positions, a word\'s query matches the key of the word **just before** it. So `blue` mostly copies what `red` handed over. That is how this model knows what came before.' },
  { t: 'inspect', title: 'The KV cache',
    text: 'A word\'s key and value never change once they are worked out, so `attention` stores them in `cache_k` and `cache_v` instead of working them out again for every new word. Run the program and find `cache_k` in the Memory panel.',
    pre: 'thru:attention', show: ['cache_k', 'cache_v'],
    code: asm(`
.data
red:  .word 186, 0, 0, 0, 0, 0, 0, 0
.bss
out: .space 32
.text
    bl load_model
    ldr r0, =red
    mov r1, #0
    ldr r2, =out
    bl attention`),
    ask: 'How many bytes does `cache_k` take?', options: ['256', '32', '64', '8'], verify: 'bytes:cache_k', unit: 'bytes',
    why: '8 positions x 8 numbers x 4 bytes. The cache trades memory for time, and its size is what limits how many words a model can look back over. This one remembers 8 words; BitNet b1.58 2B4T remembers 4,096 tokens.' },
  { t: 'fill', title: 'Build dot',
    text: 'Fill in how far to step after each load, and the instruction that multiplies two numbers and adds them to the total.',
    pre: 'upto:dot',
    code: swap(ENGINE.parts.dot, [['ldr r12, [r0], #4      @ next a, then step forward', 'ldr r12, [r0], #[[1]]    @ next a, then step'], ['mla r2, r12, r4, r2', '[[2]] r2, r12, r4, r2']]),
    chips: ['4', '1', '8', 'mla', 'mls'], answer: ['4', 'mla'],
    tests: [{ name: 'dot of 1, 2, 3... with 4, 5, 6...', post: '.data\na: .word 1, 2, 3, 0, 0, 0, 0, 2\nb: .word 4, 5, 6, 9, 9, 9, 9, 10\n.text\n_start:\n    ldr r0, =a\n    ldr r1, =b\n    bl dot' }],
    why: 'Words are 4 bytes apart. `mla r2, r12, r4, r2` means "r2 = r12 x r4 + r2": one instruction multiplies and keeps the running total.' }
] } ] });
})(typeof window !== 'undefined' ? window : globalThis);
