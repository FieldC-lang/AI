/* Units 7-9. Truths are computed by the emulator at run time; tools/check.cjs verifies every step. */
(function (root) {
var U = root.UNITS = root.UNITS || [];
var ENGINE = root.ENGINE || require('./engine.js');
var asm = root.LESSON_TOOLS.asm, swap = root.LESSON_TOOLS.swap;

function ffnRun(x) {
  return asm(`
.data
x: .word ${x}
.bss
out: .space 32
.text
    bl load_model
    ldr r0, =x
    ldr r1, =out
    bl ffn`);
}
function feed(words) {
  return '    bl load_model\n' + words.map(function (w, i) {
    return '    mov r0, #' + w[0] + '            @ "' + w[1] + '"\n    mov r1, #' + i + '            @ position ' + i + '\n    bl forward';
  }).join('\n');
}
var MAIN = ENGINE.parts.main;
var GEN_NO_END = swap(ENGINE.parts.generate, [['    cmp r0, #END\n    beq gen_done\n', '']]);
var WEIGHT_CALLS = asm(`
.data
w: .byte 145, 6
xq: .word 10, 20, 30, 40, 50, 60, 70, 80
.text
    ldr r4, =w
    ldr r5, =xq
    mov r6, #0            @ total
    mov r8, #0            @ which weight
each:
    mov r0, r4
    mov r1, r8
    bl weight_at
    ldr r3, [r5, r8, lsl #2]
    cmp r0, #1
    addeq r6, r6, r3
    cmn r0, #1
    subeq r6, r6, r3
    add r8, r8, #1
    cmp r8, #8
    blt each`);
var WEIGHT_BYTES = asm(`
.data
w: .byte 145, 6
xq: .word 10, 20, 30, 40, 50, 60, 70, 80
.text
    ldr r4, =w
    ldr r5, =xq
    mov r6, #0            @ total
    mov r8, #0            @ which byte
byte:
    ldrb r2, [r4, r8]     @ fetch 4 weights at once
    mov r9, #4
slot:
    lsr r0, r2, #6        @ the top 2 bits
    and r0, r0, #3
    lsl r2, r2, #2        @ line up the next slot
    ldr r3, [r5], #4
    cmp r0, #2
    addeq r6, r6, r3
    cmp r0, #0
    subeq r6, r6, r3
    subs r9, r9, #1
    bne slot
    add r8, r8, #1
    cmp r8, #2
    blt byte`);

U.push({ id: 'u7', title: 'The whole model', blurb: 'The second half of a block, then one word from start to finish.', lessons: [
{ id: 'l17', title: 'Feed-forward', blurb: 'The step that makes one answer stand out.', unlock: ['ffn'], steps: [
  { t: 'learn', title: 'Squared and never negative',
    text: 'After attention has gathered information, a second step works on it: the **feed-forward** step. At its heart is a small rule BitNet uses, called squared ReLU:\n\n- a negative number becomes 0\n- anything else is multiplied by itself\n\nRemember that 64 stands for 1.0, so after multiplying two such numbers the result is slid right by 6 to bring it back. 1.0 squared is still 1.0.',
    code: asm(`
    mov r0, #64           @ 1.0
    cmp r0, #0
    movlt r0, #0          @ negative? make it 0
    mul r0, r0, r0        @ times itself
    asr r0, r0, #6        @ back to 64ths`) },
  { t: 'predict', title: 'Big gets bigger',
    text: 'Now the input is 128, which stands for 2.0.',
    code: asm(`
    mov r0, #128          @ 2.0
    cmp r0, #0
    movlt r0, #0
    mul r0, r0, r0
    asr r0, r0, #6`),
    ask: 'What is `r0` at the end?', options: ['256', '128', '16384', '4'], verify: 'reg:r0',
    why: '128 x 128 = 16,384, and sliding right by 6 gives 256, which stands for 4.0. Squaring makes strong signals much stronger than weak ones.' },
  { t: 'predict', title: 'Negative closes',
    text: '`mvn r0, #127` puts -128 into `r0`.',
    code: asm(`
    mvn r0, #127          @ -128, which is -2.0
    cmp r0, #0
    movlt r0, #0
    mul r0, r0, r0
    asr r0, r0, #6`),
    ask: 'What is `r0` at the end?', options: ['0', '256', '-256', '-128'], verify: 'reg:r0',
    why: 'The `movlt` turns any negative number into 0 before the squaring. Without it, -2.0 squared would wrongly come out as +4.0.' },
  { t: 'learn', title: 'Gate, value, result',
    text: '`ffn` runs three layers:\n\n- **gate** decides how far each slot opens. In this model the gate for a slot is that slot minus its rivals.\n- **up** carries the values.\n- **down** writes the result.\n\nEach gate is squashed by the rule you just saw, then multiplied by its value. Slots 4, 5 and 6 here mean "the next word is red", "blue" and "end". Red leads with 150. Compare `gate_out` and `out`.',
    pre: 'thru:ffn', show: ['gate_out', 'up_out', 'inner'],
    code: ffnRun('0, 0, 0, 0, 150, 40, 20, 0') },
  { t: 'inspect', title: 'The losers are shut out',
    text: 'Run it and look at `out` in the Memory panel. Slot 5 went in as 40.',
    pre: 'thru:ffn', show: ['gate_out', 'up_out', 'inner'],
    code: ffnRun('0, 0, 0, 0, 150, 40, 20, 0'),
    ask: 'What is `out[5]`?', options: ['0', '40', '38', '-129'], verify: 'mem:out[5]',
    why: 'The gate for slot 5 came out as -129: slot 5 minus its bigger rivals is negative, so the gate closed fully. Only the leader got through. Feed-forward has turned "probably red" into "red".' },
  { t: 'inspect', title: 'Three layers, three times the cost',
    text: 'Run it once more and read the clock.',
    pre: 'thru:ffn',
    code: ffnRun('0, 0, 0, 0, 150, 40, 20, 0'),
    ask: 'How many ticks did the program take?', options: ['4873', '1559', '448', '76303'], verify: 'clock', unit: 'ticks',
    why: 'One layer on its own took 1,559 ticks. `ffn` runs three of them, so it costs about three times as much. Everything else in `ffn` is small change.' },
  { t: 'fill', title: 'Build the gate rule',
    text: 'Fill in the two pieces of the squared ReLU inside `ffn`.',
    pre: 'upto:ffn',
    code: swap(ENGINE.parts.ffn, [['movlt r0, #0           @ negative gates close fully', '[[1]] r0, #0           @ negative gates close'], ['mul r0, r0, r0         @ squared: big gates open wide', 'mul r0, r0, [[2]]         @ squared']]),
    chips: ['movlt', 'movgt', 'r0', 'r1', 'r2'], answer: ['movlt', 'r0'],
    tests: [
      { name: 'red leads', checks: ['mem:out'], post: '.data\nx: .word 0, 0, 0, 0, 150, 40, 20, 0\n.bss\nout: .space 32\n.text\n_start:\n    bl load_model\n    ldr r0, =x\n    ldr r1, =out\n    bl ffn' },
      { name: 'blue leads', checks: ['mem:out'], post: '.data\nx: .word 0, 0, 0, 0, 20, 150, 40, 0\n.bss\nout: .space 32\n.text\n_start:\n    bl load_model\n    ldr r0, =x\n    ldr r1, =out\n    bl ffn' } ],
    why: '`movlt` zeroes the gate only when it is negative, and `mul r0, r0, r0` multiplies the gate by itself.' }
] },
{ id: 'l18', title: 'One word, start to finish', blurb: 'Embedding, attention, feed-forward, scores.', unlock: ['forward'], steps: [
  { t: 'learn', title: 'The forward pass',
    text: '`forward` runs one word through the whole model:\n\n1. look up the word\'s row of numbers, into `x`\n2. attention, added on top of `x`\n3. feed-forward, added on top of `x`\n4. score every word the model knows, into `logits`\n\n`logits` holds one score per word: red, blue, end. The highest score is the model\'s guess for the **next** word. Here the model has seen only `red`.',
    pre: 'thru:forward', show: ['x', 'logits'],
    code: feed([[0, 'red']]) },
  { t: 'predict', title: 'Added on top',
    text: 'Attention and feed-forward never replace `x`. Their result is **added** to it by `add_into`. Here `a` is the word `red` and `b` is what attention found.',
    pre: 'thru:forward',
    code: asm(`
.data
a: .word 64, 0, 0, 0, 0, 0, 0, 0
b: .word 0, 0, 0, 0, 181, 7, 0, 0
.text
    ldr r0, =a
    ldr r1, =b
    bl add_into`),
    ask: 'What does `a` hold afterwards?', options: ['64, 0, 0, 0, 181, 7, 0, 0', '0, 0, 0, 0, 181, 7, 0, 0', '64, 0, 0, 0, 0, 0, 0, 0', '245, 7, 0, 0, 0, 0, 0, 0'], verify: 'mem:a',
    why: 'The 64 that says "I am red" is still there, and the new information sits beside it. Every block adds notes to the same list and never erases it. In large models this is what lets dozens of blocks work together.' },
  { t: 'inspect', title: 'Two words in',
    text: 'Feed `red` at position 0 and then `blue` at position 1. Run it and look at `logits`.',
    pre: 'thru:forward', show: ['x', 'logits', 'probs'],
    code: feed([[0, 'red'], [1, 'blue']]),
    ask: 'What does `logits` hold after `blue`?', options: ['179, 3, 0', '3, 179, 0', '0, 0, 179', '64, 64, 0'], verify: 'mem:logits',
    why: 'The first score, for `red`, is far ahead. The model has just seen `blue`, looked back one word, found `red`, and now bets that `red` comes next. That is the whole trick of this tiny model: say the word before the current one.' },
  { t: 'inspect', title: 'The price of one word',
    text: 'Run one word through the model and read the clock.',
    pre: 'thru:forward',
    code: feed([[0, 'red']]),
    ask: 'How many ticks did one word cost?', options: ['12289', '1559', '4873', '495'], verify: 'clock', unit: 'ticks',
    why: 'One word runs seven layers: four in attention and three in feed-forward. Seven times about 1,500 is already 10,500. The rest is normalising, rotating and scoring.' },
  { t: 'inspect', title: 'Still the same hot spot',
    text: 'Run it again and look at the ticks spent in each function.',
    pre: 'thru:forward',
    code: feed([[0, 'red']]),
    ask: 'Which function used the most ticks?', options: ['bitlinear', 'attention', 'forward', 'rmsnorm'], verify: 'hot',
    why: 'Even in the full model, most ticks go to `bitlinear` and the `weight_at` calls inside it. That is why bitnet.cpp puts nearly all of its effort into making that one loop fast.' },
  { t: 'inspect', title: 'How deep does the stack go?',
    text: '`forward` calls `attention`, which calls `bitlinear`. Each one pushes the registers it needs to keep. Run it and read the peak memory.',
    pre: 'thru:forward',
    code: feed([[0, 'red']]),
    ask: 'What was the peak, in bytes?', options: ['72', '16', '1308', '0'], verify: 'peak', unit: 'bytes',
    why: '`forward` pushes 4 registers (16 bytes), `attention` 5 (20 bytes) and `bitlinear` 9 (36 bytes). 16 + 20 + 36 = 72. The whole model thinks using 72 bytes of stack.' },
  { t: 'write', title: 'Write add_into',
    text: 'Write `add_into`. `r0` holds the address of a list of 8 numbers and `r1` the address of another. Add each number of the second list onto the first list. `DIM` is 8.',
    pre: 'upto:forward',
    code: asm(`
@ add_into: r0 = list to change, r1 = list to add to it
add_into:
    @ for each of the 8 numbers:
    @ load both, add them, store into r0's list
    bx lr`),
    solution: asm(`
@ add_into: r0 = list to change, r1 = list to add to it
add_into:
    mov r2, #0
add_loop:
    ldr r3, [r0, r2, lsl #2]
    ldr r12, [r1, r2, lsl #2]
    add r3, r3, r12
    str r3, [r0, r2, lsl #2]
    add r2, r2, #1
    cmp r2, #DIM
    blt add_loop
    bx lr`),
    tests: [
      { name: 'red plus what attention found', checks: ['mem:a'], post: '.data\na: .word 64, 0, 0, 0, 0, 0, 0, 0\nb: .word 0, 0, 0, 0, 181, 7, 0, 0\n.text\n_start:\n    ldr r0, =a\n    ldr r1, =b\n    bl add_into' },
      { name: 'eight different numbers', checks: ['mem:a'], post: '.data\na: .word 1, 2, 3, 4, 5, 6, 7, 8\nb: .word 10, -20, 30, -40, 50, -60, 70, -80\n.text\n_start:\n    ldr r0, =a\n    ldr r1, =b\n    bl add_into' } ],
    hint: 'Use `r2` as the position, starting at 0. Inside the loop: `ldr r3, [r0, r2, lsl #2]`, `ldr r12, [r1, r2, lsl #2]`, `add r3, r3, r12`, `str r3, [r0, r2, lsl #2]`. Then add 1 to `r2`, `cmp r2, #DIM` and `blt` back to the top. `r2`, `r3` and `r12` are free to use without saving.',
    why: 'Load, load, add, store, eight times. This small loop is what the diagrams of language models call a "residual connection".' }
] } ] });

U.push({ id: 'u8', title: 'Words out', blurb: 'Pick a word, print it, feed it back in.', lessons: [
{ id: 'l19', title: 'Pick a word and print it', blurb: 'The best score, then a request to the system.', unlock: ['argmax', 'print'], steps: [
  { t: 'learn', title: 'Which score is biggest?',
    text: '`argmax` walks along a list and returns the **position** of the biggest number. Run on `logits`, that position is the number of the word the model picks.',
    pre: 'thru:argmax',
    code: asm(`
.data
s: .word 3, 179, 0
.text
    ldr r0, =s
    mov r1, #3            @ three scores
    bl argmax`) },
  { t: 'predict', title: 'A tie',
    text: 'Two scores share first place. `argmax` only replaces its best when a new score is **greater** (`movgt`).',
    pre: 'thru:argmax',
    code: asm(`
.data
s: .word 5, 9, 9
.text
    ldr r0, =s
    mov r1, #3
    bl argmax`),
    ask: 'What comes back in `r0`?', options: ['1', '2', '9', '0'], verify: 'reg:r0',
    why: 'The second 9 is not greater than the first 9, so the earlier position is kept. A fixed rule for ties means the program gives the same answer every time.' },
  { t: 'fill', title: 'Build argmax',
    text: 'Fill in what each new score is compared with, and the instruction that remembers its position.',
    pre: 'upto:argmax',
    code: swap(ENGINE.parts.argmax, [['cmp r4, r3\n    movgt r3, r4\n    movgt r2, r12', 'cmp r4, [[1]]\n    movgt r3, r4\n    [[2]] r2, r12']]),
    chips: ['r3', 'r2', 'r1', 'movgt', 'movge', 'movlt'], answer: ['r3', 'movgt'],
    tests: [
      { name: 'scores 3, 179, 0', post: '.data\ns: .word 3, 179, 0\n.text\n_start:\n    ldr r0, =s\n    mov r1, #3\n    bl argmax' },
      { name: 'a tie: 5, 9, 9', post: '.data\ns: .word 5, 9, 9\n.text\n_start:\n    ldr r0, =s\n    mov r1, #3\n    bl argmax' },
      { name: 'the last is biggest: 1, 2, 7', post: '.data\ns: .word 1, 2, 7\n.text\n_start:\n    ldr r0, =s\n    mov r1, #3\n    bl argmax' } ],
    why: '`r3` holds the best value so far, so that is what each new score is compared with. `movgt` copies the position only when the new score was greater.' },
  { t: 'learn', title: 'Asking the system for help',
    text: 'A program cannot touch the screen by itself. It asks the operating system, using `svc #0`. Before that it fills in a small form:\n\n- `r7` = which service: 4 means "write"\n- `r0` = where to: 1 means the screen\n- `r1` = the address of the text\n- `r2` = how many bytes\n\nWatch the Output panel when the `svc` line runs.',
    code: asm(`
.data
msg: .ascii "hi\\n"
.text
    mov r0, #1            @ the screen
    ldr r1, =msg
    mov r2, #3            @ three bytes: h, i, new line
    mov r7, #4            @ "write"
    svc #0`) },
  { t: 'predict', title: 'From a number back to letters',
    text: '`print_word` takes a word number, finds the word in the `words` table, counts its letters up to the 0 byte, and prints them.',
    pre: 'thru:print',
    code: asm(`
    mov r0, #1
    bl print_word`),
    ask: 'What appears in the output?', options: ['blue', 'red', '1', 'end'], verify: 'out',
    why: 'Word 1 is `blue`. This is the tokenizer running backwards: numbers in, letters out.' },
  { t: 'predict', title: 'Saying goodbye',
    text: 'Service number 1 is "exit". It stops the program and hands the number in `r0` back to whoever started it. By custom 0 means "all went well".',
    code: asm(`
    mov r0, #7
    mov r7, #1            @ "exit"
    svc #0
    mov r0, #9`),
    ask: 'What exit code does the program end with?', options: ['7', '9', '1', '0'], verify: 'exit',
    why: 'The program stops at the `svc`. The last line never runs, so the code is 7. The finished program exits with 0 normally and with 1 if the model data is damaged.' },
  { t: 'write', title: 'Write a letter counter',
    text: 'Write `count`. `r0` holds the address of some text that ends with a 0 byte. Return the number of letters before that 0 in `r0`.',
    code: asm(`
count:
    @ r0 = address of the text
    @ return how many bytes come before the 0
    bx lr`),
    solution: asm(`
count:
    mov r1, r0            @ keep the address
    mov r0, #0            @ letters so far
count_loop:
    ldrb r2, [r1, r0]
    cmp r2, #0
    addne r0, r0, #1
    bne count_loop
    bx lr`),
    tests: [
      { name: 'count("blue")', post: '.data\nt: .asciz "blue"\n.text\n_start:\n    ldr r0, =t\n    bl count' },
      { name: 'count("red")', post: '.data\nt: .asciz "red"\n.text\n_start:\n    ldr r0, =t\n    bl count' },
      { name: 'count("")', post: '.data\nt: .asciz ""\n.text\n_start:\n    ldr r0, =t\n    bl count' } ],
    hint: 'Move the address out of the way first: `mov r1, r0`, then `mov r0, #0`. In a loop, `ldrb r2, [r1, r0]` loads the next letter. `cmp r2, #0`, then `addne r0, r0, #1` and `bne` back to the loop.',
    why: 'This is the loop inside `print_word`. Text that ends with a 0 byte does not need its length stored anywhere, but finding the length means walking the whole text.' }
] },
{ id: 'l20', title: 'The generate loop', blurb: 'The last piece. After this the program is complete.', unlock: ['generate', 'main'], steps: [
  { t: 'learn', title: 'The finished program',
    text: 'This is the last part: the program\'s starting point. It checks the model, reads a line from the keyboard, turns it into word numbers with `encode`, and calls `generate`.\n\n`generate` feeds each prompt word through `forward`. Then it repeats: pick the best word, print it, feed it back in as if it had been typed. That loop is all "text generation" is.\n\nThe keyboard input here is `red blue`. Run it.',
    pre: 'thru:generate', stdin: 'red blue\n', code: MAIN },
  { t: 'predict', title: 'One word of prompt',
    text: 'Now the keyboard input is just `blue`. Remember the model\'s one trick: it says the word before the current one. When there is no earlier word, a word looks at itself.',
    pre: 'thru:generate', stdin: 'blue\n', code: MAIN,
    ask: 'What does the program print?', options: ['blue blue blue blue', 'blue red blue red', 'red red red red', 'blue'], verify: 'out',
    why: 'With nothing before it, `blue` attends to itself and predicts `blue`. That new `blue` looks back one word, finds `blue`, and so on. It stops after 4 new words because `MAXNEW` is 4.' },
  { t: 'predict', title: 'A longer prompt',
    text: 'The keyboard input is `red red blue`.',
    pre: 'thru:generate', stdin: 'red red blue\n', code: MAIN,
    ask: 'What does the program print?', options: ['red blue red blue', 'red red blue red', 'blue blue blue blue', 'blue red blue red'], verify: 'out',
    why: 'The last word is `blue` and the word before it is `red`, so `red` comes first. Then the newest word is `red` and the one before it is `blue`. From there the two take turns.' },
  { t: 'predict', title: 'The stop word',
    text: 'The keyboard input is `blue end`. The word `end` is special: when the model picks it, `generate` stops.',
    pre: 'thru:generate', stdin: 'blue end\n', code: MAIN,
    ask: 'What does the program print?', options: ['blue', 'blue end blue end', 'end', 'blue blue blue blue'], verify: 'out',
    why: 'The word before `end` is `blue`, so `blue` is printed. Now the word before the newest one is `end`. The model picks `end`, and the loop stops without printing it. Real models stop the same way, with a special end-of-text token.' },
  { t: 'experiment', title: 'Take the stop check out',
    text: 'Version B is `generate` with two lines removed: `cmp r0, #END` and `beq gen_done`. Both get the keyboard input `blue end`.',
    pre: 'thru:print', post: MAIN, stdin: 'blue end\n',
    variants: [
      { label: 'With the check', code: ENGINE.parts.generate },
      { label: 'Without it', code: GEN_NO_END } ],
    verify: 'out',
    ask: 'What changed?',
    options: ['Without the check, `end` is printed like any other word and the loop carries on', 'Without the check the program crashes', 'Without the check nothing is printed', 'Nothing changed'], answer: 0,
    why: 'To the model, `end` is just word number 2. Only those two lines in `generate` give it a meaning. The loop then runs until `MAXNEW` stops it.' },
  { t: 'inspect', title: 'What a sentence costs',
    text: 'Run the full program on `red blue` and read the clock.',
    pre: 'thru:generate', stdin: 'red blue\n', code: MAIN,
    ask: 'How many ticks did it take?', options: ['76303', '12289', '1980', '600000'], verify: 'clock', unit: 'ticks',
    why: 'Six words went through `forward`: two from the prompt and four new ones. Six times about 12,400 is 74,400, plus reading, tokenizing and printing. The cost grows with every word, in and out.' },
  { t: 'inspect', title: 'How big is the whole thing?',
    text: 'Run it once more. The Memory panel now reports the size of the complete program.',
    pre: 'thru:generate', stdin: 'red blue\n', code: MAIN,
    ask: 'How many bytes do all its instructions take?', options: ['1980', '495', '1308', '76303'], verify: 'allcode', unit: 'bytes',
    why: '495 instructions at 4 bytes each. The data, including the model and both caches, takes another 1,308 bytes. Built for Linux with the GNU tools, the finished program file is 5,448 bytes: a complete language model that fits in a few thousand bytes.' }
] } ] });

U.push({ id: 'u9', title: 'The real thing', blurb: 'What bitnet.cpp does differently, and why.', lessons: [
{ id: 'l21', title: 'Why bitnet.cpp is fast', blurb: 'Same idea, much heavier machinery.', steps: [
  { t: 'learn', title: 'Where the ticks went',
    text: 'You measured it yourself: one word costs about 12,300 ticks, and most of that is the weights. Each weight costs 20 ticks here, and one word needs 7 layers of 64 weights.\n\nBitNet b1.58 2B4T has about **2 billion** weights. At 20 ticks each it would be hopeless. bitnet.cpp, the official program for running these models, exists to shrink that cost per weight. Its README reports speedups of 1.37x to 5.07x on ARM chips, with 55.4% to 70.0% less energy used.',
    code: asm(`
    mov r0, #448          @ 7 layers x 64 weights
    mov r1, #20           @ ticks per weight
    mul r0, r0, r1        @ ticks spent on weights per word`) },
  { t: 'duel', title: 'Stop asking for one weight at a time',
    text: 'Both versions add up 8 inputs using the same 8 packed weights and get the same total in `r6`. Version A calls `weight_at` for every weight. Version B fetches a byte once and peels off its four weights with slides.',
    pre: 'thru:weight_at',
    variants: [
      { label: 'weight_at each time', code: WEIGHT_CALLS },
      { label: 'A byte at a time', code: WEIGHT_BYTES } ],
    ask: 'Which one uses fewer clock ticks?', metric: 'clock', unit: 'ticks',
    why: 'Version A works out "which byte, which slot" from scratch for every weight and pays for a call each time. Version B walks through the data in the order it is stored. Same answer, far fewer ticks. Laying work out to match how the data is packed is the first thing a fast kernel does.' },
  { t: 'predict', title: 'Look the answer up',
    text: 'The next idea goes further. Two weights have only 9 possible combinations, so for a pair of inputs every possible result can be worked out **once** and kept in a table. After that, half a byte of packed weights is simply a position in the table.\n\nThis table was built for the inputs 10 and 20. The byte 145 starts with the bits 1001: weights +1 and 0.',
    code: asm(`
.data
table: .word -30, -10, 10, 0, -20, 0, 20, 0
       .word -10, 10, 30, 0, 0, 0, 0, 0
.text
    mov r0, #145          @ one packed byte
    lsr r1, r0, #4        @ top half: two weights
    ldr r2, =table
    ldr r0, [r2, r1, lsl #2]`),
    ask: 'What is `r0` at the end?', options: ['10', '9', '145', '30'], verify: 'reg:r0',
    why: 'The top half of 145 is 9, and entry 9 of the table is 10: one times 10 plus zero times 20. No compare, no add, no subtract: one load. The README says the bitnet.cpp kernels (it names I2_S, TL1 and TL2) build on the lookup-table methods of a project called T-MAC.' },
  { t: 'predict', title: 'Many numbers in one register',
    text: 'One more trick. A 32-bit register can be treated as four separate bytes. `0x` marks a number written in base 16, where every two digits are one byte. This adds 0x10 to four bytes with a single `add`.',
    code: asm(`
    ldr r0, =0x01020304   @ the bytes 01 02 03 04
    ldr r1, =0x10101010   @ the bytes 10 10 10 10
    add r0, r0, r1`),
    ask: 'What is `r0`, written in base 16?', options: ['0x11121314', '0x01020304', '0x10101010', '0x0000000A'], verify: 'hex:r0',
    why: 'Four additions happened in one tick. Real ARM chips have an extra set of wide registers, called NEON, built for exactly this: 16 bytes handled by one instruction. Fast kernels lean on it heavily. This emulator leaves NEON out to stay simple.' },
  { t: 'predict', title: 'Two billion weights',
    text: 'Your program stores a weight in 2 bits, so 4 weights fit in a byte. The real model has about 2,000,000,000 weights. `lsr #2` divides by 4.',
    code: asm(`
    ldr r0, =2000000000   @ weights
    lsr r0, r0, #2        @ 4 weights per byte`),
    ask: 'How many bytes is that?', options: ['500000000', '2000000000', '8000000000', '250000000'], verify: 'reg:r0',
    why: 'About half a gigabyte, the same order as the 0.4 GB the model card reports. Stored the ordinary way, as 4-byte fractions, the same weights would need 8 gigabytes. That 16-fold saving is why a model like this fits on a phone or a small ARM board.' },
  { t: 'learn', title: 'Run it on a real ARM chip',
    text: 'The program you built is real ARMv7 assembly. Copy `microbit.s` from the Project tab, and on Linux with the GNU ARM tools:\n\n- `arm-linux-gnueabihf-as microbit.s -o microbit.o`\n- `arm-linux-gnueabihf-ld microbit.o -o microbit`\n- `echo "red blue" | qemu-arm ./microbit`\n\nThe last line runs it in QEMU, an emulator; on a 32-bit ARM Linux board you can run `./microbit` directly. It needs a core that has the divide instructions, which means Cortex-A7 or later. These exact steps were checked with QEMU, not on a physical board.\n\n**What is different in the real BitNet:** 128,256 word pieces instead of 3 words, about 2 billion trained weights instead of 448 hand-picked ones, many blocks instead of one, true fractions instead of 64ths, and a memory of 4,096 tokens instead of 8. The steps are the ones you just built.',
    pre: 'thru:generate', stdin: 'red blue\n', code: MAIN }
] } ] });
})(typeof window !== 'undefined' ? window : globalThis);
