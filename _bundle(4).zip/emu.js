/* Emu: glue between lesson steps and ArmVM. Pure logic (no DOM), shared by the app and the test harness. */
(function (root) {
'use strict';
var VM = root.ArmVM || (typeof require !== 'undefined' ? require('./armvm.js') : null);
var ENGINE = root.ENGINE || (typeof require !== 'undefined' ? require('./engine.js') : null);
var LIMIT = 600000;
var preCache = {};

function lineCount(s) { return s === '' ? 0 : s.split('\n').length; }
function trimEnd(s) { return (s || '').replace(/\s+$/, ''); }
// Names of the engine parts a step starts with.
function preParts(pre) {
  if (!pre) return [];
  var m = /^(upto|thru|parts):([\w,]+)$/.exec(pre), out = [], i;
  if (!m) throw new Error('bad pre: ' + pre);
  if (m[1] === 'parts') return m[2].split(',');
  for (i = 0; i < ENGINE.order.length; i++) {
    var name = ENGINE.order[i];
    if (m[1] === 'upto' && name === m[2]) break;
    if (name !== 'header') out.push(name);
    if (name === m[2]) break;
  }
  return out;
}
function preSource(spec) { var names = preParts(spec.pre); return names.length ? ENGINE.join(names) : ''; }
// spec: {pre, setup, code, post, stdin, show, watch}
// Layout: [engine parts] .text [setup] [code] .text [post]
function program(spec, codeOverride) {
  var pre = preSource(spec), setup = trimEnd(spec.setup);
  var code = trimEnd(codeOverride === undefined ? spec.code : codeOverride);
  var post = trimEnd(spec.post);
  var head = (pre ? pre + '\n' : '') + '.text\n', entry = lineCount(head);
  if (setup) head += setup + '\n';
  var off = lineCount(head) - 1;
  var src = head + code + '\n' + (post ? '.text\n' + post + '\n' : '');
  if (!(pre in preCache)) {
    var total = 0;
    if (pre) { try { total = VM.assemble(pre + '\n').total; } catch (e) { total = 0; } }
    preCache[pre] = total;
  }
  return { src: src, off: off, n: lineCount(code), entry: entry, stdin: spec.stdin || '', preBytes: preCache[pre], show: spec.show || null, watch: spec.watch || null };
}
function visible(p, line) { return line > p.off && line <= p.off + p.n; }
function trace(p) {
  var res = VM.run(p.src, { stdin: p.stdin, trace: true, entryLine: p.entry, maxTicks: LIMIT });
  var first = -1, stops = [], i, tr = res.trace || [], n = res.ticks;
  for (i = 0; i < n; i++) if (visible(p, tr[i])) { if (first < 0) first = i; stops.push(i); }
  if (first < 0) first = n;
  var data = res.asm ? Math.max(0, res.dataBytes - p.preBytes) : 0;
  var peaks = new Int32Array(n + 1), pk = 0;
  for (i = 0; i <= n; i++) {
    var d = i < n ? res.stackAt[i] : res.stack;
    if (i >= first && d > pk) pk = d;
    peaks[i] = pk;
  }
  if (res.stackPeak > pk && n >= first) { /* the last instruction may have pushed */ }
  return { res: res, first: first, stops: stops, data: data, peaks: peaks };
}
function fmtValues(res, sym) {
  var v = VM.symValues(res, sym);
  if (v.text !== null) return { text: v.text, values: null, size: 1 };
  var ptrs = v.size === 4 && v.values.length > 0 && v.values.some(function (x) { return x !== 0; }) && v.values.every(function (x) { return x === 0 || ((x >>> 0) >= VM.DATA && (x >>> 0) < VM.DATA + res.dataBytes) || ((x >>> 0) >= VM.TEXT && (x >>> 0) <= res.textEnd && (x & 3) === 0); });
  var shown = ptrs ? v.values.map(function (x) { return x === 0 ? '0' : hex(x); }) : v.values.map(String);
  return { text: shown.join(', '), values: shown, size: v.size, ptrs: ptrs };
}
function symsOf(p, res) {
  var out = [], i;
  if (!res.syms) return out;
  for (i = 0; i < res.syms.length; i++) {
    var s = res.syms[i];
    if (s.name.slice(0, 2) === '__') continue;
    if (!(s.line > p.entry - 1) && !(p.show && p.show.indexOf(s.name) >= 0)) continue;
    var f = fmtValues(res, s);
    out.push({ name: s.name, addr: s.addr, bytes: s.size, kind: s.kind, unit: f.size, text: f.text, values: f.values, sec: s.sec });
  }
  return out;
}
// What an address points at, for display: "model+8", "line 4", "stack".
function describe(res, v) {
  v = v >>> 0;
  if (!res.syms) return '';
  if (v >= VM.DATA && v < VM.DATA + res.dataBytes) {
    for (var i = 0; i < res.syms.length; i++) { var s = res.syms[i]; if (v >= s.addr && v < s.addr + s.size) return s.name + (v > s.addr ? '+' + (v - s.addr) : ''); }
    return 'data';
  }
  if (v >= VM.TEXT && v <= res.textEnd && (v & 3) === 0) return 'code';
  if (v <= res.stackTop && v > res.stackTop - 65536) return 'stack';
  return '';
}
// State after `idx` ticks (idx === ticks means the end of the run).
function stateAt(p, t, idx) {
  var res = t.res, end = idx >= res.ticks;
  var r = end ? res : VM.run(p.src, { stdin: p.stdin, stopAt: idx, entryLine: p.entry, maxTicks: LIMIT });
  var line = end ? (res.error ? res.error.line : 0) : res.trace[idx];
  var at = end ? res.ticks : idx, i;
  var stackWords = [];
  if (r.regs) for (i = 0; i < Math.min(r.stack, 48); i += 4) { var a = r.regs[13] + i; stackWords.push({ addr: a >>> 0, value: r.read(a, 4) }); }
  var st = {
    idx: at, end: end,
    status: end ? res.status : 'paused',
    line: visible(p, line) ? line - p.off : 0,
    rawLine: line,
    clock: Math.max(0, at - t.first),
    stack: r.regs ? r.stack : 0,
    live: t.data + (r.regs ? r.stack : 0),
    peak: t.data + t.peaks[Math.min(at, t.peaks.length - 1)],
    data: t.data,
    out: end ? res.out : res.out.substr(0, res.outAt[idx]),
    regs: r.regs ? r.regs.slice(0, 15).concat([r.pc]) : null,
    flags: r.flags || null,
    syms: r.regs ? symsOf(p, r) : [],
    stackWords: stackWords, stackMore: r.regs ? Math.max(0, r.stack - 48) : 0,
    calls: r.calls || [],
    exit: end ? res.exit : null,
    error: end && res.error ? { type: res.error.type, msg: res.error.msg, line: res.error.line, text: res.error.type + ': ' + res.error.msg } : null,
    notes: function (v) { return describe(r, v); }
  };
  if (st.error) st.errorLine = visible(p, st.error.line) ? st.error.line - p.off : 0;
  return st;
}
function nextStop(t, idx) { for (var i = 0; i < t.stops.length; i++) if (t.stops[i] > idx) return t.stops[i]; return t.res.ticks; }
function prevStop(t, idx) { var best = -1; for (var i = 0; i < t.stops.length; i++) { if (t.stops[i] < idx) best = t.stops[i]; else break; } return best; }
function stopLine(p, stop) {
  if (stop.line) return stop.line;
  var lines = p.src.split('\n');
  for (var i = p.off; i < p.off + p.n; i++) if (lines[i].indexOf(stop.match) >= 0) return i - p.off + 1;
  return -1;
}
function stopIndex(p, t, stop) {
  var want = p.off + stopLine(p, stop), hit = stop.hit || 1, tr = t.res.trace, n = t.res.ticks;
  for (var i = 0; i < n; i++) if (tr[i] === want && --hit === 0) return i;
  return -1;
}
function trimOut(s) { return s.replace(/\s+$/, ''); }
function hot(profile) { var best = '', n = -1; for (var k in profile) if (k !== '(top level)' && profile[k] > n) { n = profile[k]; best = k; } return best || '(top level)'; }
var REGNO = { r0: 0, r1: 1, r2: 2, r3: 3, r4: 4, r5: 5, r6: 6, r7: 7, r8: 8, r9: 9, r10: 10, r11: 11, r12: 12, sp: 13, lr: 14, pc: 15 };
function hex(v) { return '0x' + (v >>> 0).toString(16); }
function findSym(st, name) { for (var i = 0; i < st.syms.length; i++) if (st.syms[i].name === name) return st.syms[i]; return null; }
function measure(st, t, verify, p) {
  var m = /^(\w+)(?::(.+))?$/.exec(verify), kind = m[1], arg = m[2], s, mm;
  switch (kind) {
    case 'out': return trimOut(st.out);
    case 'clock': return String(st.clock);
    case 'live': return String(st.live);
    case 'peak': return String(st.peak);
    case 'stack': return String(st.stack);
    case 'data': return String(st.data);
    case 'error': return st.error ? st.error.type : 'No error';
    case 'alldata': return String(t.res.dataBytes || 0);
    case 'allcode': return String(t.res.codeBytes || 0);
    case 'exit': return st.exit === null ? 'none' : String(st.exit);
    case 'hot': return hot(t.res.profile);
    case 'ins': case 'code': {
      var n = 0, ins = VM.assemble(p.src).ins;
      for (var i = 0; i < ins.length; i++) if (visible(p, ins[i].line)) n++;
      return String(kind === 'ins' ? n : n * 4);
    }
    case 'reg': return st.regs ? String(st.regs[REGNO[arg]]) : '(not available)';
    case 'hex': return st.regs ? hex(st.regs[REGNO[arg]]) : '(not available)';
    case 'flag': return st.flags ? String(st.flags[arg]) : '(not available)';
    case 'flags': return st.flags ? (['N', 'Z', 'C', 'V'].filter(function (f) { return st.flags[f]; }).join(' ') || 'none') : '(not available)';
    case 'bytes': s = findSym(st, arg); return s ? String(s.bytes) : '(not defined)';
    case 'addr': s = findSym(st, arg); return s ? hex(s.addr) : '(not defined)';
    case 'mem':
      mm = /^(\w+)(?:\[(\d+)\])?$/.exec(arg); s = findSym(st, mm[1]);
      if (!s) return '(not defined)';
      if (mm[2] === undefined) return s.text;
      return s.values && s.values[Number(mm[2])] !== undefined ? s.values[Number(mm[2])] : '(out of range)';
    case 'watch': return p && p.watch ? measure(st, t, p.watch[0], p) : '(not available)';
  }
  throw new Error('bad verify: ' + verify);
}
function labelOf(verify) {
  var m = /^(\w+)(?::(.+))?$/.exec(verify), k = m[1];
  return { out: 'Output', clock: 'Clock', live: 'Memory now', peak: 'Peak memory', stack: 'Stack in use', data: 'Data bytes', error: 'Result', exit: 'Exit code', hot: 'Most ticks', ins: 'Instructions', code: 'Code bytes', flags: 'Flags set', alldata: 'Data bytes', allcode: 'Code bytes' }[k] ||
    (k === 'reg' || k === 'hex' ? m[2] : k === 'flag' ? m[2] + ' flag' : k === 'bytes' ? 'Bytes of ' + m[2] : k === 'addr' ? 'Address of ' + m[2] : m[2]);
}
// Truth for a predict / inspect step.
function truth(step, codeOverride) {
  var p = program(step, codeOverride), t = trace(p), idx = t.res.ticks;
  if (step.stop) { idx = stopIndex(p, t, step.stop); if (idx < 0) return { value: '(line never reached)', p: p, t: t, st: stateAt(p, t, t.res.ticks) }; }
  var st = stateAt(p, t, idx);
  return { value: measure(st, t, step.verify, p), p: p, t: t, st: st };
}
// Duel: which variant has the smaller (or larger) metric.
function duel(step) {
  var rows = step.variants.map(function (v) {
    var p = program(step, v.code), t = trace(p), st = stateAt(p, t, t.res.ticks);
    return { label: v.label, value: Number(measure(st, t, step.metric, p)), st: st };
  });
  var a = rows[0].value, b = rows[1].value;
  var want = step.want === 'more' ? (a > b ? 0 : b > a ? 1 : 2) : (a < b ? 0 : b < a ? 1 : 2);
  return { rows: rows, winner: want === 2 ? 'They tie' : rows[want].label };
}
// Fill: put the chosen chips into the [[n]] blanks.
function fillCode(code, picks) { return code.replace(/\[\[(\d+)\]\]/g, function (_, n) { var v = picks[Number(n) - 1]; return v === undefined || v === null ? '___' : v; }); }
// Tests for fill / write: the expected result comes from running the stored solution.
function runTests(step, code) {
  var solution = step.t === 'fill' ? fillCode(step.code, step.answer) : step.solution;
  var tests = step.tests || [{ post: step.post || '', stdin: step.stdin || '' }];
  return tests.map(function (test) {
    var checks = test.checks || step.checks || ['reg:r0'];
    function go(c) {
      var spec = { pre: step.pre, setup: step.setup, code: c, post: test.post, stdin: test.stdin, show: step.show };
      var p = program(spec), t = trace(p), st = stateAt(p, t, t.res.ticks);
      var parts = checks.map(function (ck) { return labelOf(ck) + ' = ' + measure(st, t, ck, p); });
      if (checks.indexOf('out') < 0 && trimOut(st.out) !== '') parts.push('Output = ' + trimOut(st.out));
      return { text: parts.join('; '), error: st.error, status: st.status, p: p, st: st };
    }
    var want = go(solution), got = go(code);
    var errLine = got.error ? got.st.errorLine : 0;
    return { name: test.name || '', want: want.text, wantError: want.error, got: got.error ? '' : got.text, error: got.error, errorLine: errLine, limit: got.status === 'limit', pass: !got.error && got.status === 'done' && !want.error && got.text === want.text };
  });
}
var api = { program: program, trace: trace, stateAt: stateAt, nextStop: nextStop, prevStop: prevStop, stopIndex: stopIndex, stopLine: stopLine, truth: truth, duel: duel, fillCode: fillCode, runTests: runTests, measure: measure, labelOf: labelOf, hot: hot, preParts: preParts, hex: hex, LIMIT: LIMIT };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.Emu = api;
})(typeof window !== 'undefined' ? window : globalThis);
