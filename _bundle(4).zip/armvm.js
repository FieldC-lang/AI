/* ArmVM: a small ARMv7-A (ARM state, GNU unified syntax) assembler and emulator.
   Clock = one tick per instruction fetched. Memory = bytes of data plus bytes of stack in use.
   Plain ES2017, no dependencies. tools/conf.cjs checks it against GNU as + QEMU. */
(function (root) {
'use strict';
var TEXT = 0x10000, DATA = 0x20000, STACK_SIZE = 0x10000, STACK_TOP = 0x7fff0000;
var CONDS = { eq: 0, ne: 1, cs: 2, hs: 2, cc: 3, lo: 3, mi: 4, pl: 5, vs: 6, vc: 7, hi: 8, ls: 9, ge: 10, lt: 11, gt: 12, le: 13, al: 14 };
var REGS = { sp: 13, lr: 14, pc: 15, fp: 11, ip: 12 };
for (var ri = 0; ri < 16; ri++) REGS['r' + ri] = ri;
var REGNAME = ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'r12', 'sp', 'lr', 'pc'];
// mnemonic -> [kind, allowsS]
var OPS = {
  add: ['dp', 1], adc: ['dp', 1], sub: ['dp', 1], sbc: ['dp', 1], rsb: ['dp', 1], rsc: ['dp', 1], and: ['dp', 1], orr: ['dp', 1], eor: ['dp', 1], bic: ['dp', 1],
  mov: ['mov', 1], mvn: ['mov', 1], cmp: ['cmp', 0], cmn: ['cmp', 0], tst: ['cmp', 0], teq: ['cmp', 0],
  lsl: ['sh', 1], lsr: ['sh', 1], asr: ['sh', 1], ror: ['sh', 1],
  mul: ['mul', 1], mla: ['mla', 1], mls: ['mla', 0], sdiv: ['div', 0], udiv: ['div', 0], umull: ['mull', 1], smull: ['mull', 1], clz: ['clz', 0],
  movw: ['mw', 0], movt: ['mw', 0],
  ldr: ['mem', 0], str: ['mem', 0], ldrb: ['mem', 0], strb: ['mem', 0], ldrh: ['mem', 0], strh: ['mem', 0], ldrsb: ['mem', 0], ldrsh: ['mem', 0],
  push: ['stk', 0], pop: ['stk', 0], b: ['b', 0], bl: ['b', 0], bx: ['bx', 0], blx: ['bx', 0], svc: ['svc', 0], swi: ['svc', 0], nop: ['nop', 0], adr: ['adr', 0]
};
var OPNAMES = Object.keys(OPS).sort(function (a, b) { return b.length - a.length; });
var SHIFTS = { lsl: 0, lsr: 1, asr: 2, ror: 3 };

function AsmError(line, msg) { this.line = line; this.msg = msg; }
function hex(v) { return '0x' + (v >>> 0).toString(16); }
function enc(v) { v = v >>> 0; if (v < 256) return true; for (var r = 2; r < 32; r += 2) if ((((v << r) | (v >>> (32 - r))) >>> 0) < 256) return true; return false; }

function stripComment(s) {
  var out = '', i = 0, n = s.length;
  while (i < n) {
    var c = s[i];
    if (c === '"') { var j = i + 1; while (j < n && s[j] !== '"') { if (s[j] === '\\') j++; j++; } out += s.slice(i, j + 1); i = j + 1; continue; }
    if (c === "'" && i + 2 < n && s[i + 2] === "'") { out += s.slice(i, i + 3); i += 3; continue; }
    if (c === '@' || (c === '/' && s[i + 1] === '/')) break;
    out += c; i++;
  }
  return out;
}
function splitTop(s) {
  var out = [], cur = '', depth = 0, q = false;
  for (var i = 0; i < s.length; i++) {
    var c = s[i];
    if (q) { cur += c; if (c === '\\') { cur += s[++i] || ''; } else if (c === '"') q = false; continue; }
    if (c === '"') { q = true; cur += c; continue; }
    if (c === '[' || c === '{' || c === '(') depth++;
    if (c === ']' || c === '}' || c === ')') depth--;
    if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; } else cur += c;
  }
  if (cur.trim() !== '' || out.length) out.push(cur.trim());
  return out;
}
function parseString(tok, line) {
  var m = /^"((?:[^"\\]|\\.)*)"$/.exec(tok);
  if (!m) throw new AsmError(line, 'Text must be inside double quotes, like "red"');
  var out = [], s = m[1];
  for (var i = 0; i < s.length; i++) {
    var c = s[i];
    if (c === '\\') { c = s[++i]; var map = { n: 10, t: 9, r: 13, '0': 0, '\\': 92, '"': 34 }; out.push(c in map ? map[c] : c.charCodeAt(0)); }
    else { var code = c.charCodeAt(0); if (code > 127) throw new AsmError(line, 'Only plain English letters and symbols can be used in text here'); out.push(code); }
  }
  return out;
}

// ----- expressions -----
function evalExpr(text, ctx, line) {
  var s = text.trim(), i = 0;
  if (s === '') throw new AsmError(line, 'A value is missing');
  function ws() { while (i < s.length && /\s/.test(s[i])) i++; }
  function prim() {
    ws(); var c = s[i];
    if (c === '(') { i++; var v = bor(); ws(); if (s[i] !== ')') throw new AsmError(line, 'Missing )'); i++; return v; }
    if (c === '-') { i++; return -prim(); }
    if (c === '+') { i++; return prim(); }
    if (c === '~') { i++; return ~prim(); }
    if (c === "'") { if (s[i + 2] !== "'") throw new AsmError(line, "A single character is written like 'a'"); var ch = s.charCodeAt(i + 1); i += 3; return ch; }
    var m = /^(0[xX][0-9a-fA-F]+|0[bB][01]+|\d+)(?![\w.$])/.exec(s.slice(i));
    if (m) { i += m[1].length; var t = m[1].toLowerCase(); return t.indexOf('0x') === 0 ? parseInt(t.slice(2), 16) : t.indexOf('0b') === 0 ? parseInt(t.slice(2), 2) : parseInt(t, 10); }
    m = /^[A-Za-z_.$][\w.$]*/.exec(s.slice(i));
    if (m) { i += m[0].length; return ctx(m[0], line); }
    throw new AsmError(line, 'Cannot understand the value "' + text.trim() + '"');
  }
  function mul() { var v = prim(); for (;;) { ws(); var c = s[i]; if (c === '*') { i++; v = v * prim(); } else if (c === '/' && s[i + 1] !== '/') { i++; var d = prim(); if (d === 0) throw new AsmError(line, 'Division by zero in a value'); v = Math.trunc(v / d); } else if (c === '%') { i++; v = v % prim(); } else return v; } }
  function add() { var v = mul(); for (;;) { ws(); var c = s[i]; if (c === '+') { i++; v += mul(); } else if (c === '-') { i++; v -= mul(); } else return v; } }
  function shf() { var v = add(); for (;;) { ws(); if (s.substr(i, 2) === '<<') { i += 2; v = v * Math.pow(2, add()); } else if (s.substr(i, 2) === '>>') { i += 2; v = Math.floor(v / Math.pow(2, add())); } else return v; } }
  function band() { var v = shf(); for (;;) { ws(); if (s[i] === '&') { i++; v = (v & shf()); } else return v; } }
  function bxor() { var v = band(); for (;;) { ws(); if (s[i] === '^') { i++; v = (v ^ band()); } else return v; } }
  function bor() { var v = bxor(); for (;;) { ws(); if (s[i] === '|') { i++; v = (v | bxor()); } else return v; } }
  var val = bor(); ws();
  if (i < s.length) throw new AsmError(line, 'Cannot understand the value "' + text.trim() + '"');
  return val;
}

// ----- assembler -----
function assemble(src) {
  var lines = src.split('\n'), sec = 'text';
  var raw = [], labels = {}, equs = {}, syms = [];
  var data = [], bssSize = 0, bssAlign = 4, fix = [], lastSym = { data: null, bss: null };
  function here() { return sec === 'text' ? TEXT + raw.length * 4 : sec === 'data' ? data.length : bssSize; }
  function defLabel(name, line) {
    if (labels[name] || equs[name] !== undefined) throw new AsmError(line, 'The label ' + name + ' is used twice');
    if (name in REGS) throw new AsmError(line, name + ' is a register name, so it cannot be a label');
    labels[name] = { sec: sec, off: here(), line: line };
    if (sec !== 'text') { var sy = { name: name, sec: sec, off: here(), line: line, kind: null, size: 0 }; syms.push(sy); lastSym[sec] = sy; }
  }
  function kindOf(k) { if (lastSym[sec] && lastSym[sec].kind === null && lastSym[sec].off === here()) lastSym[sec].kind = k; }
  function early(text, line) { return evalExpr(text, function (name, ln) { if (name === '.') return here(); if (equs[name] !== undefined) return early(equs[name].text, equs[name].line); throw new AsmError(ln, 'The size must use names that are already defined above (' + name + ' is not)'); }, line); }
  function alignTo(n, line) {
    if (!(n >= 1) || (n & (n - 1))) throw new AsmError(line, 'Alignment must be a power of two');
    if (sec === 'text') return;
    if (sec === 'data') while (data.length % n) data.push(0); else { while (bssSize % n) bssSize++; if (n > bssAlign) bssAlign = n; }
  }
  for (var li = 0; li < lines.length; li++) {
    var line = li + 1, t = stripComment(lines[li]).trim(), m;
    while ((m = /^([A-Za-z_.$][\w.$]*)\s*:/.exec(t))) { defLabel(m[1], line); t = t.slice(m[0].length).trim(); }
    if (t === '') continue;
    if ((m = /^([A-Za-z_$][\w.$]*)\s*=\s*(.+)$/.exec(t)) && !OPS[m[1].toLowerCase()]) { equs[m[1]] = { text: m[2], line: line }; continue; }
    if (t[0] === '.') {
      m = /^(\.\w+)\s*(.*)$/.exec(t); var d = m[1].toLowerCase(), args = splitTop(m[2]);
      switch (d) {
        case '.text': sec = 'text'; break;
        case '.data': sec = 'data'; break;
        case '.bss': sec = 'bss'; break;
        case '.section':
          if (/^\.text/.test(args[0])) sec = 'text'; else if (/^\.(data|rodata)/.test(args[0])) sec = 'data'; else if (/^\.bss/.test(args[0])) sec = 'bss'; else throw new AsmError(line, 'This emulator knows the sections .text, .data and .bss');
          break;
        case '.global': case '.globl': case '.syntax': case '.arm': case '.arch': case '.cpu': case '.fpu': case '.type': case '.size': case '.ltorg': case '.pool': case '.end': case '.file': case '.ident': break;
        case '.equ': case '.set':
          if (args.length !== 2) throw new AsmError(line, 'Write .equ like this: .equ DIM, 8');
          if (labels[args[0]]) throw new AsmError(line, 'The name ' + args[0] + ' is used twice');
          equs[args[0]] = { text: args[1], line: line }; break;
        case '.align': case '.p2align': alignTo(args.length && args[0] !== '' ? Math.pow(2, early(args[0], line)) : (d === '.align' ? 1 : 1), line); break;
        case '.balign': alignTo(early(args[0] || '', line), line); break;
        case '.space': case '.skip': case '.zero':
          if (sec === 'text') throw new AsmError(line, 'Put data after a .data or .bss line, not in the code');
          var n = early(args[0] || '', line), fill = args[1] ? early(args[1], line) : 0;
          if (!(n >= 0) || n > 1048576) throw new AsmError(line, 'That is too much space for this emulator (limit 1 MB)');
          kindOf('space');
          if (sec === 'data') for (var z = 0; z < n; z++) data.push(fill & 255); else { if (fill) throw new AsmError(line, '.bss memory always starts as zeros'); bssSize += n; }
          break;
        case '.word': case '.long': case '.int': case '.4byte': case '.hword': case '.short': case '.2byte': case '.byte': case '.1byte':
          if (sec !== 'data') throw new AsmError(line, sec === 'text' ? 'Put data after a .data line, not in the code' : 'A .bss section can only reserve space. Put starting values in .data');
          var size = /word|long|int|4byte/.test(d) && d !== '.hword' ? 4 : /hword|short|2byte/.test(d) ? 2 : 1;
          if (!args.length || args[0] === '') throw new AsmError(line, d + ' needs at least one value');
          kindOf(size === 4 ? 'word' : size === 2 ? 'half' : 'byte');
          for (var a = 0; a < args.length; a++) { fix.push({ off: data.length, size: size, text: args[a], line: line, at: data.length }); for (var b = 0; b < size; b++) data.push(0); }
          break;
        case '.ascii': case '.asciz': case '.string':
          if (sec !== 'data') throw new AsmError(line, 'Put text after a .data line');
          kindOf('str');
          for (var s2 = 0; s2 < args.length; s2++) { var bytes = parseString(args[s2], line); for (var q = 0; q < bytes.length; q++) data.push(bytes[q]); if (d !== '.ascii') data.push(0); }
          break;
        default: throw new AsmError(line, 'Unknown directive ' + m[1]);
      }
      continue;
    }
    if (sec !== 'text') throw new AsmError(line, 'Instructions belong in the code. Add a .text line before this one');
    raw.push({ line: line, text: t });
  }
  // layout
  var textEnd = TEXT + raw.length * 4, dataSize = data.length;
  var bssOff = dataSize; while (bssOff % bssAlign) bssOff++;
  var total = bssOff + bssSize;
  function addrOf(l) { return l.sec === 'text' ? l.off : DATA + (l.sec === 'data' ? l.off : bssOff + l.off); }
  var depth = 0;
  function lookup(dot) {
    return function (name, line) {
      if (name === '.') return dot;
      if (labels[name]) return addrOf(labels[name]);
      if (equs[name] !== undefined) { if (++depth > 50) { depth = 0; throw new AsmError(line, 'The name ' + name + ' is defined in terms of itself'); } var v = evalExpr(equs[name].text, lookup(dot), equs[name].line); depth--; return v; }
      if (name.toLowerCase() in REGS) throw new AsmError(line, 'A register cannot be used here: ' + name);
      throw new AsmError(line, 'There is no label or name called ' + name);
    };
  }
  var mem = new Uint8Array(total);
  for (var di = 0; di < dataSize; di++) mem[di] = data[di];
  for (var f = 0; f < fix.length; f++) {
    var fx = fix[f], v = evalExpr(fx.text, lookup(DATA + fx.at), fx.line);
    var lo = fx.size === 1 ? -128 : fx.size === 2 ? -32768 : -2147483648, hi = fx.size === 1 ? 255 : fx.size === 2 ? 65535 : 4294967295;
    if (v < lo || v > hi) throw new AsmError(fx.line, 'The value ' + v + ' does not fit in ' + fx.size + (fx.size === 1 ? ' byte' : ' bytes'));
    for (var k = 0; k < fx.size; k++) mem[fx.off + k] = Math.floor(v / Math.pow(2, 8 * k)) & 255;
  }
  // symbol sizes
  var bySec = { data: [], bss: [] };
  syms.forEach(function (s) { bySec[s.sec].push(s); });
  ['data', 'bss'].forEach(function (sc) {
    var list = bySec[sc], end = sc === 'data' ? dataSize : bssSize;
    for (var i = 0; i < list.length; i++) { list[i].size = (i + 1 < list.length ? list[i + 1].off : end) - list[i].off; list[i].addr = DATA + (sc === 'data' ? list[i].off : bssOff + list[i].off); if (!list[i].kind) list[i].kind = 'space'; }
  });
  syms = syms.filter(function (s) { return s.size > 0; });
  // instructions
  var ins = [], callTargets = {};
  for (var ii = 0; ii < raw.length; ii++) ins.push(parseIns(raw[ii], TEXT + ii * 4, lookup(TEXT + ii * 4), textEnd, labels, callTargets));
  // function names for profile / call stack
  var textLabels = Object.keys(labels).filter(function (n) { return labels[n].sec === 'text'; }).sort(function (a, b) { return labels[a].off - labels[b].off; });
  var funcs = ['(top level)'], funcOf = new Int32Array(raw.length + 1), cur = 0, tl = 0, nameAt = {};
  for (var x = 0; x <= raw.length; x++) {
    while (tl < textLabels.length && labels[textLabels[tl]].off === TEXT + x * 4) { var nm = textLabels[tl++]; nameAt[x] = nameAt[x] || nm; if (callTargets[nm] || nm === '_start' || nm === 'main') { funcs.push(nm); cur = funcs.length - 1; } }
    funcOf[x] = cur;
  }
  return { ins: ins, labels: labels, addrOf: addrOf, syms: syms, mem: mem, total: total, dataSize: dataSize, bssOff: bssOff, textEnd: textEnd, funcs: funcs, funcOf: funcOf, nameAt: nameAt, lines: lines.length };
}

function parseIns(r, addr, ctx, textEnd, labels, callTargets) {
  var line = r.line, m = /^(\S+)\s*(.*)$/.exec(r.text), mn = m[1].toLowerCase(), rest = m[2].trim();
  var base = null, s = 0, cond = 14;
  for (var i = 0; i < OPNAMES.length && !base; i++) {
    var b = OPNAMES[i];
    if (mn.indexOf(b) !== 0) continue;
    var tail = mn.slice(b.length), ss = 0;
    if (OPS[b][1] && tail[0] === 's' && !(tail in CONDS)) { ss = 1; tail = tail.slice(1); }
    if (tail === '') { base = b; s = ss; } else if (tail in CONDS) { base = b; s = ss; cond = CONDS[tail]; }
  }
  if (!base) throw new AsmError(line, 'Unknown instruction: ' + m[1]);
  var kind = OPS[base][0], ops = splitTop(rest);
  var I = { op: base, kind: kind, cond: cond, s: s, line: line, addr: addr, rd: -1, rn: -1, rm: -1, rs: -1, imm: 0, immC: -1, sh: 0, shImm: 0 };
  function reg(t, what) {
    var k = (t || '').toLowerCase();
    if (!(k in REGS)) throw new AsmError(line, t ? '"' + t + '" is not a register. Registers are r0 to r12, sp, lr and pc' : base + ' is missing ' + (what || 'a register'));
    return REGS[k];
  }
  function isReg(t) { return (t || '').toLowerCase() in REGS; }
  function imm(t) {
    if (t[0] !== '#') throw new AsmError(line, 'Put # in front of a number, like #' + t.replace(/^=/, ''));
    return evalExpr(t.slice(1), ctx, line);
  }
  function need(n, shape) { if (ops.length < n[0] || ops.length > n[1]) throw new AsmError(line, 'Write it like this: ' + shape); }
  function fits(v, how) {
    var ok = how === 'mov' ? (enc(v) || enc(~v) || (!s && v >= 0 && v <= 0xffff)) : how === 'neg' ? (enc(v) || enc(-v)) : how === 'not' ? (enc(v) || enc(~v)) : enc(v);
    if (!ok) throw new AsmError(line, 'The number ' + v + ' does not fit inside one instruction. Load it with: ldr r0, =' + v);
    return v | 0;
  }
  // operand 2 from ops[k..]
  function op2(k, how) {
    var t = ops[k];
    if (t === undefined) throw new AsmError(line, base + ' needs one more value');
    if (t[0] === '#') {
      if (ops.length > k + 1) throw new AsmError(line, 'Too many values for ' + base);
      var v = imm(t); I.imm = fits(v, how); var used = enc(v) ? v : ~v; I.immC = (used >>> 0) < 256 || (!enc(v) && how === 'mov' && !enc(~v)) ? -1 : (used >>> 31) & 1; return;
    }
    I.rm = reg(t);
    if (ops.length > k + 2) throw new AsmError(line, 'Too many values for ' + base);
    if (ops[k + 1] !== undefined) shiftSpec(ops[k + 1]);
  }
  function shiftSpec(t) {
    var mm = /^(lsl|lsr|asr|ror)\s+(.+)$/i.exec(t);
    if (!mm) throw new AsmError(line, 'Expected a shift such as lsl #2, not "' + t + '"');
    I.sh = SHIFTS[mm[1].toLowerCase()];
    if (isReg(mm[2])) { I.rs = reg(mm[2]); return; }
    var n = imm(mm[2]);
    if (n < 0 || n > 32 || (n === 32 && I.sh !== 1 && I.sh !== 2) || (n === 0 && I.sh !== 0)) throw new AsmError(line, 'A shift amount must be from ' + (I.sh === 0 ? '0 to 31' : I.sh === 3 ? '1 to 31' : '1 to 32'));
    I.shImm = n;
  }
  switch (kind) {
    case 'dp':
      need([2, 4], base + ' r0, r1, r2   or   ' + base + ' r0, r1, #5');
      I.rd = reg(ops[0]);
      if (ops.length === 2 || (ops.length === 3 && !isReg(ops[1]) ) || (ops.length === 3 && /^(lsl|lsr|asr|ror)\s/i.test(ops[2]))) { I.rn = I.rd; op2(1, how(base)); }
      else { I.rn = reg(ops[1]); op2(2, how(base)); }
      break;
    case 'mov': need([2, 3], base + ' r0, r1   or   ' + base + ' r0, #5'); I.rd = reg(ops[0]); op2(1, base === 'mov' ? 'mov' : 'not'); break;
    case 'cmp': need([2, 3], base + ' r0, r1   or   ' + base + ' r0, #5'); I.rn = reg(ops[0]); I.s = 1; op2(1, base === 'cmp' || base === 'cmn' ? 'neg' : 'plain'); break;
    case 'sh':
      need([2, 3], base + ' r0, r1, #2');
      I.rd = reg(ops[0]); I.sh = SHIFTS[base];
      var src = ops.length === 3 ? ops[1] : ops[0], amt = ops[ops.length - 1];
      I.rm = reg(src);
      if (isReg(amt)) I.rs = reg(amt);
      else { var n = imm(amt); if (n < 0 || n > 32 || (n === 32 && (I.sh === 0 || I.sh === 3))) throw new AsmError(line, 'A shift amount must be from 0 to 31'); I.shImm = n; if (n === 0) I.sh = 0; }
      break;
    case 'mul':
      need([2, 3], 'mul r0, r1, r2'); I.rd = reg(ops[0]);
      if (ops.length === 2) { I.rn = I.rd; I.rm = reg(ops[1]); } else { I.rn = reg(ops[1]); I.rm = reg(ops[2]); }
      break;
    case 'mla': need([4, 4], base + ' r0, r1, r2, r3'); I.rd = reg(ops[0]); I.rn = reg(ops[1]); I.rm = reg(ops[2]); I.rs = reg(ops[3]); break;
    case 'div':
      need([2, 3], base + ' r0, r1, r2'); I.rd = reg(ops[0]);
      if (ops.length === 2) { I.rn = I.rd; I.rm = reg(ops[1]); } else { I.rn = reg(ops[1]); I.rm = reg(ops[2]); }
      break;
    case 'mull': need([4, 4], base + ' r0, r1, r2, r3'); I.rd = reg(ops[0]); I.rs = reg(ops[1]); I.rn = reg(ops[2]); I.rm = reg(ops[3]); if (I.rd === I.rs) throw new AsmError(line, 'The two result registers must be different'); break;
    case 'clz': need([2, 2], 'clz r0, r1'); I.rd = reg(ops[0]); I.rm = reg(ops[1]); break;
    case 'mw':
      need([2, 2], base + ' r0, #1000'); I.rd = reg(ops[0]); var w = imm(ops[1]);
      if (w < 0 || w > 0xffff) throw new AsmError(line, base + ' takes a number from 0 to 65535'); I.imm = w; break;
    case 'mem': parseMem(); break;
    case 'stk':
      var lm = /^\{(.*)\}$/.exec(rest);
      if (!lm) throw new AsmError(line, 'Write it like this: ' + base + ' {r4, lr}');
      var mask = 0;
      splitTop(lm[1]).forEach(function (part) {
        var rg = /^(\w+)\s*-\s*(\w+)$/.exec(part), a = reg(rg ? rg[1] : part), z = rg ? reg(rg[2]) : a;
        if (z < a) throw new AsmError(line, 'A register range must go upwards, like r4-r7');
        for (var q = a; q <= z; q++) mask |= 1 << q;
      });
      if (!mask) throw new AsmError(line, base + ' needs at least one register');
      if (mask & (1 << 13)) throw new AsmError(line, 'sp cannot be in a push or pop list');
      if (base === 'push' && (mask & (1 << 15))) throw new AsmError(line, 'pc cannot be pushed');
      I.imm = mask; break;
    case 'b':
      need([1, 1], base + ' some_label');
      if (isReg(ops[0])) throw new AsmError(line, base + ' needs a label. To jump to an address in a register use bx ' + ops[0]);
      var lab = labels[ops[0]];
      if (!lab) throw new AsmError(line, 'There is no label called ' + ops[0]);
      if (lab.sec !== 'text') throw new AsmError(line, ops[0] + ' is data, not code, so the program cannot jump to it');
      I.imm = lab.off; if (base === 'bl') callTargets[ops[0]] = 1; break;
    case 'bx': need([1, 1], base + ' lr'); I.rm = reg(ops[0]); break;
    case 'svc': need([1, 1], 'svc #0'); I.imm = ops[0][0] === '#' ? imm(ops[0]) : evalExpr(ops[0], ctx, line); break;
    case 'nop': if (rest !== '') throw new AsmError(line, 'nop takes no values'); break;
    case 'adr':
      need([2, 2], 'adr r0, some_label'); I.rd = reg(ops[0]);
      if (!labels[ops[1]] || labels[ops[1]].sec !== 'text') throw new AsmError(line, 'adr needs a label in the code. For data use: ldr ' + ops[0] + ', =' + ops[1]);
      I.imm = labels[ops[1]].off; break;
  }
  if (I.kind !== 'mem' && I.kind !== 'b' && I.kind !== 'stk' && I.kind !== 'bx' && I.rd === 15 && I.kind !== 'mov' && I.kind !== 'dp') throw new AsmError(line, 'pc cannot be the result of ' + base);
  return I;

  function how(b) { return b === 'add' || b === 'sub' ? 'neg' : b === 'and' || b === 'bic' || b === 'adc' || b === 'sbc' ? 'not' : 'plain'; }
  function parseMem() {
    var load = base[0] === 'l';
    if (ops.length < 2) throw new AsmError(line, 'Write it like this: ' + base + ' r0, [r1]');
    I.rd = reg(ops[0]);
    I.size = /b$/.test(base) ? 1 : /h$/.test(base) ? 2 : 4; I.signed = /^ldrs/.test(base); I.load = load;
    var a = rest.slice(rest.indexOf(',') + 1).trim();
    if (a[0] === '=') {
      if (base !== 'ldr') throw new AsmError(line, 'Only ldr can load a value with =');
      I.kind = 'lit'; I.imm = evalExpr(a.slice(1), ctx, line) | 0; return;
    }
    var mm = /^\[\s*([^,\]]+?)\s*(?:,\s*([^\]]+?))?\s*\]\s*(!)?\s*(?:,\s*(.+))?$/.exec(a);
    if (!mm) {
      if (labels[a] || /^[A-Za-z_.$][\w.$]*$/.test(a)) throw new AsmError(line, 'To read memory at a label, first get its address: ldr r1, =' + a + '  then  ' + base + ' ' + ops[0] + ', [r1]');
      throw new AsmError(line, 'Write the address in square brackets, like ' + base + ' r0, [r1] or ' + base + ' r0, [r1, #4]');
    }
    I.rn = reg(mm[1]); I.pre = !mm[4]; I.wb = !!mm[3] || !!mm[4]; I.neg = false;
    if (mm[2] && mm[4]) throw new AsmError(line, 'Use an offset inside the brackets or after them, not both');
    if (mm[3] && !mm[2]) throw new AsmError(line, 'The ! needs an offset inside the brackets');
    var off = mm[2] || mm[4];
    if (!off) return;
    var parts = splitTop(off), o = parts[0];
    if (o[0] === '#') {
      if (parts.length > 1) throw new AsmError(line, 'Too many values in the address');
      var v = imm(o), lim = I.size === 4 || base === 'ldrb' || base === 'strb' ? 4095 : 255;
      if (v < -lim || v > lim) throw new AsmError(line, 'An offset here must be between -' + lim + ' and ' + lim);
      I.imm = v; return;
    }
    if (o[0] === '-') { I.neg = true; o = o.slice(1).trim(); } else if (o[0] === '+') o = o.slice(1).trim();
    I.rm = reg(o);
    if (parts.length > 2) throw new AsmError(line, 'Too many values in the address');
    if (parts[1] !== undefined) { if (lim2()) throw new AsmError(line, base + ' cannot use a shifted register in its address'); shiftSpec(parts[1]); if (I.rs >= 0) throw new AsmError(line, 'The shift amount in an address must be a number'); }
    function lim2() { return !(I.size === 4 || base === 'ldrb' || base === 'strb'); }
  }
}

// ----- execution -----
var cacheSrc = [], cacheProg = [];
function getProg(src) {
  var i = cacheSrc.indexOf(src);
  if (i >= 0) return cacheProg[i];
  var p; try { p = assemble(src); } catch (e) { if (!(e instanceof AsmError)) throw e; p = { error: e }; }
  cacheSrc.unshift(src); cacheProg.unshift(p); if (cacheSrc.length > 12) { cacheSrc.pop(); cacheProg.pop(); }
  return p;
}

function run(src, opts) {
  opts = opts || {};
  var P = getProg(src);
  if (P.error) return { status: 'error', ticks: 0, out: '', exit: null, error: { type: 'AssemblyError', line: P.error.line, msg: P.error.msg }, asm: false };
  var ins = P.ins, nIns = ins.length, textEnd = P.textEnd;
  var stackTop = opts.stackTop || STACK_TOP, stackLo = stackTop - STACK_SIZE;
  var dmem = new Uint8Array(P.mem), dEnd = DATA + P.total, smem = new Uint8Array(STACK_SIZE);
  var R = new Int32Array(16), N = 0, Z = 0, C = 0, V = 0;
  R[13] = stackTop;
  var maxTicks = opts.maxTicks || 2000000, stopAt = opts.stopAt === undefined ? -1 : opts.stopAt;
  var trace = opts.trace ? new Int32Array(4096) : null, outAt = opts.trace ? new Int32Array(4096) : null, stackAt = opts.trace ? new Int32Array(4096) : null;
  var prof = new Float64Array(P.funcs.length), funcOf = P.funcOf;
  var out = '', stdin = opts.stdin || '', inPos = 0, exit = null, status = 'done', error = null;
  var calls = [], peak = 0, ticks = 0, shC = 0;
  // entry point
  var pcI = 0;
  if (P.labels._start && P.labels._start.sec === 'text') pcI = (P.labels._start.off - TEXT) >> 2;
  else if (opts.entryLine) { pcI = nIns; for (var e = 0; e < nIns; e++) if (ins[e].line >= opts.entryLine) { pcI = e; break; } }
  var entry = pcI;

  function fault(a, what) { var inCode = (a >>> 0) >= TEXT && (a >>> 0) < textEnd; return { type: 'MemoryError', msg: inCode ? 'The program tried to ' + what + ' address ' + hex(a) + ', which holds program code, not data.' : 'The program tried to ' + what + ' address ' + hex(a) + ', which is not memory it owns. Check the address register and any offset.' }; }
  function ld(a, size) {
    a = a >>> 0; var m, o;
    if (a >= DATA && a + size <= dEnd) { m = dmem; o = a - DATA; } else if (a >= stackLo && a + size <= stackTop) { m = smem; o = a - stackLo; } else throw fault(a, 'read');
    return size === 1 ? m[o] : size === 2 ? m[o] | (m[o + 1] << 8) : (m[o] | (m[o + 1] << 8) | (m[o + 2] << 16) | (m[o + 3] << 24));
  }
  function st(a, size, v) {
    a = a >>> 0; var m, o;
    if (a >= DATA && a + size <= dEnd) { m = dmem; o = a - DATA; } else if (a >= stackLo && a + size <= stackTop) { m = smem; o = a - stackLo; } else throw fault(a, 'write to');
    m[o] = v & 255; if (size > 1) { m[o + 1] = (v >> 8) & 255; if (size > 2) { m[o + 2] = (v >> 16) & 255; m[o + 3] = (v >> 24) & 255; } }
  }
  function shift(type, v, amt, isReg) {
    shC = C;
    if (amt === 0) return v;
    switch (type) {
      case 0: if (amt < 32) { shC = (v >>> (32 - amt)) & 1; return v << amt; } shC = amt === 32 ? v & 1 : 0; return 0;
      case 1: if (amt < 32) { shC = (v >>> (amt - 1)) & 1; return v >>> amt; } shC = amt === 32 ? v >>> 31 : 0; return 0;
      case 2: if (amt < 32) { shC = (v >> (amt - 1)) & 1; return v >> amt; } shC = v >>> 31; return v >> 31;
      default: var a = amt & 31; if (a === 0) { shC = v >>> 31; return v; } var r = (v >>> a) | (v << (32 - a)); shC = r >>> 31; return r;
    }
  }
  function rd(n, I) { return n === 15 ? I.addr + 8 : R[n]; }
  function operand(I) {
    if (I.rm < 0) { shC = I.immC < 0 ? C : I.immC; return I.imm; }
    var v = rd(I.rm, I);
    if (I.rs >= 0) return shift(I.sh, v, R[I.rs] & 255, true);
    return shift(I.sh, v, I.shImm, false);
  }
  function addc(a, b, c, set) {
    var r = (a + b + c) | 0;
    if (set) { N = r < 0 ? 1 : 0; Z = r === 0 ? 1 : 0; C = (a >>> 0) + (b >>> 0) + c > 4294967295 ? 1 : 0; V = ((a ^ r) & (b ^ r)) < 0 ? 1 : 0; }
    return r;
  }
  function logic(r, set) { if (set) { N = r < 0 ? 1 : 0; Z = r === 0 ? 1 : 0; C = shC; } return r; }
  function jump(addr, I) {
    addr = addr >>> 0;
    if (addr & 1) throw { type: 'JumpError', msg: 'The program jumped to an odd address (' + hex(addr) + '). This emulator runs ARM code, not Thumb code.' };
    if (addr < TEXT || addr > textEnd || (addr & 3)) throw { type: 'JumpError', msg: 'The program jumped to address ' + hex(addr) + ', which is not part of the code.' + (addr === 0 ? (calls.length ? ' A register that should hold a return address was 0. Did a function forget to save lr before calling another function?' : ' The return address was 0: nothing called this code, so there is nowhere to go back to.') : '') };
    if (calls.length && calls[calls.length - 1].ret === addr) calls.pop();
    return (addr - TEXT) >> 2;
  }
  function mulhi(a, b, signed) {
    var a0 = a & 0xffff, a1 = signed ? a >> 16 : a >>> 16, b0 = b & 0xffff, b1 = signed ? b >> 16 : b >>> 16;
    var p00 = a0 * b0, mid = a1 * b0 + a0 * b1 + Math.floor(p00 / 65536);
    return (a1 * b1 + Math.floor(mid / 65536)) | 0;
  }

  try {
    for (;;) {
      if (pcI >= nIns) { status = 'done'; break; }
      if (ticks === stopAt) { status = 'paused'; break; }
      if (ticks >= maxTicks) { status = 'limit'; error = { type: 'TimeLimit', msg: 'The program ran for ' + maxTicks.toLocaleString('en-US') + ' ticks without finishing, so the emulator stopped it. A loop probably never ends.', line: ins[pcI].line }; break; }
      var I = ins[pcI], next = pcI + 1, c = I.cond, pass;
      if (trace) {
        if (ticks >= trace.length) { var bigger = new Int32Array(trace.length * 2); bigger.set(trace); trace = bigger; bigger = new Int32Array(trace.length); bigger.set(outAt); outAt = bigger; bigger = new Int32Array(trace.length); bigger.set(stackAt); stackAt = bigger; }
        trace[ticks] = I.line; outAt[ticks] = out.length; var dp = stackTop - R[13]; stackAt[ticks] = dp < 0 || dp > STACK_SIZE ? 0 : dp;
      }
      prof[funcOf[pcI]]++;
      ticks++;
      if (c === 14) pass = true; else switch (c) {
        case 0: pass = Z === 1; break; case 1: pass = Z === 0; break; case 2: pass = C === 1; break; case 3: pass = C === 0; break;
        case 4: pass = N === 1; break; case 5: pass = N === 0; break; case 6: pass = V === 1; break; case 7: pass = V === 0; break;
        case 8: pass = C === 1 && Z === 0; break; case 9: pass = C === 0 || Z === 1; break; case 10: pass = N === V; break; case 11: pass = N !== V; break;
        case 12: pass = Z === 0 && N === V; break; default: pass = Z === 1 || N !== V;
      }
      if (pass) {
        var a, b, r, set = I.s === 1;
        switch (I.kind) {
          case 'dp':
            a = rd(I.rn, I); b = operand(I);
            switch (I.op) {
              case 'add': r = addc(a, b, 0, set); break; case 'adc': r = addc(a, b, C, set); break;
              case 'sub': r = addc(a, ~b, 1, set); break; case 'sbc': r = addc(a, ~b, C, set); break;
              case 'rsb': r = addc(b, ~a, 1, set); break; case 'rsc': r = addc(b, ~a, C, set); break;
              case 'and': r = logic(a & b, set); break; case 'orr': r = logic(a | b, set); break;
              case 'eor': r = logic(a ^ b, set); break; default: r = logic(a & ~b, set);
            }
            if (I.rd === 15) next = jump(r, I); else R[I.rd] = r;
            break;
          case 'mov':
            b = operand(I); r = logic(I.op === 'mov' ? b : ~b, set);
            if (I.rd === 15) next = jump(r, I); else R[I.rd] = r;
            break;
          case 'cmp':
            a = rd(I.rn, I); b = operand(I);
            if (I.op === 'cmp') addc(a, ~b, 1, true); else if (I.op === 'cmn') addc(a, b, 0, true); else if (I.op === 'tst') logic(a & b, true); else logic(a ^ b, true);
            break;
          case 'sh': r = I.rs >= 0 ? shift(I.sh, R[I.rm], R[I.rs] & 255, true) : shift(I.sh, R[I.rm], I.shImm, false); R[I.rd] = logic(r, set); break;
          case 'mul': r = Math.imul(R[I.rn], R[I.rm]); R[I.rd] = r; if (set) { N = r < 0 ? 1 : 0; Z = r === 0 ? 1 : 0; } break;
          case 'mla':
            r = Math.imul(R[I.rn], R[I.rm]); r = I.op === 'mla' ? (r + R[I.rs]) | 0 : (R[I.rs] - r) | 0; R[I.rd] = r;
            if (set) { N = r < 0 ? 1 : 0; Z = r === 0 ? 1 : 0; } break;
          case 'div':
            a = R[I.rn]; b = R[I.rm];
            if (I.op === 'sdiv') r = b === 0 ? 0 : (a === -2147483648 && b === -1) ? a : (a / b) | 0;
            else r = b === 0 ? 0 : Math.floor((a >>> 0) / (b >>> 0)) | 0;
            R[I.rd] = r; break;
          case 'mull':
            a = R[I.rn]; b = R[I.rm];
            var lo = Math.imul(a, b), hi = mulhi(a, b, I.op === 'smull');
            R[I.rd] = lo; R[I.rs] = hi; if (set) { N = hi < 0 ? 1 : 0; Z = (hi === 0 && lo === 0) ? 1 : 0; } break;
          case 'clz': R[I.rd] = Math.clz32(R[I.rm]); break;
          case 'mw': if (I.op === 'movw') R[I.rd] = I.imm; else R[I.rd] = (R[I.rd] & 0xffff) | (I.imm << 16); break;
          case 'lit': R[I.rd] = I.imm; break;
          case 'adr': R[I.rd] = I.imm; break;
          case 'mem':
            var basev = rd(I.rn, I), off = I.rm >= 0 ? shift(I.sh, R[I.rm], I.shImm, false) : I.imm;
            if (I.neg) off = -off;
            var ea = I.pre ? (basev + off) | 0 : basev;
            if (I.load) {
              r = ld(ea, I.size);
              if (I.signed) r = I.size === 1 ? (r << 24) >> 24 : (r << 16) >> 16;
              if (I.wb) R[I.rn] = (basev + off) | 0;
              if (I.rd === 15) next = jump(r, I); else R[I.rd] = r;
            } else { st(ea, I.size, rd(I.rd, I)); if (I.wb) R[I.rn] = (basev + off) | 0; }
            break;
          case 'stk':
            var mask = I.imm, q, sp = R[13];
            if (I.op === 'push') {
              var cnt = 0; for (q = 0; q < 16; q++) if (mask & (1 << q)) cnt++;
              sp = (sp - 4 * cnt) | 0; var p = sp;
              for (q = 0; q < 16; q++) if (mask & (1 << q)) { st(p, 4, R[q]); p += 4; }
              R[13] = sp;
            } else {
              var newPc = -1;
              for (q = 0; q < 16; q++) if (mask & (1 << q)) { var val = ld(sp, 4); sp += 4; if (q === 15) newPc = val; else R[q] = val; }
              R[13] = sp | 0;
              if (newPc !== -1 || (mask & 0x8000)) next = jump(newPc, I);
            }
            break;
          case 'b':
            if (I.op === 'bl') { R[14] = I.addr + 4; calls.push({ name: P.nameAt[(I.imm - TEXT) >> 2] || hex(I.imm), ret: I.addr + 4 }); if (calls.length > 5000) throw { type: 'StackError', msg: 'More than 5,000 calls are waiting to return. A function probably calls itself forever.' }; next = (I.imm - TEXT) >> 2; }
            else next = (I.imm - TEXT) >> 2;
            break;
          case 'bx':
            a = R[I.rm];
            if (I.op === 'blx') { R[14] = I.addr + 4; var tgt = jump(a, I); calls.push({ name: P.nameAt[tgt] || hex(a), ret: I.addr + 4 }); next = tgt; }
            else next = jump(a, I);
            break;
          case 'svc':
            switch (R[7]) {
              case 1: exit = R[0] & 255; status = 'done'; break;
              case 3:
                if (R[0] !== 0) { R[0] = -9; break; }
                var want = R[2] >>> 0, got = 0;
                while (got < want && inPos < stdin.length) { st(R[1] + got, 1, stdin.charCodeAt(inPos++) & 255); got++; }
                R[0] = got; break;
              case 4:
                if (R[0] !== 1 && R[0] !== 2) { R[0] = -9; break; }
                var len = R[2] >>> 0, txt = '';
                if (len > 65536) throw { type: 'MemoryError', msg: 'write was asked to print ' + len + ' bytes. Check the length in r2.' };
                for (var w = 0; w < len; w++) txt += String.fromCharCode(ld(R[1] + w, 1));
                out += txt; R[0] = len;
                if (out.length > 20000) throw { type: 'OutputLimit', msg: 'The program printed more than 20,000 characters, so the emulator stopped it.' };
                break;
              default: throw { type: 'SystemCallError', msg: 'r7 holds ' + R[7] + ', which is not a system call this emulator knows. It knows 1 (exit), 3 (read) and 4 (write).' };
            }
            break;
        }
      }
      var depth = stackTop - R[13];
      if (depth > peak && depth <= STACK_SIZE) peak = depth;
      if (exit !== null) break;
      pcI = next;
    }
  } catch (err) {
    if (!err || !err.type) throw err;
    status = 'error'; error = { type: err.type, msg: err.msg, line: ins[pcI] ? ins[pcI].line : 0 };
  }
  var depthNow = stackTop - R[13]; if (depthNow < 0 || depthNow > STACK_SIZE) depthNow = 0;
  var profile = {};
  for (var pf = 0; pf < prof.length; pf++) if (prof[pf]) profile[P.funcs[pf]] = prof[pf];
  var res = {
    status: status, ticks: ticks, out: out, exit: exit, error: error, asm: true,
    regs: Array.prototype.slice.call(R), flags: { N: N, Z: Z, C: C, V: V },
    line: status === 'paused' || status === 'limit' ? ins[pcI].line : 0,
    pc: pcI < nIns ? TEXT + pcI * 4 : textEnd, entry: TEXT + entry * 4,
    trace: trace, outAt: outAt, stackAt: stackAt, profile: profile, calls: calls.map(function (c) { return c.name; }),
    syms: P.syms, labels: P.labels, addrOf: P.addrOf, dataBytes: P.total, codeBytes: nIns * 4, textEnd: textEnd,
    stack: depthNow, stackPeak: peak, stackTop: stackTop, dataMem: dmem,
    read: function (addr, size) { try { return ld(addr, size); } catch (e2) { return null; } }
  };
  return res;
}

// Values of one data symbol, decoded by the way it was declared.
function symValues(res, sym) {
  var out = [], i, size = sym.kind === 'word' ? 4 : sym.kind === 'half' ? 2 : 1;
  if (sym.kind === 'space') size = sym.size % 4 === 0 && sym.addr % 4 === 0 ? 4 : 1;
  if (sym.kind === 'str') { var s = ''; for (i = 0; i < sym.size; i++) { var ch = res.read(sym.addr + i, 1); s += ch === 0 ? '\\0' : ch === 10 ? '\\n' : ch < 32 || ch > 126 ? '\\x' + (ch < 16 ? '0' : '') + ch.toString(16) : String.fromCharCode(ch); } return { size: 1, text: '"' + s + '"', values: null }; }
  for (i = 0; i + size <= sym.size; i += size) out.push(res.read(sym.addr + i, size));
  return { size: size, values: out, text: null };
}

var api = { run: run, assemble: assemble, symValues: symValues, REGNAME: REGNAME, TEXT: TEXT, DATA: DATA, STACK_TOP: STACK_TOP, hex: hex };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.ArmVM = api;
})(typeof window !== 'undefined' ? window : globalThis);
