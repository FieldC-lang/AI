/* Units 1-3. Truths are computed by the emulator at run time; tools/check.cjs verifies every step. */
(function (root) {
var U = root.UNITS = root.UNITS || [];
var ENGINE = root.ENGINE || require('./engine.js');
// Multi-line assembly without the first and last line breaks.
function asm(s) { return String(s).replace(/^\n/, '').replace(/\s+$/, ''); }
// Replace exact pieces of an engine part (throws if a piece is missing, so lessons cannot drift from the program).
function swap(src, pairs) {
  pairs.forEach(function (p) { if (src.indexOf(p[0]) < 0) throw new Error('swap: missing ' + p[0]); src = src.replace(p[0], p[1]); });
  return src;
}
root.LESSON_TOOLS = { asm: asm, swap: swap };

U.push({ id: 'u1', title: 'Meet the machine', blurb: 'Registers, memory, loops and functions on an ARM chip.', lessons: [
{ id: 'l1', title: 'Registers and the clock', blurb: 'Sixteen small boxes and one instruction per tick.', steps: [
  { t: 'learn', title: 'Your ARM machine',
    text: 'An ARM chip does its work in 16 small boxes called **registers**. Each one holds a single whole number. Assembly is a list of tiny orders, one per line: `mov` puts a number in a register, `add` adds two of them.\n\nPress **Run**. The **clock** counts one tick for every instruction. You will use it to see why BitNet is built the way it is.',
    code: asm(`
    mov r0, #5
    mov r1, #7
    add r2, r0, r1`) },
  { t: 'predict', title: 'The result goes on the left',
    text: 'The first register named is where the answer goes. `sub r1, r0, #3` means "r1 = r0 - 3". A `#` marks a plain number.',
    code: asm(`
    mov r0, #10
    sub r1, r0, #3
    add r0, r1, r1`),
    ask: 'What is in `r0` at the end?', options: ['14', '7', '20', '13'], verify: 'reg:r0',
    why: '`r1` becomes 10 - 3 = 7. Then `r0` is overwritten with 7 + 7 = 14. A register only remembers the last thing put into it.' },
  { t: 'inspect', title: 'Count the ticks',
    text: 'Press **Step** to run one instruction at a time. The yellow line is the instruction that will run next. Keep going to the end, then read the clock.',
    code: asm(`
    mov r0, #2
    add r0, r0, r0
    add r0, r0, r0
    add r0, r0, r0`),
    ask: 'How many ticks did the whole program take?', options: ['4', '3', '16', '8'], verify: 'clock', unit: 'ticks',
    why: 'Four instructions, four ticks. In this emulator every instruction costs exactly one tick, so a shorter path through the code is a faster program.' },
  { t: 'predict', title: 'Sliding bits',
    text: '`lsl` slides the bits of a number to the left. Each step doubles it. `lsr` slides to the right, and each step halves it. BitNet uses these to pull tiny weights out of a byte.',
    code: asm(`
    mov r0, #3
    lsl r1, r0, #2`),
    ask: 'What is in `r1`?', options: ['12', '6', '9', '5'], verify: 'reg:r1',
    why: 'Sliding left by 2 doubles twice: 3, 6, 12. Sliding by n multiplies by 2 to the power n.' },
  { t: 'predict', title: 'A slide inside another instruction',
    text: 'ARM can slide the last value while it does something else. `add r1, r0, r0, lsl #3` means "r1 = r0 + (r0 slid left by 3)".',
    code: asm(`
    mov r0, #6
    add r1, r0, r0, lsl #3`),
    ask: 'What is in `r1`?', options: ['54', '48', '9', '18'], verify: 'reg:r1',
    why: '6 slid left by 3 is 48, and 6 + 48 = 54. That is 6 times 9 in a single instruction. You will see this trick whenever the program needs "row times 8".' },
  { t: 'duel', title: 'Multiply or slide?',
    text: 'Both versions turn 5 into 40.',
    variants: [
      { label: 'mul', code: asm(`
    mov r0, #5
    mov r1, #8
    mul r0, r0, r1`) },
      { label: 'lsl', code: asm(`
    mov r0, #5
    lsl r0, r0, #3`) } ],
    ask: 'Which one uses fewer clock ticks?', metric: 'clock', unit: 'ticks',
    why: '`mul` needs both numbers in registers, so the 8 costs an extra `mov`. Sliding left by 3 does the same job in one instruction.' }
] },
{ id: 'l2', title: 'Memory: load and store', blurb: 'Registers are few. Everything else lives in memory.', steps: [
  { t: 'learn', title: 'Numbers that live in memory',
    text: 'Sixteen registers are not enough for a model. The rest lives in **memory**: a long row of numbered bytes. Lines after `.data` put values there, and a **label** such as `nums:` names the spot.\n\n`ldr r0, =nums` puts the **address** of `nums` in `r0`. `ldr r1, [r0]` then loads the number stored at that address. Run it and look at the **Memory** panel.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    ldr r1, [r0]
    ldr r2, [r0, #4]`) },
  { t: 'predict', title: 'Four bytes per word',
    text: 'A `.word` is 4 bytes wide. So the second number sits 4 bytes after the first, and the third 8 bytes after it.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    ldr r2, [r0, #8]`),
    ask: 'What is loaded into `r2`?', options: ['7', '8', '6', '5'], verify: 'reg:r2',
    why: '`[r0, #8]` means "the address in r0, plus 8". Eight bytes in is the third word, which holds 7.' },
  { t: 'predict', title: 'Storing a number',
    text: '`str` goes the other way: it copies a register **into** memory.',
    code: asm(`
.data
box: .word 1, 2, 3
.text
    ldr r0, =box
    mov r1, #9
    str r1, [r0, #4]`),
    ask: 'What does `box` hold afterwards?', options: ['1, 9, 3', '9, 2, 3', '1, 2, 9', '1, 2, 3'], verify: 'mem:box',
    why: 'Four bytes past the start is the second word, so the 2 is replaced by 9. The model will store its results this way.' },
  { t: 'duel', title: 'Bytes or words?',
    text: 'Both versions keep the same eight small numbers. One uses `.byte` (1 byte each, loaded with `ldrb`). The other uses `.word` (4 bytes each).',
    variants: [
      { label: '.byte', code: asm(`
.data
w: .byte 1, 0, 1, 1, 0, 1, 0, 1
.text
    ldr r0, =w
    ldrb r1, [r0, #2]`) },
      { label: '.word', code: asm(`
.data
w: .word 1, 0, 1, 1, 0, 1, 0, 1
.text
    ldr r0, =w
    ldr r1, [r0, #8]`) } ],
    ask: 'Which version uses more memory?', metric: 'live', want: 'more', unit: 'bytes',
    why: 'Eight words take 32 bytes. Eight bytes take 8. Small numbers do not need a whole word, and BitNet pushes this idea much further: its weights need only 2 bits each.' },
  { t: 'predict', title: 'A register as the position',
    text: 'The position can come from a second register. `ldrb r2, [r0, r1]` loads the byte at address `r0 + r1`.',
    code: asm(`
.data
w: .byte 10, 20, 30, 40
.text
    ldr r0, =w
    mov r1, #2
    ldrb r2, [r0, r1]`),
    ask: 'What is loaded into `r2`?', options: ['30', '20', '2', '40'], verify: 'reg:r2',
    why: 'Counting starts at 0, so position 2 is the third byte: 30.' },
  { t: 'fill', title: 'Word number 2',
    text: 'For words, position 2 is 8 bytes in, not 2. Slide the position left so it counts in steps of 4 bytes.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    mov r1, #2
    ldr r2, [r0, r1, [[1]]]`),
    chips: ['lsl #2', 'lsl #1', 'lsl #3', 'lsr #2'], answer: ['lsl #2'], checks: ['reg:r2'],
    why: '`lsl #2` multiplies the position by 4, the width of a word. `[r0, r1, lsl #2]` is how every list of words in the model is read.' }
] },
{ id: 'l3', title: 'Compare, branch, loop', blurb: 'How a straight list of instructions learns to repeat.', steps: [
  { t: 'learn', title: 'A loop',
    text: '`cmp` compares two values and records the result in four one-bit **flags** (N, Z, C, V). A **branch** then jumps or not depending on those flags. `blt loop` means "branch to `loop` if the first value was less than the second".\n\nThis program adds up three numbers. Step through it and watch `r1` count 0, 1, 2.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    mov r1, #0            @ position
    mov r2, #0            @ total
loop:
    ldr r3, [r0, r1, lsl #2]
    add r2, r2, r3
    add r1, r1, #1
    cmp r1, #3
    blt loop`) },
  { t: 'predict', title: 'Instructions with a condition',
    text: 'On ARM almost any instruction can carry a condition. `movgt` is "mov, but only if the last compare said greater than". `movle` is "only if less or equal".',
    code: asm(`
    mov r0, #7
    mov r1, #0
    cmp r0, #5
    movgt r1, #1
    movle r1, #2`),
    ask: 'What is in `r1` at the end?', options: ['1', '2', '0', '7'], verify: 'reg:r1',
    why: '7 is greater than 5, so `movgt` runs and `movle` is skipped. A skipped instruction still costs one tick. These conditional instructions are how BitNet will add, subtract or skip.' },
  { t: 'inspect', title: 'What a loop costs',
    text: 'Run the adding loop to the end and read the clock.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    mov r1, #0
    mov r2, #0
loop:
    ldr r3, [r0, r1, lsl #2]
    add r2, r2, r3
    add r1, r1, #1
    cmp r1, #3
    blt loop`),
    ask: 'How many ticks did the whole program take?', options: ['18', '8', '15', '24'], verify: 'clock', unit: 'ticks',
    why: 'Three instructions set things up. The loop body is five instructions and runs three times: 3 + 5 x 3 = 18. Whatever is inside a loop is paid for again and again.' },
  { t: 'inspect', title: 'Stop in the middle',
    text: 'The red dot is a **breakpoint**. Press **Run** and the program pauses each time it reaches that line. Run to the **second** stop, then read `r2` in the Registers panel.',
    code: asm(`
.data
nums: .word 5, 6, 7
.text
    ldr r0, =nums
    mov r1, #0
    mov r2, #0
loop:
    ldr r3, [r0, r1, lsl #2]
    add r2, r2, r3
    add r1, r1, #1
    cmp r1, #3
    blt loop`),
    stop: { match: 'blt loop', hit: 2 },
    ask: 'What is in `r2` at the second stop?', options: ['11', '5', '18', '6'], verify: 'reg:r2',
    why: 'By the second time round, the loop has added 5 and 6. The 7 comes on the third trip.' },
  { t: 'duel', title: 'Count up or count down?',
    text: 'Both loops run ten times. Version B counts **down** and uses `subs`: subtract, and set the flags at the same time. `bne` means "branch if the result was not zero".',
    variants: [
      { label: 'Count up', code: asm(`
    mov r0, #0
    mov r1, #0
loop:
    add r0, r0, #2
    add r1, r1, #1
    cmp r1, #10
    blt loop`) },
      { label: 'Count down', code: asm(`
    mov r0, #0
    mov r1, #10
loop:
    add r0, r0, #2
    subs r1, r1, #1
    bne loop`) } ],
    ask: 'Which one uses fewer clock ticks?', metric: 'clock', unit: 'ticks',
    why: 'An `s` on the end of an instruction makes it set the flags, so the separate `cmp` is not needed. One instruction saved, ten times over.' },
  { t: 'fill', title: 'Finish the loop',
    text: 'This loop should add up **four** numbers and then stop.',
    code: asm(`
.data
nums: .word 5, 6, 7, 2
.text
    ldr r0, =nums
    mov r1, #0
    mov r2, #0
loop:
    ldr r3, [r0, r1, lsl #2]
    add r2, r2, r3
    add r1, r1, #1
    cmp r1, #[[1]]
    [[2]] loop`),
    chips: ['4', '3', 'blt', 'bgt', 'beq'], answer: ['4', 'blt'], checks: ['reg:r2'],
    why: 'The position runs 0, 1, 2, 3. While it is still less than 4 the loop goes round again. Total: 5 + 6 + 7 + 2 = 20.' }
] },
{ id: 'l4', title: 'Functions and the stack', blurb: 'Calling, returning, and keeping things safe in between.', steps: [
  { t: 'learn', title: 'Call and return',
    text: 'A **function** is a labelled piece of code you can jump into and come back from. `bl double` ("branch and link") jumps to `double` and saves the way back in the register `lr`. `bx lr` jumps back.\n\nBy agreement, the inputs go in `r0` to `r3` and the answer comes back in `r0`. A program with functions starts at the label `_start`.',
    code: asm(`
double:
    add r0, r0, r0
    bx lr
_start:
    mov r0, #4
    bl double
    bl double`) },
  { t: 'predict', title: 'A function that calls a function',
    text: '`quad` calls `double` twice. Remember that **every** `bl` writes a new return address into `lr`. Think about what `lr` holds when `quad` reaches its own `bx lr`.\n\n`TimeLimit` means the program never finishes and the emulator has to stop it.',
    code: asm(`
double:
    add r0, r0, r0
    bx lr
quad:
    bl double
    bl double
    bx lr
_start:
    mov r0, #3
    bl quad`),
    ask: 'What happens when this runs?', options: ['TimeLimit', 'No error', 'JumpError', 'MemoryError'], verify: 'error',
    why: 'The second `bl double` left `lr` pointing at the line after it, which is quad\'s own `bx lr`. So that `bx lr` jumps to itself, forever. The way back to `_start` was overwritten and lost.' },
  { t: 'learn', title: 'The stack keeps things safe',
    text: 'The **stack** is scratch memory. `push {lr}` saves `lr` there before it can be overwritten. `pop {pc}` takes the saved address back and puts it straight into `pc`, the register that says which instruction runs next. That is a return.\n\nStep through and watch **Memory now** rise by 4 bytes while `quad` is running.',
    code: asm(`
double:
    add r0, r0, r0
    bx lr
quad:
    push {lr}
    bl double
    bl double
    pop {pc}
_start:
    mov r0, #3
    bl quad`) },
  { t: 'predict', title: 'Whose registers are these?',
    text: 'Another agreement: `r4` to `r11` belong to the **caller**. A function may use them only if it saves them first and puts them back before it returns.',
    code: asm(`
square_sum:
    push {r4, r5}
    mul r4, r0, r0
    mul r5, r1, r1
    add r0, r4, r5
    pop {r4, r5}
    bx lr
_start:
    mov r4, #99
    mov r0, #3
    mov r1, #4
    bl square_sum`),
    ask: 'After the call, what is in `r4`?', options: ['99', '9', '25', '16'], verify: 'reg:r4',
    why: 'The function used `r4` for 3 x 3 = 9, but `pop` restored the 99 before returning. The answer, 25, came back in `r0`. Every big function in the model starts with a `push` and ends with a `pop` for this reason.' },
  { t: 'inspect', title: 'How deep did the stack go?',
    text: 'Run the same program to the end and read **Peak memory**. This program has no `.data`, so the only memory it uses is the stack.',
    code: asm(`
square_sum:
    push {r4, r5}
    mul r4, r0, r0
    mul r5, r1, r1
    add r0, r4, r5
    pop {r4, r5}
    bx lr
_start:
    mov r4, #99
    mov r0, #3
    mov r1, #4
    bl square_sum`),
    ask: 'What was the peak memory?', options: ['8', '0', '4', '16'], verify: 'peak', unit: 'bytes',
    why: 'Two registers were pushed, 4 bytes each. After the `pop` the stack is empty again, so **Memory now** ends at 0 but the peak was 8.' },
  { t: 'write', title: 'Write a function',
    text: 'Write `triple`. It receives a number in `r0` and must return three times that number in `r0`.',
    code: asm(`
triple:
    @ make r0 three times bigger
    bx lr`),
    solution: asm(`
triple:
    add r0, r0, r0, lsl #1
    bx lr`),
    tests: [
      { name: 'triple(7)', post: '_start:\n    mov r0, #7\n    bl triple' },
      { name: 'triple(100)', post: '_start:\n    mov r0, #100\n    bl triple' } ],
    hint: 'r0 + r0 + r0 needs somewhere to keep a copy: `add r1, r0, r0` then `add r0, r0, r1`. Or do it in one line with a slide: `add r0, r0, r0, lsl #1`.',
    why: 'Three times a number is the number plus twice the number. The slide gives you "twice" for free.' }
] } ] });

U.push({ id: 'u2', title: 'Three-value weights', blurb: 'The one idea that makes BitNet small: every weight is -1, 0 or +1.', lessons: [
{ id: 'l5', title: 'Add, subtract, skip', blurb: 'What multiplying by a weight turns into.', steps: [
  { t: 'learn', title: 'No multiplying needed',
    text: 'A language model is mostly one job repeated: take a list of inputs, multiply each by a **weight**, and add up the results. Ordinary models use weights like 0.4137.\n\nIn BitNet every weight is **-1, 0 or +1**. So "multiply" becomes: add the input, subtract it, or skip it. `ldrsb` loads one byte and keeps its sign. `cmn r3, #1` asks "is r3 equal to -1?". The Memory panel shows raw bytes, so the weight -1 appears there as 255.',
    code: asm(`
.data
x: .word 5, 3, 2
w: .byte 1, -1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0            @ total
    mov r1, #0            @ position
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrsb r3, [r5, r1]    @ the weight
    cmp r3, #1
    addeq r0, r0, r2      @ +1: add
    cmn r3, #1
    subeq r0, r0, r2      @ -1: subtract
    add r1, r1, #1
    cmp r1, #3
    blt loop`) },
  { t: 'predict', title: 'Work one out',
    text: 'Same loop, new numbers. The weights are -1, +1, +1 and 0.',
    code: asm(`
.data
x: .word 4, 6, 1, 9
w: .byte -1, 1, 1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrsb r3, [r5, r1]
    cmp r3, #1
    addeq r0, r0, r2
    cmn r3, #1
    subeq r0, r0, r2
    add r1, r1, #1
    cmp r1, #4
    blt loop`),
    ask: 'What is the total in `r0`?', options: ['3', '20', '11', '-3'], verify: 'reg:r0',
    why: 'Subtract 4, add 6, add 1, skip 9: the total is 3. A weight of 0 means "this input does not matter here".' },
  { t: 'experiment', title: 'Signed or unsigned?',
    text: 'Version A loads each weight with `ldrsb`. Version B uses `ldrb`, which loads the same byte but treats it as a number from 0 to 255. Run both and compare `r0`.',
    variants: [
      { label: 'ldrsb', code: asm(`
.data
x: .word 5, 3, 2
w: .byte 1, -1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrsb r3, [r5, r1]
    cmp r3, #1
    addeq r0, r0, r2
    cmn r3, #1
    subeq r0, r0, r2
    add r1, r1, #1
    cmp r1, #3
    blt loop`) },
      { label: 'ldrb', code: asm(`
.data
x: .word 5, 3, 2
w: .byte 1, -1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrb r3, [r5, r1]
    cmp r3, #1
    addeq r0, r0, r2
    cmn r3, #1
    subeq r0, r0, r2
    add r1, r1, #1
    cmp r1, #3
    blt loop`) } ],
    verify: 'reg:r0',
    ask: 'Why does the `ldrb` version get the wrong total?',
    options: ['It reads the byte for -1 as 255, so the subtract never happens', 'It loads four bytes instead of one', 'It skips the first weight', 'It adds every input twice'], answer: 0,
    why: 'In one byte, -1 is stored as the bit pattern 255. `ldrsb` stretches the sign so the register really holds -1. `ldrb` leaves 255, which is neither +1 nor -1, so that input is skipped.' },
  { t: 'inspect', title: 'The price of one weight',
    text: 'Run the three-weight loop to the end and read the clock.',
    code: asm(`
.data
x: .word 5, 3, 2
w: .byte 1, -1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrsb r3, [r5, r1]
    cmp r3, #1
    addeq r0, r0, r2
    cmn r3, #1
    subeq r0, r0, r2
    add r1, r1, #1
    cmp r1, #3
    blt loop`),
    ask: 'How many ticks did it take?', options: ['31', '13', '27', '39'], verify: 'clock', unit: 'ticks',
    why: 'Four instructions to set up, then nine per weight: 4 + 9 x 3 = 31. A real model does this for billions of weights for every word, so this little loop is where the time goes.' },
  { t: 'fill', title: 'Add or subtract',
    text: 'Put the right conditional instruction on each line. The weights are +1, -1 and 0.',
    code: asm(`
.data
x: .word 7, 2, 4
w: .byte 1, -1, 0
.text
    ldr r4, =x
    ldr r5, =w
    mov r0, #0
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    ldrsb r3, [r5, r1]
    cmp r3, #1
    [[1]] r0, r0, r2
    cmn r3, #1
    [[2]] r0, r0, r2
    add r1, r1, #1
    cmp r1, #3
    blt loop`),
    chips: ['addeq', 'subeq', 'addne', 'subne', 'add'], answer: ['addeq', 'subeq'], checks: ['reg:r0'],
    why: '`eq` means "the compare found them equal". After `cmp r3, #1` that is weight +1, so add. After `cmn r3, #1` it is weight -1, so subtract. Total: 7 - 2 = 5.' }
] },
{ id: 'l6', title: 'Where the three values come from', blurb: 'Rounding ordinary weights down to -1, 0 or +1.', steps: [
  { t: 'learn', title: 'The typical size',
    text: 'A model is trained with ordinary weights. BitNet rounds each one to -1, 0 or +1 while it trains. The first step is to find the **typical size** of the weights: the average with the signs ignored.\n\nThese four weights are stored times 100, so 90 means 0.90. `rsblt r2, r2, #0` flips a negative number to positive.',
    code: asm(`
.data
real: .word 90, -40, 10, -120
.text
    ldr r4, =real
    mov r0, #0            @ total size
    mov r1, #0
loop:
    ldr r2, [r4, r1, lsl #2]
    cmp r2, #0
    rsblt r2, r2, #0      @ negative? flip the sign
    add r0, r0, r2
    add r1, r1, #1
    cmp r1, #4
    blt loop
    lsr r0, r0, #2        @ divide by 4`) },
  { t: 'predict', title: 'Flip the sign',
    text: '`rsb` is "reverse subtract": `rsb r0, r0, #0` means "r0 = 0 - r0". With `lt` on the end it only runs when the compare said "less than".',
    code: asm(`
    ldr r0, =-9
    cmp r0, #0
    rsblt r0, r0, #0`),
    ask: 'What is in `r0` at the end?', options: ['9', '-9', '0', '18'], verify: 'reg:r0',
    why: '-9 is less than 0, so the instruction runs: 0 - (-9) = 9. A positive number would be left alone. The model uses this to measure how big its numbers are.' },
  { t: 'predict', title: 'Round to three values',
    text: 'The typical size was 65. A weight becomes +1 if it is above half of that, -1 if it is below minus half, and 0 otherwise. `squash` gets the weight in `r0` and half the typical size in `r1`.',
    code: asm(`
squash:
    cmp r0, r1
    movgt r0, #1          @ clearly positive
    bxgt lr
    cmn r0, r1            @ compare r0 with -r1
    mvnlt r0, #0          @ clearly negative: -1
    bxlt lr
    mov r0, #0            @ too small to matter
    bx lr
_start:
    mov r0, #10
    mov r1, #32
    bl squash`),
    ask: 'What does the weight 10 (meaning 0.10) become?', options: ['0', '1', '-1', '10'], verify: 'reg:r0',
    why: '10 is between -32 and +32, so it rounds to 0. Three possible values carry about 1.58 bits of information each, which is where the name "1.58-bit" comes from.' },
  { t: 'fill', title: 'Finish squash',
    text: 'Fill in the two conditional instructions. `mvn r0, #0` puts -1 in `r0`.',
    code: asm(`
squash:
    cmp r0, r1
    [[1]] r0, #1
    bxgt lr
    cmn r0, r1
    [[2]] r0, #0
    bxlt lr
    mov r0, #0
    bx lr`),
    chips: ['movgt', 'mvnlt', 'movlt', 'mvngt'], answer: ['movgt', 'mvnlt'],
    tests: [
      { name: 'squash(90)', post: '_start:\n    mov r0, #90\n    mov r1, #32\n    bl squash' },
      { name: 'squash(-40)', post: '_start:\n    ldr r0, =-40\n    mov r1, #32\n    bl squash' },
      { name: 'squash(10)', post: '_start:\n    mov r0, #10\n    mov r1, #32\n    bl squash' } ],
    why: 'The model file you will load already holds weights rounded like this. The real BitNet does the rounding during training, so the model learns to work well with only three values.' }
] },
{ id: 'l7', title: 'Four weights in one byte', blurb: 'Packing, and the function that unpacks.', unlock: ['weight_at'], steps: [
  { t: 'learn', title: 'Two bits are enough',
    text: 'Two bits can hold four different values. BitNet stores each weight **plus one** in two bits: 0 means -1, 1 means 0, and 2 means +1. Four weights fit in one byte.\n\nThe byte 145 is `10 01 00 01` in binary: the weights +1, 0, -1, 0. To read the first one, slide it down to the bottom, keep two bits with `and`, and take away 1.',
    code: asm(`
    mov r0, #145          @ binary 10 01 00 01
    lsr r1, r0, #6        @ slide the first pair down
    and r1, r1, #3        @ keep only 2 bits
    sub r1, r1, #1        @ 2 becomes +1`) },
  { t: 'predict', title: 'The third weight',
    text: 'The third pair of bits in `10 01 00 01` needs a slide of 2 to reach the bottom.',
    code: asm(`
    mov r0, #145          @ binary 10 01 00 01
    lsr r1, r0, #2
    and r1, r1, #3
    sub r1, r1, #1`),
    ask: 'What is in `r1` at the end?', options: ['-1', '0', '1', '2'], verify: 'reg:r1',
    why: 'After the slide the bottom two bits are `00`. That is 0, and 0 - 1 = -1. The `and` with 3 throws away the other pairs that slid down too.' },
  { t: 'duel', title: 'Packed or not?',
    text: 'Both versions hold the same 16 weights. Version A spends a byte on each. Version B packs four to a byte.',
    variants: [
      { label: 'One byte each', code: asm(`
.data
w: .byte 1, 0, -1, 0, 1, 1, 0, 0
   .byte -1, 0, 0, 1, 0, -1, 1, 0
.text
    ldr r0, =w
    ldrsb r1, [r0]`) },
      { label: 'Packed', code: asm(`
.data
w: .byte 145, 165, 22, 73
.text
    ldr r0, =w
    ldrb r1, [r0]
    lsr r1, r1, #6
    sub r1, r1, #1`) } ],
    ask: 'Which version uses less memory?', metric: 'live', unit: 'bytes',
    why: '16 bytes against 4. Next to an ordinary model that stores each weight as a 4-byte number, packing is 16 times smaller. Size is the main reason BitNet exists.' },
  { t: 'fill', title: 'Build weight_at',
    text: '`weight_at` gets the address of the packed bytes in `r0` and a weight number in `r1`. It finds the right byte (number / 4), the right slot in it (number % 4), and returns -1, 0 or +1.',
    code: asm(`
weight_at:
    lsr r2, r1, #[[1]]     @ which byte: i / 4
    ldrb r2, [r0, r2]      @ fetch that byte
    and r3, r1, #[[2]]     @ which slot: i % 4
    lsl r3, r3, #1         @ each slot is 2 bits wide
    rsb r3, r3, #[[3]]     @ slot 0 needs the longest slide
    lsr r2, r2, r3         @ slide the slot to the bottom
    and r2, r2, #3         @ keep only those 2 bits
    sub r0, r2, #1         @ 0,1,2 becomes -1,0,+1
    bx lr`),
    chips: ['2', '3', '6', '4', '8', '1'], answer: ['2', '3', '6'],
    tests: [{ name: 'all 8 weights of the bytes 145, 6', checks: ['mem:got'], post: asm(`
.data
packed: .byte 145, 6
.bss
got: .space 32
.text
_start:
    mov r4, #0
try:
    ldr r0, =packed
    mov r1, r4
    bl weight_at
    ldr r1, =got
    str r0, [r1, r4, lsl #2]
    add r4, r4, #1
    cmp r4, #8
    blt try`) }],
    why: 'Sliding right by 2 divides by 4. `and` with 3 keeps the remainder. Slot 0 sits in the top two bits, so it needs a slide of 6; slot 3 needs none. This function is now part of your project.' },
  { t: 'predict', title: 'A weight from the real model',
    text: 'The first layer of the model begins with a scale byte and then the packed byte 169, which is `10 10 10 01`. Its address is `model+33`. This asks for weight number 3.',
    pre: 'thru:weight_at', show: ['model'],
    code: asm(`
    ldr r0, =model+33
    mov r1, #3
    bl weight_at`),
    ask: 'What comes back in `r0`?', options: ['0', '1', '-1', '3'], verify: 'reg:r0',
    why: 'Weights 0, 1 and 2 are `10`, which is +1. Weight 3 is `01`, which is 0: skip that input.' },
  { t: 'inspect', title: 'What one weight costs',
    text: 'Run it and read the clock. The clock counts the instructions inside `weight_at` too.',
    pre: 'thru:weight_at',
    code: asm(`
    ldr r0, =model+33
    mov r1, #3
    bl weight_at`),
    ask: 'How many ticks did it take to fetch one weight?', options: ['12', '3', '9', '4'], verify: 'clock', unit: 'ticks',
    why: 'Three instructions to set up and call, then nine inside the function. The model has 448 weights and uses each of them for every word. In the last unit you will see how the real BitNet avoids paying this price one weight at a time.' }
] } ] });

U.push({ id: 'u3', title: 'The model in memory', blurb: 'A model is a block of bytes with a small label on the front.', lessons: [
{ id: 'l8', title: 'The model is just bytes', blurb: 'A header, a word table, seven layers, an output table.', unlock: ['model'], steps: [
  { t: 'learn', title: 'Read the label',
    text: 'The whole model is 175 bytes placed in memory under the label `model`. It starts with an 8-byte **header** that says what the rest contains.\n\nThe first two bytes are the letters M and B (77 and 66). Byte 3 says how many numbers describe one word. Run this and look at the registers, then open `model` in the Memory panel.',
    pre: 'thru:model', show: ['model'],
    code: asm(`
    ldr r0, =model
    ldrb r1, [r0]         @ 77 is the letter M
    ldrb r2, [r0, #1]     @ 66 is the letter B
    ldrb r3, [r0, #3]     @ numbers per word`) },
  { t: 'predict', title: 'How many words?',
    text: 'Byte 4 of the header says how many words the model knows. This tiny model knows `red`, `blue` and `end`.',
    pre: 'thru:model', show: ['model'],
    code: asm(`
    ldr r0, =model
    ldrb r1, [r0, #4]`),
    ask: 'What is loaded into `r1`?', options: ['3', '8', '77', '175'], verify: 'reg:r1',
    why: 'Three words. The real BitNet b1.58 2B4T model knows 128,256 word pieces, and its header is much longer, but the idea is the same: the file describes itself.' },
  { t: 'inspect', title: 'How big is it?',
    text: 'Run the program, then find `model` in the Memory panel and read its size in the **Bytes** column.',
    pre: 'thru:model', show: ['model'],
    code: asm(`
    ldr r0, =model
    ldrb r1, [r0, #4]`),
    ask: 'How many bytes is the whole model?', options: ['175', '448', '1792', '64'], verify: 'bytes:model', unit: 'bytes',
    why: '8 for the header, 24 for the word table, 7 layers of 17 bytes, and 24 for the output table. The 448 layer weights fit in 112 bytes. Stored as ordinary 4-byte numbers they would need 1,792.' },
  { t: 'inspect', title: 'Step over to the first layer',
    text: 'After the header comes the word table: 3 words times 8 numbers, one byte each. `VOCAB*DIM` is worked out by the assembler as 3 x 8 = 24. The first byte after that is the **scale** of the first layer. Run it and read `r1`.',
    pre: 'thru:model', show: ['model'],
    code: asm(`
    ldr r0, =model
    add r0, r0, #8          @ skip the header
    add r0, r0, #VOCAB*DIM  @ skip the word table
    ldrb r1, [r0]`),
    ask: 'What is the scale byte of the first layer?', options: ['16', '8', '169', '77'], verify: 'reg:r1',
    why: 'The scale is counted in eighths, so 16 means "multiply this layer\'s results by 2". Every layer is one scale byte followed by 16 bytes of packed weights.' }
] },
{ id: 'l9', title: 'Finding every part', blurb: 'load_model checks the file and notes where things are.', unlock: ['load_model'], steps: [
  { t: 'learn', title: 'A table of addresses',
    text: '`load_model` walks through the model once and writes down the **address** of each part: the word table, each of the 7 layers, and the output table. An address kept in memory like this is called a **pointer**.\n\nRun it and look at `layer_ptr` in the Memory panel. Addresses are shown starting with `0x`.',
    pre: 'thru:load_model', show: ['embed_ptr', 'layer_ptr', 'head_ptr'],
    code: asm(`
    bl load_model`) },
  { t: 'predict', title: 'A damaged file',
    text: 'This program first overwrites the letter M at the start of the model with 0, then calls `load_model`. The function returns 1 in `r0` if the file looks right and 0 if it does not.',
    pre: 'thru:load_model', show: ['model'],
    code: asm(`
    ldr r0, =model
    mov r1, #0
    strb r1, [r0]         @ spoil the first byte
    bl load_model`),
    ask: 'What comes back in `r0`?', options: ['0', '1', '77', '-1'], verify: 'reg:r0',
    why: 'The first two bytes must be 77 and 66. If they are not, these bytes are not a model of this kind, and reading them as weights would produce nonsense. Checking first is cheap protection.' },
  { t: 'inspect', title: 'How far apart are the layers?',
    text: 'This loads the addresses of layer 0 and layer 1 from the table and subtracts them. Run it and read `r3`.',
    pre: 'thru:load_model', show: ['layer_ptr'],
    code: asm(`
    bl load_model
    ldr r0, =layer_ptr
    ldr r1, [r0]          @ where layer 0 starts
    ldr r2, [r0, #4]      @ where layer 1 starts
    sub r3, r2, r1`),
    ask: 'How many bytes does one layer take?', options: ['17', '16', '64', '8'], verify: 'reg:r3', unit: 'bytes',
    why: 'One scale byte, then 64 weights at 2 bits each, which is 16 bytes. The seven layers are named q, k, v, o, gate, up and down. You will meet each of them.' },
  { t: 'fill', title: 'Build load_model',
    text: 'Fill in how far to step for each layer, and how many layers there are.',
    pre: 'upto:load_model',
    code: swap(ENGINE.parts.load_model, [['add r0, r0, #17        @ 1 scale byte + 16 weight bytes', 'add r0, r0, #[[1]]'], ['cmp r3, #7', 'cmp r3, #[[2]]']]),
    chips: ['17', '16', '7', '8', '64'], answer: ['17', '7'],
    tests: [
      { name: 'where layer 6 starts, counted from the start of the model', post: '_start:\n    bl load_model\n    ldr r1, =layer_ptr\n    ldr r1, [r1, #24]\n    ldr r2, =model\n    sub r0, r1, r2' },
      { name: 'where the output table starts', post: '_start:\n    bl load_model\n    ldr r1, =head_ptr\n    ldr r1, [r1]\n    ldr r2, =model\n    sub r0, r1, r2' } ],
    why: 'Layer 6 starts 8 + 24 + 6 x 17 = 134 bytes in, and the output table at 151. From now on, any function can find its layer with one `ldr` from the table.' }
] } ] });
})(typeof window !== 'undefined' ? window : globalThis);
