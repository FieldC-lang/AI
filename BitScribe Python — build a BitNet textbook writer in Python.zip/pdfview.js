// A small PDF reader for the PDFs that BitScribe makes (uncompressed content streams, the 14 standard fonts).
// It reads the cross-reference table, the page tree, bookmarks and fonts, and draws pages on a canvas.
(function (G) {
  const WIN = { 0x80: '€', 0x82: '‚', 0x83: 'ƒ', 0x84: '„', 0x85: '…', 0x86: '†', 0x87: '‡', 0x88: 'ˆ', 0x89: '‰', 0x8a: 'Š', 0x8b: '‹', 0x8c: 'Œ', 0x8e: 'Ž',
    0x91: '‘', 0x92: '’', 0x93: '“', 0x94: '”', 0x95: '•', 0x96: '–', 0x97: '—', 0x98: '˜', 0x99: '™', 0x9a: 'š', 0x9b: '›', 0x9c: 'œ', 0x9e: 'ž', 0x9f: 'Ÿ' };
  const winChar = (b) => WIN[b] || String.fromCharCode(b);

  // widths from AFM text (same rules as the course's load_afm)
  const WINANSI = [[0x95, 'bullet'], [0x96, 'endash'], [0x97, 'emdash'], [0x91, 'quoteleft'], [0x92, 'quoteright'], [0x93, 'quotedblleft'], [0x94, 'quotedblright'], [0x85, 'ellipsis'],
    [0xB0, 'degree'], [0xD7, 'multiply'], [0xF7, 'divide'], [0xB1, 'plusminus'], [0xB2, 'twosuperior'], [0xB3, 'threesuperior'], [0xBD, 'onehalf'], [0xB5, 'mu'], [0xA9, 'copyright'], [0xE9, 'eacute']];
  function afmWidths(text) {
    const w = new Array(256).fill(500);
    for (const line of text.split('\n')) {
      const m = /^C (-?\d+) ; WX (\d+) ; N (\S+)/.exec(line);
      if (!m) continue;
      const code = +m[1], wx = +m[2], name = m[3];
      if (code >= 32 && code <= 126 && code !== 39 && code !== 96) w[code] = wx;
      if (name === 'quotesingle') w[39] = wx;
      if (name === 'grave') w[96] = wx;
      for (const [c, g] of WINANSI) if (g === name) w[c] = wx;
    }
    return w;
  }

  class PdfDoc {
    constructor(bytes, afm) {
      this.b = bytes;
      this.afm = afm || {};
      this.widthCache = {};
      const tail = this.str(Math.max(0, bytes.length - 64), bytes.length);
      const m = /startxref\s+(\d+)/.exec(tail);
      if (!m) throw new Error('this file has no startxref - it is not a complete PDF');
      const xref = +m[1];
      const head = this.str(xref, Math.min(bytes.length, xref + 40));
      const h = /^xref\s+(\d+)\s+(\d+)\s*\n/.exec(head);
      if (!h) throw new Error('startxref does not point at an xref table');
      this.nobj = +h[2];
      const rows = xref + h[0].length;
      this.off = [];
      for (let i = 0; i < this.nobj; i++) this.off.push(parseInt(this.str(rows + 20 * i, rows + 20 * i + 10), 10));
      const cat = this.obj(1);
      const pagesRef = /\/Pages\s+(\d+)\s+0\s+R/.exec(cat);
      if (!pagesRef) throw new Error('no page tree');
      const kids = /\/Kids\s*\[([^\]]*)\]/.exec(this.obj(+pagesRef[1]));
      this.pages = kids ? [...kids[1].matchAll(/(\d+)\s+0\s+R/g)].map(x => +x[1]) : [];
      this.fonts = {};
      const page0 = this.pages.length ? this.obj(this.pages[0]) : '';
      const resRef = /\/Resources\s+(\d+)\s+0\s+R/.exec(page0);
      const res = resRef ? this.obj(+resRef[1]) : page0;
      for (const f of res.matchAll(/\/(F\d+)\s+(\d+)\s+0\s+R/g)) {
        const bf = /\/BaseFont\s*\/([A-Za-z-]+)/.exec(this.obj(+f[2]));
        this.fonts[f[1]] = bf ? bf[1] : 'Times-Roman';
      }
      const mb = /\/MediaBox\s*\[\s*([\d.\s-]+)\]/.exec(page0);
      const box = mb ? mb[1].trim().split(/\s+/).map(Number) : [0, 0, 595.28, 841.89];
      this.w = box[2] - box[0]; this.h = box[3] - box[1];
      this.outline = this.readOutline();
    }
    str(a, b) { let s = ''; for (let i = a; i < b; i++) s += String.fromCharCode(this.b[i]); return s; }
    obj(n) {
      const a = this.off[n];
      if (!(a > 0)) return '';
      let e = a, lim = Math.min(this.b.length, a + 4000);
      // objects without streams are short; find "endobj"
      const s = this.str(a, lim);
      const k = s.indexOf('stream\n');
      const j = s.indexOf('endobj');
      if (k >= 0 && (j < 0 || k < j)) return s.slice(0, k);
      return j >= 0 ? s.slice(0, j) : s;
    }
    stream(n) {
      const a = this.off[n];
      const head = this.str(a, Math.min(this.b.length, a + 200));
      const len = /\/Length\s+(\d+)/.exec(head);
      const k = head.indexOf('stream\n');
      if (!len || k < 0) return new Uint8Array(0);
      const start = a + k + 7;
      return this.b.subarray(start, start + +len[1]);
    }
    pdfString(s) { // decode a (...) literal into bytes
      const out = [];
      for (let i = 0; i < s.length; i++) {
        let c = s.charCodeAt(i);
        if (c === 92) {
          const d = s[i + 1];
          if (/[0-7]/.test(d)) { let k = 0, v = 0; while (k < 3 && /[0-7]/.test(s[i + 1 + k])) { v = v * 8 + (+s[i + 1 + k]); k++; } out.push(v & 255); i += k; continue; }
          const map = { n: 10, r: 13, t: 9, b: 8, f: 12 };
          out.push(map[d] !== undefined ? map[d] : d.charCodeAt(0)); i++; continue;
        }
        out.push(c & 255);
      }
      return out;
    }
    readOutline() {
      const cat = this.obj(1);
      const o = /\/Outlines\s+(\d+)\s+0\s+R/.exec(cat);
      if (!o) return [];
      const first = /\/First\s+(\d+)\s+0\s+R/.exec(this.obj(+o[1]));
      const list = [];
      let n = first ? +first[1] : 0, guard = 0;
      while (n && guard++ < 5000) {
        const s = this.obj(n);
        const t = /\/Title\s*\(((?:\\.|[^\\)])*)\)/.exec(s);
        const d = /\/Dest\s*\[\s*(\d+)\s+0\s+R/.exec(s);
        const title = t ? this.pdfString(t[1]).map(winChar).join('') : '?';
        const page = d ? this.pages.indexOf(+d[1]) : -1;
        list.push({ title, page });
        const nx = /\/Next\s+(\d+)\s+0\s+R/.exec(s);
        n = nx ? +nx[1] : 0;
      }
      return list;
    }
    widths(base) {
      if (!this.widthCache[base]) this.widthCache[base] = this.afm[base] ? afmWidths(this.afm[base]) : null;
      return this.widthCache[base];
    }
    // draw page i (0-based) onto a canvas 2D context with `scale` pixels per point
    render(i, ctx, scale) {
      const data = this.stream(+(/\/Contents\s+(\d+)\s+0\s+R/.exec(this.obj(this.pages[i])) || [0, 0])[1]);
      const H = this.h;
      ctx.save();
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, this.w * scale, H * scale);
      ctx.setTransform(scale, 0, 0, -scale, 0, H * scale); // PDF coordinates: origin at the bottom left
      const st = { fill: '#000', stroke: '#000', lw: 1, font: 'F0', size: 12, tx: 0, ty: 0 };
      const stack = [];
      let path = new Path2D(), cx = 0, cy = 0;
      const ops = [];
      const s = data;
      const n = s.length;
      let p = 0;
      const isWs = (c) => c === 32 || c === 10 || c === 13 || c === 9;
      const nums = [];
      let strArg = null;
      while (p < n) {
        const c = s[p];
        if (isWs(c)) { p++; continue; }
        if (c === 40) { // (string)
          let depth = 0, q = p + 1, bytes = [];
          for (; q < n; q++) {
            const d = s[q];
            if (d === 92) { const e = s[q + 1]; if (e >= 48 && e <= 55) { let v = 0, k = 0; while (k < 3 && s[q + 1 + k] >= 48 && s[q + 1 + k] <= 55) { v = v * 8 + s[q + 1 + k] - 48; k++; } bytes.push(v & 255); q += k; } else { bytes.push(e === 110 ? 10 : e === 116 ? 9 : e === 114 ? 13 : e); q++; } continue; }
            if (d === 40) depth++;
            if (d === 41) { if (depth === 0) break; depth--; }
            bytes.push(d);
          }
          strArg = bytes; p = q + 1; continue;
        }
        let q = p;
        while (q < n && !isWs(s[q]) && s[q] !== 40) q++;
        let tok = '';
        for (let k = p; k < q; k++) tok += String.fromCharCode(s[k]);
        p = q;
        if (/^[-+]?(\d+\.?\d*|\.\d+)$/.test(tok)) { nums.push(parseFloat(tok)); continue; }
        if (tok[0] === '/') { st._name = tok.slice(1); continue; }
        // operator
        const a = nums;
        switch (tok) {
          case 'q': stack.push({ ...st }); ctx.save(); break;
          case 'Q': if (stack.length) Object.assign(st, stack.pop()); ctx.restore(); break;
          case 'rg': st.fill = `rgb(${a[0] * 255 | 0},${a[1] * 255 | 0},${a[2] * 255 | 0})`; break;
          case 'RG': st.stroke = `rgb(${a[0] * 255 | 0},${a[1] * 255 | 0},${a[2] * 255 | 0})`; break;
          case 'g': st.fill = `rgb(${a[0] * 255 | 0},${a[0] * 255 | 0},${a[0] * 255 | 0})`; break;
          case 'G': st.stroke = `rgb(${a[0] * 255 | 0},${a[0] * 255 | 0},${a[0] * 255 | 0})`; break;
          case 'w': st.lw = a[0]; break;
          case 'm': path.moveTo(a[0], a[1]); cx = a[0]; cy = a[1]; break;
          case 'l': path.lineTo(a[0], a[1]); cx = a[0]; cy = a[1]; break;
          case 'c': path.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]); cx = a[4]; cy = a[5]; break;
          case 'h': path.closePath(); break;
          case 're': path.rect(a[0], a[1], a[2], a[3]); break;
          case 'S': ctx.strokeStyle = st.stroke; ctx.lineWidth = st.lw; ctx.stroke(path); path = new Path2D(); break;
          case 'f': case 'f*': ctx.fillStyle = st.fill; ctx.fill(path); path = new Path2D(); break;
          case 'B': case 'b': ctx.fillStyle = st.fill; ctx.fill(path); ctx.strokeStyle = st.stroke; ctx.lineWidth = st.lw; ctx.stroke(path); path = new Path2D(); break;
          case 'n': path = new Path2D(); break;
          case 'BT': st.tx = 0; st.ty = 0; break;
          case 'ET': break;
          case 'Tf': st.font = st._name || 'F0'; st.size = a[0]; break;
          case 'Tm': st.tx = a[4]; st.ty = a[5]; break;
          case 'Td': st.tx += a[0]; st.ty += a[1]; break;
          case 'Tj': if (strArg) this.drawText(ctx, st, strArg); break;
          default: break;
        }
        nums.length = 0; strArg = null;
      }
      ctx.restore();
    }
    drawText(ctx, st, bytes) {
      const base = this.fonts[st.font] || 'Times-Roman';
      const serif = /^Times/.test(base), mono = /^Courier/.test(base);
      const bold = /Bold/.test(base), italic = /Italic|Oblique/.test(base);
      const family = mono ? '"Courier New", Courier, monospace' : serif ? '"Times New Roman", Times, "Liberation Serif", "Nimbus Roman", serif' : 'Helvetica, Arial, "Liberation Sans", "Nimbus Sans", sans-serif';
      const text = bytes.map(winChar).join('');
      ctx.save();
      ctx.translate(st.tx, st.ty);
      ctx.scale(1, -1);
      ctx.font = `${italic ? 'italic ' : ''}${bold ? '700 ' : ''}${st.size}px ${family}`;
      ctx.fillStyle = st.fill;
      const w = this.widths(base);
      if (w) {
        let units = 0;
        for (const b of bytes) units += w[b];
        const want = units * st.size / 1000, got = ctx.measureText(text).width;
        if (got > 0.01 && want > 0.01) ctx.scale(want / got, 1);
      }
      ctx.fillText(text, 0, 0);
      ctx.restore();
    }
  }

  // A full-screen viewer: G.PdfViewer.open(bytes, {title, afm, onDownload})
  function open(bytes, opts) {
    opts = opts || {};
    let doc;
    try { doc = new PdfDoc(bytes, opts.afm); } catch (e) { alertBox('This PDF could not be shown: ' + e.message); return; }
    const wrap = document.createElement('div');
    wrap.className = 'pdfv';
    wrap.innerHTML = `<div class="pdfv-bar"><button class="pdfv-close" aria-label="Close">✕</button><button class="pdfv-toc">Contents</button>
      <span class="pdfv-title"></span><span class="pdfv-sp"></span>
      <button class="pdfv-prev" aria-label="Previous page">‹</button><input class="pdfv-num" type="number" min="1" value="1"><span class="pdfv-of"></span><button class="pdfv-next" aria-label="Next page">›</button>
      <button class="pdfv-zout" aria-label="Zoom out">−</button><button class="pdfv-zin" aria-label="Zoom in">+</button>${opts.onDownload ? '<button class="pdfv-dl">Download</button>' : ''}</div>
      <div class="pdfv-body"><div class="pdfv-side" hidden></div><div class="pdfv-scroll"><canvas class="pdfv-canvas"></canvas></div></div>`;
    document.body.appendChild(wrap);
    const $ = (c) => wrap.querySelector(c);
    $('.pdfv-title').textContent = opts.title || 'PDF';
    $('.pdfv-of').textContent = ' / ' + doc.pages.length;
    let page = 0, zoom = 1;
    const canvas = $('.pdfv-canvas');
    function draw() {
      const area = $('.pdfv-scroll');
      const fit = Math.min((area.clientWidth - 24) / doc.w, 3);
      const scale = Math.max(0.3, fit * zoom);
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(doc.w * scale * dpr); canvas.height = Math.round(doc.h * scale * dpr);
      canvas.style.width = Math.round(doc.w * scale) + 'px'; canvas.style.height = Math.round(doc.h * scale) + 'px';
      const ctx = canvas.getContext('2d');
      try { doc.render(page, ctx, scale * dpr); } catch (e) { console.error(e); }
      $('.pdfv-num').value = page + 1;
    }
    const go = (k) => { page = Math.max(0, Math.min(doc.pages.length - 1, k)); draw(); $('.pdfv-scroll').scrollTop = 0; };
    $('.pdfv-prev').onclick = () => go(page - 1);
    $('.pdfv-next').onclick = () => go(page + 1);
    $('.pdfv-num').onchange = (e) => go((+e.target.value || 1) - 1);
    $('.pdfv-zin').onclick = () => { zoom = Math.min(4, zoom * 1.25); draw(); };
    $('.pdfv-zout').onclick = () => { zoom = Math.max(0.4, zoom / 1.25); draw(); };
    const close = () => { wrap.remove(); window.removeEventListener('keydown', key); window.removeEventListener('resize', draw); };
    $('.pdfv-close').onclick = close;
    if (opts.onDownload) $('.pdfv-dl').onclick = opts.onDownload;
    const side = $('.pdfv-side');
    if (doc.outline.length) {
      for (const o of doc.outline) {
        const b = document.createElement('button');
        b.textContent = o.title + (o.page >= 0 ? '  ·  p. ' + (o.page + 1) : '');
        b.onclick = () => { if (o.page >= 0) go(o.page); if (window.innerWidth < 800) side.hidden = true; };
        side.appendChild(b);
      }
    } else $('.pdfv-toc').hidden = true;
    $('.pdfv-toc').onclick = () => { side.hidden = !side.hidden; draw(); };
    const key = (e) => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight' || e.key === 'PageDown') go(page + 1); if (e.key === 'ArrowLeft' || e.key === 'PageUp') go(page - 1); };
    window.addEventListener('keydown', key);
    window.addEventListener('resize', draw);
    requestAnimationFrame(draw);
    let sx = null;
    canvas.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
    canvas.addEventListener('touchend', (e) => { if (sx === null || zoom > 1.01) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 60) go(page + (dx < 0 ? 1 : -1)); sx = null; });
  }
  function alertBox(msg) { if (G.App && G.App.toast) G.App.toast(msg); else console.warn(msg); }
  G.PdfViewer = { open, PdfDoc, afmWidths };
})(typeof window !== 'undefined' ? window : globalThis);
