// BitScribe Python worker: runs Pyodide (Python compiled to WebAssembly) in the background,
// for the lesson tests, the Playground and the Writer. The Python side of the work is in runner.py.
let py = null;
let ready = null;
let runJob = null, stripFn = null;   // the Python functions, looked up once

// A hosted page may not serve .zip and .whl files, so the web build stores Python's standard library and the NumPy
// wheel as base64 text next to them (NAME.b64.txt). This hands Pyodide the original bytes when it fetches NAME.
function unpackB64(base) {
  const realFetch = self.fetch.bind(self);
  self.fetch = async (input, init) => {
    const u = typeof input === 'string' ? input : (input && input.url) || String(input);
    if (u.startsWith(base) && /\.(zip|whl)$/.test(u.split('?')[0])) {
      try {
        const r = await realFetch(u.split('?')[0] + '.b64.txt');
        if (r.ok) {
          const bin = atob((await r.text()).trim());
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          return new Response(bytes, { status: 200, headers: { 'Content-Type': 'application/octet-stream' } });
        }
      } catch (e) { /* fall back to the file itself */ }
    }
    return realFetch(input, init);
  };
}

async function startPython(m) {
  let lastErr = null;
  if (m.packed && m.urls.length) unpackB64(m.urls[0]);
  for (const url of m.urls) {
    try {
      if (typeof loadPyodide === 'undefined') importScripts(url + 'pyodide.js');
      const p = await loadPyodide({ indexURL: url, stdout: () => {}, stderr: () => {} });
      await p.loadPackage('numpy', { messageCallback: () => {}, errorCallback: () => {} });
      return p;
    } catch (e) {
      lastErr = e;
      // a failed importScripts leaves no loadPyodide; try the next place
      try { delete self.loadPyodide; } catch (e2) { self.loadPyodide = undefined; }
    }
  }
  throw lastErr || new Error('Python (Pyodide) could not be loaded');
}

async function init(m) {
  py = await startPython(m);
  const FS = py.FS;
  for (const d of ['/bitscribe', '/bitscribe/runtime', '/bitscribe/base', '/bitscribe/base/models', '/bitscribe/base/fonts']) FS.mkdirTree(d);
  for (const [name, text] of Object.entries(m.runtime)) FS.writeFile('/bitscribe/runtime/' + name, text);
  for (const [path, data] of m.base) FS.writeFile('/bitscribe/base/' + path, data);
  FS.writeFile('/bitscribe/init.json', JSON.stringify({ items: m.items, articles: m.articles }));
  py.runPython(`
import sys, json
sys.path.insert(0, "/bitscribe/runtime")
sys.setrecursionlimit(1500)
import runner
_init = json.load(open("/bitscribe/init.json", encoding="utf-8"))
runner.init("/bitscribe/base", dict(_init["items"]), _init["articles"])
del _init
from pyodide.ffi import to_js as _to_js
def _files_js(files):
    return _to_js([[p, memoryview(d)] for p, d in files])
def _run_job(job_json, emit, send_files):
    job = json.loads(job_json)
    sf = (lambda files: send_files(_files_js(files))) if job.get("snapshot") else None
    res = runner.run(job, emit, sf)
    files = res.pop("files", [])
    return json.dumps(res), _files_js(files)
def _strip(items_json):
    return json.dumps([runner.strip_experiments(code, keep) for code, keep in json.loads(items_json)])
`);
  runJob = py.globals.get('_run_job');
  stripFn = py.globals.get('_strip');
  return { python: py.runPython('sys.version.split()[0]'), numpy: py.runPython('__import__("numpy").__version__') };
}

self.onmessage = async (ev) => {
  const m = ev.data;
  if (m.type === 'init') {
    ready = init(m);
    try { const info = await ready; self.postMessage({ type: 'ready', info }); }
    catch (e) { self.postMessage({ type: 'failed', msg: String((e && e.message) || e).slice(0, 400) }); }
    return;
  }
  try { await ready; } catch (e) { return; }
  if (m.type === 'run') {
    const id = m.id;
    const emit = (text, isErr) => self.postMessage({ type: 'out', id, text, err: !!isErr });
    const sendFiles = (files) => self.postMessage({ type: 'files', id, files });
    let res, files = [];
    try {
      const out = runJob(JSON.stringify(m.job), emit, sendFiles);
      res = JSON.parse(out.get(0));
      files = out.get(1);
      out.destroy();
    } catch (e) {
      res = { error: { kind: 'exception', type: 'InternalError', msg: String((e && e.message) || e).slice(-800), full: String((e && e.message) || e).slice(-800), frames: [] }, fails: [], checks: 0, exit_code: 1 };
    }
    self.postMessage({ type: 'done', id, res, files });
    return;
  }
  if (m.type === 'strip') {
    let res;
    try { res = { texts: JSON.parse(stripFn(JSON.stringify(m.items))) }; }
    catch (e) { res = { texts: m.items.map(x => x[0]) }; }
    self.postMessage({ type: 'done', id: m.id, res });
  }
};
