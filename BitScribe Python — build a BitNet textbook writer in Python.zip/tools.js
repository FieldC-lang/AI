// BitScribe Python tools: the Playground (run Python, step through it line by line), the Writer (textbook writer)
// and My code (the project and its export).
(function () {
'use strict';
const BS = window.BS;
const { $, $$, esc, h, toast, modal, fmtTime } = BS;
BS.views = BS.views || {};
const S = () => BS.S();

// ---------------- a tiny IndexedDB store for books (optional; the app works without it) ----------------
const Store = (() => {
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((res) => {
      try {
        const r = indexedDB.open('bitscribe-python-books', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('files');
        r.onsuccess = () => res(r.result);
        r.onerror = () => res(null);
      } catch (e) { res(null); }
    });
    return dbp;
  }
  async function op(mode, fn) {
    const db = await open();
    if (!db) return null;
    return new Promise((res) => {
      try { const tx = db.transaction('files', mode); const st = tx.objectStore('files'); const r = fn(st); tx.oncomplete = () => res(r && r.result); tx.onerror = () => res(null); } catch (e) { res(null); }
    });
  }
  return {
    put: (k, v) => op('readwrite', st => st.put(v, k)),
    get: (k) => op('readonly', st => st.get(k)),
    del: (k) => op('readwrite', st => st.delete(k)),
  };
})();

const decode = (d) => (typeof d === 'string' ? d : new TextDecoder().decode(d));

// ---------------- Playground ----------------
BS.views.playground = function (view) {
  const st = S();
  const T = BS.ASSETS.templates;
  if (!st.machine.src) { st.machine.src = T.hello.src; st.machine.mine = false; }
  view.innerHTML = `
    <h1>Playground</h1>
    <p class="sub">Your own Python, right here. Write a program and press <b>Run</b>, or press <b>Step through</b> to watch it run one line at a time, with every variable. Tick <b>Use my BitScribe code</b> to call the functions you wrote in the lessons.</p>
    <div class="card editor-card">
      <div class="editor-bar">
        <select id="tpl" style="width:auto"><option value="">Examples…</option>${Object.entries(T).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('')}</select>
        <label class="switch" style="margin:0"><input type="checkbox" id="mine" ${st.machine.mine ? 'checked' : ''}> Use my BitScribe code</label>
        <span class="grow"></span>
        <button class="btn" id="mstep">👣 Step through</button>
        <button class="btn primary" id="mrun">▶ Run</button>
      </div>
      <div id="med"></div>
      <div id="dbg" class="dbg hidden">
        <div class="dbg-bar">
          <button class="btn small" id="d-first" title="Go to the first step">⏮</button>
          <button class="btn small" id="d-back" title="One step back (Shift+F10)">◀ Back</button>
          <button class="btn small blue" id="d-next" title="One step forward (F10)">Next ▶</button>
          <button class="btn small primary" id="d-cont" title="Run to the next breakpoint (F5)">▶▶ Continue</button>
          <button class="btn small" id="d-last" title="Go to the last step">⏭</button>
          <button class="btn small danger" id="d-stop">✕ Close</button>
          <span class="muted dbg-tip">Click a line number to set a breakpoint.</span>
        </div>
        <input type="range" id="d-slider" min="0" max="0" value="0" style="width:100%;margin:6px 0">
        <div class="dbg-now"><span id="d-where"></span><code id="d-insn"></code></div>
        <div class="dbg-grid">
          <div class="dbg-box"><h4>Variables</h4><div id="d-vars" class="vars"></div></div>
          <div class="dbg-box"><h4>Function calls</h4><div id="d-stack" class="stack"></div><div class="muted" id="d-steps"></div></div>
          <div class="dbg-box" style="grid-column:1/-1"><h4>Output so far</h4><pre id="d-out" class="console" style="max-height:180px;margin:0"></pre></div>
        </div>
      </div>
      <div class="results">
        <div class="grid2" style="margin-bottom:8px">
          <label>Arguments <input type="text" id="margs" placeholder="for example: --topic Bees" value="${esc(st.machine.args || '')}"></label>
          <label>Input for input() (separate answers with |) <input type="text" id="mstdin" placeholder="for example: Ada | 15" value="${esc(st.machine.stdin || '')}"></label>
        </div>
        <div class="console" id="mout">Output appears here.</div>
        <div id="mfiles" class="filelist"></div>
      </div>
    </div>`;
  const ed = BS.makeEditor($('#med', view), st.machine.src, { onChange: (v) => { st.machine.src = v; BS.save({ local: true }); if (steps) closeSteps('The code changed, so the steps were closed.'); }, onRun: () => run(), allowPaste: true, breakpoints: true });
  const cm = ed.cm;
  const bpMarker = () => { const d = document.createElement('div'); d.className = 'bp-dot'; d.textContent = '●'; return d; };
  const toggleBp = (n) => { if (!cm) return; const info = cm.lineInfo(n); cm.setGutterMarker(n, 'bp-gutter', info.gutterMarkers && info.gutterMarkers['bp-gutter'] ? null : bpMarker()); };
  if (cm) cm.on('gutterClick', (c, n) => toggleBp(n));
  const breakpoints = () => { const out = new Set(); if (cm) cm.eachLine(lh => { if (lh.gutterMarkers && lh.gutterMarkers['bp-gutter']) out.add(cm.getLineNumber(lh) + 1); }); return out; };
  $('#tpl', view).onchange = (e) => { const t = T[e.target.value]; if (!t) return; if (steps) closeSteps(); ed.set(t.src); st.machine.src = t.src; $('#mine', view).checked = t.mine; st.machine.mine = t.mine; BS.save({ local: true }); e.target.value = ''; };
  $('#mine', view).onchange = (e) => { st.machine.mine = e.target.checked; BS.save({ local: true }); };
  $('#margs', view).onchange = (e) => { st.machine.args = e.target.value; BS.save({ local: true }); };
  $('#mstdin', view).onchange = (e) => { st.machine.stdin = e.target.value; BS.save({ local: true }); };
  const out = $('#mout', view), runBtn = $('#mrun', view), stepBtn = $('#mstep', view), filesBox = $('#mfiles', view);
  const runner = BS.testRunner;
  let running = false;
  const args = () => ($('#margs', view).value.match(/"[^"]*"|\S+/g) || []).map(a => a.replace(/^"|"$/g, ''));
  const stdin = () => $('#mstdin', view).value.split('|').map(s => s.trim()).join('\n');
  // the chunks of a Playground program: (if ticked) your BitScribe code, then your program as the main module
  function playJob(mode) {
    let chunks = [], note = '';
    const mine = $('#mine', view).checked;
    if (mine) {
      const p = BS.programChunks({ fill: true, moduleName: 'bitscribe' });
      chunks = p.chunks;
      if (p.missing.length) note = `(${p.missing.length} lesson(s) not done yet: the course's code fills in for those parts)\n`;
    }
    chunks.push({ name: 'your code', code: ed.get(), module_name: '__main__', traced: mode === 'trace' });
    const job = { mode, chunks, argv: ['program.py', ...args()], stdin: stdin(), return_files: '.', max_out: 2e6 };
    if (mode === 'trace') { job.max_steps = 3000; job.trace_file = 'your code'; }
    return { job, note };
  }
  const printOut = (t, e) => {
    if (t && !e) out.appendChild(document.createTextNode(t));
    if (t && e) { const s = document.createElement('span'); s.className = 'e'; s.textContent = t; out.appendChild(s); }
    if (out.childNodes.length > 4000) out.removeChild(out.firstChild);
    out.scrollTop = out.scrollHeight;
  };
  function errorText(err) {
    if (!err) return '';
    if (err.kind === 'syntax') { if (err.chunk === 'your code' && err.line) ed.mark(err.line); return `\n${err.type} on line ${err.line}${err.chunk !== 'your code' ? ' of ' + err.chunk : ''}: ${err.msg}${err.text ? '\n    ' + err.text : ''}`; }
    if (err.kind === 'exception') {
      const w = BS.errorWhere(err);
      const where = (err.frames || []).filter(f => !/^course code/.test(f.file)).map(f => `  ${f.file === 'your code' ? 'line ' + f.line : f.file + ', line ' + f.line}${f.func && f.func !== '<module>' ? ', in ' + f.func : ''}${f.text ? '\n      ' + f.text : ''}`).join('\n');
      if (w.mine && w.mine.file === 'your code') ed.mark(w.mine.line);
      return `\nTraceback (the newest call last):\n${where}\n${err.full}`;
    }
    if (err.kind === 'startup') return '\nPython could not start: ' + err.msg;
    return '\n' + (err.msg || JSON.stringify(err));
  }
  function finishLine(res, t0) {
    const tail = document.createElement('span');
    tail.className = res.error ? 'e' : '';
    if (res.stopped) tail.textContent = '\n[stopped]';
    else if (res.error) tail.textContent = errorText(res.error);
    else tail.textContent = `\n[finished with exit code ${res.exit_code} in ${fmtTime((Date.now() - t0) / 1000)}]`;
    out.appendChild(tail);
    out.scrollTop = out.scrollHeight;
  }
  async function run() {
    if (steps) closeSteps();
    if (running) { runner.stop(); return; }
    running = true; runBtn.textContent = '■ Stop'; runBtn.classList.replace('primary', 'danger'); stepBtn.disabled = true;
    out.innerHTML = ''; filesBox.innerHTML = ''; ed.mark(0);
    const { job, note } = playJob('program');
    if (note) out.appendChild(document.createTextNode(note));
    if (runner.state !== 'ready') out.appendChild(document.createTextNode('(starting Python…)\n'));
    const t0 = Date.now();
    const res = await runner.run(job, { onOut: printOut });
    running = false; runBtn.textContent = '▶ Run'; runBtn.classList.replace('danger', 'primary'); stepBtn.disabled = false;
    finishLine(res, t0);
    showFiles(filesBox, res.files || []);
  }
  runBtn.onclick = run;

  // ---------- step through: the program runs once, recording every line; then you move through the steps ----------
  let steps = null, k = 0, fullOut = '';
  const D = (id) => $('#' + id, view);
  function closeSteps(msg) {
    steps = null;
    D('dbg').classList.add('hidden');
    stepBtn.textContent = '👣 Step through'; stepBtn.classList.remove('danger');
    runBtn.disabled = false;
    ed.current(0);
    if (msg) toast(msg);
  }
  async function startSteps() {
    if (steps) { closeSteps(); return; }
    if (running) return;
    running = true; stepBtn.disabled = true; runBtn.disabled = true;
    out.innerHTML = ''; filesBox.innerHTML = ''; ed.mark(0);
    const { job, note } = playJob('trace');
    if (note) out.appendChild(document.createTextNode(note));
    out.appendChild(document.createTextNode('(running your program and recording every step…)\n'));
    const t0 = Date.now();
    const res = await runner.run(job, { onOut: printOut });
    running = false; stepBtn.disabled = false;
    finishLine(res, t0);
    showFiles(filesBox, res.files || []);
    if (!res.steps || !res.steps.length) { runBtn.disabled = false; if (!res.error) toast('No line of your program ran, so there is nothing to step through.'); return; }
    steps = res.steps; fullOut = res.out || ''; k = 0;
    D('dbg').classList.remove('hidden');
    stepBtn.textContent = '✕ Close the steps'; stepBtn.classList.add('danger');
    D('d-slider').max = steps.length - 1;
    D('d-steps').textContent = `${steps.length.toLocaleString()} steps recorded${res.truncated ? ' (the first 3000 only)' : ''}.`;
    draw();
  }
  stepBtn.onclick = startSteps;
  function go(n) { if (!steps) return; k = Math.max(0, Math.min(steps.length - 1, n)); draw(); }
  D('d-first').onclick = () => go(0);
  D('d-back').onclick = () => go(k - 1);
  D('d-next').onclick = () => go(k + 1);
  D('d-last').onclick = () => go(steps ? steps.length - 1 : 0);
  D('d-cont').onclick = () => {
    if (!steps) return;
    const bps = breakpoints();
    for (let i = k + 1; i < steps.length; i++) if (bps.has(steps[i].line) && steps[i].event === 'line') { go(i); return; }
    go(steps.length - 1);
    if (bps.size) toast('No more breakpoints: this is the last step.');
  };
  D('d-stop').onclick = () => closeSteps();
  D('d-slider').oninput = (e) => go(+e.target.value);
  function draw() {
    const s = steps[k];
    ed.current(s.line);
    D('d-slider').value = k;
    const what = s.event === 'return' ? `↩ <code>${esc(s.func)}</code> returns <code>${esc(s.value)}</code>` : s.event === 'exception' ? `💥 ${esc(s.value)}` : 'about to run';
    D('d-where').innerHTML = `Step ${k + 1} of ${steps.length} · line <b>${s.line}</b>${s.func !== '<module>' ? ` in <code>${esc(s.func)}</code>` : ''} · ${what}`;
    D('d-insn').textContent = (ed.cm ? ed.cm.getLine(s.line - 1) || '' : '').trim();
    const prev = k > 0 ? steps[k - 1] : null;
    const old = new Map(prev && prev.func === s.func ? prev.vars : []);
    D('d-vars').innerHTML = s.vars.length ? s.vars.map(([n, v]) => `<div class="var ${old.has(n) && old.get(n) !== v ? 'chg' : !old.has(n) && prev && prev.func === s.func ? 'new' : ''}"><b>${esc(n)}</b> <span>${esc(v)}</span></div>`).join('') : '<span class="muted">no variables yet</span>';
    D('d-stack').innerHTML = s.stack.map((f, i) => `<div>${i === 0 ? '▶ ' : ''}<code>${esc(f[0] === '<module>' ? 'your program' : f[0] + '()')}</code> <span class="muted">line ${f[1]}</span></div>`).join('');
    const o = D('d-out'); o.textContent = fullOut.slice(0, s.out); o.scrollTop = 1e9;
  }
  const keyh = (e) => {
    if (!steps || !document.body.contains(view) || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (e.key === 'F10') { e.preventDefault(); go(e.shiftKey ? k - 1 : k + 1); }
    else if (e.key === 'F5') { e.preventDefault(); D('d-cont').click(); }
  };
  window.addEventListener('keydown', keyh);
  BS.onLeave = () => { if (running) runner.stop(); window.removeEventListener('keydown', keyh); };
};
function showFiles(box, files) {
  box.innerHTML = '';
  for (const [path, data] of files) {
    if (/\.state$/.test(path)) continue;
    const name = path.replace(/^\//, '');
    const isPdf = /\.pdf$/i.test(name);
    const row = h(`<div class="f"><span class="ic">${isPdf ? '📕' : '📄'}</span><b class="grow">${esc(name)}</b><span class="muted">${(data.length / 1024).toFixed(1)} KB</span>${isPdf ? '<button class="btn small blue" data-a="view">View</button>' : '<button class="btn small" data-a="text">Show</button>'}<button class="btn small" data-a="save">Download</button></div>`);
    const v = $('[data-a=view]', row); if (v) v.onclick = () => BS.openPdf(data, name);
    const t = $('[data-a=text]', row); if (t) t.onclick = () => modal(`<h3>${esc(name)}</h3><pre class="console" style="max-height:60vh">${esc(new TextDecoder().decode(data.slice(0, 200000)))}</pre>`);
    $('[data-a=save]', row).onclick = () => BS.saveFile(name.split('/').pop().replace(/\.(state)$/, '.txt'), data);
    box.appendChild(row);
  }
}
BS.showFiles = showFiles;

// ---------------- Writer ----------------
let writerRunner = null;
let job = null;   // the running (or last) writing job, kept while you switch tabs
function settingsText(w, native) {
  const one = (s) => String(s == null ? '' : s).replace(/[\r\n]+/g, ' ').trim();
  const lines = [
    '# BitScribe settings: one "key = value" per line. Lines starting with # are comments.',
    'topic = ' + one(w.topic), 'title = ' + one(w.title), 'audience = ' + one(w.audience), 'author = ' + one(w.author || 'BitScribe'),
    'model = models/tiny.bnet', 'tokenizer = models/tiny.tok', 'out = book', 'font = ' + (w.font === 'sans' ? 'sans' : 'serif'),
    'user_agent = BitScribe/1.0 (student textbook project' + (native ? '; add your email here' : '') + ')',
    'wiki = ' + (native ? 'en.wikipedia.org' : 'offline.bitscribe'),
    'pages = ' + w.pages, 'volumes = ' + w.volumes, 'chapters = ' + w.chapters, 'sections = ' + w.sections, 'tokens_per_hit = ' + w.tokens_per_hit,
    'web = ' + (w.web ? 1 : 0), 'web_sources = ' + w.web_sources, 'diagrams = ' + (w.diagrams ? 1 : 0), 'diagram_every = ' + w.diagram_every,
    'exercises = ' + (w.exercises ? 1 : 0), 'key_ideas = ' + (w.key_ideas ? 1 : 0), 'toc = ' + (w.toc ? 1 : 0), 'index = ' + (w.index ? 1 : 0), 'resume = 1',
    'temperature = ' + w.temperature, 'top_p = ' + w.top_p, 'top_k = ' + w.top_k, 'repeat_penalty = ' + w.repeat_penalty, 'seed = ' + w.seed,
    'font_size = ' + w.font_size, 'line_spacing = ' + w.line_spacing, 'margin_mm = ' + w.margin_mm,
  ];
  return lines.join('\n') + '\n';
}
BS.settingsText = settingsText;
function userPages(text) {
  // "My sources": blocks separated by a line with --- ; the first line of a block is its title
  return String(text || '').split(/^\s*---\s*$/m).map(b => b.trim()).filter(Boolean).map(b => {
    const nl = b.indexOf('\n');
    return { title: (nl < 0 ? b : b.slice(0, nl)).replace(/^#+\s*/, '').trim().slice(0, 90), text: nl < 0 ? '' : b.slice(nl + 1).trim() };
  }).filter(p => p.title && p.text.length > 40);
}
function estimate(w) {
  const tokens = w.pages * w.volumes * 450 * 1.4;
  const speed = S().writerSpeed || 150;      // forward passes per second in this browser (measured after a run)
  return tokens * 2.6 / speed;               // prompts are re-read on every hit, so ~2.6 forward passes per new token
}
BS.views.writer = function (view) {
  const st = S(), w = st.writer;
  const coding = BS.LESSONS.filter(BS.isProject);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  view.innerHTML = `
    <div class="hero"><h1>The Writer</h1><div class="sub">One prompt in, a finished textbook out: your BitNet program — written in Python — researches the topic, plans volumes and chapters, writes every section in many short model “hits”, draws diagrams, and lays out PDFs with contents and an index.</div></div>
    <div class="card" id="prog-status" style="margin-bottom:14px">${missing.length === 0 ? `<b>✅ Your program: all ${BS.TOTAL_PARTS()} parts written by you.</b> The Writer runs exactly your Python code.` : `<b>Your program: ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts written by you.</b> <span class="sub">Until you finish the course, the Writer can run as a <b>demo</b> in which the course's own code fills in the ${missing.length} lesson(s) you have not done yet.</span>`}</div>
    <div class="grid2">
      <div class="card">
        <h3>Your book</h3>
        <label class="field"><span>Topic — the one prompt</span><input type="text" class="big-input" data-k="topic" maxlength="90" placeholder="for example: Volcanoes"></label>
        <label class="field"><span>Title (empty = the topic)</span><input type="text" data-k="title" maxlength="90"></label>
        <div class="grid2"><label class="field"><span>Written for</span><input type="text" data-k="audience" maxlength="90"></label><label class="field"><span>Author line</span><input type="text" data-k="author" maxlength="90" placeholder="BitScribe"></label></div>
        <label class="field"><span>Pages per volume: <b id="v-pages"></b></span><div class="range-row"><input type="range" min="1" max="600" data-k="pages" data-num="1"><input type="number" min="1" max="600" data-k="pages" data-num="1"></div></label>
        <label class="field"><span>Volumes: <b id="v-vols"></b></span><div class="range-row"><input type="range" min="1" max="10" data-k="volumes" data-num="1"><input type="number" min="1" max="10" data-k="volumes" data-num="1"></div></label>
        <p class="muted" id="est"></p>
      </div>
      <div class="card">
        <h3>What goes in</h3>
        <label class="switch"><input type="checkbox" data-k="web"> Research the topic in the encyclopedia first</label>
        <label class="field"><span>Articles to read</span><input type="number" min="0" max="8" data-k="web_sources" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="diagrams"> Diagrams and pictures</label>
        <label class="field"><span>Automatic diagram every … sections</span><input type="number" min="1" max="20" data-k="diagram_every" data-num="1"></label>
        <label class="switch"><input type="checkbox" data-k="exercises"> Exercises after each chapter</label>
        <label class="switch"><input type="checkbox" data-k="key_ideas"> “Key idea” boxes</label>
        <label class="switch"><input type="checkbox" data-k="toc"> Contents pages</label>
        <label class="switch"><input type="checkbox" data-k="index"> Index</label>
      </div>
    </div>
    <details class="card" style="margin-top:14px"><summary style="cursor:pointer;font-weight:800">More settings: model, layout and your own sources</summary>
      <div class="grid3" style="margin-top:10px">
        <label class="field"><span>Chapters per volume (0 = auto)</span><input type="number" min="0" max="80" data-k="chapters" data-num="1"></label>
        <label class="field"><span>Sections per chapter (0 = auto)</span><input type="number" min="0" max="16" data-k="sections" data-num="1"></label>
        <label class="field"><span>Most tokens per hit</span><input type="number" min="32" max="4000" data-k="tokens_per_hit" data-num="1"></label>
        <label class="field"><span>Temperature</span><input type="number" min="0" max="2" step="0.05" data-k="temperature" data-num="1"></label>
        <label class="field"><span>Top-p</span><input type="number" min="0.05" max="1" step="0.05" data-k="top_p" data-num="1"></label>
        <label class="field"><span>Top-k (0 = off)</span><input type="number" min="0" max="1000" data-k="top_k" data-num="1"></label>
        <label class="field"><span>Repeat penalty</span><input type="number" min="1" max="2" step="0.05" data-k="repeat_penalty" data-num="1"></label>
        <label class="field"><span>Random seed</span><input type="number" data-k="seed" data-num="1"></label>
        <label class="field"><span>Book font</span><select data-k="font"><option value="serif">Times (serif)</option><option value="sans">Helvetica (sans-serif)</option></select></label>
        <label class="field"><span>Font size (pt)</span><input type="number" min="7" max="16" step="0.5" data-k="font_size" data-num="1"></label>
        <label class="field"><span>Line spacing</span><input type="number" min="1" max="2.5" step="0.05" data-k="line_spacing" data-num="1"></label>
        <label class="field"><span>Margins (mm)</span><input type="number" min="8" max="40" data-k="margin_mm" data-num="1"></label>
      </div>
      <label class="field"><span>My own sources (optional). Paste notes or articles you are allowed to use: first line = title, then the text. Separate sources with a line containing only ---</span><textarea data-k="sources" rows="6" placeholder="Photosynthesis notes&#10;Plants make glucose from carbon dioxide and water using light energy..."></textarea></label>
      <p class="muted">The browser cannot reach the internet, so your program's “web” here is a built-in encyclopedia of ${BS.ASSETS.articles.length} articles plus your own sources. On your own computer, your exported program reads Wikipedia.</p>
    </details>
    <div class="row" style="margin:16px 0"><button class="btn primary" id="go" style="font-size:16px;padding:14px 22px">✍️ Write my textbook</button><button class="btn" id="stop" hidden>■ Stop</button><button class="btn" id="resume" hidden>Continue writing</button><span class="grow"></span><button class="btn small" id="dl-settings">Download settings.txt</button></div>
    <div id="job"></div>`;
  $$('[data-k]', view).forEach(inp => {
    const k = inp.dataset.k;
    if (inp.type === 'checkbox') inp.checked = !!w[k]; else inp.value = w[k];
    const ev = inp.type === 'range' || inp.tagName === 'TEXTAREA' || inp.type === 'text' ? 'input' : 'change';
    inp.addEventListener(ev, () => {
      let v = inp.type === 'checkbox' ? (inp.checked ? 1 : 0) : inp.value;
      if (inp.dataset.num) { v = Number(v); if (!isFinite(v)) return; const mn = inp.min !== '' ? Number(inp.min) : -Infinity, mx = inp.max !== '' ? Number(inp.max) : Infinity; v = Math.min(mx, Math.max(mn, v)); }
      w[k] = v;
      $$(`[data-k="${k}"]`, view).forEach(o => { if (o !== inp && o.type !== 'checkbox') o.value = v; });
      BS.save();
      refresh();
    });
  });
  function refresh() {
    $('#v-pages', view).textContent = w.pages;
    $('#v-vols', view).textContent = w.volumes;
    const words = Math.round(w.pages * w.volumes * 450);
    $('#est', view).textContent = `About ${words.toLocaleString()} words in ${w.volumes * w.pages} pages. Estimated writing time in this browser with the small model: ${fmtTime(estimate(w))}${w.pages * w.volumes > 100 ? ' — big books are best written on a computer with the exported program' : ''}.`;
  }
  refresh();
  $('#dl-settings', view).onclick = () => BS.saveFile('settings.txt', settingsText(w, true));
  const go = $('#go', view), stop = $('#stop', view), resume = $('#resume', view), jobBox = $('#job', view);
  go.onclick = () => start(false);
  resume.onclick = () => start(true);
  stop.onclick = () => { if (job && job.running && writerRunner) writerRunner.stop(); };
  async function start(cont) {
    if (job && job.running) return;
    if (!w.topic || !String(w.topic).trim()) { toast('Type a topic first.'); return; }
    const miss = BS.LESSONS.filter(BS.isProject).filter(L => !(S().done[L.id] && S().code[L.id]));
    if (miss.length) {
      const ok = await modal(`<h3>Run a demo?</h3><p>You have written ${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts. For the other ${miss.length} lesson(s) the course's own code will be used, hidden from you. Your written parts are used as they are.</p><p class="muted">When you finish the course, the Writer runs 100% your code.</p>`, [{ label: 'Cancel', value: false }, { label: 'Run the demo', value: true, cls: 'primary' }]);
      if (!ok) return;
    }
    const prev = cont && job ? job.files : new Map();
    job = { running: true, t0: Date.now(), tWrite: 0, log: [], plan: [], status: 'Starting Python…', frac: 0, tokens: 0, files: new Map(), results: [], cont, done: null, error: null };
    if (!cont) await Store.del('lastbook');
    built = null;
    renderJob();
    go.disabled = true; stop.hidden = false; resume.hidden = true;
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(true); } catch (e) {}
    if (!writerRunner) writerRunner = new BS.Runner('writer');
    const { chunks } = BS.programChunks({ fill: true });
    const files = { 'settings.txt': settingsText(w, false) };
    if (cont) for (const [p, d] of prev) if (/\.(md|state)$/.test(p)) files[p.replace(/^\//, '')] = decode(d);
    let buf = '';
    const res = await writerRunner.run({ mode: 'program', chunks, argv: ['bitscribe.py'], files, user_pages: userPages(w.sources),
      snapshot: '_vol\\d+\\.(md|state|pdf)$', return_files: '\\.(pdf|md|state)$', max_out: 200e6 }, {
      onOut: (t, isErr) => {
        if (isErr) { job.log.push(...t.split('\n').filter(Boolean)); renderJobSoon(); return; }
        if (job.status === 'Starting Python…') job.status = 'Researching and planning…';
        buf += t;
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) { handleLine(buf.slice(0, nl)); buf = buf.slice(nl + 1); }
        renderJobSoon();
      },
      onFiles: (fs) => { for (const [p, d] of fs) job.files.set(p, d); renderJobSoon(); },
    });
    if (buf) handleLine(buf);
    job.running = false;
    for (const [p, d] of (res.files || [])) job.files.set(p, d);
    if (res.stopped) job.status = 'Stopped. Press “Continue writing” to carry on from the last finished chapter.';
    else if (res.error) job.error = { msg: writerError(res.error) };
    else if (res.exit_code && !job.error) job.error = { msg: (res.err || 'the program stopped with exit code ' + res.exit_code).trim() };
    if (!res.stopped && !job.error) {
      job.status = 'Finished!';
      const secs = (Date.now() - (job.tWrite || job.t0)) / 1000;
      if (job.tokens > 50 && secs > 5) { S().writerSpeed = Math.round(job.tokens * 2.6 / secs); BS.save({ local: true }); }
      BS.sound('complete'); BS.confetti();
    }
    try { await Store.put('lastbook', { files: [...job.files.entries()], results: job.results, topic: w.topic, t: Date.now() }); } catch (e) {}
    if (BS.IS_APP && window.BitScribeApp.keepAwake) try { window.BitScribeApp.keepAwake(false); } catch (e) {}
    go.disabled = false; stop.hidden = true; resume.hidden = !(res.stopped || job.error) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  }
  function writerError(err) {
    if (err.kind === 'exception') {
      const wh = BS.errorWhere(err);
      const f = wh.mine || wh.last;
      return err.full + (f ? ` (${f.file.replace(/^your code: /, 'your lesson “').replace(/^(your lesson “.*)$/, '$1”')}, line ${f.line}${f.func && f.func !== '<module>' ? ', in ' + f.func : ''})` : '');
    }
    if (err.kind === 'syntax') return `${err.type} in ${err.chunk.replace(/^your code: /, 'your lesson “')}${/^your code: /.test(err.chunk) ? '”' : ''}, line ${err.line}: ${err.msg}`;
    return err.msg || JSON.stringify(err);
  }
  function handleLine(line) {
    if (!line.startsWith('@@')) { if (line.trim()) job.log.push(line); return; }
    const sp = line.indexOf(' ');
    const kind = line.slice(2, sp < 0 ? undefined : sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    if (kind === 'status') {
      job.status = rest;
      if (!job.tWrite) job.tWrite = Date.now();
      const m = /volume (\d+)\/(\d+), chapter (\d+)\/(\d+), section (\d+)\/(\d+)/.exec(rest);
      if (m) { const [V, NV, C, NC, K, NK] = m.slice(1).map(Number); job.frac = ((V - 1) + ((C - 1) + (K - 1) / NK) / NC) / NV; }
    } else if (kind === 'progress') { const m = /tokens (\d+)/.exec(rest); if (m) job.tokens += +m[1]; }
    else if (kind === 'plan') job.plan.push(rest);
    else if (kind === 'log') job.log.push(rest);
    else if (kind === 'file') { const m = /^(\S+)\s+(\d+)/.exec(rest); if (m) job.results.push({ path: '/' + m[1].replace(/^\//, ''), pages: +m[2] }); job.log.push('finished ' + rest.replace(/^\//, '') + ' pages'); }
    else if (kind === 'done') job.log.push(rest);
    if (job.log.length > 300) job.log.splice(0, job.log.length - 300);
  }
  let renderTimer = null, built = null, shownResults = -1;
  function renderJobSoon() { if (!renderTimer) renderTimer = setTimeout(() => { renderTimer = null; renderJob(); }, 400); }
  function buildJob() {
    jobBox.innerHTML = `<div class="card">
      <div class="jerr"></div>
      <div class="row"><b class="grow jstatus"></b><span class="muted jtime"></span></div>
      <div class="bar" style="margin:10px 0"><i class="jbar"></i></div>
      <div class="jfiles"></div>
      <details class="jprev-d"><summary class="muted" style="cursor:pointer">Latest text from the model</summary><div class="preview-text jprev"></div></details>
      <details class="jplan-d"><summary class="muted jplan-s" style="cursor:pointer">The plan</summary><div class="log jplan"></div></details>
      <details><summary class="muted" style="cursor:pointer">Log</summary><div class="log jlog"></div></details>
    </div>`;
    built = { box: jobBox.firstElementChild };
    for (const k of ['jerr', 'jstatus', 'jtime', 'jbar', 'jfiles', 'jprev', 'jprev-d', 'jplan', 'jplan-d', 'jplan-s', 'jlog']) built[k] = $('.' + k, jobBox);
    if (job.running) built['jprev-d'].open = true;
    shownResults = -1;
  }
  function renderJob() {
    if (!job || !document.body.contains(jobBox)) return;
    if (!built || !jobBox.contains(built.box)) buildJob();
    const B = built;
    const elapsed = (Date.now() - job.t0) / 1000;
    let eta = '';
    if (job.running && job.frac > 0.02 && job.tWrite) { const we = (Date.now() - job.tWrite) / 1000; eta = ' · about ' + fmtTime(we * (1 - job.frac) / job.frac) + ' left'; }
    B.jerr.innerHTML = job.error ? `<div class="res err"><h4>The program stopped with an error</h4><pre class="console">${esc(job.error.msg)}</pre></div>` : '';
    B.jstatus.textContent = job.status;
    B.jtime.textContent = (job.done && !job.running && !job.tokens ? '' : fmtTime(elapsed) + eta + ' · ' + job.tokens.toLocaleString() + ' tokens');
    B.jbar.style.width = (job.running ? Math.max(2, 100 * job.frac) : job.error ? 100 * job.frac : 100).toFixed(1) + '%';
    const pdfs = job.results.filter(r => job.files.has(r.path));
    if (pdfs.length !== shownResults) {
      shownResults = pdfs.length;
      B.jfiles.innerHTML = pdfs.length ? `<h3>Your book</h3><div class="filelist">${pdfs.map((r, i) => `<div class="f"><span class="ic">📕</span><b class="grow">${esc(r.path.slice(1))}</b><span class="muted">${r.pages} pages</span><button class="btn small blue" data-v="${i}">View</button><button class="btn small" data-d="${i}">Download PDF</button><button class="btn small" data-m="${i}">Text (.md)</button></div>`).join('')}</div>` : '';
      $$('[data-v]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.v]; b.onclick = () => BS.openPdf(job.files.get(r.path), r.path.slice(1)); });
      $$('[data-d]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.d]; b.onclick = () => BS.saveFile(r.path.slice(1), job.files.get(r.path)); });
      $$('[data-m]', B.jfiles).forEach(b => { const r = pdfs[+b.dataset.m]; const mdp = r.path.replace(/\.pdf$/, '.md'); b.onclick = () => { const d = job.files.get(mdp); if (d) BS.saveFile(mdp.slice(1), d); else toast('The text file is not available.'); }; });
    }
    const md = [...job.files.entries()].filter(([p]) => /\.md$/.test(p)).sort((a, b) => a[0] < b[0] ? -1 : 1).pop();
    const preview = md ? decode(md[1].slice(Math.max(0, md[1].length - 2500))) : '';
    B['jprev-d'].hidden = !preview;
    if (B.jprev.textContent !== preview) { B.jprev.textContent = preview; B.jprev.scrollTop = 1e9; }
    B['jplan-d'].hidden = !job.plan.length;
    B['jplan-s'].textContent = 'The plan (' + job.plan.length + ' chapters)';
    const planText = job.plan.join('\n');
    if (B.jplan.textContent !== planText) B.jplan.textContent = planText;
    const logText = job.log.slice(-150).join('\n');
    if (B.jlog.textContent !== logText) { B.jlog.textContent = logText; B.jlog.scrollTop = 1e9; }
  }
  if (job) {
    if (job.running) { go.disabled = true; stop.hidden = false; }
    else resume.hidden = !(job.error || /Stopped/.test(job.status)) || ![...job.files.keys()].some(p => /\.state$/.test(p));
    renderJob();
  } else {
    Store.get('lastbook').then(last => {
      if (!last || job || !document.body.contains(jobBox)) return;
      job = { running: false, t0: last.t, tWrite: last.t, log: [], plan: [], status: 'Your last book (' + (last.topic || '') + ')', frac: 1, tokens: 0, files: new Map(last.files || []), results: last.results || [], done: true, error: null };
      resume.hidden = !(job.results.length === 0 && [...job.files.keys()].some(p => /\.state$/.test(p)));
      renderJob();
    });
  }
  const tick = setInterval(() => { if (!document.body.contains(jobBox)) { clearInterval(tick); return; } if (job && job.running) renderJob(); }, 1000);
};

// ---------------- My code: the project ----------------
BS.views.project = function (view) {
  const st = S();
  const coding = BS.LESSONS.filter(BS.isProject);
  const mine = coding.filter(L => st.done[L.id] && st.code[L.id]);
  view.innerHTML = `
    <h1>My code</h1>
    <div class="card">
      <div class="row"><div class="grow"><b>${BS.partsWritten()} of ${BS.TOTAL_PARTS()} parts</b> of BitScribe are written by you in Python (${mine.length} of ${coding.length} coding lessons).</div></div>
      <div class="bar" style="margin:10px 0"><i style="width:${(100 * BS.partsWritten() / BS.TOTAL_PARTS()).toFixed(1)}%"></i></div>
      <div class="row">
        <button class="btn" id="chk">Check that it loads</button>
        <button class="btn" id="alltests">Run every test with my code</button>
        <button class="btn blue" id="export">Export project (.zip)</button>
      </div>
      <div id="pres" style="margin-top:10px"></div>
    </div>
    <div class="card" style="margin-top:14px" id="units"></div>`;
  const unitsBox = $('#units', view);
  for (const u of BS.UNITS) {
    const ls = u.lessons.filter(BS.isCoding);
    if (!ls.length) continue;
    const row = h(`<div class="unit-row"><div class="row"><span class="pill" style="background:${esc(u.color)};color:#fff">${esc(u.title)}</span><span class="muted">${ls.filter(L => st.done[L.id] && st.code[L.id]).length}/${ls.length}</span></div></div>`);
    for (const L of ls) {
      const ok = st.done[L.id] && st.code[L.id];
      const r = h(`<div class="lesson-row"><span>${ok ? '✅' : '⬜'}</span><span class="lt" style="font-weight:800">${esc(L.title)}</span>${L.items.map(i => `<span class="pill ${ok ? 'green' : ''}">${esc(i)}</span>`).join('')}</div>`);
      r.onclick = () => {
        if (!ok) { location.hash = 'lesson-' + L.id; return; }
        modal(`<h3>${esc(L.title)}</h3><div class="code-view">${BS.hlPy(st.code[L.id].src)}</div><p class="muted">To change this code, open the lesson again: it is tested before it is saved.</p>`, [{ label: 'Close', value: 0 }, { label: 'Open the lesson', value: 1, cls: 'primary' }]).then(v => { if (v) location.hash = 'lesson-' + L.id; });
      };
      row.appendChild(r);
    }
    unitsBox.appendChild(row);
  }
  const pres = $('#pres', view);
  // one job at a time: the three buttons share the result box and the Python worker
  const buttons = ['#chk', '#alltests', '#export'].map(sel => $(sel, view));
  const busy = (on) => buttons.forEach(b => { b.disabled = on; });
  $('#chk', view).onclick = async () => {
    busy(true);
    pres.innerHTML = '<div class="res info"><div class="row"><div class="spin" style="width:22px;height:22px;border-width:3px"></div><b>Loading your whole program into Python…</b></div></div>';
    try {
      const res = await BS.checkProgram();
      if (res.ok) { pres.innerHTML = `<div class="res ok"><h4>✅ Your whole program loads</h4>${res.chunks} lessons of your own code define every part of BitScribe (${Math.round(res.ms)} ms).</div>`; BS.sound('pass'); }
      else pres.innerHTML = res.html;
    } finally { busy(false); }
  };
  $('#alltests', view).onclick = async () => {
    const todo = BS.LESSONS.filter(BS.isCoding).filter(L => st.done[L.id] && st.code[L.id]);
    if (!todo.length) { pres.innerHTML = '<div class="res info">Finish a coding lesson first.</div>'; return; }
    let stopped = false, passed = 0;
    const failed = [];
    busy(true);
    pres.innerHTML = '<div class="res info"><div class="row"><b id="atp" class="grow">Starting…</b><button class="btn small" id="atstop">Stop</button></div><div class="bar" style="margin-top:8px"><i id="atbar"></i></div></div><div id="atfail"></div>';
    const stop = () => { stopped = true; BS.testRunner.stop(); };
    $('#atstop', pres).onclick = stop;
    BS.onLeave = stop;   // leaving My code stops the run
    const set = (sel, f) => { const e = $(sel, pres); if (e) f(e); };
    try {
      for (let i = 0; i < todo.length && !stopped; i++) {
        const L = todo[i];
        set('#atp', e => { e.textContent = `Testing ${i + 1} of ${todo.length}: ${L.title}`; });
        set('#atbar', e => { e.style.width = (100 * i / todo.length) + '%'; });
        const res = await BS.testRunner.run(BS.lessonJob(L, st.code[L.id].src, true));
        if (res.stopped) { stopped = true; break; }
        const r = BS.interpret(L, res);
        if (r.pass) passed++;
        else {
          failed.push(L);
          const e = r.error;
          const msg = e ? (e.kind === 'exception' ? e.full : e.kind === 'syntax' ? `${e.type} in ${e.chunk}, line ${e.line}: ${e.msg}` : e.msg || e.kind) : r.fails[0] || 'failed';
          set('#atfail', box => box.insertAdjacentHTML('beforeend', `<div class="res err"><b>${esc(L.title)}</b>: ${esc(msg)}</div>`));
        }
      }
    } finally {
      busy(false);
      if (BS.onLeave === stop) BS.onLeave = null;
    }
    set('#atbar', e => { e.style.width = '100%'; });
    set('#atstop', e => e.remove());
    set('#atp', e => { e.textContent = stopped ? `Stopped: ${passed} passed, ${failed.length} failed so far.` : `${failed.length ? '' : '✅ '}${passed} of ${todo.length} lessons pass with your own code for every earlier part.${failed.length ? ' A lesson can fail here when an earlier function of yours behaves a little differently from the course\'s.' : ''}`; });
    if (!stopped && !failed.length) BS.sound('complete');
  };
  $('#export', view).onclick = async () => { busy(true); try { await exportZip(pres); } finally { busy(false); } };
};

// ---------------- export the project as a .zip: bitscribe.py and everything it needs ----------------
async function exportZip(box) {
  const st = S(), A = BS.ASSETS;
  const coding = BS.LESSONS.filter(BS.isProject);
  const missing = coding.filter(L => !(st.done[L.id] && st.code[L.id]));
  if (box) box.innerHTML = '<div class="res info">Putting your program together…</div>';
  const mineL = coding.filter(L => st.done[L.id] && st.code[L.id]);
  let stripped = [];
  try {
    const r = await BS.testRunner.call('strip', { items: mineL.map(L => [st.code[L.id].src, L.items.includes('main')]) });
    stripped = r.texts || [];
  } catch (e) { stripped = []; }
  const textOf = new Map(mineL.map((L, i) => [L.id, stripped[i] != null ? stripped[i] : st.code[L.id].src]));
  let py = '"""BitScribe - a textbook writer powered by a 1.58-bit BitNet language model.\n\n' +
    'Written function by function in the BitScribe Python course. Exported ' + BS.today() + '.\n' +
    'Run it with:  python3 bitscribe.py --topic "Volcanoes" --pages 12\n' +
    'Settings are read from settings.txt (key = value) and from --key value options.\n' +
    'Lines marked "(tried out in the lesson)" were experiments: they are comments here.\n"""\n';
  if (missing.length) py += '\nraise SystemExit("This BitScribe program is not finished yet: ' + missing.length + ' lesson(s) are missing (see the MISSING notes). Finish them in the app, then export again.")\n';
  for (const L of coding) {
    py += `\n\n# ===== ${L.unitObj.title}: ${L.title} (${L.items.join(', ')}) =====\n`;
    if (textOf.has(L.id)) py += textOf.get(L.id).replace(/\s+$/, '') + '\n';
    else py += `# MISSING - write ${L.items.join(', ')} in the lesson "${L.title}".\n`;
  }
  const model = BS.modelBytes();
  const files = [
    { name: 'bitscribe/bitscribe.py', data: py, exec: true },
    { name: 'bitscribe/requirements.txt', data: 'numpy>=1.24\n' },
    { name: 'bitscribe/README.md', data: A.readme + (missing.length ? `\n\n## Not finished yet\n\n${missing.length} lesson(s) are still missing (marked MISSING in bitscribe.py). Finish them in the app, then export again.\n` : '') },
    { name: 'bitscribe/settings.txt', data: BS.settingsText(st.writer, true) },
    { name: 'bitscribe/convert.py', data: A.convertPy, exec: true },
    { name: 'bitscribe/models/tiny.bnet', data: model.bnet },
    { name: 'bitscribe/models/tiny.tok', data: model.tok },
    { name: 'bitscribe/models/README.txt', data: A.modelCard },
    { name: 'bitscribe/fonts/readme.txt', data: A.afmReadme },
    { name: 'bitscribe/fonts/NOTE.txt', data: A.fontsNote },
  ];
  for (const [nm, t] of Object.entries(BS.afmTexts())) files.push({ name: 'bitscribe/fonts/' + nm + '.afm', data: t });
  const blob = ZipWriter.make(files);
  if (box) box.innerHTML = `<div class="res ok"><h4>Project ready (${(blob.size / 1048576).toFixed(1)} MB)</h4>${missing.length ? `${missing.length} lesson(s) are still missing, so the exported program will not run yet.` : 'Unzip it, run <code>pip install numpy</code>, then <code>python3 bitscribe.py</code>. The README explains everything, including the 2-billion-weight BitNet model.'}</div>`;
  await BS.saveFile('bitscribe-python-project.zip', blob);
}
BS.exportZip = exportZip;
})();
