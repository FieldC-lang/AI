// Instructional diagrams for the lessons: turns "[DIAGRAM type: items ; caption]" into an SVG picture.
// The eight kinds of diagram that the program draws into PDFs (flow, cycle, steps, bars, plot, tree, venn, timeline),
// plus three for learning assembly: regs (registers), memory (bytes and words in memory) and stack.
(function (G) {
  const PAL = ['#d6e8ff', '#dbf5de', '#ffe8cc', '#ede0ff', '#fff4c7', '#dbf8f7'];
  const INK = '#33415c';
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function parse(line) {
    const m = /\[DIAGRAM\s+([a-zA-Z]+)\s*:([^\]]*)\]/.exec(line);
    if (!m) return null;
    const type = m[1].toLowerCase();
    let body = m[2], caption = '';
    const semi = body.indexOf(';');
    if (semi >= 0) { caption = body.slice(semi + 1).trim(); body = body.slice(0, semi); }
    let items;
    if (type === 'tree') {
      const gt = body.indexOf('>');
      if (gt < 0) return null;
      items = [body.slice(0, gt).trim()].concat(body.slice(gt + 1).split(/[,|]/).map(s => s.trim()).filter(Boolean));
    } else items = body.split('|').map(s => s.trim()).filter(Boolean);
    if (items.length < 2 && !(type === 'plot' && items.length === 1)) return null;
    return { type, items: items.slice(0, 12), caption };
  }

  // word-wrap text into at most `maxLines` lines that fit `maxw` pixels at font size `size`
  function wrap(text, maxw, size, maxLines) {
    const cw = size * 0.56;
    const words = String(text).split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = '';
    for (const w of words) {
      const t = cur ? cur + ' ' + w : w;
      if (t.length * cw <= maxw || !cur) cur = t;
      else { lines.push(cur); cur = w; }
    }
    if (cur) lines.push(cur);
    if (lines.length > maxLines) { lines.length = maxLines; lines[maxLines - 1] = lines[maxLines - 1].replace(/.{0,2}$/, '…'); }
    return lines.map(l => (l.length * cw > maxw ? l.slice(0, Math.max(1, Math.floor(maxw / cw) - 1)) + '…' : l));
  }
  function label(text, cx, cy, maxw, size, weight) {
    const lines = wrap(text, maxw, size, 3);
    const y0 = cy - (lines.length - 1) * size * 0.6 + size * 0.35;
    return lines.map((l, i) => `<text x="${cx}" y="${(y0 + i * size * 1.2).toFixed(1)}" text-anchor="middle" font-size="${size}" font-weight="${weight || 600}" fill="${INK}">${esc(l)}</text>`).join('');
  }
  const box = (x, y, w, h, i) => `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="9" fill="${PAL[((i % 6) + 6) % 6]}" stroke="${INK}" stroke-width="1.3"/>`;
  const arrow = (x1, y1, x2, y2) => {
    const a = Math.atan2(y2 - y1, x2 - x1), bx = x2 - 8 * Math.cos(a), by = y2 - 8 * Math.sin(a);
    return `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${bx.toFixed(1)}" y2="${by.toFixed(1)}" stroke="${INK}" stroke-width="1.6"/>` +
      `<polygon points="${x2.toFixed(1)},${y2.toFixed(1)} ${(bx + 4 * Math.sin(a)).toFixed(1)},${(by - 4 * Math.cos(a)).toFixed(1)} ${(bx - 4 * Math.sin(a)).toFixed(1)},${(by + 4 * Math.cos(a)).toFixed(1)}" fill="${INK}"/>`;
  };

  // tiny formula evaluator for plots (same grammar as the C course's eval_expr)
  function evalExpr(s, x) {
    let i = 0;
    const skip = () => { while (s[i] === ' ') i++; };
    const fail = () => { throw new Error('bad formula'); };
    function atom() {
      skip();
      if (s[i] === '(') { i++; const v = sum(); skip(); if (s[i] !== ')') fail(); i++; return v; }
      const num = /^(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?/.exec(s.slice(i));
      if (num) { i += num[0].length; return parseFloat(num[0]); }
      const nm = /^[a-zA-Z]+/.exec(s.slice(i));
      if (!nm) fail();
      i += nm[0].length;
      const n = nm[0];
      if (n === 'x') return x;
      if (n === 'pi') return Math.PI;
      if (n === 'e') return Math.E;
      const f = { sin: Math.sin, cos: Math.cos, tan: Math.tan, sqrt: Math.sqrt, abs: Math.abs, exp: Math.exp, log: Math.log, ln: Math.log }[n];
      if (!f) fail();
      return f(atom());
    }
    function power() { skip(); if (s[i] === '-') { i++; return -power(); } const b = atom(); skip(); if (s[i] === '^') { i++; return Math.pow(b, power()); } return b; }
    function product() {
      let v = power();
      for (;;) {
        skip();
        if (s[i] === '*') { i++; v *= power(); } else if (s[i] === '/') { i++; v /= power(); }
        else if (s[i] === '(' || /[a-zA-Z0-9.]/.test(s[i] || '')) v *= power();
        else return v;
      }
    }
    function sum() { let v = product(); for (;;) { skip(); if (s[i] === '+') { i++; v += product(); } else if (s[i] === '-') { i++; v -= product(); } else return v; } }
    const v = sum(); skip(); if (i < s.length) fail(); return v;
  }

  function render(d, W) {
    W = W || 560;
    const it = d.items, n = it.length;
    let h = 0, g = '';
    if (d.type === 'flow') {
      const cols = n > 4 ? Math.ceil(n / 2) : n, rows = Math.ceil(n / cols), gap = 30, bh = 58;
      const bw = Math.min(160, (W - 20 - gap * (cols - 1)) / cols), total = bw * cols + gap * (cols - 1), x0 = (W - total) / 2;
      const pos = (k) => { const row = Math.floor(k / cols); let col = k % cols; if (row % 2) col = cols - 1 - col; return [x0 + col * (bw + gap), 10 + row * (bh + 34), row]; };
      for (let k = 0; k < n; k++) { const [x, y] = pos(k); g += box(x, y, bw, bh, k) + label(it[k], x + bw / 2, y + bh / 2, bw - 12, 12.5); }
      for (let k = 0; k + 1 < n; k++) {
        const [x, y, r] = pos(k), [x2, y2, r2] = pos(k + 1);
        if (r === r2) g += x2 > x ? arrow(x + bw + 2, y + bh / 2, x2 - 2, y + bh / 2) : arrow(x - 2, y + bh / 2, x2 + bw + 2, y + bh / 2);
        else g += arrow(x + bw / 2, y + bh + 2, x2 + bw / 2, y2 - 2);
      }
      h = 20 + rows * bh + (rows - 1) * 34;
    } else if (d.type === 'cycle') {
      const cx = W / 2, cy = 150, R = 105, bw = 128, bh = 44;
      const ang = (k) => Math.PI / 2 - 2 * Math.PI * k / n;
      for (let k = 0; k < n; k++) {
        const a1 = ang(k), a2 = ang((k + 1) % n), am = k === n - 1 ? a1 - Math.PI / n : (a1 + a2) / 2, r2 = R * 0.62;
        const p1 = [cx + r2 * 1.5 * Math.cos(am + 0.33), cy - r2 * Math.sin(am + 0.33)], p2 = [cx + r2 * 1.5 * Math.cos(am - 0.33), cy - r2 * Math.sin(am - 0.33)];
        g += arrow(p1[0], p1[1], p2[0], p2[1]);
      }
      for (let k = 0; k < n; k++) {
        const a = ang(k), x = cx + R * 1.5 * Math.cos(a), y = cy - R * Math.sin(a);
        g += box(x - bw / 2, y - bh / 2, bw, bh, k) + label(it[k], x, y, bw - 10, 11.5);
      }
      h = 300;
    } else if (d.type === 'steps') {
      let y = 26;
      for (let k = 0; k < n; k++) {
        if (k + 1 < n) g += `<line x1="34" y1="${y + 14}" x2="34" y2="${y + 30}" stroke="#9aaccc" stroke-width="2.5"/>`;
        g += `<circle cx="34" cy="${y}" r="14" fill="${PAL[k % 6]}" stroke="${INK}" stroke-width="1.3"/>` + `<text x="34" y="${y + 5}" text-anchor="middle" font-size="13" font-weight="800" fill="${INK}">${k + 1}</text>`;
        const lines = wrap(it[k], W - 80, 13.5, 2);
        g += lines.map((l, j) => `<text x="58" y="${y + 5 + j * 16 - (lines.length - 1) * 8}" font-size="13.5" fill="${INK}">${esc(l)}</text>`).join('');
        y += 44;
      }
      h = y - 12;
    } else if (d.type === 'bars') {
      const data = it.map(s => { const e = s.lastIndexOf('='); return e < 0 ? null : { name: s.slice(0, e).trim(), v: parseFloat(s.slice(e + 1)) || 0 }; }).filter(Boolean);
      if (!data.length) return null;
      const vmax = Math.max(1e-9, ...data.map(b => b.v)), left = 40, bottom = 200, height = 170, width = W - 60, slot = width / data.length, bw = slot * 0.6;
      g += `<path d="M${left} ${bottom - height - 6} V${bottom} H${left + width}" fill="none" stroke="${INK}" stroke-width="1.3"/>`;
      data.forEach((b, k) => {
        const bh = Math.max(0, b.v / vmax * height), x = left + k * slot + (slot - bw) / 2;
        g += `<rect x="${x.toFixed(1)}" y="${(bottom - bh).toFixed(1)}" width="${bw.toFixed(1)}" height="${bh.toFixed(1)}" fill="${PAL[k % 6]}" stroke="${INK}"/>`;
        g += label(String(b.v), x + bw / 2, bottom - bh - 10, slot, 11, 700) + label(b.name, x + bw / 2, bottom + 15, slot - 4, 11, 600);
      });
      h = 230;
    } else if (d.type === 'plot') {
      let f = 'x', x0 = -5, x1 = 5;
      for (const s of it) {
        if (/^y/.test(s) && s.includes('=')) f = s.slice(s.indexOf('=') + 1).trim();
        else if (/^x/.test(s) && s.includes('=')) { const m = /(-?[\d.]+)\s*\.\.\s*(-?[\d.]+)/.exec(s); if (m && +m[2] > +m[1]) { x0 = +m[1]; x1 = +m[2]; } }
      }
      const pts = [];
      let ymin = Infinity, ymax = -Infinity;
      for (let k = 0; k <= 120; k++) {
        const x = x0 + (x1 - x0) * k / 120;
        let y; try { y = evalExpr(f, x); } catch (e) { return null; }
        if (!isFinite(y) || Math.abs(y) > 1e12) { pts.push(null); continue; }
        pts.push([x, y]); ymin = Math.min(ymin, y); ymax = Math.max(ymax, y);
      }
      if (!isFinite(ymin)) return null;
      if (ymax - ymin < 1e-9) { ymin -= 1; ymax += 1; }
      const L = 56, T = 14, Wd = W - 80, Hd = 180;
      const sx = (x) => L + (x - x0) / (x1 - x0) * Wd, sy = (y) => T + Hd - (y - ymin) / (ymax - ymin) * Hd;
      g += `<rect x="${L}" y="${T}" width="${Wd}" height="${Hd}" fill="none" stroke="#d5dbe6"/>`;
      if (ymin <= 0 && ymax >= 0) g += `<line x1="${L}" x2="${L + Wd}" y1="${sy(0)}" y2="${sy(0)}" stroke="#7a8599"/>`;
      if (x0 <= 0 && x1 >= 0) g += `<line y1="${T}" y2="${T + Hd}" x1="${sx(0)}" x2="${sx(0)}" stroke="#7a8599"/>`;
      let dpath = '', pen = false;
      for (const p of pts) { if (!p) { pen = false; continue; } dpath += (pen ? 'L' : 'M') + sx(p[0]).toFixed(1) + ' ' + sy(p[1]).toFixed(1) + ' '; pen = true; }
      g += `<path d="${dpath}" fill="none" stroke="#2563eb" stroke-width="2.4"/>`;
      const fmt = (v) => (Math.abs(v) >= 1000 || (Math.abs(v) < 0.01 && v !== 0) ? v.toExponential(1) : +v.toPrecision(3));
      g += `<text x="${L}" y="${T + Hd + 15}" font-size="11" fill="${INK}" text-anchor="middle">${fmt(x0)}</text><text x="${L + Wd}" y="${T + Hd + 15}" font-size="11" fill="${INK}" text-anchor="middle">${fmt(x1)}</text>`;
      g += `<text x="${L - 6}" y="${T + 4}" font-size="11" fill="${INK}" text-anchor="end">${fmt(ymax)}</text><text x="${L - 6}" y="${T + Hd}" font-size="11" fill="${INK}" text-anchor="end">${fmt(ymin)}</text>`;
      g += `<text x="${L + Wd / 2}" y="${T + 16}" font-size="13" font-weight="700" fill="#2563eb" text-anchor="middle">y = ${esc(f)}</text>`;
      h = T + Hd + 24;
    } else if (d.type === 'tree') {
      const kids = it.slice(1, 7), rw = 190, rh = 44, rx = (W - rw) / 2, ry = 8;
      const gap = 12, cw = Math.min(150, (W - gap * (kids.length - 1)) / kids.length), total = cw * kids.length + gap * (kids.length - 1), cx0 = (W - total) / 2, cy = ry + rh + 50;
      kids.forEach((k, j) => { const mx = cx0 + j * (cw + gap) + cw / 2; g += `<path d="M${W / 2} ${ry + rh} V${ry + rh + 25} H${mx} V${cy}" fill="none" stroke="#7a8599" stroke-width="1.4"/>`; });
      g += box(rx, ry, rw, rh, 0) + label(it[0], W / 2, ry + rh / 2, rw - 12, 14, 800);
      kids.forEach((k, j) => { const x = cx0 + j * (cw + gap); g += box(x, cy, cw, 48, j + 1) + label(k, x + cw / 2, cy + 24, cw - 10, 11.5); });
      h = cy + 56;
    } else if (d.type === 'venn') {
      const cx = W / 2, cy = 105, r = 92;
      g += `<circle cx="${cx - 58}" cy="${cy}" r="${r}" fill="${PAL[0]}" fill-opacity="0.85" stroke="${INK}"/><circle cx="${cx + 58}" cy="${cy}" r="${r}" fill="${PAL[2]}" fill-opacity="0.7" stroke="${INK}"/>`;
      g += label(it[0], cx - 100, cy, 84, 13, 800) + label(it[1], cx + 100, cy, 84, 13, 800);
      if (it[2]) g += label(it[2], cx, cy, 56, 11, 600);
      h = 212;
    } else if (d.type === 'timeline') {
      const y = 70, left = 24, right = W - 24;
      g += arrow(left, y, right, y);
      it.forEach((s, k) => {
        const tx = n === 1 ? (left + right) / 2 : left + 24 + (right - left - 60) * k / (n - 1);
        const e = s.indexOf('='), when = e < 0 ? '' : s.slice(0, e).trim(), what = e < 0 ? s : s.slice(e + 1).trim();
        g += `<circle cx="${tx}" cy="${y}" r="7" fill="${PAL[k % 6]}" stroke="${INK}"/>`;
        if (when) g += label(when, tx, y - 22, 90, 12.5, 800);
        g += label(what, tx, y + 30, (right - left) / n - 6, 11, 600);
      });
      h = 130;
    } else if (d.type === 'regs') {
      // processor registers as a row of boxes: "r1 = 17" puts 17 inside the box named r1
      const cols = Math.min(n, 6), rows = Math.ceil(n / cols), gap = 10, bw = Math.min(118, (W - 16 - gap * (cols - 1)) / cols), bh = 56;
      const x0 = (W - (bw * cols + gap * (cols - 1))) / 2;
      it.forEach((s, k) => {
        const e = s.indexOf('='), name = e < 0 ? s : s.slice(0, e).trim(), val = e < 0 ? '' : s.slice(e + 1).trim();
        const x = x0 + (k % cols) * (bw + gap), y = 8 + Math.floor(k / cols) * (bh + 12);
        g += `<rect x="${x.toFixed(1)}" y="${y}" width="${bw.toFixed(1)}" height="${bh}" rx="8" fill="#eef3fb" stroke="${INK}" stroke-width="1.3"/>`;
        g += `<rect x="${x.toFixed(1)}" y="${y}" width="${bw.toFixed(1)}" height="20" rx="8" fill="${PAL[k % 6]}" stroke="${INK}" stroke-width="1.3"/>`;
        g += label(name, x + bw / 2, y + 10, bw - 8, 11.5, 800);
        g += val ? label(val, x + bw / 2, y + 38, bw - 8, 13, 700).replace(/font-size="13"/g, 'font-size="13" font-family="JetBrains Mono, monospace"') : '';
      });
      h = 16 + rows * bh + (rows - 1) * 12;
    } else if (d.type === 'memory') {
      // memory cells side by side: "nums+4 = 20" is the cell at address nums+4 holding 20
      const cols = Math.min(n, 6), rows = Math.ceil(n / cols), bw = Math.min(110, (W - 20) / cols), bh = 40;
      const x0 = (W - bw * cols) / 2;
      it.forEach((s, k) => {
        const e = s.indexOf('='), addr = e < 0 ? '' : s.slice(0, e).trim(), val = e < 0 ? s : s.slice(e + 1).trim();
        const x = x0 + (k % cols) * bw, y = 8 + Math.floor(k / cols) * (bh + 34);
        g += `<rect x="${x.toFixed(1)}" y="${y}" width="${bw.toFixed(1)}" height="${bh}" fill="${PAL[k % 6]}" stroke="${INK}" stroke-width="1.3"/>`;
        g += label(val, x + bw / 2, y + bh / 2, bw - 8, 12.5, 700);
        if (addr) g += label(addr, x + bw / 2, y + bh + 13, bw - 4, 11, 600).replace(/fill="#33415c"/g, 'fill="#5b6478"');
      });
      g += `<text x="${x0 - 6}" y="${8 + bh / 2 + 4}" font-size="11" text-anchor="end" fill="#5b6478">low</text><text x="${x0 + bw * cols + 6}" y="${8 + bh / 2 + 4}" font-size="11" fill="#5b6478">high</text>`;
      h = 8 + rows * (bh + 34) - 12;
    } else if (d.type === 'stack') {
      // the stack, higher addresses at the top; sp points at the last item
      const bw = Math.min(300, W - 150), bh = 34, x = (W - bw) / 2 + 20;
      g += `<text x="${x + bw / 2}" y="14" text-anchor="middle" font-size="11" fill="#5b6478">higher addresses</text>`;
      it.forEach((s, k) => {
        const y = 22 + k * bh;
        g += `<rect x="${x}" y="${y}" width="${bw}" height="${bh}" fill="${PAL[k % 6]}" stroke="${INK}" stroke-width="1.3"/>` + label(s, x + bw / 2, y + bh / 2, bw - 12, 12.5, 650);
      });
      const yl = 22 + (n - 1) * bh + bh / 2;
      g += `<text x="${x - 46}" y="${yl + 4}" font-size="13" font-weight="800" fill="#2563eb" text-anchor="end">sp</text>` + arrow(x - 42, yl, x - 3, yl);
      g += `<text x="${x + bw / 2}" y="${22 + n * bh + 15}" text-anchor="middle" font-size="11" fill="#5b6478">lower addresses (the stack grows this way)</text>`;
      h = 22 + n * bh + 20;
    } else return null;
    const capH = d.caption ? 26 : 4;
    return `<svg class="diagram" viewBox="0 0 ${W} ${h + capH}" role="img" aria-label="${esc(d.caption || d.type + ' diagram')}" xmlns="http://www.w3.org/2000/svg" font-family="Nunito, system-ui, sans-serif">${g}` +
      (d.caption ? `<text x="${W / 2}" y="${h + 18}" text-anchor="middle" font-size="12.5" font-style="italic" fill="#5b6478">${esc(d.caption)}</text>` : '') + '</svg>';
  }
  G.Diagrams = { parse, render, evalExpr };
})(typeof window !== 'undefined' ? window : globalThis);
